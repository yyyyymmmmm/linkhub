/**
 * 子页面通用JavaScript功能
 */

// 导入主JS功能
// 这里可以复用主页面的一些功能

// 页面通用初始化
document.addEventListener('DOMContentLoaded', function() {
    initCommonFeatures();
    initPageSpecific();
});

// 通用功能初始化
function initCommonFeatures() {
    initNavigation();
    initScrollEffects(); 
    initCodeBlocks();
    initTabs();
    initAccordion();
}

// 页面特定初始化（子页面可以覆盖）
function initPageSpecific() {
    // 子页面特定功能在各自页面中实现
}

// 导航功能（简化版）
function initNavigation() {
    const header = document.querySelector('.header');
    const navToggle = document.querySelector('.nav__toggle');
    const navMenu = document.querySelector('.nav__menu');

    if (!header) return;

    // 滚动效果
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // 移动端菜单
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            const icon = navToggle.querySelector('i');
            if (navMenu.classList.contains('active')) {
                icon.className = 'fas fa-times';
            } else {
                icon.className = 'fas fa-bars';
            }
        });
    }
}

// 滚动效果
function initScrollEffects() {
    // 返回顶部按钮
    const backToTop = document.querySelector('.back-to-top');
    if (backToTop) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTop.classList.add('show');
            } else {
                backToTop.classList.remove('show');
            }
        });

        backToTop.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // 侧边栏导航高亮
    initSidebarHighlight();
}

// 侧边栏导航高亮
function initSidebarHighlight() {
    const sidebarLinks = document.querySelectorAll('.sidebar-nav a[href^="#"]');
    if (sidebarLinks.length === 0) return;

    function highlightCurrentSection() {
        const sections = document.querySelectorAll('section[id], h2[id], h3[id]');
        const scrollPos = window.scrollY + 100;

        let currentSection = null;
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (scrollPos >= sectionTop) {
                currentSection = section.id;
            }
        });

        sidebarLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === `#${currentSection}`) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    window.addEventListener('scroll', throttle(highlightCurrentSection, 100));
    highlightCurrentSection(); // 初始检查
}

// 代码块功能
function initCodeBlocks() {
    const codeBlocks = document.querySelectorAll('pre code');
    
    codeBlocks.forEach(block => {
        // 添加复制按钮
        const pre = block.parentElement;
        const copyBtn = document.createElement('button');
        copyBtn.className = 'copy-code-btn';
        copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
        copyBtn.title = '复制代码';
        
        copyBtn.addEventListener('click', () => {
            copyToClipboard(block.textContent);
            copyBtn.innerHTML = '<i class="fas fa-check"></i>';
            copyBtn.style.color = '#10b981';
            
            setTimeout(() => {
                copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
                copyBtn.style.color = '';
            }, 2000);
        });

        pre.style.position = 'relative';
        pre.appendChild(copyBtn);
    });
}

// 复制到剪贴板
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification('代码已复制到剪贴板', 'success');
        });
    } else {
        // 降级方案
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        document.body.appendChild(textArea);
        textArea.select();
        
        try {
            document.execCommand('copy');
            showNotification('代码已复制到剪贴板', 'success');
        } catch (err) {
            showNotification('复制失败，请手动复制', 'error');
        }
        
        document.body.removeChild(textArea);
    }
}

// 标签页功能
function initTabs() {
    const tabContainers = document.querySelectorAll('.tabs');
    
    tabContainers.forEach(container => {
        const tabButtons = container.querySelectorAll('.tab-btn');
        const tabPanes = container.querySelectorAll('.tab-pane');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const target = button.dataset.tab;
                
                // 移除所有活跃状态
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanes.forEach(pane => pane.classList.remove('active'));
                
                // 激活当前标签
                button.classList.add('active');
                const targetPane = container.querySelector(`[data-tab-content="${target}"]`);
                if (targetPane) {
                    targetPane.classList.add('active');
                }
            });
        });
    });
}

// 手风琴功能
function initAccordion() {
    const accordions = document.querySelectorAll('.accordion');
    
    accordions.forEach(accordion => {
        const items = accordion.querySelectorAll('.accordion-item');
        
        items.forEach(item => {
            const header = item.querySelector('.accordion-header');
            const content = item.querySelector('.accordion-content');
            
            if (header && content) {
                header.addEventListener('click', () => {
                    const isActive = item.classList.contains('active');
                    
                    // 关闭其他项目（如果需要单选模式）
                    if (accordion.dataset.single === 'true') {
                        items.forEach(otherItem => {
                            if (otherItem !== item) {
                                otherItem.classList.remove('active');
                                const otherContent = otherItem.querySelector('.accordion-content');
                                if (otherContent) {
                                    otherContent.style.maxHeight = null;
                                }
                            }
                        });
                    }
                    
                    // 切换当前项目
                    if (isActive) {
                        item.classList.remove('active');
                        content.style.maxHeight = null;
                    } else {
                        item.classList.add('active');
                        content.style.maxHeight = content.scrollHeight + 'px';
                    }
                });
            }
        });
    });
}

// 通知功能
function showNotification(message, type = 'info', duration = 3000) {
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#6366f1'
    };
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        background: ${colors[type] || colors.info};
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        transform: translateX(100%);
        transition: transform 0.3s ease-in-out;
        font-size: 14px;
        font-weight: 500;
        max-width: 300px;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.style.transform = 'translateX(0)', 100);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => document.body.removeChild(notification), 300);
    }, duration);
}

// 工具函数：节流
function throttle(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 工具函数：防抖
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 添加复制按钮样式
const copyButtonStyle = document.createElement('style');
copyButtonStyle.textContent = `
    .copy-code-btn {
        position: absolute;
        top: 12px;
        right: 12px;
        background: rgba(255, 255, 255, 0.1);
        border: none;
        color: #9ca3af;
        padding: 6px 8px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
        transition: all 0.2s;
    }
    
    .copy-code-btn:hover {
        background: rgba(255, 255, 255, 0.2);
        color: #fff;
    }
    
    /* 标签页样式 */
    .tabs {
        margin: 20px 0;
    }
    
    .tab-buttons {
        display: flex;
        border-bottom: 2px solid #e5e7eb;
        margin-bottom: 20px;
    }
    
    .tab-btn {
        padding: 10px 20px;
        background: none;
        border: none;
        cursor: pointer;
        font-weight: 500;
        color: #6b7280;
        transition: all 0.2s;
        border-bottom: 2px solid transparent;
    }
    
    .tab-btn.active {
        color: #6366f1;
        border-bottom-color: #6366f1;
    }
    
    .tab-pane {
        display: none;
    }
    
    .tab-pane.active {
        display: block;
    }
    
    /* 手风琴样式 */
    .accordion-item {
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        margin-bottom: 8px;
        overflow: hidden;
    }
    
    .accordion-header {
        padding: 16px;
        background: #f9fafb;
        cursor: pointer;
        font-weight: 600;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background-color 0.2s;
    }
    
    .accordion-header:hover {
        background: #f3f4f6;
    }
    
    .accordion-header::after {
        content: '+';
        font-size: 18px;
        transition: transform 0.2s;
    }
    
    .accordion-item.active .accordion-header::after {
        transform: rotate(45deg);
    }
    
    .accordion-content {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
    }
    
    .accordion-content-inner {
        padding: 16px;
    }
`;
document.head.appendChild(copyButtonStyle);

// 导出常用功能
window.CommonUtils = {
    showNotification,
    copyToClipboard,
    throttle,
    debounce
};


