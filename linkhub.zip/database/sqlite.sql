-- LinkHub SQLite Database Schema

-- 分类表
CREATE TABLE IF NOT EXISTS "on_categorys" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "fid" INTEGER DEFAULT 0,
    "property" INTEGER DEFAULT 0,
    "weight" INTEGER DEFAULT 0,
    "description" TEXT,
    "font_icon" TEXT,
    "icon_color" TEXT DEFAULT '#6366f1',
    "add_time" INTEGER DEFAULT 0,
    "up_time" INTEGER DEFAULT 0
);

-- 链接表
CREATE TABLE IF NOT EXISTS "on_links" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "fid" INTEGER DEFAULT 0,
    "title" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "url_standby" TEXT,
    "note" TEXT,
    "font_icon" TEXT,
    "icon" TEXT,
    "icon_url" TEXT,
    "icon_color" TEXT DEFAULT '#6b7280',
    "icon_type" TEXT DEFAULT 'fa',
    "property" INTEGER DEFAULT 0,
    "weight" INTEGER DEFAULT 0,
    "add_time" INTEGER DEFAULT 0,
    "up_time" INTEGER DEFAULT 0,
    "click" INTEGER DEFAULT 0
);

-- 用户表
CREATE TABLE IF NOT EXISTS "on_users" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "username" TEXT NOT NULL UNIQUE,
    "password" TEXT NOT NULL,
    "email" TEXT,
    "role" INTEGER DEFAULT 1,
    "status" INTEGER DEFAULT 1,
    "add_time" INTEGER DEFAULT 0,
    "last_login" INTEGER DEFAULT 0
);

-- 设置表
CREATE TABLE IF NOT EXISTS "on_settings" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "key" TEXT NOT NULL UNIQUE,
    "value" TEXT,
    "description" TEXT,
    "group_name" TEXT DEFAULT 'site'
);

-- 点击统计表
CREATE TABLE IF NOT EXISTS "on_clicks" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "link_id" INTEGER NOT NULL,
    "ip" TEXT,
    "user_agent" TEXT,
    "referer" TEXT,
    "click_time" INTEGER DEFAULT 0
);

-- 创建索引
CREATE INDEX IF NOT EXISTS "idx_categorys_fid" ON "on_categorys" ("fid");
CREATE INDEX IF NOT EXISTS "idx_categorys_weight" ON "on_categorys" ("weight");
CREATE INDEX IF NOT EXISTS "idx_links_fid" ON "on_links" ("fid");
CREATE INDEX IF NOT EXISTS "idx_links_weight" ON "on_links" ("weight");
CREATE INDEX IF NOT EXISTS "idx_clicks_link_id" ON "on_clicks" ("link_id");
CREATE INDEX IF NOT EXISTS "idx_clicks_time" ON "on_clicks" ("click_time");

-- 插入默认数据
INSERT OR IGNORE INTO "on_settings" ("key", "value", "description", "group_name") VALUES
('site_name', 'LinkHub', '网站名称', 'site'),
('site_subtitle', '简洁高效的网址导航系统', '网站副标题', 'site'),
('site_keywords', 'LinkHub,书签,导航,网址导航', '网站关键词', 'site'),
('site_description', 'LinkHub - 简洁高效的网址导航系统', '网站描述', 'site'),
('site_icp', '', '备案号', 'site'),
('site_statistics', '', '统计代码', 'site'),
('default_theme', 'default', '默认主题', 'theme'),
('enable_register', '0', '是否开启注册', 'user'),
('enable_public_links', '1', '是否显示公开链接', 'site'),
('links_per_page', '20', '每页链接数', 'site');

-- 插入默认分类
INSERT OR IGNORE INTO "on_categorys" ("id", "name", "fid", "property", "weight", "description", "font_icon", "add_time") VALUES
(1, '常用网站', 0, 0, 100, '日常使用的常用网站', 'fa-star', strftime('%s', 'now')),
(2, '开发工具', 0, 0, 90, '开发相关的工具和资源', 'fa-code', strftime('%s', 'now')),
(3, '学习资源', 0, 0, 80, '学习和教育相关网站', 'fa-book', strftime('%s', 'now')),
(4, '娱乐休闲', 0, 0, 70, '娱乐和休闲网站', 'fa-gamepad', strftime('%s', 'now'));

-- 插入默认链接
INSERT OR IGNORE INTO "on_links" ("id", "fid", "title", "url", "note", "font_icon", "property", "weight", "add_time") VALUES
(1, 1, 'Google', 'https://www.google.com', '全球最大的搜索引擎', 'fa-search', 0, 100, strftime('%s', 'now')),
(2, 1, 'GitHub', 'https://github.com', '全球最大的代码托管平台', 'fa-github', 0, 90, strftime('%s', 'now')),
(3, 1, 'YouTube', 'https://www.youtube.com', '全球最大的视频分享平台', 'fa-youtube', 0, 80, strftime('%s', 'now')),
(4, 2, 'Visual Studio Code', 'https://code.visualstudio.com', '微软开发的免费代码编辑器', 'fa-code', 0, 100, strftime('%s', 'now')),
(5, 2, 'Docker', 'https://www.docker.com', '容器化平台', 'fa-docker', 0, 90, strftime('%s', 'now')),
(6, 3, 'MDN Web Docs', 'https://developer.mozilla.org', 'Web开发者文档', 'fa-book', 0, 100, strftime('%s', 'now')),
(7, 3, 'Stack Overflow', 'https://stackoverflow.com', '程序员问答社区', 'fa-stack-overflow', 0, 90, strftime('%s', 'now'));