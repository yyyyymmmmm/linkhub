-- OneNav Professional MySQL数据库结构
-- 创建用户表
CREATE TABLE IF NOT EXISTS `on_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `token` varchar(255) DEFAULT NULL COMMENT 'API Token',
  `token_expire` int(11) DEFAULT NULL COMMENT 'Token过期时间',
  `role` tinyint(4) NOT NULL DEFAULT '1' COMMENT '角色:1管理员,2普通用户',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态:1正常,0禁用',
  `add_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `last_login_at` int(11) DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(45) DEFAULT NULL COMMENT '最后登录IP',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 创建分类表
CREATE TABLE IF NOT EXISTS `on_categorys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `fid` int(11) NOT NULL DEFAULT '0' COMMENT '父分类ID',
  `property` tinyint(4) NOT NULL DEFAULT '0' COMMENT '属性:0公开,1私有',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT '权重(排序)',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `font_icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `icon_color` varchar(7) DEFAULT '#6366f1' COMMENT '图标颜色',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `up_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `fid` (`fid`),
  KEY `property` (`property`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分类表';

-- 创建链接表
CREATE TABLE IF NOT EXISTS `on_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL COMMENT '分类ID',
  `title` varchar(100) NOT NULL COMMENT '链接标题',
  `url` varchar(1000) NOT NULL COMMENT 'URL地址',
  `url_standby` varchar(1000) DEFAULT NULL COMMENT '备用URL',
  `note` varchar(500) DEFAULT NULL COMMENT '备注',
  `font_icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标样式',
  `icon_url` varchar(500) DEFAULT NULL COMMENT '图标URL',
  `icon_color` varchar(20) DEFAULT '#6b7280' COMMENT '图标颜色',
  `icon_type` varchar(20) DEFAULT 'fa' COMMENT '图标类型',
  `property` tinyint(4) NOT NULL DEFAULT '0' COMMENT '属性:0公开,1私有',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT '权重(排序)',
  `click` int(11) NOT NULL DEFAULT '0' COMMENT '点击次数',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `up_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `fid` (`fid`),
  KEY `property` (`property`),
  KEY `weight` (`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='链接表';

-- 创建点击统计表
CREATE TABLE IF NOT EXISTS `on_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_id` int(11) NOT NULL COMMENT '链接ID',
  `ip` varchar(45) DEFAULT NULL COMMENT '访问者IP',
  `user_agent` varchar(255) DEFAULT NULL COMMENT '用户代理',
  `referer` varchar(255) DEFAULT NULL COMMENT '来源页面',
  `click_time` int(11) NOT NULL COMMENT '点击时间',
  PRIMARY KEY (`id`),
  KEY `link_id` (`link_id`),
  KEY `click_time` (`click_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='点击统计表';

-- 创建设置表
CREATE TABLE IF NOT EXISTS `on_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL COMMENT '键名',
  `value` text NOT NULL COMMENT '键值',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `group_name` varchar(50) DEFAULT 'site' COMMENT '分组',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设置表';

-- 创建分享表
CREATE TABLE IF NOT EXISTS `on_shares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(32) NOT NULL COMMENT '分享ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `title` varchar(100) NOT NULL COMMENT '分享标题',
  `description` varchar(255) DEFAULT NULL COMMENT '分享描述',
  `views` int(11) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `expire_time` int(11) DEFAULT NULL COMMENT '过期时间',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  `up_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分享表';

-- 创建分享链接关联表
CREATE TABLE IF NOT EXISTS `on_share_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `share_id` int(11) NOT NULL COMMENT '分享ID',
  `link_id` int(11) NOT NULL COMMENT '链接ID',
  PRIMARY KEY (`id`),
  KEY `share_id` (`share_id`),
  KEY `link_id` (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分享链接关联表';

-- 创建标签表
CREATE TABLE IF NOT EXISTS `on_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '标签名称',
  `color` varchar(20) DEFAULT NULL COMMENT '标签颜色',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标签表';

-- 创建链接标签关联表
CREATE TABLE IF NOT EXISTS `on_link_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_id` int(11) NOT NULL COMMENT '链接ID',
  `tag_id` int(11) NOT NULL COMMENT '标签ID',
  PRIMARY KEY (`id`),
  KEY `link_id` (`link_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='链接标签关联表';

-- 创建备份表
CREATE TABLE IF NOT EXISTS `on_backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL COMMENT '文件名',
  `size` int(11) NOT NULL COMMENT '文件大小',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='备份表';

-- 插入默认设置
INSERT INTO `on_settings` (`key`, `value`, `description`, `group_name`) VALUES
('site_name', 'LinkHub', '站点名称', 'site'),
('site_subtitle', '简洁高效的网址导航系统', '站点副标题', 'site'),
('site_description', '简洁高效的网址导航系统', '站点描述', 'site'),
('site_keywords', 'LinkHub,导航,书签管理,网址导航', '站点关键词', 'site'),
('site_icp', '', '备案信息', 'site'),
('site_statistics', '', '统计代码', 'site'),
('theme', 'default', '当前主题', 'theme'),
('admin_theme', 'admin', '后台主题', 'theme'),
('mobile_theme', 'default', '移动端主题', 'theme'),
('custom_header', '', '自定义头部代码', 'site'),
('custom_footer', '', '自定义底部代码', 'site'),
('link_model', 'click', '链接打开模式', 'site'),
('enable_public_links', '1', '是否显示公开链接', 'site'),
('enable_register', '0', '是否开启注册', 'user'),
('enable_transition_page', '0', '启用过渡页', 'transition'),
('transition_time', '3', '过渡时间（秒）', 'transition'),
('transition_theme_color', '#6366f1', '过渡页主题色', 'transition'),
('transition_title', '正在跳转中...', '过渡页标题', 'transition'),
('transition_message', '即将为您跳转到目标网站，请稍候...', '过渡页消息', 'transition'),
('transition_ad_code', '', '过渡页广告代码', 'transition'),
('transition_show_progress', '1', '显示进度条', 'transition'),
('transition_allow_skip', '1', '允许跳过', 'transition'),
('version', '2.0.0', '系统版本', 'system');


