<?php

declare(strict_types=1);

namespace LinkHub\Core\Container;

/**
 * 容器接口
 * 
 * 基于PSR-11标准，但不依赖外部包
 */
interface ContainerInterface
{
    /**
     * 从容器中获取实例
     *
     * @param string $id 标识�?     * @return mixed 实例
     * @throws NotFoundException 当没有找到标识符对应的实例时抛出
     * @throws ContainerException 当获取实例时发生错误时抛�?     */
    public function get(string $id);
    
    /**
     * 检查容器中是否存在标识符对应的实例
     *
     * @param string $id 标识�?     * @return bool
     */
    public function has(string $id);
}
