<?php

declare(strict_types=1);

namespace LinkHub\Core\Container\Exceptions;

/**
 * 未找到异�? */
class NotFoundException extends ContainerException
{
}
