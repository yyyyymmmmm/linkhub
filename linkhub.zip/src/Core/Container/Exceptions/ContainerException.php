<?php

declare(strict_types=1);

namespace LinkHub\Core\Container\Exceptions;

/**
 * 容器异常
 */
class ContainerException extends \Exception
{
}
