<?php

declare(strict_types=1);

namespace LinkHub\Core\Container;

use LinkHub\Core\Container\Exceptions\ContainerException;
use LinkHub\Core\Container\Exceptions\NotFoundException;
use ReflectionClass;
use ReflectionParameter;
use ReflectionException;

/**
 * 容器实现
 */
class Container implements ContainerInterface
{
    /**
     * @var array 绑定
     */
    protected \$bindings = [];
    
    /**
     * @var array 实例
     */
    protected \$instances = [];
    
    /**
     * @var array 别名
     */
    protected \$aliases = [];
    
    /**
     * 绑定接口到实�?     */
    public function bind(string $abstract, $concrete = null, bool $shared = false)
    {
        // 移除旧的实例
        $this->dropStaleInstances($abstract);
        
        // 如果没有指定实现，则使用抽象作为实现
        if (is_null($concrete)) {
            $concrete = $abstract;
        }
        
        // 如果实现不是闭包，则将其包装成闭�?        if (!$concrete instanceof \Closure) {
            $concrete = $this->getClosure($abstract, $concrete);
        }
        
        $this->bindings[$abstract] = compact('concrete', 'shared');
    }
    
    /**
     * 绑定单例
     */
    public function singleton(string $abstract, $concrete = null)
    {
        $this->bind($abstract, $concrete, true);
    }
    
    /**
     * 绑定已存在的实例
     */
    public function instance(string $abstract, $instance)
    {
        // 移除别名
        $abstract = $this->getAlias($abstract);
        
        // 移除旧的绑定
        $this->dropStaleInstances($abstract);
        
        $this->instances[$abstract] = $instance;
    }
    
    /**
     * 别名
     */
    public function alias(string $abstract, string $alias)
    {
        $this->aliases[$alias] = $abstract;
    }
    
    /**
     * 获取别名对应的抽�?     */
    public function getAlias(string $abstract)
    {
        return $this->aliases[$abstract] ?? $abstract;
    }
    
    /**
     * 从容器中解析实例
     */
    public function make(string $abstract, array $parameters = [])
    {
        $abstract = $this->getAlias($abstract);
        
        // 如果已经有实例，则直接返�?        if (isset($this->instances[$abstract]) && empty($parameters)) {
            return $this->instances[$abstract];
        }
        
        // 获取具体实现
        $concrete = $this->getConcrete($abstract);
        
        // 解析实例
        $object = $this->build($concrete, $parameters);
        
        // 如果是共享的，则保存实例
        if ($this->isShared($abstract) && empty($parameters)) {
            $this->instances[$abstract] = $object;
        }
        
        return $object;
    }
    
    /**
     * 获取具体实现
     */
    protected function getConcrete(string $abstract)
    {
        if (isset($this->bindings[$abstract])) {
            return $this->bindings[$abstract]['concrete'];
        }
        
        return $abstract;
    }
    
    /**
     * 构建实例
     */
    protected function build($concrete, array $parameters = [])
    {
        // 如果是闭包，则直接调�?        if ($concrete instanceof \Closure) {
            return $concrete($this, $parameters);
        }
        
        try {
            $reflector = new ReflectionClass($concrete);
        } catch (ReflectionException $e) {
            throw new ContainerException("Target class [$concrete] does not exist.", 0, $e);
        }
        
        // 如果类不可实例化，则抛出异常
        if (!$reflector->isInstantiable()) {
            throw new ContainerException("Target [$concrete] is not instantiable.");
        }
        
        $constructor = $reflector->getConstructor();
        
        // 如果没有构造函数，则直接实例化
        if (is_null($constructor)) {
            return new $concrete;
        }
        
        // 获取构造函数参�?        $dependencies = $constructor->getParameters();
        
        // 解析构造函数参�?        $instances = $this->resolveDependencies($dependencies, $parameters);
        
        // 实例化对�?        return $reflector->newInstanceArgs($instances);
    }
    
    /**
     * 解析依赖
     */
    protected function resolveDependencies(array $dependencies, array $parameters = [])
    {
        $results = [];
        
        foreach ($dependencies as $dependency) {
            // 如果参数中有对应的值，则使用参数中的�?            if (array_key_exists($dependency->name, $parameters)) {
                $results[] = $parameters[$dependency->name];
                continue;
            }
            
            // 如果参数有类型提示，则解析类型提�?            $results[] = $this->resolveClass($dependency);
        }
        
        return $results;
    }
    
    /**
     * 解析类型提示
     */
    protected function resolveClass(ReflectionParameter $parameter)
    {
        $type = $parameter->getType();
        
        // 如果参数没有类型提示，则抛出异常
        if (!$type || $type->isBuiltin()) {
            if ($parameter->isDefaultValueAvailable()) {
                return $parameter->getDefaultValue();
            }
            
            throw new ContainerException("Unresolvable dependency resolving [$parameter] in class {$parameter->getDeclaringClass()->getName()}");
        }
        
        try {
            return $this->make($type->getName());
        } catch (ContainerException $e) {
            // 如果参数可选，则返回null
            if ($parameter->isOptional()) {
                return null;
            }
            
            throw $e;
        }
    }
    
    /**
     * 获取闭包
     */
    protected function getClosure(string $abstract, string $concrete): \Closure
    {
        return function ($container, $parameters = []) use ($abstract, $concrete) {
            if ($abstract == $concrete) {
                return $container->build($concrete, $parameters);
            }
            
            return $container->make($concrete, $parameters);
        };
    }
    
    /**
     * 移除过期的实�?     */
    protected function dropStaleInstances(string $abstract)
    {
        unset($this->instances[$abstract]);
    }
    
    /**
     * 检查是否是共享�?     */
    protected function isShared(string $abstract)
    {
        return isset($this->instances[$abstract]) || 
               (isset($this->bindings[$abstract]) && $this->bindings[$abstract]['shared']);
    }
    
    /**
     * 检查容器中是否存在给定的绑�?     */
    public function has(string $id)
    {
        return isset($this->bindings[$id]) || 
               isset($this->instances[$id]) || 
               isset($this->aliases[$id]);
    }
    
    /**
     * 从容器中获取实例
     */
    public function get(string $id)
    {
        if (!$this->has($id)) {
            throw new NotFoundException("No entry was found for {$id} identifier.");
        }
        
        return $this->make($id);
    }
}
