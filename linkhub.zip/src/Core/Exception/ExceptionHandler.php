<?php

declare(strict_types=1);

namespace LinkHub\Core\Exception;

use LinkHub\Core\Http\Response;

/**
 * 异常处理�? */
class ExceptionHandler
{
    /**
     * 处理异常
     */
    public function handle(\Throwable $e): Response
    {
        // 判断是否为HTTP异常
        if ($e instanceof HttpException) {
            return $this->renderHttpException($e);
        }
        
        // 判断是否为验证异�?        if ($e instanceof ValidationException) {
            return $this->renderValidationException($e);
        }
        
        // 其他异常
        return $this->renderException($e);
    }
    
    /**
     * 渲染HTTP异常
     */
    protected function renderHttpException(HttpException $e): Response
    {
        $statusCode = $e->getStatusCode();
        $message = $e->getMessage();
        
        return new Response($this->formatExceptionContent($statusCode, $message), $statusCode);
    }
    
    /**
     * 渲染验证异常
     */
    protected function renderValidationException(ValidationException $e): Response
    {
        $errors = $e->getErrors();
        
        return Response::json([
            'status' => 'error',
            'message' => 'Validation failed',
            'errors' => $errors,
        ], 422);
    }
    
    /**
     * 渲染其他异常
     */
    protected function renderException(\Throwable $e): Response
    {
        $statusCode = 500;
        $message = $this->isDebug() ? $e->getMessage() : 'Internal Server Error';
        
        if ($this->isDebug()) {
            $content = $this->formatExceptionContent($statusCode, $message, $e->getTraceAsString());
        } else {
            $content = $this->formatExceptionContent($statusCode, $message);
        }
        
        return new Response($content, $statusCode);
    }
    
    /**
     * 格式化异常内�?     */
    protected function formatExceptionContent(int $statusCode, string $message, string $trace = null)
    {
        $content = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error ' . $statusCode . '</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #e74c3c;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .trace {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            overflow: auto;
            font-family: monospace;
            font-size: 14px;
            line-height: 1.4;
        }
    </style>
</head>
<body>
    <h1>Error ' . $statusCode . '</h1>
    <div class="message">' . htmlspecialchars($message) . '</div>';
    
    if ($trace) {
        $content .= '<h2>Stack Trace</h2>
    <div class="trace">' . nl2br(htmlspecialchars($trace)) . '</div>';
    }
    
    $content .= '</body>
</html>';
    
        return $content;
    }
    
    /**
     * 是否为调试模�?     */
    protected function isDebug()
    {
        return isset($_ENV['APP_DEBUG']) && $_ENV['APP_DEBUG'] === true;
    }
}
