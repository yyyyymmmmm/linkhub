<?php

declare(strict_types=1);

namespace LinkHub\Core\Exception;

/**
 * HTTP异常
 */
class HttpException extends \Exception
{
    /**
     * @var int HTTP状态码
     */
    protected \$statusCode;
    
    /**
     * 构造函�?
     */
    public function __construct(int $statusCode, string $message = '', \Throwable $previous = null)
    {
        $this->statusCode = $statusCode;
        
        parent::__construct($message, $statusCode, $previous);
    }
    
    /**
     * 获取HTTP状态码
     */
    public function getStatusCode()
    {
        return $this->statusCode;
    }
}
