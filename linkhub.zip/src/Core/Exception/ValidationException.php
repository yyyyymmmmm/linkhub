<?php

declare(strict_types=1);

namespace LinkHub\Core\Exception;

/**
 * 验证异常
 */
class ValidationException extends \Exception
{
    /**
     * @var array 验证错误
     */
    protected \$errors;
    
    /**
     * 构造函�?
     */
    public function __construct(array $errors, string $message = 'Validation failed', int $code = 422, \Throwable $previous = null)
    {
        $this->errors = $errors;
        
        parent::__construct($message, $code, $previous);
    }
    
    /**
     * 获取验证错误
     */
    public function getErrors()
    {
        return $this->errors;
    }
}
