<?php

declare(strict_types=1);

namespace LinkHub\Core;

use LinkHub\Core\Container\Container;
use LinkHub\Core\Container\ContainerInterface;
use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;
use LinkHub\Core\Routing\Router;
use LinkHub\Core\Exception\ExceptionHandler;

/**
 * 应用程序�? */
class Application implements ContainerInterface
{
    /**
     * @var Container 容器实例
     */
    protected \$container;
    
    /**
     * @var string 应用基础路径
     */
    protected \$basePath;
    
    /**
     * @var array 已注册的服务提供�?     */
    protected \$serviceProviders = [];
    
    /**
     * @var array 已启动的服务提供�?     */
    protected \$bootedProviders = [];
    
    /**
     * @var static 应用实例
     */
    protected static ?self $instance = null;
    
    /**
     * 构造函�?     */
    public function __construct(string $basePath = '')
    {
        $this->basePath = rtrim($basePath, '\/');
        $this->container = new Container();
        
        $this->registerBaseBindings();
        
        static::$instance = $this;
    }
    
    /**
     * 注册基础绑定
     */
    protected function registerBaseBindings()
    {
        $this->container->instance('app', $this);
        $this->container->instance(Application::class, $this);
        $this->container->instance(Container::class, $this->container);
        $this->container->instance(ContainerInterface::class, $this->container);
    }
    
    /**
     * 获取应用实例
     */
    public static function getInstance(): self
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }
        
        return static::$instance;
    }
    
    /**
     * 获取应用基础路径
     */
    public function basePath(string $path = '')
    {
        return $this->basePath . ($path ? DIRECTORY_SEPARATOR . $path : $path);
    }
    
    /**
     * 注册服务提供�?     */
    public function register(ServiceProviderInterface $provider): self
    {
        $provider->register();
        
        $this->serviceProviders[] = $provider;
        
        return $this;
    }
    
    /**
     * 启动服务提供�?     */
    public function boot()
    {
        foreach ($this->serviceProviders as $provider) {
            if (!in_array($provider, $this->bootedProviders)) {
                $provider->boot();
                $this->bootedProviders[] = $provider;
            }
        }
    }
    
    /**
     * 处理请求
     */
    public function handle(Request $request): Response
    {
        try {
            $this->boot();
            
            $router = $this->make(Router::class);
            return $router->dispatch($request);
        } catch (\Throwable $e) {
            return $this->handleException($request, $e);
        }
    }
    
    /**
     * 处理异常
     */
    protected function handleException(Request $request, \Throwable $e): Response
    {
        if ($this->container->has(ExceptionHandler::class)) {
            $handler = $this->make(ExceptionHandler::class);
            return $handler->handle($e);
        }
        
        // 默认异常处理
        $statusCode = 500;
        $message = 'Internal Server Error';
        
        if ($e instanceof \LinkHub\Core\Exception\HttpException) {
            $statusCode = $e->getStatusCode();
            $message = $e->getMessage();
        }
        
        if ($request->isAjax()) {
            return Response::json([
                'error' => $message,
                'code' => $statusCode,
            ], $statusCode);
        }
        
        $contentType = $request->header('Content-Type', '');
        if (strpos($contentType, 'application/json') !== false) {
            return Response::json([
                'error' => $message,
                'code' => $statusCode,
            ], $statusCode);
        }
        
        return new Response($message, $statusCode);
    }
    
    /**
     * 终止应用
     */
    public function terminate(Request $request, Response $response)
    {
        // 执行终止回调
    }
    
    /**
     * 从容器中解析实例
     */
    public function make(string $abstract, array $parameters = [])
    {
        return $this->container->make($abstract, $parameters);
    }
    
    /**
     * 确定容器中是否存在给定的绑定
     */
    public function has(string $id)
    {
        return $this->container->has($id);
    }
    
    /**
     * 从容器中获取实例
     */
    public function get(string $id)
    {
        return $this->container->get($id);
    }
    
    /**
     * 注册单例
     */
    public function singleton(string $abstract, $concrete = null)
    {
        $this->container->singleton($abstract, $concrete);
    }
    
    /**
     * 注册实例
     */
    public function instance(string $abstract, $instance)
    {
        $this->container->instance($abstract, $instance);
    }
}
