<?php

declare(strict_types=1);

namespace LinkHub\Core\Controller;

use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;

/**
 * 基础控制器类
 */
abstract class BaseController
{
    /**
     * 渲染JSON响应
     */
    protected function json($data, $status = 200)
    {
        $response = new Response(json_encode($data), $status);
        $response->headers['Content-Type'] = 'application/json';
        return $response;
    }
    
    /**
     * 渲染成功响应
     */
    protected function success($message = '操作成功', $data = null)
    {
        return $this->json([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    /**
     * 渲染错误响应
     */
    protected function error($message = '操作失败', $code = 400, $data = null)
    {
        return $this->json([
            'success' => false,
            'message' => $message,
            'data' => $data
        ], $code);
    }
    
    /**
     * 渲染视图
     */
    protected function view($template, $data = [])
    {
        // 提取数据到变量
        extract($data);
        
        // 开始输出缓冲
        ob_start();
        
        // 包含视图文件
        $viewFile = dirname(dirname(dirname(__DIR__))) . '/resources/views/' . $template . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new \Exception("View file not found: {$template}");
        }
        
        // 获取输出内容
        $content = ob_get_clean();
        
        return new Response($content);
    }
    
    /**
     * 重定向
     */
    protected function redirect($url, $status = 302)
    {
        $response = new Response('', $status);
        $response->headers['Location'] = $url;
        return $response;
    }
    
    /**
     * 验证请求参数
     */
    protected function validate(Request $request, $rules)
    {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $request->input($field);
            
            if (strpos($rule, 'required') !== false && empty($value)) {
                $errors[$field] = "{$field}不能为空";
                continue;
            }
            
            if (strpos($rule, 'email') !== false && !empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                $errors[$field] = "{$field}格式不正确";
            }
            
            if (preg_match('/min:(\d+)/', $rule, $matches) && !empty($value) && strlen($value) < $matches[1]) {
                $errors[$field] = "{$field}长度不能少于{$matches[1]}个字符";
            }
            
            if (preg_match('/max:(\d+)/', $rule, $matches) && !empty($value) && strlen($value) > $matches[1]) {
                $errors[$field] = "{$field}长度不能超过{$matches[1]}个字符";
            }
        }
        
        if (!empty($errors)) {
            throw new \Exception(json_encode($errors));
        }
        
        return true;
    }
    
    /**
     * 记录日志
     */
    protected function log($message, $context = [])
    {
        $logFile = dirname(dirname(dirname(__DIR__))) . '/storage/logs/app.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $contextStr = !empty($context) ? ' ' . json_encode($context) : '';
        $logEntry = '[' . $timestamp . '] ' . $message . $contextStr . PHP_EOL;
        
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
}