<?php

declare(strict_types=1);

namespace LinkHub\Core\Routing;

use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;
use LinkHub\Core\Container\ContainerInterface;

/**
 * 中间件管�?
 * 
 * @author OneNav Professional Team
 */
class MiddlewarePipeline
{
    protected \$container;
    
    public function __construct(\$container)
    {
        $this->container = $container;
    }
    
    /**
     * 处理中间件管�?
     */
    public function process(Request $request, array $middleware, callable $destination): Response
    {
        $pipeline = array_reduce(
            array_reverse($middleware),
            $this->carry(),
            $this->prepareDestination($destination)
        );
        
        return $pipeline($request);
    }
    
    /**
     * 获取中间件携带闭�?
     */
    protected function carry(): callable
    {
        return function ($stack, $pipe) {
            return function ($passable) use ($stack, $pipe) {
                try {
                    $slice = $this->getSlice();
                    
                    $callable = $slice($stack, $pipe);
                    
                    return $callable($passable);
                } catch (\Throwable $e) {
                    return $this->handleException($passable, $e);
                }
            };
        };
    }
    
    /**
     * 获取中间件片�?
     */
    protected function getSlice(): callable
    {
        return function ($stack, $pipe) {
            return function ($passable) use ($stack, $pipe) {
                if (is_callable($pipe)) {
                    // 如果是闭包，直接调用
                    return $pipe($passable, $stack);
                } elseif (is_string($pipe)) {
                    // 如果是字符串，从容器中解�?
                    [$name, $parameters] = $this->parsePipeString($pipe);
                    
                    $middleware = $this->container->make($name);
                    
                    if (method_exists($middleware, 'handle')) {
                        return $middleware->handle($passable, $stack, ...$parameters);
                    }
                    
                    throw new \InvalidArgumentException("Middleware [{$name}] does not have a handle method.");
                } else {
                    throw new \InvalidArgumentException('Invalid middleware type.');
                }
            };
        };
    }
    
    /**
     * 解析管道字符�?
     */
    protected function parsePipeString(string $pipe)
    {
        [$name, $parameters] = array_pad(explode(':', $pipe, 2), 2, []);
        
        if (is_string($parameters)) {
            $parameters = explode(',', $parameters);
        }
        
        return [$name, $parameters];
    }
    
    /**
     * 准备目标处理�?
     */
    protected function prepareDestination(callable $destination): callable
    {
        return function ($passable) use ($destination) {
            try {
                return $destination($passable);
            } catch (\Throwable $e) {
                return $this->handleException($passable, $e);
            }
        };
    }
    
    /**
     * 处理管道异常
     */
    protected function handleException($passable, \Throwable $e): Response
    {
        if ($this->container->has('exception.handler')) {
            $handler = $this->container->get('exception.handler');
            return $handler->render($e);
        }
        
        // 简单的异常处理
        $response = new Response('Internal Server Error', 500);
        
        if ($_ENV['APP_DEBUG'] ?? false) {
            $response->setContent(
                '<h1>Exception</h1>' .
                '<p><strong>Message:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>' .
                '<p><strong>File:</strong> ' . htmlspecialchars($e->getFile()) . '</p>' .
                '<p><strong>Line:</strong> ' . $e->getLine() . '</p>' .
                '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>'
            );
        }
        
        return $response;
    }
}
