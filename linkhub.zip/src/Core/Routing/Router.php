<?php

declare(strict_types=1);

namespace LinkHub\Core\Routing;

use LinkHub\Core\Application;
use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;
use LinkHub\Core\Routing\Exceptions\RouteNotFoundException;

/**
 * 路由器类
 */
class Router
{
    /**
     * @var Application 应用实例
     */
    protected \$app;
    
    /**
     * @var array 路由�?     */
    protected \$routes = [
        'GET' => [],
        'POST' => [],
        'PUT' => [],
        'DELETE' => [],
        'PATCH' => [],
        'HEAD' => [],
        'OPTIONS' => [],
    ];
    
    /**
     * @var array 路由组配�?     */
    protected \$groupStack = [];
    
    /**
     * 构造函�?     */
    public function __construct(\$app)
    {
        $this->app = $app;
    }
    
    /**
     * 添加GET路由
     */
    public function get(string $uri, $action): self
    {
        return $this->addRoute('GET', $uri, $action);
    }
    
    /**
     * 添加POST路由
     */
    public function post(string $uri, $action): self
    {
        return $this->addRoute('POST', $uri, $action);
    }
    
    /**
     * 添加PUT路由
     */
    public function put(string $uri, $action): self
    {
        return $this->addRoute('PUT', $uri, $action);
    }
    
    /**
     * 添加DELETE路由
     */
    public function delete(string $uri, $action): self
    {
        return $this->addRoute('DELETE', $uri, $action);
    }
    
    /**
     * 添加PATCH路由
     */
    public function patch(string $uri, $action): self
    {
        return $this->addRoute('PATCH', $uri, $action);
    }
    
    /**
     * 添加路由
     */
    protected function addRoute(string $method, string $uri, $action): self
    {
        $uri = $this->getGroupPrefix() . '/' . trim($uri, '/');
        $uri = trim($uri, '/');
        $uri = $uri ?: '/';
        
        if (is_string($action) && strpos($action, '@') !== false) {
            list($controller, $method) = explode('@', $action);
            $action = [
                'controller' => $controller,
                'method' => $method,
            ];
        }
        
        $this->routes[$method][$uri] = [
            'uri' => $uri,
            'action' => $action,
            'middleware' => $this->getGroupMiddleware(),
        ];
        
        return $this;
    }
    
    /**
     * 路由�?     */
    public function group(array $attributes, callable $callback): self
    {
        $this->groupStack[] = $attributes;
        
        $callback($this);
        
        array_pop($this->groupStack);
        
        return $this;
    }
    
    /**
     * 获取当前组前缀
     */
    protected function getGroupPrefix()
    {
        if (empty($this->groupStack)) {
            return '';
        }
        
        $prefix = '';
        
        foreach ($this->groupStack as $group) {
            if (isset($group['prefix'])) {
                $prefix .= '/' . trim($group['prefix'], '/');
            }
        }
        
        return trim($prefix, '/');
    }
    
    /**
     * 获取当前组中间件
     */
    protected function getGroupMiddleware()
    {
        if (empty($this->groupStack)) {
            return [];
        }
        
        $middleware = [];
        
        foreach ($this->groupStack as $group) {
            if (isset($group['middleware'])) {
                if (is_array($group['middleware'])) {
                    $middleware = array_merge($middleware, $group['middleware']);
                } else {
                    $middleware[] = $group['middleware'];
                }
            }
        }
        
        return $middleware;
    }
    
    /**
     * 调度请求
     */
    public function dispatch(Request $request): Response
    {
        $method = $request->method();
        $uri = $request->path();
        
        // 查找匹配的路�?        $route = $this->findRoute($method, $uri);
        
        if (!$route) {
            throw new RouteNotFoundException("Route not found: {$method} {$uri}");
        }
        
        // 解析路由参数
        $params = $this->parseRouteParams($route['uri'], $uri);
        
        // 执行路由
        return $this->executeRoute($route, $request, $params);
    }
    
    /**
     * 查找匹配的路�?     */
    protected function findRoute(string $method, string $uri)
    {
        $uri = trim($uri, '/') ?: '/';
        
        // 精确匹配
        if (isset($this->routes[$method][$uri])) {
            return $this->routes[$method][$uri];
        }
        
        // 参数匹配
        foreach ($this->routes[$method] as $routeUri => $route) {
            $pattern = $this->convertUriToRegex($routeUri);
            
            if (preg_match($pattern, $uri)) {
                return $route;
            }
        }
        
        return null;
    }
    
    /**
     * 将URI转换为正则表达式
     */
    protected function convertUriToRegex(string $uri)
    {
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '([^/]+)', $uri);
        return '#^' . $pattern . '$#';
    }
    
    /**
     * 解析路由参数
     */
    protected function parseRouteParams(string $routeUri, string $uri)
    {
        $params = [];
        
        // 提取参数�?        preg_match_all('/\{([a-zA-Z0-9_]+)\}/', $routeUri, $paramNames);
        
        // 提取参数�?        $pattern = $this->convertUriToRegex($routeUri);
        preg_match($pattern, trim($uri, '/') ?: '/', $paramValues);
        
        // 移除完整匹配
        array_shift($paramValues);
        
        // 组合参数
        foreach ($paramNames[1] as $index => $name) {
            $params[$name] = $paramValues[$index] ?? null;
        }
        
        return $params;
    }
    
    /**
     * 执行路由
     */
    protected function executeRoute(array $route, Request $request, array $params): Response
    {
        $action = $route['action'];
        
        // 处理控制器方�?        if (is_array($action) && isset($action['controller']) && isset($action['method'])) {
            $controller = $this->app->make($action['controller']);
            $method = $action['method'];
            
            $result = $controller->$method($request, ...$params);
        } 
        // 处理闭包
        elseif (is_callable($action)) {
            $result = $action($request, ...$params);
        } 
        // 无效的路由动�?        else {
            throw new \RuntimeException('Invalid route action');
        }
        
        // 处理响应
        if ($result instanceof Response) {
            return $result;
        }
        
        if (is_string($result)) {
            return new Response($result);
        }
        
        if (is_array($result) || is_object($result)) {
            return Response::json($result);
        }
        
        return new Response('');
    }
    
    /**
     * 获取所有注册的路由
     */
    public function getRoutes()
    {
        return $this->routes;
    }
}
