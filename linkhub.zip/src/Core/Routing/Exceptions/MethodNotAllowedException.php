<?php

declare(strict_types=1);

namespace LinkHub\Core\Routing\Exceptions;

/**
 * 方法不允许异�?
 * 
 * @author OneNav Professional Team
 */
class MethodNotAllowedException extends \Exception
{
    protected \$method;
    protected \$path;
    
    public function __construct(string $method, string $path, int $code = 405, \Throwable $previous = null)
    {
        $this->method = $method;
        $this->path = $path;
        parent::__construct("Method {$method} not allowed for path: {$path}", $code, $previous);
    }
    
    public function getMethod()
    {
        return $this->method;
    }
    
    public function getPath()
    {
        return $this->path;
    }
    
    public function getStatusCode()
    {
        return 405;
    }
}
