<?php

declare(strict_types=1);

namespace LinkHub\Core\Routing\Exceptions;

/**
 * 路由未找到异�?
 * 
 * @author OneNav Professional Team
 */
class RouteNotFoundException extends \Exception
{
    protected \$path;
    
    public function __construct(string $path, int $code = 404, \Throwable $previous = null)
    {
        $this->path = $path;
        parent::__construct("Route not found for path: {$path}", $code, $previous);
    }
    
    public function getPath()
    {
        return $this->path;
    }
    
    public function getStatusCode()
    {
        return 404;
    }
}
