<?php

declare(strict_types=1);

namespace LinkHub\Core\Routing;

/**
 * 路由�? */
class Route
{
    /**
     * @var string 路由URI
     */
    protected \$uri;
    
    /**
     * @var mixed 路由动作
     */
    protected $action;
    
    /**
     * @var array 路由中间�?     */
    protected \$middleware = [];
    
    /**
     * @var string 路由名称
     */
    protected \$name = null;
    
    /**
     * @var array 路由参数
     */
    protected \$parameters = [];
    
    /**
     * 构造函�?     */
    public function __construct(string $uri, $action)
    {
        $this->uri = $uri;
        $this->action = $action;
    }
    
    /**
     * 获取路由URI
     */
    public function getUri()
    {
        return $this->uri;
    }
    
    /**
     * 获取路由动作
     */
    public function getAction()
    {
        return $this->action;
    }
    
    /**
     * 设置路由中间�?     */
    public function middleware($middleware): self
    {
        if (is_array($middleware)) {
            $this->middleware = array_merge($this->middleware, $middleware);
        } else {
            $this->middleware[] = $middleware;
        }
        
        return $this;
    }
    
    /**
     * 获取路由中间�?     */
    public function getMiddleware()
    {
        return $this->middleware;
    }
    
    /**
     * 设置路由名称
     */
    public function name(string $name): self
    {
        $this->name = $name;
        
        return $this;
    }
    
    /**
     * 获取路由名称
     */
    public function getName()
    {
        return $this->name;
    }
    
    /**
     * 设置路由参数
     */
    public function parameters(array $parameters): self
    {
        $this->parameters = $parameters;
        
        return $this;
    }
    
    /**
     * 获取路由参数
     */
    public function getParameters()
    {
        return $this->parameters;
    }
}
