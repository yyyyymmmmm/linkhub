<?php

declare(strict_types=1);

namespace LinkHub\Core\Http;

/**
 * HTTP响应类
 */
class Response
{
    /**
     * @var string 响应内容
     */
    protected $content;
    
    /**
     * @var int 状态码
     */
    protected $statusCode;
    
    /**
     * @var array 响应头
     */
    public $headers = [];
    
    /**
     * 构造函数
     */
    public function __construct($content = '', $statusCode = 200, array $headers = [])
    {
        $this->content = $content;
        $this->statusCode = $statusCode;
        $this->headers = $headers;
    }
    
    /**
     * 获取内容
     */
    public function getContent()
    {
        return $this->content;
    }
    
    /**
     * 设置内容
     */
    public function setContent($content)
    {
        $this->content = $content;
        return $this;
    }
    
    /**
     * 获取状态码
     */
    public function getStatusCode()
    {
        return $this->statusCode;
    }
    
    /**
     * 设置状态码
     */
    public function setStatusCode($statusCode)
    {
        $this->statusCode = $statusCode;
        return $this;
    }
    
    /**
     * 设置响应头
     */
    public function setHeader($name, $value)
    {
        $this->headers[$name] = $value;
        return $this;
    }
    
    /**
     * 发送响应
     */
    public function send()
    {
        // 发送状态码
        http_response_code($this->statusCode);
        
        // 发送响应头
        foreach ($this->headers as $name => $value) {
            header($name . ': ' . $value);
        }
        
        // 发送内容
        echo $this->content;
    }
    
    /**
     * 创建重定向响应
     */
    public static function redirect($url, $statusCode = 302)
    {
        $response = new static('', $statusCode);
        $response->setHeader('Location', $url);
        return $response;
    }
    
    /**
     * 创建JSON响应
     */
    public static function json($data, $statusCode = 200)
    {
        $response = new static(json_encode($data), $statusCode);
        $response->setHeader('Content-Type', 'application/json');
        return $response;
    }
}