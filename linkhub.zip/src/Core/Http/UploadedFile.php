<?php

declare(strict_types=1);

namespace LinkHub\Core\Http;

/**
 * 上传文件�?
 * 
 * @author OneNav Professional Team
 */
class UploadedFile
{
    protected \$file;
    protected \$originalName;
    protected \$mimeType;
    protected \$size;
    protected \$error;
    
    public function __construct(array $file)
    {
        $this->file = $file;
        $this->originalName = $file['name'] ?? null;
        $this->mimeType = $file['type'] ?? null;
        $this->size = $file['size'] ?? null;
        $this->error = $file['error'] ?? null;
    }
    
    /**
     * 获取原始文件�?
     */
    public function getOriginalName()
    {
        return $this->originalName;
    }
    
    /**
     * 获取MIME类型
     */
    public function getMimeType()
    {
        return $this->mimeType;
    }
    
    /**
     * 获取文件大小
     */
    public function getSize()
    {
        return $this->size;
    }
    
    /**
     * 获取上传错误代码
     */
    public function getError()
    {
        return $this->error;
    }
    
    /**
     * 获取临时文件路径
     */
    public function getTempName()
    {
        return $this->file['tmp_name'] ?? null;
    }
    
    /**
     * 检查文件是否上传成�?
     */
    public function isValid()
    {
        return $this->error === UPLOAD_ERR_OK && is_uploaded_file($this->getTempName());
    }
    
    /**
     * 获取文件扩展�?
     */
    public function getExtension()
    {
        if (!$this->originalName) {
            return '';
        }
        
        return strtolower(pathinfo($this->originalName, PATHINFO_EXTENSION));
    }
    
    /**
     * 获取文件基本名（不含扩展名）
     */
    public function getBasename()
    {
        if (!$this->originalName) {
            return '';
        }
        
        return pathinfo($this->originalName, PATHINFO_FILENAME);
    }
    
    /**
     * 移动上传文件到指定位�?
     */
    public function moveTo(string $destination)
    {
        if (!$this->isValid()) {
            return false;
        }
        
        // 确保目标目录存在
        $directory = dirname($destination);
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }
        
        return move_uploaded_file($this->getTempName(), $destination);
    }
    
    /**
     * 生成安全的文件名
     */
    public function generateSafeName(string $prefix = '')
    {
        $extension = $this->getExtension();
        $timestamp = time();
        $random = bin2hex(random_bytes(8));
        
        return $prefix . $timestamp . '_' . $random . ($extension ? '.' . $extension : '');
    }
    
    /**
     * 检查文件类型是否被允许
     */
    public function isAllowedType(array $allowedTypes)
    {
        $extension = $this->getExtension();
        return in_array($extension, $allowedTypes, true);
    }
    
    /**
     * 检查文件大小是否在限制范围�?
     */
    public function isValidSize(int $maxSize)
    {
        return $this->size !== null && $this->size <= $maxSize;
    }
    
    /**
     * 获取上传错误信息
     */
    public function getErrorMessage()
    {
        switch ($this->error) {
            case UPLOAD_ERR_OK:
                return '上传成功';
            case UPLOAD_ERR_INI_SIZE:
                return '文件大小超过�?php.ini �?upload_max_filesize 的限�?;
            case UPLOAD_ERR_FORM_SIZE:
                return '文件大小超过了表单中 MAX_FILE_SIZE 的限�?;
            case UPLOAD_ERR_PARTIAL:
                return '文件只有部分被上�?;
            case UPLOAD_ERR_NO_FILE:
                return '没有文件被上�?;
            case UPLOAD_ERR_NO_TMP_DIR:
                return '找不到临时文件夹';
            case UPLOAD_ERR_CANT_WRITE:
                return '文件写入失败';
            case UPLOAD_ERR_EXTENSION:
                return '文件上传被扩展阻�?;
            default:
                return '未知上传错误';
        }
    }
    
    /**
     * 检查是否为图片文件
     */
    public function isImage()
    {
        $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
        return $this->isAllowedType($imageExtensions);
    }
    
    /**
     * 获取图片信息
     */
    public function getImageInfo()
    {
        if (!$this->isImage() || !$this->isValid()) {
            return null;
        }
        
        $info = getimagesize($this->getTempName());
        
        if ($info === false) {
            return null;
        }
        
        return [
            'width' => $info[0],
            'height' => $info[1],
            'type' => $info[2],
            'mime' => $info['mime'],
        ];
    }
    
    /**
     * 验证文件签名
     */
    public function verifySignature()
    {
        if (!$this->isValid()) {
            return false;
        }
        
        $file = fopen($this->getTempName(), 'rb');
        if (!$file) {
            return false;
        }
        
        $header = fread($file, 16);
        fclose($file);
        
        // 常见文件签名
        $signatures = [
            'jpg' => ["\xFF\xD8\xFF"],
            'png' => ["\x89\x50\x4E\x47\x0D\x0A\x1A\x0A"],
            'gif' => ["GIF87a", "GIF89a"],
            'pdf' => ["%PDF"],
            'zip' => ["PK\x03\x04"],
        ];
        
        $extension = $this->getExtension();
        
        if (!isset($signatures[$extension])) {
            return true; // 未知类型，跳过验�?
        }
        
        foreach ($signatures[$extension] as $signature) {
            if (str_starts_with($header, $signature)) {
                return true;
            }
        }
        
        return false;
    }
}
