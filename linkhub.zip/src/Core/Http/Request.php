<?php

declare(strict_types=1);

namespace LinkHub\Core\Http;

/**
 * HTTP请求类
 */
class Request
{
    /**
     * @var array 查询参数 ($_GET)
     */
    protected $query = [];
    
    /**
     * @var array 请求参数 ($_POST)
     */
    protected $request = [];
    
    /**
     * @var array 服务器参数 ($_SERVER)
     */
    protected $server = [];
    
    /**
     * @var array 文件 ($_FILES)
     */
    protected $files = [];
    
    /**
     * @var array Cookie ($_COOKIE)
     */
    protected $cookies = [];
    
    /**
     * @var array 请求头
     */
    protected $headers = [];
    
    /**
     * @var string 请求方法
     */
    protected $method;
    
    /**
     * @var string 请求URI
     */
    protected $uri;
    
    /**
     * 构造函数
     */
    public function __construct(
        array $query = [],
        array $request = [],
        array $server = [],
        array $files = [],
        array $cookies = []
    ) {
        $this->query = $query;
        $this->request = $request;
        $this->server = $server;
        $this->files = $files;
        $this->cookies = $cookies;
        
        $this->method = strtoupper($server['REQUEST_METHOD'] ?? 'GET');
        $this->uri = $server['REQUEST_URI'] ?? '/';
        
        $this->headers = $this->getHeadersFromServer();
    }
    
    /**
     * 获取查询参数
     */
    public function query($key = null, $default = null)
    {
        if ($key === null) {
            return $this->query;
        }
        
        return $this->query[$key] ?? $default;
    }
    
    /**
     * 获取请求参数
     */
    public function request($key = null, $default = null)
    {
        if ($key === null) {
            return $this->request;
        }
        
        return $this->request[$key] ?? $default;
    }
    
    /**
     * 获取输入参数 (query 或 request)
     */
    public function input($key = null, $default = null)
    {
        if ($key === null) {
            return array_merge($this->query, $this->request);
        }
        
        // 优先从query获取，再从request获取
        return $this->query[$key] ?? $this->request[$key] ?? $default;
    }
    
    /**
     * 获取服务器参数
     */
    public function server($key = null, $default = null)
    {
        if ($key === null) {
            return $this->server;
        }
        
        return $this->server[$key] ?? $default;
    }
    
    /**
     * 获取文件
     */
    public function file($key)
    {
        return $this->files[$key] ?? null;
    }
    
    /**
     * 获取Cookie
     */
    public function cookie($key = null, $default = null)
    {
        if ($key === null) {
            return $this->cookies;
        }
        
        return $this->cookies[$key] ?? $default;
    }
    
    /**
     * 获取请求方法
     */
    public function getMethod()
    {
        return $this->method;
    }
    
    /**
     * 获取URI
     */
    public function getUri()
    {
        return $this->uri;
    }
    
    /**
     * 获取路径信息
     */
    public function getPathInfo()
    {
        $path = parse_url($this->uri, PHP_URL_PATH);
        return $path ?: '/';
    }
    
    /**
     * 获取请求头
     */
    public function header($key = null, $default = null)
    {
        if ($key === null) {
            return $this->headers;
        }
        
        $key = strtolower($key);
        return $this->headers[$key] ?? $default;
    }
    
    /**
     * 检查请求方法
     */
    public function isMethod($method)
    {
        return strtoupper($this->method) === strtoupper($method);
    }
    
    /**
     * 获取所有输入参数 (GET + POST)
     */
    public function all()
    {
        return array_merge($this->query, $this->request);
    }
    
    /**
     * 检查参数是否存在
     */
    public function has($key)
    {
        return isset($this->query[$key]) || isset($this->request[$key]);
    }
    
    /**
     * 获取指定的参数
     */
    public function only(array $keys)
    {
        $result = [];
        $all = $this->all();
        
        foreach ($keys as $key) {
            if (isset($all[$key])) {
                $result[$key] = $all[$key];
            }
        }
        
        return $result;
    }
    
    /**
     * 从服务器参数获取请求头
     */
    protected function getHeadersFromServer()
    {
        $headers = [];
        
        foreach ($this->server as $key => $value) {
            if (strpos($key, 'HTTP_') === 0) {
                $header = strtolower(str_replace('_', '-', substr($key, 5)));
                $headers[$header] = $value;
            }
        }
        
        return $headers;
    }
}