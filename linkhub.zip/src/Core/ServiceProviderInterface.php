<?php

declare(strict_types=1);

namespace LinkHub\Core;

/**
 * 服务提供者接�? */
interface ServiceProviderInterface
{
    /**
     * 注册服务
     */
    public function register();
    
    /**
     * 启动服务
     */
    public function boot();
}
