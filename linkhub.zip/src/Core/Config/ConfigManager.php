<?php

declare(strict_types=1);

namespace LinkHub\Core\Config;

/**
 * 配置管理�? */
class ConfigManager
{
    /**
     * @var array 配置�?     */
    protected \$items = [];
    
    /**
     * @var string 配置文件路径
     */
    protected \$path;
    
    /**
     * 构造函�?     */
    public function __construct(string $path = null)
    {
        $this->path = $path ?? dirname(dirname(dirname(__DIR__))) . '/config';
    }
    
    /**
     * 获取配置�?     */
    public function get(string $key, $default = null)
    {
        $keys = explode('.', $key);
        $config = $this->items;
        
        // 加载配置文件
        $file = array_shift($keys);
        if (!isset($this->items[$file])) {
            $this->load($file);
            $config = $this->items;
        }
        
        // 遍历配置�?        foreach ($keys as $segment) {
            if (!is_array($config) || !array_key_exists($file, $config)) {
                return $default;
            }
            
            $config = $config[$file];
            
            if (!is_array($config) || !array_key_exists($segment, $config)) {
                return $default;
            }
            
            $config = $config[$segment];
            $file = $segment;
        }
        
        return $config;
    }
    
    /**
     * 设置配置�?     */
    public function set(string $key, $value)
    {
        $keys = explode('.', $key);
        $file = array_shift($keys);
        
        // 加载配置文件
        if (!isset($this->items[$file])) {
            $this->load($file);
        }
        
        $config = &$this->items;
        
        // 遍历配置�?        foreach ($keys as $segment) {
            if (!isset($config[$file]) || !is_array($config[$file])) {
                $config[$file] = [];
            }
            
            $config = &$config[$file];
            $file = $segment;
        }
        
        $config[$file] = $value;
    }
    
    /**
     * 加载配置文件
     */
    public function load(string $file)
    {
        $path = $this->path . '/' . $file . '.php';
        
        if (file_exists($path)) {
            $this->items[$file] = require $path;
        } else {
            $this->items[$file] = [];
        }
    }
    
    /**
     * 获取所有配置项
     */
    public function all()
    {
        return $this->items;
    }
    
    /**
     * 检查配置项是否存在
     */
    public function has(string $key)
    {
        return $this->get($key) !== null;
    }
}
