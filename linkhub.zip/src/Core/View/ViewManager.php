<?php

declare(strict_types=1);

namespace LinkHub\Core\View;

use LinkHub\Core\Config\ConfigManager;
use LinkHub\Core\Application;

/**
 * 视图管理�? */
class ViewManager
{
    protected \$app;
    protected ConfigManager $config;
    protected \$data = [];
    protected \$viewsPath;
    
    /**
     * 构造函�?     */
    public function __construct($configOrApp)
    {
        if ($configOrApp instanceof Application) {
            $this->app = $configOrApp;
            $this->config = $configOrApp->make(ConfigManager::class);
        } elseif ($configOrApp instanceof ConfigManager) {
            $this->config = $configOrApp;
        }
        
        $this->viewsPath = dirname(dirname(dirname(__DIR__))) . '/resources/views';
    }
    
    /**
     * 渲染视图
     */
    public function render(string $view, array $data = [])
    {
        $data = array_merge($this->data, $data);
        
        // 提取视图文件路径
        $viewFile = $this->findViewFile($view);
        
        if (!file_exists($viewFile)) {
            throw new \Exception("View file not found: {$view} (Path: {$viewFile})");
        }
        
        // 开启输出缓�?        ob_start();
        
        // 提取变量
        extract($data);
        
        // 包含视图文件
        include $viewFile;
        
        // 获取缓冲内容并清空缓�?        $content = ob_get_clean();
        
        if ($content === false) {
            throw new \Exception("Failed to get output buffer content");
        }
        
        return $content;
    }
    
    /**
     * 查找视图文件
     */
    protected function findViewFile(string $view)
    {
        // 替换点为目录分隔�?        $view = str_replace('.', '/', $view);
        
        // 检查是否有扩展�?        if (strpos($view, '.') === false) {
            $view .= '.php';
        }
        
        return $this->viewsPath . '/' . $view;
    }
    
    /**
     * 设置共享数据
     */
    public function share(string $key, $value): self
    {
        $this->data[$key] = $value;
        return $this;
    }
    
    /**
     * 批量设置共享数据
     */
    public function shareMany(array $data): self
    {
        $this->data = array_merge($this->data, $data);
        return $this;
    }
    
    /**
     * 获取共享数据
     */
    public function getData()
    {
        return $this->data;
    }
    
    /**
     * 设置视图路径
     */
    public function setViewsPath(string $path): self
    {
        $this->viewsPath = $path;
        return $this;
    }
    
    /**
     * 获取视图路径
     */
    public function getViewsPath()
    {
        return $this->viewsPath;
    }
}
