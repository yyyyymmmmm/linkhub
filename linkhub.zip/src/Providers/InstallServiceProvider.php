<?php

declare(strict_types=1);

namespace LinkHub\Providers;

use LinkHub\Core\Application;
use LinkHub\Core\ServiceProviderInterface;
use LinkHub\Core\Routing\Router;
use LinkHub\Http\Controllers\Install\InstallController;
use LinkHub\Core\View\ViewManager;

/**
 * 安装服务提供�?
 */
class InstallServiceProvider implements ServiceProviderInterface
{
    protected \$app;
    
    public function __construct(\$app)
    {
        $this->app = $app;
    }
    
    /**
     * 注册服务
     */
    public function register()
    {
        // 注册路由�?
        $this->app->singleton(Router::class, function () {
            return new Router($this->app);
        });
        
        // 注册视图管理�?
        $this->app->singleton(ViewManager::class, function () {
            $viewManager = new ViewManager($this->app);
            $viewManager->setViewsPath($this->app->basePath('resources/views'));
            return $viewManager;
        });
        
        // 注册安装控制�?
        $this->app->singleton(InstallController::class, function () {
            return new InstallController(
                $this->app->make(ViewManager::class)
            );
        });
    }
    
    /**
     * 启动服务
     */
    public function boot()
    {
        $router = $this->app->make(Router::class);
        
        // 注册安装路由
        $router->get('/', 'LinkHub\Http\Controllers\Install\InstallController@index');
        $router->get('/install', 'LinkHub\Http\Controllers\Install\InstallController@index');
        $router->get('/install/requirements', 'LinkHub\Http\Controllers\Install\InstallController@requirements');
        $router->get('/install/database', 'LinkHub\Http\Controllers\Install\InstallController@database');
        $router->post('/install/database', 'LinkHub\Http\Controllers\Install\InstallController@setupDatabase');
        $router->get('/install/admin', 'LinkHub\Http\Controllers\Install\InstallController@admin');
        $router->post('/install/admin', 'LinkHub\Http\Controllers\Install\InstallController@setupAdmin');
        $router->get('/install/complete', 'LinkHub\Http\Controllers\Install\InstallController@complete');
    }
}
