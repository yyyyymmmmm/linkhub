<?php

declare(strict_types=1);

namespace LinkHub\Providers;

use LinkHub\Core\Application;
use LinkHub\Core\ServiceProviderInterface;
use LinkHub\Core\Config\ConfigManager;

/**
 * 配置服务提供�? */
class ConfigServiceProvider implements ServiceProviderInterface
{
    protected \$app;
    
    public function __construct(\$app)
    {
        $this->app = $app;
    }
    
    /**
     * 注册服务
     */
    public function register()
    {
        $this->app->singleton(ConfigManager::class, function () {
            return new ConfigManager($this->app->basePath('config'));
        });
        
        // 加载环境变量
        $this->loadEnvironmentVariables();
    }
    
    /**
     * 启动服务
     */
    public function boot()
    {
        // 无需启动操作
    }
    
    /**
     * 加载环境变量
     */
    protected function loadEnvironmentVariables()
    {
        $envFile = $this->app->basePath('.env');
        
        if (file_exists($envFile)) {
            $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            
            foreach ($lines as $line) {
                // 忽略注释
                if (strpos(trim($line), '#') === 0) {
                    continue;
                }
                
                // 解析环境变量
                if (strpos($line, '=') !== false) {
                    list($name, $value) = explode('=', $line, 2);
                    $name = trim($name);
                    $value = trim($value);
                    
                    // 去除引号
                    if (strpos($value, '"') === 0 && strrpos($value, '"') === strlen($value) - 1) {
                        $value = substr($value, 1, -1);
                    } elseif (strpos($value, "'") === 0 && strrpos($value, "'") === strlen($value) - 1) {
                        $value = substr($value, 1, -1);
                    }
                    
                    // 设置环境变量
                    $_ENV[$name] = $value;
                    $_SERVER[$name] = $value;
                    putenv("{$name}={$value}");
                }
            }
        }
    }
}
