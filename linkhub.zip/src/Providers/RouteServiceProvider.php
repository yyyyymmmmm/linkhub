<?php

declare(strict_types=1);

namespace LinkHub\Providers;

use LinkHub\Core\Application;
use LinkHub\Core\ServiceProviderInterface;
use LinkHub\Core\Routing\Router;
use LinkHub\Core\View\ViewManager;
use LinkHub\Http\Controllers\HomeController;

/**
 * 路由服务提供�? */
class RouteServiceProvider implements ServiceProviderInterface
{
    protected \$app;
    
    public function __construct(\$app)
    {
        $this->app = $app;
    }
    
    /**
     * 注册服务
     */
    public function register()
    {
        // 注册路由�?        $this->app->singleton(Router::class, function () {
            return new Router($this->app);
        });
        
        // 注册视图管理�?        $this->app->singleton(ViewManager::class, function () {
            $viewManager = new ViewManager($this->app);
            $viewManager->setViewsPath($this->app->basePath('resources/views'));
            return $viewManager;
        });
        
        // 注册控制�?        $this->app->singleton('LinkHub\Controllers\HomeController', function () {
            return new \LinkHub\Controllers\HomeController();
        });
    }
    
    /**
     * 启动服务
     */
    public function boot()
    {
        $router = $this->app->make(Router::class);
        
        // 检查是否已安装
        $envFile = $this->app->basePath('/.env');
        $installFile = $this->app->basePath('/storage/installed');
        $isInstalled = file_exists($envFile) || file_exists($installFile);
        
        // 安装路由
        if (!$isInstalled) {
            $this->registerInstallRoutes($router);
            return;
        }
        
        // 前台路由
        $this->registerWebRoutes($router);
        
        // API路由
        $this->registerApiRoutes($router);
        
        // 管理后台路由
        $this->registerAdminRoutes($router);
    }
    
    /**
     * 注册安装路由
     */
    protected function registerInstallRoutes(Router $router)
    {
        $router->get('/install', 'LinkHub\Http\Controllers\Install\InstallController@index');
        $router->get('/install/database', 'LinkHub\Http\Controllers\Install\InstallController@database');
        $router->post('/install/setup-database', 'LinkHub\Http\Controllers\Install\InstallController@setupDatabase');
        $router->get('/install/admin', 'LinkHub\Http\Controllers\Install\InstallController@admin');
        $router->post('/install/setup-admin', 'LinkHub\Http\Controllers\Install\InstallController@setupAdmin');
        $router->get('/install/complete', 'LinkHub\Http\Controllers\Install\InstallController@complete');
    }
    
    /**
     * 注册前台路由
     */
    protected function registerWebRoutes(Router $router)
    {
        // 首页路由
        $router->get('/', 'LinkHub\Controllers\HomeController@index');
        $router->post('/', 'LinkHub\Controllers\HomeController@index');
        $router->get('/index.php', 'LinkHub\Controllers\HomeController@index');
        $router->post('/index.php', 'LinkHub\Controllers\HomeController@index');
        
        // 功能路由
        $router->get('/click/{id}', 'LinkHub\Controllers\HomeController@click');
        $router->get('/favicon', 'LinkHub\Controllers\HomeController@favicon');
        $router->get('/site-icon', 'LinkHub\Controllers\HomeController@siteIcon');
        
        // 登录相关路由
        $router->get('/login', 'LinkHub\Http\Controllers\Auth\LoginController@showLoginForm');
        $router->post('/login', 'LinkHub\Http\Controllers\Auth\LoginController@login');
        $router->get('/logout', 'LinkHub\Http\Controllers\Auth\LoginController@logout');
        
        // 分类页面
        $router->get('/category/{id}', 'LinkHub\Http\Controllers\CategoryController@show');
        
        // 链接点击 (兼容旧版)
        $router->get('/go/{id}', 'LinkHub\Http\Controllers\LinkController@redirect');
        
        // 分享页面
        $router->get('/share/{sid}', 'LinkHub\Http\Controllers\ShareController@show');
    }
    
    /**
     * 注册API路由
     */
    protected function registerApiRoutes(Router $router)
    {
        $router->group(['prefix' => 'api'], function (Router $router) {
            // 认证
            $router->post('/auth/login', 'LinkHub\Http\Controllers\Api\AuthController@login');
            $router->post('/auth/refresh', 'LinkHub\Http\Controllers\Api\AuthController@refresh');
            $router->post('/auth/logout', 'LinkHub\Http\Controllers\Api\AuthController@logout');
            
            // 需要认证的API
            $router->group(['middleware' => 'auth.api'], function (Router $router) {
                // 分类API
                $router->get('/categories', 'LinkHub\Http\Controllers\Api\CategoryController@index');
                $router->get('/categories/{id}', 'LinkHub\Http\Controllers\Api\CategoryController@show');
                $router->post('/categories', 'LinkHub\Http\Controllers\Api\CategoryController@store');
                $router->put('/categories/{id}', 'LinkHub\Http\Controllers\Api\CategoryController@update');
                $router->delete('/categories/{id}', 'LinkHub\Http\Controllers\Api\CategoryController@destroy');
                
                // 链接API
                $router->get('/links', 'LinkHub\Http\Controllers\Api\LinkController@index');
                $router->get('/links/{id}', 'LinkHub\Http\Controllers\Api\LinkController@show');
                $router->post('/links', 'LinkHub\Http\Controllers\Api\LinkController@store');
                $router->put('/links/{id}', 'LinkHub\Http\Controllers\Api\LinkController@update');
                $router->delete('/links/{id}', 'LinkHub\Http\Controllers\Api\LinkController@destroy');
                
                // 用户API
                $router->get('/user', 'LinkHub\Http\Controllers\Api\UserController@show');
                $router->put('/user', 'LinkHub\Http\Controllers\Api\UserController@update');
                $router->put('/user/password', 'LinkHub\Http\Controllers\Api\UserController@updatePassword');
            });
            
            // 公开API
            $router->get('/click/{id}', 'LinkHub\Http\Controllers\Api\LinkController@click');
        });
    }
    
    /**
     * 注册管理后台路由
     */
    protected function registerAdminRoutes(Router $router)
    {
        $router->group(['prefix' => 'admin', 'middleware' => 'auth.web'], function (Router $router) {
            // 仪表�?            $router->get('/', 'LinkHub\Http\Controllers\Admin\DashboardController@index');
            
            // 分类管理
            $router->get('/categories', 'LinkHub\Http\Controllers\Admin\CategoryController@index');
            $router->get('/categories/create', 'LinkHub\Http\Controllers\Admin\CategoryController@create');
            $router->post('/categories', 'LinkHub\Http\Controllers\Admin\CategoryController@store');
            $router->get('/categories/{id}/edit', 'LinkHub\Http\Controllers\Admin\CategoryController@edit');
            $router->put('/categories/{id}', 'LinkHub\Http\Controllers\Admin\CategoryController@update');
            $router->delete('/categories/{id}', 'LinkHub\Http\Controllers\Admin\CategoryController@destroy');
            $router->post('/categories/order', 'LinkHub\Http\Controllers\Admin\CategoryController@updateOrder');
            
            // 链接管理
            $router->get('/links', 'LinkHub\Http\Controllers\Admin\LinkController@index');
            $router->get('/links/create', 'LinkHub\Http\Controllers\Admin\LinkController@create');
            $router->post('/links', 'LinkHub\Http\Controllers\Admin\LinkController@store');
            $router->get('/links/{id}/edit', 'LinkHub\Http\Controllers\Admin\LinkController@edit');
            $router->put('/links/{id}', 'LinkHub\Http\Controllers\Admin\LinkController@update');
            $router->delete('/links/{id}', 'LinkHub\Http\Controllers\Admin\LinkController@destroy');
            $router->post('/links/order', 'LinkHub\Http\Controllers\Admin\LinkController@updateOrder');
            $router->post('/links/batch-move', 'LinkHub\Http\Controllers\Admin\LinkController@batchMove');
            $router->post('/links/batch-property', 'LinkHub\Http\Controllers\Admin\LinkController@batchSetProperty');
            
            // 设置
            $router->get('/settings', 'LinkHub\Http\Controllers\Admin\SettingController@index');
            $router->post('/settings', 'LinkHub\Http\Controllers\Admin\SettingController@update');
            
            // 主题
            $router->get('/themes', 'LinkHub\Http\Controllers\Admin\ThemeController@index');
            $router->get('/themes/{theme}/config', 'LinkHub\Http\Controllers\Admin\ThemeController@config');
            $router->post('/themes/{theme}/config', 'LinkHub\Http\Controllers\Admin\ThemeController@saveConfig');
            $router->post('/themes/{theme}/activate', 'LinkHub\Http\Controllers\Admin\ThemeController@activate');
            
            // 备份
            $router->get('/backup', 'LinkHub\Http\Controllers\Admin\BackupController@index');
            $router->post('/backup', 'LinkHub\Http\Controllers\Admin\BackupController@create');
            $router->get('/backup/{id}/download', 'LinkHub\Http\Controllers\Admin\BackupController@download');
            $router->delete('/backup/{id}', 'LinkHub\Http\Controllers\Admin\BackupController@destroy');
            $router->post('/backup/{id}/restore', 'LinkHub\Http\Controllers\Admin\BackupController@restore');
            
            // 用户管理
            $router->get('/user', 'LinkHub\Http\Controllers\Admin\UserController@index');
            $router->get('/user/profile', 'LinkHub\Http\Controllers\Admin\UserController@profile');
            $router->post('/user/profile', 'LinkHub\Http\Controllers\Admin\UserController@updateProfile');
            $router->get('/user/password', 'LinkHub\Http\Controllers\Admin\UserController@password');
            $router->post('/user/password', 'LinkHub\Http\Controllers\Admin\UserController@updatePassword');
        });
    }
}
