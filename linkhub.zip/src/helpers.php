<?php

/**
 * OneNav Professional 助手函数
 */

if (!function_exists('str_contains')) {
    /**
     * 检查字符串是否包含给定的子字符�?     * PHP 8.0+ 兼容性函�?     */
    function str_contains(string $haystack, string $needle)
    {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

if (!function_exists('str_starts_with')) {
    /**
     * 检查字符串是否以给定的子字符串开�?     * PHP 8.0+ 兼容性函�?     */
    function str_starts_with(string $haystack, string $needle)
    {
        return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

if (!function_exists('str_ends_with')) {
    /**
     * 检查字符串是否以给定的子字符串结尾
     * PHP 8.0+ 兼容性函�?     */
    function str_ends_with(string $haystack, string $needle)
    {
        return $needle === '' || substr($haystack, -strlen($needle)) === $needle;
    }
}

if (!function_exists('env')) {
    /**
     * 获取环境变量�?     */
    function env(string $key, $default = null)
    {
        $value = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);
        
        if ($value === false) {
            return $default;
        }
        
        switch (strtolower($value)) {
            case 'true':
            case '(true)':
                return true;
            case 'false':
            case '(false)':
                return false;
            case 'empty':
            case '(empty)':
                return '';
            case 'null':
            case '(null)':
                return null;
        }
        
        if (strlen($value) > 1 && $value[0] === '"' && $value[strlen($value) - 1] === '"') {
            return substr($value, 1, -1);
        }
        
        return $value;
    }
}

if (!function_exists('app')) {
    /**
     * 获取应用实例或从容器中解析实�?     */
    function app(?string $abstract = null, array $parameters = [])
    {
        $app = \LinkHub\Core\Application::getInstance();
        
        if ($abstract === null) {
            return $app;
        }
        
        return $app->make($abstract, $parameters);
    }
}

if (!function_exists('config')) {
    /**
     * 获取配置�?     */
    function config(string $key = null, $default = null)
    {
        $config = app(\LinkHub\Core\Config\ConfigManager::class);
        
        if ($key === null) {
            return $config;
        }
        
        return $config->get($key, $default);
    }
}

if (!function_exists('base_path')) {
    /**
     * 获取应用基础路径
     */
    function base_path(string $path = '')
    {
        return app()->basePath($path);
    }
}

if (!function_exists('storage_path')) {
    /**
     * 获取存储路径
     */
    function storage_path(string $path = '')
    {
        return base_path('storage/' . $path);
    }
}

if (!function_exists('public_path')) {
    /**
     * 获取公共路径
     */
    function public_path(string $path = '')
    {
        return base_path('public/' . $path);
    }
}

if (!function_exists('resource_path')) {
    /**
     * 获取资源路径
     */
    function resource_path(string $path = '')
    {
        return base_path('resources/' . $path);
    }
}

if (!function_exists('view')) {
    /**
     * 获取视图实例或渲染视�?     */
    function view(string $view = null, array $data = [])
    {
        $viewManager = app(\LinkHub\Core\View\ViewManager::class);
        
        if ($view === null) {
            return $viewManager;
        }
        
        return $viewManager->render($view, $data);
    }
}

if (!function_exists('redirect')) {
    /**
     * 创建重定向响�?     */
    function redirect(string $url, int $statusCode = 302): \LinkHub\Core\Http\Response
    {
        return \LinkHub\Core\Http\Response::redirect($url, $statusCode);
    }
}

if (!function_exists('response')) {
    /**
     * 创建响应
     */
    function response($content = '', int $statusCode = 200, array $headers = []): \LinkHub\Core\Http\Response
    {
        return new \LinkHub\Core\Http\Response($content, $statusCode, $headers);
    }
}

if (!function_exists('json')) {
    /**
     * 创建JSON响应
     */
    function json($data, int $statusCode = 200, array $headers = []): \LinkHub\Core\Http\Response
    {
        return \LinkHub\Core\Http\Response::json($data, $statusCode, $headers);
    }
}

if (!function_exists('session')) {
    /**
     * 获取或设置会话�?     */
    function session($key = null, $default = null)
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        if ($key === null) {
            return $_SESSION;
        }
        
        if (func_num_args() === 1) {
            return $_SESSION[$key] ?? $default;
        }
        
        $_SESSION[$key] = func_get_arg(1);
        
        return null;
    }
}

if (!function_exists('csrf_token')) {
    /**
     * 获取CSRF令牌
     */
    function csrf_token()
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        if (!isset($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }
        
        return $_SESSION['_csrf_token'];
    }
}

if (!function_exists('csrf_field')) {
    /**
     * 生成CSRF字段HTML
     */
    function csrf_field()
    {
        return '<input type="hidden" name="_token" value="' . csrf_token() . '">';
    }
}

if (!function_exists('method_field')) {
    /**
     * 生成方法字段HTML
     */
    function method_field(string $method)
    {
        return '<input type="hidden" name="_method" value="' . $method . '">';
    }
}

if (!function_exists('old')) {
    /**
     * 获取旧输入�?     */
    function old(string $key, $default = null)
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        return $_SESSION['_old_input'][$key] ?? $default;
    }
}

if (!function_exists('asset')) {
    /**
     * 获取资源URL
     */
    function asset(string $path)
    {
        return rtrim(env('APP_URL', ''), '/') . '/' . ltrim($path, '/');
    }
}
