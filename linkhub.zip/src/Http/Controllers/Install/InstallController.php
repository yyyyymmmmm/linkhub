<?php

declare(strict_types=1);

namespace LinkHub\Http\Controllers\Install;

use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;
use LinkHub\Core\View\ViewManager;
use PDO;
use PDOException;

/**
 * 安装控制�? */
class InstallController
{
    /**
     * @var ViewManager 视图管理�?     */
    protected \$view;
    
    /**
     * @var string 应用基础路径
     */
    protected \$basePath;
    
    /**
     * 构造函�?     */
    public function __construct(\$view)
    {
        $this->view = $view;
        $this->basePath = dirname(dirname(dirname(dirname(__DIR__))));
    }
    
    /**
     * 显示安装首页
     */
    public function index(Request $request): Response
    {
        // 检查是否已安装
        if ($this->isInstalled()) {
            return Response::redirect('/');
        }
        
        return $this->renderView('install/index', [
            'step' => 1,
        ]);
    }
    
    /**
     * 显示环境要求页面
     */
    public function requirements(Request $request): Response
    {
        // 检查是否已安装
        if ($this->isInstalled()) {
            return Response::redirect('/');
        }
        
        $requirements = $this->checkRequirements();
        
        return $this->renderView('install/requirements', [
            'step' => 1,
            'requirements' => $requirements,
        ]);
    }
    
    /**
     * 显示数据库配置页�?     */
    public function database(Request $request): Response
    {
        // 检查是否已安装
        if ($this->isInstalled()) {
            return Response::redirect('/');
        }
        
        // 检查环境要�?        $requirements = $this->checkRequirements();
        if (!$requirements['success']) {
            return Response::redirect('/install/requirements');
        }
        
        return $this->renderView('install/database', [
            'step' => 2,
        ]);
    }
    
    /**
     * 处理数据库配�?     */
    public function setupDatabase(Request $request): Response
    {
        // 检查是否已安装
        if ($this->isInstalled()) {
            return Response::redirect('/');
        }
        
        $dbType = $request->request('db_type', 'sqlite');
        $dbHost = $request->request('db_host', 'localhost');
        $dbPort = (int)$request->request('db_port', 3306);
        $dbName = $request->request('db_name', 'onenav');
        $dbUser = $request->request('db_user', 'root');
        $dbPass = $request->request('db_pass', '');
        $dbPrefix = $request->request('db_prefix', 'on_');
        
        // 测试数据库连�?        try {
            if ($dbType === 'mysql') {
                $dsn = "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4";
                $pdo = new PDO($dsn, $dbUser, $dbPass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
                
                // 检查数据库是否存在，不存在则创�?                $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                
                // 切换到指定数据库
                $pdo->exec("USE `{$dbName}`");
            } else {
                // SQLite
                $dbFile = $this->basePath . '/storage/database/onenav.db3';
                $dbDir = dirname($dbFile);
                
                // 确保数据库目录存�?                if (!is_dir($dbDir)) {
                    mkdir($dbDir, 0755, true);
                }
                
                $dsn = "sqlite:{$dbFile}";
                $pdo = new PDO($dsn);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            
            // 创建数据库表
            $this->createTables($pdo, $dbType, $dbPrefix);
            
            // 生成.env文件
            $this->generateEnvFile($dbType, $dbHost, $dbPort, $dbName, $dbUser, $dbPass, $dbPrefix);
            
            // 重定向到管理员设置页�?            return Response::redirect('/install/admin');
        } catch (PDOException $e) {
            return $this->renderView('install/database', [
                'step' => 2,
                'error' => '数据库连接失�? ' . $e->getMessage(),
                'db_type' => $dbType,
                'db_host' => $dbHost,
                'db_port' => $dbPort,
                'db_name' => $dbName,
                'db_user' => $dbUser,
                'db_prefix' => $dbPrefix
            ]);
        } catch (\Exception $e) {
            return $this->renderView('install/database', [
                'step' => 2,
                'error' => '安装错误: ' . $e->getMessage(),
                'db_type' => $dbType,
                'db_host' => $dbHost,
                'db_port' => $dbPort,
                'db_name' => $dbName,
                'db_user' => $dbUser,
                'db_prefix' => $dbPrefix
            ]);
        }
    }
    
    /**
     * 显示管理员设置页�?     */
    public function admin(Request $request): Response
    {
        // 检查是否已安装
        if ($this->isInstalled() && $this->isAdminCreated()) {
            return Response::redirect('/');
        }
        
        // 检查是否已配置数据�?        $envFile = $this->basePath . '/.env';
        if (!file_exists($envFile)) {
            return Response::redirect('/install/database');
        }
        
        return $this->renderView('install/admin', [
            'step' => 3,
        ]);
    }
    
    /**
     * 处理管理员设�?     */
    public function setupAdmin(Request $request): Response
    {
        // 检查是否已安装
        if ($this->isInstalled() && $this->isAdminCreated()) {
            return Response::redirect('/');
        }
        
        $username = $request->request('username');
        $password = $request->request('password');
        $confirmPassword = $request->request('confirm_password');
        $email = $request->request('email');
        
        // 验证输入
        $errors = [];
        
        if (empty($username)) {
            $errors['username'] = '用户名不能为�?;
        } elseif (strlen($username) < 3 || strlen($username) > 20) {
            $errors['username'] = '用户名长度必须在3-20个字符之�?;
        }
        
        if (empty($password)) {
            $errors['password'] = '密码不能为空';
        } elseif (strlen($password) < 6) {
            $errors['password'] = '密码长度不能少于6个字�?;
        }
        
        if ($password !== $confirmPassword) {
            $errors['confirm_password'] = '两次输入的密码不一�?;
        }
        
        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = '邮箱格式不正�?;
        }
        
        if (!empty($errors)) {
            return $this->renderView('install/admin', [
                'step' => 3,
                'errors' => $errors,
                'username' => $username,
                'email' => $email
            ]);
        }
        
        try {
            // 获取数据库连�?            $dbConfig = $this->getDatabaseConfig();
            
            if ($dbConfig['driver'] === 'sqlite') {
                $dsn = "sqlite:" . $dbConfig['database'];
                $pdo = new PDO($dsn);
            } else {
                $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset=utf8mb4";
                $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            }
            
            // 创建管理员账�?            $passwordHash = password_hash($password, PASSWORD_ARGON2ID, [
                'memory_cost' => 65536, // 64 MB
                'time_cost' => 4,       // 4 iterations
                'threads' => 3,         // 3 threads
            ]);
            
            $table = $dbConfig['prefix'] . 'users';
            $stmt = $pdo->prepare("INSERT INTO {$table} (username, password, email, role, add_time) VALUES (?, ?, ?, 1, ?)");
            $stmt->execute([$username, $passwordHash, $email, time()]);
            
            // 标记安装完成
            $this->markInstallComplete();
            
            // 重定向到完成页面
            return Response::redirect('/install/complete?username=' . urlencode($username));
        } catch (PDOException $e) {
            return $this->renderView('install/admin', [
                'step' => 3,
                'error' => '创建管理员失�? ' . $e->getMessage(),
                'username' => $username,
                'email' => $email
            ]);
        } catch (\Exception $e) {
            return $this->renderView('install/admin', [
                'step' => 3,
                'error' => '安装错误: ' . $e->getMessage(),
                'username' => $username,
                'email' => $email
            ]);
        }
    }
    
    /**
     * 显示安装完成页面
     */
    public function complete(Request $request): Response
    {
        // 检查是否已安装
        if (!$this->isInstalled()) {
            return Response::redirect('/install');
        }
        
        $username = $request->query('username');
        
        return $this->renderView('install/complete', [
            'step' => 4,
            'username' => $username,
        ]);
    }
    
    /**
     * 检查是否已安装
     */
    protected function isInstalled()
    {
        $envFile = $this->basePath . '/.env';
        $installFile = $this->basePath . '/storage/installed';
        return file_exists($envFile) || file_exists($installFile);
    }
    
    /**
     * 检查是否已创建管理�?     */
    protected function isAdminCreated()
    {
        try {
            $dbConfig = $this->getDatabaseConfig();
            
            if ($dbConfig['driver'] === 'sqlite') {
                $dsn = "sqlite:" . $dbConfig['database'];
                $pdo = new PDO($dsn);
            } else {
                $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['database']};charset=utf8mb4";
                $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password']);
            }
            
            $table = $dbConfig['prefix'] . 'users';
            $stmt = $pdo->query("SELECT COUNT(*) FROM {$table}");
            $count = $stmt->fetchColumn();
            
            return $count > 0;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    /**
     * 获取数据库配�?     */
    protected function getDatabaseConfig()
    {
        $envFile = $this->basePath . '/.env';
        
        if (!file_exists($envFile)) {
            return [
                'driver' => 'sqlite',
                'database' => $this->basePath . '/storage/database/onenav.db3',
                'prefix' => 'on_'
            ];
        }
        
        $env = parse_ini_file($envFile);
        
        if ($env['DB_CONNECTION'] === 'sqlite') {
            return [
                'driver' => 'sqlite',
                'database' => $this->basePath . '/' . ($env['DB_DATABASE'] ?? 'storage/database/onenav.db3'),
                'prefix' => $env['DB_PREFIX'] ?? 'on_'
            ];
        } else {
            return [
                'driver' => 'mysql',
                'host' => $env['DB_HOST'] ?? 'localhost',
                'port' => $env['DB_PORT'] ?? 3306,
                'database' => $env['DB_DATABASE'] ?? 'onenav',
                'username' => $env['DB_USERNAME'] ?? 'root',
                'password' => $env['DB_PASSWORD'] ?? '',
                'prefix' => $env['DB_PREFIX'] ?? 'on_'
            ];
        }
    }
    
    /**
     * 生成.env文件
     */
    protected function generateEnvFile(string $dbType, string $dbHost, int $dbPort, string $dbName, string $dbUser, string $dbPass, string $dbPrefix)
    {
        $envFile = $this->basePath . '/.env';
        $content = "APP_NAME=LinkHub\n";
        $content .= "APP_ENV=production\n";
        $content .= "APP_DEBUG=false\n";
        $content .= "APP_URL=http://{$_SERVER['HTTP_HOST']}\n\n";
        
        $content .= "DB_CONNECTION={$dbType}\n";
        
        if ($dbType === 'mysql') {
            $content .= "DB_HOST={$dbHost}\n";
            $content .= "DB_PORT={$dbPort}\n";
            $content .= "DB_DATABASE={$dbName}\n";
            $content .= "DB_USERNAME={$dbUser}\n";
            $content .= "DB_PASSWORD={$dbPass}\n";
        } else {
            $content .= "DB_DATABASE=storage/database/onenav.db3\n";
        }
        
        $content .= "DB_PREFIX={$dbPrefix}\n\n";
        
        $content .= "CACHE_DRIVER=file\n";
        $content .= "SESSION_DRIVER=file\n";
        $content .= "SESSION_LIFETIME=120\n\n";
        
        $content .= "LOG_CHANNEL=daily\n";
        $content .= "LOG_LEVEL=warning\n\n";
        
        $content .= "THEME_DEFAULT=default\n";
        $content .= "THEME_ADMIN=admin\n";
        $content .= "THEME_MOBILE=default\n\n";
        
        $content .= "INSTALLED=false\n";
        
        file_put_contents($envFile, $content);
    }
    
    /**
     * 标记安装完成
     */
    protected function markInstallComplete()
    {
        $envFile = $this->basePath . '/.env';
        $installFile = $this->basePath . '/storage/installed';
        
        if (file_exists($envFile)) {
            $content = file_get_contents($envFile);
            $content = str_replace("INSTALLED=false", "INSTALLED=true", $content);
            file_put_contents($envFile, $content);
        }
        
        file_put_contents($installFile, date('Y-m-d H:i:s'));
    }
    
    /**
     * 创建数据库表
     */
    protected function createTables(PDO $pdo, string $dbType, string $prefix = 'on_')
    {
        $sqlFile = $dbType === 'mysql' 
            ? $this->basePath . '/database/mysql.sql' 
            : $this->basePath . '/database/sqlite.sql';
        
        if (!file_exists($sqlFile)) {
            throw new \Exception('SQL文件不存�? ' . $sqlFile);
        }
        
        $sql = file_get_contents($sqlFile);
        $sql = str_replace('on_', $prefix, $sql);
        
        // 分割SQL语句
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        
        // 开始事�?        $pdo->beginTransaction();
        
        try {
            foreach ($statements as $statement) {
                if (!empty($statement)) {
                    $pdo->exec($statement);
                }
            }
            
            $pdo->commit();
        } catch (PDOException $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
    
    /**
     * 检查环境要�?     */
    protected function checkRequirements()
    {
        $requirements = [
            'php' => [
                'version' => PHP_VERSION,
                'required' => '7.4.0',
                'status' => version_compare(PHP_VERSION, '7.4.0', '>='),
            ],
            'extensions' => [
                'pdo' => extension_loaded('pdo'),
                'pdo_mysql' => extension_loaded('pdo_mysql'),
                'pdo_sqlite' => extension_loaded('pdo_sqlite'),
                'json' => extension_loaded('json'),
                'mbstring' => extension_loaded('mbstring'),
            ],
            'directories' => [
                'storage' => is_writable($this->basePath . '/storage'),
                'storage/database' => is_writable($this->basePath . '/storage/database'),
                'storage/cache' => is_writable($this->basePath . '/storage/cache'),
                'storage/logs' => is_writable($this->basePath . '/storage/logs'),
                'storage/uploads' => is_writable($this->basePath . '/storage/uploads'),
            ],
        ];
        
        $success = true;
        
        if (version_compare(PHP_VERSION, '7.4.0', '<')) {
            $success = false;
        }
        
        foreach ($requirements['extensions'] as $extension => $loaded) {
            if (!$loaded) {
                $success = false;
                break;
            }
        }
        
        foreach ($requirements['directories'] as $directory => $writable) {
            if (!$writable) {
                $success = false;
                break;
            }
        }
        
        $requirements['success'] = $success;
        
        return $requirements;
    }
    
    /**
     * 渲染视图
     */
    protected function renderView(string $view, array $data = []): Response
    {
        try {
            $content = $this->view->render($view, $data);
            return new Response($content);
        } catch (\Exception $e) {
            // 如果视图不存在，尝试使用PHP原生方式渲染
            $viewFile = $this->basePath . '/resources/views/' . $view . '.php';
            
            if (file_exists($viewFile)) {
                ob_start();
                extract($data);
                include $viewFile;
                $content = ob_get_clean();
                return new Response($content);
            }
            
            return new Response('视图不存�? ' . $view, 500);
        }
    }
}
