<?php

namespace LinkHub\Http\Controllers\Api;

use LinkHub\Core\Http\Request;

/**
 * 链接API控制器
 */
class LinkController extends ApiController
{
    /**
     * 获取链接列表
     * GET /api/links
     */
    public function index(Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 获取分页参数
            list($page, $perPage, $offset) = $this->getPaginationParams($request);
            
            // 获取排序参数
            list($sortBy, $sortOrder) = $this->getSortParams($request, ['id', 'title', 'click', 'weight', 'add_time']);
            
            // 构建查询
            $whereClause = "WHERE l.property = 0";
            $params = [];
            
            // 分类筛选
            if ($categoryId = $request->input('category_id')) {
                $whereClause .= " AND l.fid = ?";
                $params[] = $categoryId;
            }
            
            // 搜索功能
            if ($search = $request->input('search')) {
                $whereClause .= " AND (l.title LIKE ? OR l.note LIKE ? OR l.url LIKE ?)";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
            }
            
            // 获取总数
            $countSql = "SELECT COUNT(*) FROM {$tablePrefix}links l {$whereClause}";
            $countStmt = $pdo->prepare($countSql);
            $countStmt->execute($params);
            $total = $countStmt->fetchColumn();
            
            // 获取数据
            $sql = "SELECT 
                        l.id, 
                        l.title, 
                        l.url, 
                        l.note, 
                        l.font_icon as icon, 
                        l.icon_color, 
                        l.click, 
                        l.weight, 
                        l.fid as category_id,
                        l.add_time,
                        c.name as category_name
                    FROM {$tablePrefix}links l
                    LEFT JOIN {$tablePrefix}categorys c ON l.fid = c.id
                    {$whereClause} 
                    ORDER BY l.{$sortBy} {$sortOrder} 
                    LIMIT {$offset}, {$perPage}";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $links = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            // 格式化数据
            foreach ($links as &$link) {
                $link['id'] = (int)$link['id'];
                $link['click'] = (int)$link['click'];
                $link['weight'] = (int)$link['weight'];
                $link['category_id'] = (int)$link['category_id'];
                $link['add_time'] = date('Y-m-d H:i:s', $link['add_time']);
                $link['icon'] = $link['icon'] ?: 'fa-link';
                $link['icon_color'] = $link['icon_color'] ?: '#6b7280';
                $link['domain'] = parse_url($link['url'], PHP_URL_HOST);
                $link['favicon_url'] = "/favicon?url=" . urlencode($link['url']);
            }
            
            return $this->paginated($links, $total, $page, $perPage);
            
        } catch (\Exception $e) {
            return $this->error('获取链接列表失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 获取单个链接详情
     * GET /api/links/{id}
     */
    public function show(Request $request, $id)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            $sql = "SELECT 
                        l.id, 
                        l.title, 
                        l.url, 
                        l.note, 
                        l.font_icon as icon, 
                        l.icon_color, 
                        l.click, 
                        l.weight, 
                        l.fid as category_id,
                        l.add_time,
                        c.name as category_name
                    FROM {$tablePrefix}links l
                    LEFT JOIN {$tablePrefix}categorys c ON l.fid = c.id
                    WHERE l.id = ? AND l.property = 0";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id]);
            $link = $stmt->fetch(\PDO::FETCH_ASSOC);
            
            if (!$link) {
                return $this->error('链接不存在', 404);
            }
            
            // 格式化数据
            $link['id'] = (int)$link['id'];
            $link['click'] = (int)$link['click'];
            $link['weight'] = (int)$link['weight'];
            $link['category_id'] = (int)$link['category_id'];
            $link['add_time'] = date('Y-m-d H:i:s', $link['add_time']);
            $link['icon'] = $link['icon'] ?: 'fa-link';
            $link['icon_color'] = $link['icon_color'] ?: '#6b7280';
            $link['domain'] = parse_url($link['url'], PHP_URL_HOST);
            $link['favicon_url'] = "/favicon?url=" . urlencode($link['url']);
            
            // 获取点击统计
            if ($request->input('include_stats') === 'true') {
                $statsSql = "SELECT 
                                DATE(FROM_UNIXTIME(click_time)) as date,
                                COUNT(*) as clicks
                            FROM {$tablePrefix}clicks 
                            WHERE link_id = ? 
                            GROUP BY DATE(FROM_UNIXTIME(click_time))
                            ORDER BY date DESC 
                            LIMIT 30";
                
                $statsStmt = $pdo->prepare($statsSql);
                $statsStmt->execute([$id]);
                $stats = $statsStmt->fetchAll(\PDO::FETCH_ASSOC);
                
                $link['click_stats'] = $stats;
            }
            
            return $this->success($link);
            
        } catch (\Exception $e) {
            return $this->error('获取链接详情失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 创建链接
     * POST /api/links
     */
    public function store(Request $request)
    {
        try {
            // 验证输入
            $validation = $this->validate($request, [
                'title' => 'required|min:1|max:100',
                'url' => 'required|url|max:500',
                'category_id' => 'required|integer',
                'note' => 'max:300',
                'icon' => 'max:50',
                'icon_color' => 'max:10',
                'weight' => 'integer'
            ]);
            
            if ($validation !== true) {
                return $this->error('参数验证失败', 422, $validation);
            }
            
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查分类是否存在
            $checkCategorySql = "SELECT COUNT(*) FROM {$tablePrefix}categorys WHERE id = ? AND property = 0";
            $checkCategoryStmt = $pdo->prepare($checkCategorySql);
            $checkCategoryStmt->execute([$request->input('category_id')]);
            
            if ($checkCategoryStmt->fetchColumn() == 0) {
                return $this->error('指定的分类不存在', 422);
            }
            
            // 检查URL是否重复
            $checkUrlSql = "SELECT COUNT(*) FROM {$tablePrefix}links WHERE url = ? AND property = 0";
            $checkUrlStmt = $pdo->prepare($checkUrlSql);
            $checkUrlStmt->execute([$request->input('url')]);
            
            if ($checkUrlStmt->fetchColumn() > 0) {
                return $this->error('该URL已存在', 422);
            }
            
            // 插入数据
            $sql = "INSERT INTO {$tablePrefix}links 
                    (fid, title, url, note, font_icon, icon_color, weight, click, property, add_time) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, ?)";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                $request->input('category_id'),
                $request->input('title'),
                $request->input('url'),
                $request->input('note', ''),
                $request->input('icon', 'fa-link'),
                $request->input('icon_color', '#6b7280'),
                $request->input('weight', 100),
                time()
            ]);
            
            if ($result) {
                $linkId = $pdo->lastInsertId();
                return $this->success(['id' => (int)$linkId], '链接创建成功', 201);
            } else {
                return $this->error('链接创建失败', 500);
            }
            
        } catch (\Exception $e) {
            return $this->error('链接创建失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 更新链接
     * PUT /api/links/{id}
     */
    public function update(Request $request, $id)
    {
        try {
            // 验证输入
            $validation = $this->validate($request, [
                'title' => 'required|min:1|max:100',
                'url' => 'required|url|max:500',
                'category_id' => 'required|integer',
                'note' => 'max:300',
                'icon' => 'max:50',
                'icon_color' => 'max:10',
                'weight' => 'integer'
            ]);
            
            if ($validation !== true) {
                return $this->error('参数验证失败', 422, $validation);
            }
            
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查链接是否存在
            $checkSql = "SELECT COUNT(*) FROM {$tablePrefix}links WHERE id = ? AND property = 0";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute([$id]);
            
            if ($checkStmt->fetchColumn() == 0) {
                return $this->error('链接不存在', 404);
            }
            
            // 检查分类是否存在
            $checkCategorySql = "SELECT COUNT(*) FROM {$tablePrefix}categorys WHERE id = ? AND property = 0";
            $checkCategoryStmt = $pdo->prepare($checkCategorySql);
            $checkCategoryStmt->execute([$request->input('category_id')]);
            
            if ($checkCategoryStmt->fetchColumn() == 0) {
                return $this->error('指定的分类不存在', 422);
            }
            
            // 检查URL是否重复（排除自己）
            $checkUrlSql = "SELECT COUNT(*) FROM {$tablePrefix}links WHERE url = ? AND id != ? AND property = 0";
            $checkUrlStmt = $pdo->prepare($checkUrlSql);
            $checkUrlStmt->execute([$request->input('url'), $id]);
            
            if ($checkUrlStmt->fetchColumn() > 0) {
                return $this->error('该URL已存在', 422);
            }
            
            // 更新数据
            $sql = "UPDATE {$tablePrefix}links 
                    SET fid = ?, title = ?, url = ?, note = ?, font_icon = ?, icon_color = ?, weight = ? 
                    WHERE id = ? AND property = 0";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                $request->input('category_id'),
                $request->input('title'),
                $request->input('url'),
                $request->input('note', ''),
                $request->input('icon', 'fa-link'),
                $request->input('icon_color', '#6b7280'),
                $request->input('weight', 100),
                $id
            ]);
            
            if ($result) {
                return $this->success(['id' => (int)$id], '链接更新成功');
            } else {
                return $this->error('链接更新失败', 500);
            }
            
        } catch (\Exception $e) {
            return $this->error('链接更新失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 删除链接
     * DELETE /api/links/{id}
     */
    public function destroy(Request $request, $id)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查链接是否存在
            $checkSql = "SELECT COUNT(*) FROM {$tablePrefix}links WHERE id = ? AND property = 0";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute([$id]);
            
            if ($checkStmt->fetchColumn() == 0) {
                return $this->error('链接不存在', 404);
            }
            
            // 删除链接（软删除）
            $sql = "UPDATE {$tablePrefix}links SET property = 1 WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([$id]);
            
            if ($result) {
                return $this->success(['id' => (int)$id], '链接删除成功');
            } else {
                return $this->error('链接删除失败', 500);
            }
            
        } catch (\Exception $e) {
            return $this->error('链接删除失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 点击链接（统计）
     * POST /api/links/{id}/click
     */
    public function click(Request $request, $id)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查链接是否存在
            $checkSql = "SELECT url FROM {$tablePrefix}links WHERE id = ? AND property = 0";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute([$id]);
            $link = $checkStmt->fetch(\PDO::FETCH_ASSOC);
            
            if (!$link) {
                return $this->error('链接不存在', 404);
            }
            
            // 更新点击次数
            $updateSql = "UPDATE {$tablePrefix}links SET click = click + 1 WHERE id = ?";
            $updateStmt = $pdo->prepare($updateSql);
            $updateStmt->execute([$id]);
            
            // 记录点击日志
            $logSql = "INSERT INTO {$tablePrefix}clicks (link_id, ip, user_agent, referer, click_time) VALUES (?, ?, ?, ?, ?)";
            $logStmt = $pdo->prepare($logSql);
            $logStmt->execute([
                $id,
                $_SERVER['REMOTE_ADDR'] ?? '',
                $_SERVER['HTTP_USER_AGENT'] ?? '',
                $_SERVER['HTTP_REFERER'] ?? '',
                time()
            ]);
            
            return $this->success(['url' => $link['url']], '点击记录成功');
            
        } catch (\Exception $e) {
            return $this->error('点击记录失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 批量操作
     * POST /api/links/batch
     */
    public function batch(Request $request)
    {
        try {
            $action = $request->input('action');
            $ids = $request->input('ids', []);
            
            if (empty($ids) || !is_array($ids)) {
                return $this->error('请选择要操作的链接', 422);
            }
            
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            $placeholders = str_repeat('?,', count($ids) - 1) . '?';
            
            switch ($action) {
                case 'delete':
                    $sql = "UPDATE {$tablePrefix}links SET property = 1 WHERE id IN ({$placeholders}) AND property = 0";
                    break;
                case 'move':
                    $categoryId = $request->input('category_id');
                    if (!$categoryId) {
                        return $this->error('请指定目标分类', 422);
                    }
                    $sql = "UPDATE {$tablePrefix}links SET fid = ? WHERE id IN ({$placeholders}) AND property = 0";
                    array_unshift($ids, $categoryId);
                    break;
                default:
                    return $this->error('不支持的操作', 422);
            }
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute($ids);
            
            if ($result) {
                return $this->success(['affected' => $stmt->rowCount()], '批量操作成功');
            } else {
                return $this->error('批量操作失败', 500);
            }
            
        } catch (\Exception $e) {
            return $this->error('批量操作失败: ' . $e->getMessage(), 500);
        }
    }
}
