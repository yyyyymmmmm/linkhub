<?php

namespace LinkHub\Http\Controllers\Api;

use LinkHub\Core\Http\Request;

/**
 * 分类API控制器
 */
class CategoryController extends ApiController
{
    /**
     * 获取分类列表
     * GET /api/categories
     */
    public function index(Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 获取分页参数
            list($page, $perPage, $offset) = $this->getPaginationParams($request);
            
            // 获取排序参数
            list($sortBy, $sortOrder) = $this->getSortParams($request, ['id', 'name', 'weight', 'add_time']);
            
            // 构建查询
            $whereClause = "WHERE property = 0";
            $params = [];
            
            // 搜索功能
            if ($search = $request->input('search')) {
                $whereClause .= " AND name LIKE ?";
                $params[] = "%{$search}%";
            }
            
            // 获取总数
            $countSql = "SELECT COUNT(*) FROM {$tablePrefix}categorys {$whereClause}";
            $countStmt = $pdo->prepare($countSql);
            $countStmt->execute($params);
            $total = $countStmt->fetchColumn();
            
            // 获取数据
            $sql = "SELECT 
                        id, 
                        name, 
                        font_icon as icon, 
                        icon_color, 
                        description, 
                        weight, 
                        add_time,
                        (SELECT COUNT(*) FROM {$tablePrefix}links WHERE fid = {$tablePrefix}categorys.id AND property = 0) as links_count
                    FROM {$tablePrefix}categorys 
                    {$whereClause} 
                    ORDER BY {$sortBy} {$sortOrder} 
                    LIMIT {$offset}, {$perPage}";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $categories = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            // 格式化数据
            foreach ($categories as &$category) {
                $category['id'] = (int)$category['id'];
                $category['weight'] = (int)$category['weight'];
                $category['links_count'] = (int)$category['links_count'];
                $category['add_time'] = date('Y-m-d H:i:s', $category['add_time']);
                $category['icon'] = $category['icon'] ?: 'fa-folder';
                $category['icon_color'] = $category['icon_color'] ?: '#6366f1';
            }
            
            return $this->paginated($categories, $total, $page, $perPage);
            
        } catch (\Exception $e) {
            return $this->error('获取分类列表失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 获取单个分类详情
     * GET /api/categories/{id}
     */
    public function show(Request $request, $id)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            $sql = "SELECT 
                        id, 
                        name, 
                        font_icon as icon, 
                        icon_color, 
                        description, 
                        weight, 
                        add_time,
                        (SELECT COUNT(*) FROM {$tablePrefix}links WHERE fid = {$tablePrefix}categorys.id AND property = 0) as links_count
                    FROM {$tablePrefix}categorys 
                    WHERE id = ? AND property = 0";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$id]);
            $category = $stmt->fetch(\PDO::FETCH_ASSOC);
            
            if (!$category) {
                return $this->error('分类不存在', 404);
            }
            
            // 格式化数据
            $category['id'] = (int)$category['id'];
            $category['weight'] = (int)$category['weight'];
            $category['links_count'] = (int)$category['links_count'];
            $category['add_time'] = date('Y-m-d H:i:s', $category['add_time']);
            $category['icon'] = $category['icon'] ?: 'fa-folder';
            $category['icon_color'] = $category['icon_color'] ?: '#6366f1';
            
            // 是否包含链接
            if ($request->input('include_links') === 'true') {
                $linksSql = "SELECT 
                                id, 
                                title, 
                                url, 
                                note, 
                                font_icon as icon, 
                                icon_color, 
                                click, 
                                weight,
                                add_time
                            FROM {$tablePrefix}links 
                            WHERE fid = ? AND property = 0 
                            ORDER BY weight DESC, add_time DESC";
                
                $linksStmt = $pdo->prepare($linksSql);
                $linksStmt->execute([$id]);
                $links = $linksStmt->fetchAll(\PDO::FETCH_ASSOC);
                
                // 格式化链接数据
                foreach ($links as &$link) {
                    $link['id'] = (int)$link['id'];
                    $link['click'] = (int)$link['click'];
                    $link['weight'] = (int)$link['weight'];
                    $link['add_time'] = date('Y-m-d H:i:s', $link['add_time']);
                    $link['icon'] = $link['icon'] ?: 'fa-link';
                    $link['icon_color'] = $link['icon_color'] ?: '#6b7280';
                    $link['domain'] = parse_url($link['url'], PHP_URL_HOST);
                }
                
                $category['links'] = $links;
            }
            
            return $this->success($category);
            
        } catch (\Exception $e) {
            return $this->error('获取分类详情失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 创建分类
     * POST /api/categories
     */
    public function store(Request $request)
    {
        try {
            // 验证输入
            $validation = $this->validate($request, [
                'name' => 'required|min:1|max:50',
                'description' => 'max:200',
                'icon' => 'max:50',
                'icon_color' => 'max:10',
                'weight' => 'integer'
            ]);
            
            if ($validation !== true) {
                return $this->error('参数验证失败', 422, $validation);
            }
            
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查名称是否重复
            $checkSql = "SELECT COUNT(*) FROM {$tablePrefix}categorys WHERE name = ? AND property = 0";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute([$request->input('name')]);
            
            if ($checkStmt->fetchColumn() > 0) {
                return $this->error('分类名称已存在', 422);
            }
            
            // 插入数据
            $sql = "INSERT INTO {$tablePrefix}categorys 
                    (name, font_icon, icon_color, description, weight, property, add_time) 
                    VALUES (?, ?, ?, ?, ?, 0, ?)";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                $request->input('name'),
                $request->input('icon', 'fa-folder'),
                $request->input('icon_color', '#6366f1'),
                $request->input('description', ''),
                $request->input('weight', 100),
                time()
            ]);
            
            if ($result) {
                $categoryId = $pdo->lastInsertId();
                return $this->success(['id' => (int)$categoryId], '分类创建成功', 201);
            } else {
                return $this->error('分类创建失败', 500);
            }
            
        } catch (\Exception $e) {
            return $this->error('分类创建失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 更新分类
     * PUT /api/categories/{id}
     */
    public function update(Request $request, $id)
    {
        try {
            // 验证输入
            $validation = $this->validate($request, [
                'name' => 'required|min:1|max:50',
                'description' => 'max:200',
                'icon' => 'max:50',
                'icon_color' => 'max:10',
                'weight' => 'integer'
            ]);
            
            if ($validation !== true) {
                return $this->error('参数验证失败', 422, $validation);
            }
            
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查分类是否存在
            $checkSql = "SELECT COUNT(*) FROM {$tablePrefix}categorys WHERE id = ? AND property = 0";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute([$id]);
            
            if ($checkStmt->fetchColumn() == 0) {
                return $this->error('分类不存在', 404);
            }
            
            // 检查名称是否重复（排除自己）
            $checkNameSql = "SELECT COUNT(*) FROM {$tablePrefix}categorys WHERE name = ? AND id != ? AND property = 0";
            $checkNameStmt = $pdo->prepare($checkNameSql);
            $checkNameStmt->execute([$request->input('name'), $id]);
            
            if ($checkNameStmt->fetchColumn() > 0) {
                return $this->error('分类名称已存在', 422);
            }
            
            // 更新数据
            $sql = "UPDATE {$tablePrefix}categorys 
                    SET name = ?, font_icon = ?, icon_color = ?, description = ?, weight = ? 
                    WHERE id = ? AND property = 0";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                $request->input('name'),
                $request->input('icon', 'fa-folder'),
                $request->input('icon_color', '#6366f1'),
                $request->input('description', ''),
                $request->input('weight', 100),
                $id
            ]);
            
            if ($result) {
                return $this->success(['id' => (int)$id], '分类更新成功');
            } else {
                return $this->error('分类更新失败', 500);
            }
            
        } catch (\Exception $e) {
            return $this->error('分类更新失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 删除分类
     * DELETE /api/categories/{id}
     */
    public function destroy(Request $request, $id)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查分类是否存在
            $checkSql = "SELECT COUNT(*) FROM {$tablePrefix}categorys WHERE id = ? AND property = 0";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute([$id]);
            
            if ($checkStmt->fetchColumn() == 0) {
                return $this->error('分类不存在', 404);
            }
            
            // 检查是否有链接
            $checkLinksSql = "SELECT COUNT(*) FROM {$tablePrefix}links WHERE fid = ? AND property = 0";
            $checkLinksStmt = $pdo->prepare($checkLinksSql);
            $checkLinksStmt->execute([$id]);
            
            if ($checkLinksStmt->fetchColumn() > 0) {
                return $this->error('分类下还有链接，无法删除', 422);
            }
            
            // 删除分类（软删除）
            $sql = "UPDATE {$tablePrefix}categorys SET property = 1 WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([$id]);
            
            if ($result) {
                return $this->success(['id' => (int)$id], '分类删除成功');
            } else {
                return $this->error('分类删除失败', 500);
            }
            
        } catch (\Exception $e) {
            return $this->error('分类删除失败: ' . $e->getMessage(), 500);
        }
    }
}
