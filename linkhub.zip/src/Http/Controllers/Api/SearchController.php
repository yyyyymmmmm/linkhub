<?php

namespace LinkHub\Http\Controllers\Api;

use LinkHub\Core\Http\Request;

/**
 * 搜索API控制器
 */
class SearchController extends ApiController
{
    /**
     * 全站搜索
     * GET /api/search
     */
    public function search(Request $request)
    {
        try {
            $query = trim($request->input('q', ''));
            
            if (empty($query)) {
                return $this->error('请输入搜索关键词', 422);
            }
            
            if (strlen($query) > 100) {
                return $this->error('搜索关键词过长', 422);
            }
            
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 获取分页参数
            list($page, $perPage, $offset) = $this->getPaginationParams($request);
            
            // 搜索类型
            $type = $request->input('type', 'all'); // all, links, categories
            $results = [];
            
            if ($type === 'all' || $type === 'links') {
                // 搜索链接
                $linksSql = "SELECT 
                                'link' as type,
                                l.id,
                                l.title,
                                l.url,
                                l.note,
                                l.font_icon as icon,
                                l.icon_color,
                                l.click,
                                l.add_time,
                                c.name as category_name,
                                c.id as category_id
                            FROM {$tablePrefix}links l
                            LEFT JOIN {$tablePrefix}categorys c ON l.fid = c.id
                            WHERE l.property = 0 
                            AND (l.title LIKE ? OR l.note LIKE ? OR l.url LIKE ?)
                            ORDER BY l.click DESC, l.add_time DESC";
                
                $linksStmt = $pdo->prepare($linksSql);
                $linksStmt->execute(["%{$query}%", "%{$query}%", "%{$query}%"]);
                $links = $linksStmt->fetchAll(\PDO::FETCH_ASSOC);
                
                foreach ($links as &$link) {
                    $link['id'] = (int)$link['id'];
                    $link['click'] = (int)$link['click'];
                    $link['category_id'] = (int)$link['category_id'];
                    $link['add_time'] = date('Y-m-d H:i:s', $link['add_time']);
                    $link['domain'] = parse_url($link['url'], PHP_URL_HOST);
                    $link['highlight'] = $this->highlightText([$link['title'], $link['note']], $query);
                }
                
                $results = array_merge($results, $links);
            }
            
            if ($type === 'all' || $type === 'categories') {
                // 搜索分类
                $categoriesSql = "SELECT 
                                    'category' as type,
                                    id,
                                    name as title,
                                    description as note,
                                    font_icon as icon,
                                    icon_color,
                                    weight,
                                    add_time,
                                    (SELECT COUNT(*) FROM {$tablePrefix}links WHERE fid = {$tablePrefix}categorys.id AND property = 0) as links_count
                                FROM {$tablePrefix}categorys
                                WHERE property = 0 
                                AND (name LIKE ? OR description LIKE ?)
                                ORDER BY weight DESC, add_time DESC";
                
                $categoriesStmt = $pdo->prepare($categoriesSql);
                $categoriesStmt->execute(["%{$query}%", "%{$query}%"]);
                $categories = $categoriesStmt->fetchAll(\PDO::FETCH_ASSOC);
                
                foreach ($categories as &$category) {
                    $category['id'] = (int)$category['id'];
                    $category['weight'] = (int)$category['weight'];
                    $category['links_count'] = (int)$category['links_count'];
                    $category['add_time'] = date('Y-m-d H:i:s', $category['add_time']);
                    $category['highlight'] = $this->highlightText([$category['title'], $category['note']], $query);
                }
                
                $results = array_merge($results, $categories);
            }
            
            // 分页处理
            $total = count($results);
            $results = array_slice($results, $offset, $perPage);
            
            return $this->paginated($results, $total, $page, $perPage, "找到 {$total} 个结果");
            
        } catch (\Exception $e) {
            return $this->error('搜索失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 搜索建议
     * GET /api/search/suggestions
     */
    public function suggestions(Request $request)
    {
        try {
            $query = trim($request->input('q', ''));
            
            if (empty($query) || strlen($query) < 2) {
                return $this->success([]);
            }
            
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            $limit = min(10, max(5, (int)$request->input('limit', 8)));
            
            // 获取热门搜索建议
            $sql = "SELECT DISTINCT title, click
                    FROM {$tablePrefix}links
                    WHERE property = 0 
                    AND title LIKE ?
                    ORDER BY click DESC, title ASC
                    LIMIT {$limit}";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute(["%{$query}%"]);
            $suggestions = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            $result = [];
            foreach ($suggestions as $suggestion) {
                $result[] = [
                    'text' => $suggestion['title'],
                    'popularity' => (int)$suggestion['click']
                ];
            }
            
            return $this->success($result);
            
        } catch (\Exception $e) {
            return $this->error('获取搜索建议失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 热门搜索
     * GET /api/search/hot
     */
    public function hot(Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            $limit = min(20, max(5, (int)$request->input('limit', 10)));
            
            // 获取热门链接
            $sql = "SELECT 
                        title, 
                        url, 
                        click,
                        font_icon as icon,
                        icon_color
                    FROM {$tablePrefix}links
                    WHERE property = 0 AND click > 0
                    ORDER BY click DESC, add_time DESC
                    LIMIT {$limit}";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $hotLinks = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            foreach ($hotLinks as &$link) {
                $link['click'] = (int)$link['click'];
                $link['domain'] = parse_url($link['url'], PHP_URL_HOST);
            }
            
            return $this->success($hotLinks);
            
        } catch (\Exception $e) {
            return $this->error('获取热门搜索失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 高亮搜索关键词
     */
    private function highlightText($texts, $query)
    {
        $highlights = [];
        foreach ($texts as $text) {
            if (empty($text)) continue;
            
            $highlighted = preg_replace(
                '/(' . preg_quote($query, '/') . ')/i',
                '<mark>$1</mark>',
                $text
            );
            $highlights[] = $highlighted;
        }
        return $highlights;
    }
}

/**
 * 统计API控制器
 */
class StatsController extends ApiController
{
    /**
     * 总体统计
     * GET /api/stats
     */
    public function overview(Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 基础统计
            $stats = [];
            
            // 分类数量
            $categoriesStmt = $pdo->query("SELECT COUNT(*) FROM {$tablePrefix}categorys WHERE property = 0");
            $stats['categories_count'] = (int)$categoriesStmt->fetchColumn();
            
            // 链接数量
            $linksStmt = $pdo->query("SELECT COUNT(*) FROM {$tablePrefix}links WHERE property = 0");
            $stats['links_count'] = (int)$linksStmt->fetchColumn();
            
            // 总点击数
            $clicksStmt = $pdo->query("SELECT SUM(click) FROM {$tablePrefix}links WHERE property = 0");
            $stats['total_clicks'] = (int)$clicksStmt->fetchColumn();
            
            // 今日点击数
            $todayStart = strtotime(date('Y-m-d 00:00:00'));
            $todayStmt = $pdo->prepare("SELECT COUNT(*) FROM {$tablePrefix}clicks WHERE click_time >= ?");
            $todayStmt->execute([$todayStart]);
            $stats['today_clicks'] = (int)$todayStmt->fetchColumn();
            
            // 本周点击数
            $weekStart = strtotime(date('Y-m-d 00:00:00', strtotime('this week')));
            $weekStmt = $pdo->prepare("SELECT COUNT(*) FROM {$tablePrefix}clicks WHERE click_time >= ?");
            $weekStmt->execute([$weekStart]);
            $stats['week_clicks'] = (int)$weekStmt->fetchColumn();
            
            // 本月点击数
            $monthStart = strtotime(date('Y-m-01 00:00:00'));
            $monthStmt = $pdo->prepare("SELECT COUNT(*) FROM {$tablePrefix}clicks WHERE click_time >= ?");
            $monthStmt->execute([$monthStart]);
            $stats['month_clicks'] = (int)$monthStmt->fetchColumn();
            
            return $this->success($stats);
            
        } catch (\Exception $e) {
            return $this->error('获取统计信息失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 点击趋势
     * GET /api/stats/clicks
     */
    public function clicks(Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            $period = $request->input('period', '7d'); // 7d, 30d, 90d
            $days = 7;
            
            switch ($period) {
                case '30d':
                    $days = 30;
                    break;
                case '90d':
                    $days = 90;
                    break;
            }
            
            $startTime = strtotime("-{$days} days");
            
            $sql = "SELECT 
                        DATE(FROM_UNIXTIME(click_time)) as date,
                        COUNT(*) as clicks
                    FROM {$tablePrefix}clicks 
                    WHERE click_time >= ?
                    GROUP BY DATE(FROM_UNIXTIME(click_time))
                    ORDER BY date ASC";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$startTime]);
            $data = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            // 填充缺失的日期
            $result = [];
            for ($i = $days - 1; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-{$i} days"));
                $clicks = 0;
                
                foreach ($data as $item) {
                    if ($item['date'] === $date) {
                        $clicks = (int)$item['clicks'];
                        break;
                    }
                }
                
                $result[] = [
                    'date' => $date,
                    'clicks' => $clicks
                ];
            }
            
            return $this->success($result);
            
        } catch (\Exception $e) {
            return $this->error('获取点击统计失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 热门链接排行
     * GET /api/stats/popular
     */
    public function popular(Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            $limit = min(50, max(5, (int)$request->input('limit', 10)));
            
            $sql = "SELECT 
                        l.id,
                        l.title,
                        l.url,
                        l.click,
                        l.font_icon as icon,
                        l.icon_color,
                        c.name as category_name
                    FROM {$tablePrefix}links l
                    LEFT JOIN {$tablePrefix}categorys c ON l.fid = c.id
                    WHERE l.property = 0 AND l.click > 0
                    ORDER BY l.click DESC, l.add_time DESC
                    LIMIT {$limit}";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $links = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            foreach ($links as &$link) {
                $link['id'] = (int)$link['id'];
                $link['click'] = (int)$link['click'];
                $link['domain'] = parse_url($link['url'], PHP_URL_HOST);
            }
            
            return $this->success($links);
            
        } catch (\Exception $e) {
            return $this->error('获取热门链接失败: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * 分类统计
     * GET /api/stats/categories
     */
    public function categories(Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            $sql = "SELECT 
                        c.id,
                        c.name,
                        c.font_icon as icon,
                        c.icon_color,
                        COUNT(l.id) as links_count,
                        SUM(l.click) as total_clicks
                    FROM {$tablePrefix}categorys c
                    LEFT JOIN {$tablePrefix}links l ON c.id = l.fid AND l.property = 0
                    WHERE c.property = 0
                    GROUP BY c.id, c.name, c.font_icon, c.icon_color
                    ORDER BY total_clicks DESC, links_count DESC";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $categories = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            foreach ($categories as &$category) {
                $category['id'] = (int)$category['id'];
                $category['links_count'] = (int)$category['links_count'];
                $category['total_clicks'] = (int)$category['total_clicks'];
            }
            
            return $this->success($categories);
            
        } catch (\Exception $e) {
            return $this->error('获取分类统计失败: ' . $e->getMessage(), 500);
        }
    }
}
