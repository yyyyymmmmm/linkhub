<?php

namespace LinkHub\Http\Controllers\Api;

use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;

/**
 * API控制器基类
 * 提供通用的API响应方法和功能
 */
abstract class ApiController
{
    /**
     * 获取数据库连接
     */
    protected function getDatabaseConnection()
    {
        require_once dirname(dirname(dirname(__DIR__))) . '/config/database_connection.php';
        return getDatabaseConnection();
    }
    
    /**
     * 获取表前缀
     */
    protected function getTablePrefix()
    {
        require_once dirname(dirname(dirname(__DIR__))) . '/config/database_connection.php';
        return getTablePrefix();
    }
    
    /**
     * 成功响应
     */
    protected function success($data = null, $message = '操作成功', $code = 200)
    {
        return $this->jsonResponse([
            'success' => true,
            'code' => $code,
            'message' => $message,
            'data' => $data,
            'timestamp' => time()
        ], $code);
    }
    
    /**
     * 错误响应
     */
    protected function error($message = '操作失败', $code = 400, $errors = null)
    {
        return $this->jsonResponse([
            'success' => false,
            'code' => $code,
            'message' => $message,
            'errors' => $errors,
            'timestamp' => time()
        ], $code);
    }
    
    /**
     * 分页响应
     */
    protected function paginated($data, $total, $page = 1, $perPage = 20, $message = '获取成功')
    {
        return $this->jsonResponse([
            'success' => true,
            'message' => $message,
            'data' => $data,
            'pagination' => [
                'total' => $total,
                'per_page' => $perPage,
                'current_page' => $page,
                'total_pages' => ceil($total / $perPage),
                'has_more' => $page * $perPage < $total
            ],
            'timestamp' => time()
        ]);
    }
    
    /**
     * JSON响应
     */
    protected function jsonResponse($data, $statusCode = 200)
    {
        $response = new Response(json_encode($data, JSON_UNESCAPED_UNICODE), $statusCode);
        $response->setHeader('Content-Type', 'application/json; charset=utf-8');
        $response->setHeader('Access-Control-Allow-Origin', '*');
        $response->setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        $response->setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
        return $response;
    }
    
    /**
     * 验证参数
     */
    protected function validate(Request $request, $rules)
    {
        $errors = [];
        
        foreach ($rules as $field => $rule) {
            $value = $request->input($field);
            $ruleList = explode('|', $rule);
            
            foreach ($ruleList as $singleRule) {
                if ($singleRule === 'required' && empty($value)) {
                    $errors[$field][] = "{$field}字段是必需的";
                } elseif (strpos($singleRule, 'max:') === 0 && !empty($value)) {
                    $max = (int)substr($singleRule, 4);
                    if (strlen($value) > $max) {
                        $errors[$field][] = "{$field}字段长度不能超过{$max}个字符";
                    }
                } elseif (strpos($singleRule, 'min:') === 0 && !empty($value)) {
                    $min = (int)substr($singleRule, 4);
                    if (strlen($value) < $min) {
                        $errors[$field][] = "{$field}字段长度不能少于{$min}个字符";
                    }
                } elseif ($singleRule === 'url' && !empty($value)) {
                    if (!filter_var($value, FILTER_VALIDATE_URL)) {
                        $errors[$field][] = "{$field}必须是有效的URL格式";
                    }
                } elseif ($singleRule === 'integer' && !empty($value)) {
                    if (!filter_var($value, FILTER_VALIDATE_INT)) {
                        $errors[$field][] = "{$field}必须是整数";
                    }
                }
            }
        }
        
        return empty($errors) ? true : $errors;
    }
    
    /**
     * 获取分页参数
     */
    protected function getPaginationParams(Request $request)
    {
        $page = max(1, (int)$request->input('page', 1));
        $perPage = min(100, max(1, (int)$request->input('per_page', 20)));
        $offset = ($page - 1) * $perPage;
        
        return [$page, $perPage, $offset];
    }
    
    /**
     * 处理排序参数
     */
    protected function getSortParams(Request $request, $allowedFields = ['id', 'name', 'created_at'])
    {
        $sortBy = $request->input('sort_by', 'id');
        $sortOrder = strtoupper($request->input('sort_order', 'DESC'));
        
        if (!in_array($sortBy, $allowedFields)) {
            $sortBy = 'id';
        }
        
        if (!in_array($sortOrder, ['ASC', 'DESC'])) {
            $sortOrder = 'DESC';
        }
        
        return [$sortBy, $sortOrder];
    }
}
