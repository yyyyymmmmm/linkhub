<?php

declare(strict_types=1);

namespace LinkHub\Http\Controllers;

use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;
use LinkHub\Core\Container\ContainerInterface;

/**
 * 控制器基�?
 * 
 * @author OneNav Professional Team
 */
abstract class Controller
{
    protected \$container;
    
    public function __construct(\$container)
    {
        $this->container = $container;
    }
    
    /**
     * 返回JSON响应
     */
    protected function json($data, int $status = 200, array $headers = []): Response
    {
        return Response::json($data, $status, $headers);
    }
    
    /**
     * 返回成功响应
     */
    protected function success($data = null, string $message = 'Success', int $status = 200): Response
    {
        return $this->json([
            'success' => true,
            'message' => $message,
            'data' => $data,
        ], $status);
    }
    
    /**
     * 返回错误响应
     */
    protected function error(string $message = 'Error', int $status = 400, $errors = null): Response
    {
        $response = [
            'success' => false,
            'message' => $message,
        ];
        
        if ($errors !== null) {
            $response['errors'] = $errors;
        }
        
        return $this->json($response, $status);
    }
    
    /**
     * 返回验证错误响应
     */
    protected function validationError(array $errors, string $message = 'Validation failed'): Response
    {
        return $this->error($message, 422, $errors);
    }
    
    /**
     * 返回未找到响�?
     */
    protected function notFound(string $message = 'Resource not found'): Response
    {
        return $this->error($message, 404);
    }
    
    /**
     * 返回未授权响�?
     */
    protected function unauthorized(string $message = 'Unauthorized'): Response
    {
        return $this->error($message, 401);
    }
    
    /**
     * 返回禁止访问响应
     */
    protected function forbidden(string $message = 'Forbidden'): Response
    {
        return $this->error($message, 403);
    }
    
    /**
     * 重定�?
     */
    protected function redirect(string $url, int $status = 302): Response
    {
        return Response::redirect($url, $status);
    }
    
    /**
     * 返回视图
     */
    protected function view(string $template, array $data = []): Response
    {
        $view = $this->container->get('view');
        $content = $view->render($template, $data);
        
        return new Response($content);
    }
    
    /**
     * 获取服务
     */
    protected function get(string $service)
    {
        return $this->container->get($service);
    }
    
    /**
     * 验证请求
     */
    protected function validate(Request $request, array $rules)
    {
        $validator = $this->container->get('validator');
        
        $validated = $validator->validate($request->input(), $rules);
        
        if ($validator->fails()) {
            throw new \LinkHub\Core\Validation\ValidationException($validator->errors());
        }
        
        return $validated;
    }
    
    /**
     * 获取分页参数
     */
    protected function getPaginationParams(Request $request)
    {
        $page = max(1, (int) $request->query('page', 1));
        $limit = min(100, max(1, (int) $request->query('limit', 20)));
        $offset = ($page - 1) * $limit;
        
        return compact('page', 'limit', 'offset');
    }
    
    /**
     * 创建分页响应
     */
    protected function paginated(array $items, int $total, int $page, int $limit)
    {
        $totalPages = ceil($total / $limit);
        
        return [
            'data' => $items,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'per_page' => $limit,
                'total' => $total,
                'has_prev' => $page > 1,
                'has_next' => $page < $totalPages,
            ],
        ];
    }
    
    /**
     * 获取用户IP
     */
    protected function getClientIp(Request $request)
    {
        return $request->getClientIp();
    }
    
    /**
     * 记录日志
     */
    protected function log(string $level, string $message, array $context = [])
    {
        if ($this->container->has('logger')) {
            $logger = $this->container->get('logger');
            $logger->log($level, $message, $context);
        }
    }
}
