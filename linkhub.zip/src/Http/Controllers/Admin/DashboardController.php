<?php

declare(strict_types=1);

namespace LinkHub\Http\Controllers\Admin;

use LinkHub\Http\Controllers\Controller;
use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;
use LinkHub\Services\StatsService;
use LinkHub\Services\SystemService;

/**
 * 管理后台首页控制�?
 * 
 * @author OneNav Professional Team
 */
class DashboardController extends Controller
{
    protected \$statsService;
    protected SystemService $systemService;
    
    public function __construct($container)
    {
        parent::__construct($container);
        $this->statsService = $container->get(StatsService::class);
        $this->systemService = $container->get(SystemService::class);
    }
    
    /**
     * 管理后台首页
     */
    public function index(Request $request): Response
    {
        // 获取统计数据
        $stats = $this->getStats();
        
        // 获取系统信息
        $systemInfo = $this->getSystemInfo();
        
        // 获取最近活�?
        $recentActivity = $this->getRecentActivity();
        
        // 获取快捷操作
        $quickActions = $this->getQuickActions();
        
        $data = [
            'stats' => $stats,
            'systemInfo' => $systemInfo,
            'recentActivity' => $recentActivity,
            'quickActions' => $quickActions,
            'site' => $this->getSiteConfig(),
        ];
        
        return $this->view('admin.dashboard', $data);
    }
    
    /**
     * 获取统计数据
     */
    protected function getStats()
    {
        return [
            'categories' => [
                'total' => $this->statsService->getCategoryCount(),
                'public' => $this->statsService->getCategoryCount(['property' => 0]),
                'private' => $this->statsService->getCategoryCount(['property' => 1]),
            ],
            'links' => [
                'total' => $this->statsService->getLinkCount(),
                'public' => $this->statsService->getLinkCount(['property' => 0]),
                'private' => $this->statsService->getLinkCount(['property' => 1]),
                'today' => $this->statsService->getLinkCount(['date' => date('Y-m-d')]),
            ],
            'clicks' => [
                'total' => $this->statsService->getClickCount(),
                'today' => $this->statsService->getClickCount(['date' => date('Y-m-d')]),
                'this_month' => $this->statsService->getClickCount(['month' => date('Y-m')]),
            ],
            'storage' => [
                'used' => $this->systemService->getStorageUsed(),
                'available' => $this->systemService->getStorageAvailable(),
                'usage_percentage' => $this->systemService->getStorageUsagePercentage(),
            ],
        ];
    }
    
    /**
     * 获取系统信息
     */
    protected function getSystemInfo()
    {
        return [
            'version' => config('app.version', '2.0.0'),
            'php_version' => PHP_VERSION,
            'environment' => config('app.env', 'production'),
            'debug_mode' => config('app.debug', false),
            'timezone' => config('app.timezone', 'UTC'),
            'memory_usage' => $this->formatBytes(memory_get_usage(true)),
            'memory_peak' => $this->formatBytes(memory_get_peak_usage(true)),
            'uptime' => $this->systemService->getUptime(),
            'database' => [
                'type' => config('database.default', 'mysql'),
                'size' => $this->systemService->getDatabaseSize(),
                'tables' => $this->systemService->getTableCount(),
            ],
        ];
    }
    
    /**
     * 获取最近活�?
     */
    protected function getRecentActivity()
    {
        return [
            'recent_links' => $this->statsService->getRecentLinks(5),
            'recent_categories' => $this->statsService->getRecentCategories(5),
            'top_clicks' => $this->statsService->getTopClickedLinks(10),
            'recent_errors' => $this->systemService->getRecentErrors(5),
        ];
    }
    
    /**
     * 获取快捷操作
     */
    protected function getQuickActions()
    {
        return [
            [
                'title' => '添加分类',
                'url' => '/admin/categories/create',
                'icon' => 'fa-folder-plus',
                'color' => 'primary',
            ],
            [
                'title' => '添加链接',
                'url' => '/admin/links/create',
                'icon' => 'fa-plus',
                'color' => 'success',
            ],
            [
                'title' => '系统设置',
                'url' => '/admin/settings',
                'icon' => 'fa-cog',
                'color' => 'info',
            ],
            [
                'title' => '数据备份',
                'url' => '/admin/backup',
                'icon' => 'fa-download',
                'color' => 'warning',
            ],
            [
                'title' => '查看日志',
                'url' => '/admin/logs',
                'icon' => 'fa-file-text',
                'color' => 'secondary',
            ],
            [
                'title' => '清除缓存',
                'url' => '/admin/cache/clear',
                'icon' => 'fa-refresh',
                'color' => 'danger',
            ],
        ];
    }
    
    /**
     * 系统状态检�?
     */
    public function status(Request $request): Response
    {
        $checks = [
            'database' => $this->systemService->checkDatabase(),
            'storage' => $this->systemService->checkStorage(),
            'cache' => $this->systemService->checkCache(),
            'logs' => $this->systemService->checkLogs(),
            'permissions' => $this->systemService->checkPermissions(),
        ];
        
        $overall = true;
        foreach ($checks as $check) {
            if (!$check['status']) {
                $overall = false;
                break;
            }
        }
        
        return $this->success([
            'overall' => $overall,
            'checks' => $checks,
            'timestamp' => time(),
        ]);
    }
    
    /**
     * 获取实时统计
     */
    public function realTimeStats(Request $request): Response
    {
        $stats = [
            'visitors_online' => $this->statsService->getOnlineVisitors(),
            'clicks_today' => $this->statsService->getClickCount(['date' => date('Y-m-d')]),
            'memory_usage' => memory_get_usage(true),
            'cpu_usage' => $this->systemService->getCpuUsage(),
        ];
        
        return $this->success($stats);
    }
    
    /**
     * 获取站点配置
     */
    protected function getSiteConfig()
    {
        return [
            'title' => config('site.title', 'OneNav Professional'),
            'subtitle' => config('site.subtitle', '专业级导航系�?),
            'logo' => config('site.logo', ''),
        ];
    }
    
    /**
     * 格式化字节数
     */
    protected function formatBytes(int $bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, 2) . ' ' . $units[$i];
    }
}
