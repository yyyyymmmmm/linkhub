<?php

declare(strict_types=1);

namespace LinkHub\Http\Controllers\Auth;

use LinkHub\Http\Controllers\Controller;
use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;
use LinkHub\Services\AuthService;

/**
 * 登录控制�?
 * 
 * @author OneNav Professional Team
 */
class LoginController extends Controller
{
    protected \$authService;
    
    public function __construct($container)
    {
        parent::__construct($container);
        $this->authService = $container->get(AuthService::class);
    }
    
    /**
     * 显示登录页面
     */
    public function show(Request $request): Response
    {
        // 如果已经登录，重定向到管理后�?
        if ($this->authService->check($request)) {
            return $this->redirect('/admin');
        }
        
        $data = [
            'site' => $this->getSiteConfig(),
            'error' => $request->query('error'),
        ];
        
        return $this->view('auth.login', $data);
    }
    
    /**
     * 处理登录请求
     */
    public function login(Request $request): Response
    {
        // 验证输入
        $rules = [
            'username' => 'required|string|max:255',
            'password' => 'required|string|min:6',
        ];
        
        try {
            $validated = $this->validate($request, $rules);
        } catch (\Exception $e) {
            return $this->validationError($e->getErrors());
        }
        
        // 速率限制检�?
        if ($this->authService->tooManyAttempts($request)) {
            return $this->error('Too many login attempts. Please try again later.', 429);
        }
        
        // 尝试登录
        $result = $this->authService->attempt(
            $validated['username'],
            $validated['password'],
            $request
        );
        
        if ($result['success']) {
            // 记录登录日志
            $this->log('info', 'User logged in', [
                'username' => $validated['username'],
                'ip' => $request->getClientIp(),
                'user_agent' => $request->getUserAgent(),
            ]);
            
            // 清除登录尝试记录
            $this->authService->clearAttempts($request);
            
            // 如果是AJAX请求，返回JSON
            if ($request->isAjax()) {
                return $this->success([
                    'redirect_url' => '/admin',
                    'token' => $result['token'] ?? null,
                ], 'Login successful');
            }
            
            // 普通请求重定向
            return $this->redirect('/admin');
        }
        
        // 记录失败的登录尝�?
        $this->authService->recordAttempt($request);
        
        // 记录登录失败日志
        $this->log('warning', 'Failed login attempt', [
            'username' => $validated['username'],
            'ip' => $request->getClientIp(),
            'user_agent' => $request->getUserAgent(),
            'reason' => $result['message'],
        ]);
        
        if ($request->isAjax()) {
            return $this->error($result['message'], 401);
        }
        
        return $this->redirect('/login?error=' . urlencode($result['message']));
    }
    
    /**
     * 处理登出请求
     */
    public function logout(Request $request): Response
    {
        $user = $this->authService->user($request);
        
        // 登出
        $this->authService->logout($request);
        
        // 记录登出日志
        if ($user) {
            $this->log('info', 'User logged out', [
                'username' => $user['username'] ?? 'unknown',
                'ip' => $request->getClientIp(),
            ]);
        }
        
        if ($request->isAjax()) {
            return $this->success(null, 'Logout successful');
        }
        
        return $this->redirect('/');
    }
    
    /**
     * 检查登录状态（API�?
     */
    public function check(Request $request): Response
    {
        $isLoggedIn = $this->authService->check($request);
        $user = $isLoggedIn ? $this->authService->user($request) : null;
        
        return $this->success([
            'authenticated' => $isLoggedIn,
            'user' => $user,
        ]);
    }
    
    /**
     * 刷新令牌（API�?
     */
    public function refresh(Request $request): Response
    {
        try {
            $newToken = $this->authService->refresh($request);
            
            return $this->success([
                'token' => $newToken,
            ], 'Token refreshed successfully');
        } catch (\Exception $e) {
            return $this->error('Token refresh failed', 401);
        }
    }
    
    /**
     * 修改密码
     */
    public function changePassword(Request $request): Response
    {
        // 验证用户是否已登�?
        if (!$this->authService->check($request)) {
            return $this->unauthorized();
        }
        
        // 验证输入
        $rules = [
            'current_password' => 'required|string',
            'new_password' => 'required|string|min:6|confirmed',
            'new_password_confirmation' => 'required|string',
        ];
        
        try {
            $validated = $this->validate($request, $rules);
        } catch (\Exception $e) {
            return $this->validationError($e->getErrors());
        }
        
        // 验证当前密码
        $user = $this->authService->user($request);
        if (!$this->authService->verifyPassword($validated['current_password'], $user['password'])) {
            return $this->error('Current password is incorrect', 400);
        }
        
        // 更新密码
        $result = $this->authService->updatePassword($user['id'], $validated['new_password']);
        
        if ($result) {
            // 记录密码修改日志
            $this->log('info', 'Password changed', [
                'username' => $user['username'],
                'ip' => $request->getClientIp(),
            ]);
            
            return $this->success(null, 'Password changed successfully');
        }
        
        return $this->error('Failed to change password');
    }
    
    /**
     * 获取站点配置
     */
    protected function getSiteConfig()
    {
        return [
            'title' => config('site.title', 'OneNav Professional'),
            'logo' => config('site.logo', ''),
            'description' => config('site.description', ''),
        ];
    }
}
