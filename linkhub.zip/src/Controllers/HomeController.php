<?php

namespace LinkHub\Controllers;

use LinkHub\Core\Controller\BaseController;
use LinkHub\Core\Http\Request;
use LinkHub\Core\Http\Response;

class HomeController extends BaseController
{
    /**
     * 获取数据库连接
     */
    private function getDatabaseConnection()
    {
        require_once dirname(dirname(__DIR__)) . '/config/database_connection.php';
        return getDatabaseConnection();
    }
    
    /**
     * 获取表前缀
     */
    private function getTablePrefix()
    {
        require_once dirname(dirname(__DIR__)) . '/config/database_connection.php';
        return getTablePrefix();
    }

    /**
     * 首页显示
     */
    public function index(Request $request)
    {
        try {
            // 获取当前主题
            $currentTheme = $this->getCurrentTheme();
            
            // 获取网站配置
            $siteConfig = $this->getSiteConfig();
            
            // 获取分类和链接数据
            $categories = $this->getCategoriesWithLinks();
            
            // 提取所有链接到单独数组
            $links = [];
            foreach ($categories as $category) {
                if (isset($category['links'])) {
                    $links = array_merge($links, $category['links']);
                }
            }
            
            // 获取主题配置
            $themeConfigFile = dirname(dirname(__DIR__)) . "/public/themes/{$currentTheme}/theme.json";
            $themeConfig = [];
            if (file_exists($themeConfigFile)) {
                $themeConfig = json_decode(file_get_contents($themeConfigFile), true) ?: [];
            }
            
            return $this->renderTheme($currentTheme, [
                'site' => $siteConfig,
                'categories' => $categories,
                'links' => $links,
                'theme_config' => $themeConfig
            ]);
            
        } catch (\Exception $e) {
            // 发生错误时显示默认页面
            return $this->renderError($e->getMessage());
        }
    }
    
    /**
     * 点击统计
     */
    public function click(Request $request)
    {
        $linkId = (int) $request->input('id');
        $url = $request->input('url');
        
        // 如果没有提供URL，通过ID从数据库获取
        if ($linkId > 0 && empty($url)) {
            try {
                $pdo = $this->getDatabaseConnection();
                $tablePrefix = $this->getTablePrefix();
                
                $stmt = $pdo->prepare("SELECT url FROM " . $tablePrefix . "links WHERE id = ? AND property = 0");
                $stmt->execute([$linkId]);
                $result = $stmt->fetch(\PDO::FETCH_ASSOC);
                
                if ($result) {
                    $url = $result['url'];
                }
            } catch (\Exception $e) {
                return $this->redirect('/'); // 重定向到首页
            }
        }
        
        // 验证URL是否有效
        if (empty($url)) {
            return $this->redirect('/'); // 重定向到首页
        }
        
        // 记录点击统计
        if ($linkId > 0) {
            $this->recordClick($linkId, $request);
        }
        
        // 检查是否需要过渡页
        $siteConfig = $this->getSiteConfig();
        $enableTransition = $siteConfig['enable_transition_page'] ?? '0';
        
        if ($enableTransition === '1') {
            $transitionUrl = '/transition_advanced.php?url=' . urlencode($url) . '&site=' . urlencode(parse_url($url, PHP_URL_HOST));
            return $this->redirect($transitionUrl);
        }
        
        return $this->redirect($url);
    }
    
    /**
     * 生成网站首字母图标
     */
    public function siteIcon(Request $request)
    {
        $config = $this->getSiteConfig();
        
        // 如果有设置图标，直接返回
        if (!empty($config['logo'])) {
            // 支持相对路径和绝对路径
            if (strpos($config['logo'], 'http') === 0) {
                return $this->redirect($config['logo']);
            } else {
                $logoPath = dirname(dirname(__DIR__)) . '/public/' . ltrim($config['logo'], '/');
                if (file_exists($logoPath)) {
                    return $this->redirect('/' . ltrim($config['logo'], '/'));
                }
            }
        }
        
        // 生成首字母图标
        $siteName = $config['title'];
        $firstLetter = mb_substr($siteName, 0, 1, 'UTF-8');
        $color = $this->generateColorFromText($siteName);
        
        // 设置响应头
        header('Content-Type: image/svg+xml');
        header('Cache-Control: public, max-age=86400'); // 缓存1天
        
        $svg = $this->generateLetterAvatar($firstLetter, $color);
        echo $svg;
        exit;
    }
    
    /**
     * 根据文本生成颜色
     */
    private function generateColorFromText($text)
    {
        $colors = [
            '#6366f1', '#8b5cf6', '#ec4899', '#ef4444', '#f97316',
            '#eab308', '#22c55e', '#06b6d4', '#3b82f6', '#6366f1'
        ];
        
        $hash = 0;
        for ($i = 0; $i < mb_strlen($text); $i++) {
            $char = mb_substr($text, $i, 1);
            $hash = ord($char) + (($hash << 5) - $hash);
        }
        
        return $colors[abs($hash) % count($colors)];
    }
    
    /**
     * 生成首字母SVG头像
     */
    private function generateLetterAvatar($letter, $color)
    {
        return <<<SVG
<svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <rect width="64" height="64" rx="8" fill="{$color}"/>
    <text x="32" y="40" font-family="system-ui, -apple-system, sans-serif" 
          font-size="24" font-weight="600" fill="white" text-anchor="middle">{$letter}</text>
</svg>
SVG;
    }
    
    /**
     * 获取网站图标
     */
    public function favicon(Request $request)
    {
        $url = $request->input('url');
        if (empty($url)) {
            return $this->error('URL参数不能为空');
        }
        
        $iconUrl = $this->getFavicon($url);
        if ($iconUrl) {
            return $this->redirect($iconUrl);
        }
        
        // 返回默认图标
        $defaultIcon = dirname(dirname(__DIR__)) . '/public/static/images/default-favicon.ico';
        if (file_exists($defaultIcon)) {
            return $this->redirect('/static/images/default-favicon.ico');
        }
        
        return $this->error('图标不存在', 404);
    }
    
    /**
     * 获取当前主题
     */
    private function getCurrentTheme()
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            $stmt = $pdo->prepare("SELECT `value` FROM " . $tablePrefix . "settings WHERE `key` = 'default_theme'");
            $stmt->execute();
            $theme = $stmt->fetchColumn();
            return $theme ?: 'default';
        } catch (\Exception $e) {
            return 'default';
        }
    }
    
    /**
     * 获取网站配置
     */
    private function getSiteConfig()
    {
        $defaultConfig = [
            'title' => 'LinkHub',
            'subtitle' => '简洁高效的网址导航系统',
            'keywords' => 'LinkHub,导航,网址,书签',
            'description' => 'LinkHub - 简洁高效的网址导航系统',
            'logo' => '',
            'favicon' => '',
            'custom_header' => '',
            'custom_footer' => '',
            'statistics' => '',
            'icp' => '',
            'link_model' => 'click',
            'user_center_url' => '/login.php',
            'theme_config' => [],
            // 过渡页相关设置
            'enable_transition_page' => '0',
            'transition_time' => '3',
            'transition_theme_color' => '#6366f1',
            'transition_title' => '正在跳转中...',
            'transition_message' => '即将为您跳转到目标网站，请稍候...',
            'transition_ad_code' => '',
            'transition_show_progress' => '1',
            'transition_allow_skip' => '1'
        ];
        
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            $stmt = $pdo->query("SELECT `key`, `value` FROM " . $tablePrefix . "settings");
            $settings = $stmt->fetchAll(\PDO::FETCH_KEY_PAIR);
            
            return array_merge($defaultConfig, [
                'title' => $settings['site_name'] ?? 'LinkHub',
                'subtitle' => $settings['site_subtitle'] ?? '简洁高效的网址导航系统',
                'keywords' => $settings['site_keywords'] ?? 'LinkHub,导航,网址,书签',
                'description' => $settings['site_description'] ?? 'LinkHub - 简洁高效的网址导航系统',
                'logo' => $settings['site_logo'] ?? '',
                'favicon' => $settings['site_favicon'] ?? '',
                'custom_header' => $settings['custom_header'] ?? '',
                'custom_footer' => $settings['custom_footer'] ?? '',
                'statistics' => $settings['site_statistics'] ?? '',
                'icp' => $settings['site_icp'] ?? '',
                'link_model' => $settings['link_model'] ?? 'click',
                'theme_config' => json_decode($settings['theme_config'] ?? '{}', true),
                // 过渡页相关设置
                'enable_transition_page' => $settings['enable_transition_page'] ?? '0',
                'transition_time' => $settings['transition_time'] ?? '3',
                'transition_theme_color' => $settings['transition_theme_color'] ?? '#6366f1',
                'transition_title' => $settings['transition_title'] ?? '正在跳转中...',
                'transition_message' => $settings['transition_message'] ?? '即将为您跳转到目标网站，请稍候...',
                'transition_ad_code' => $settings['transition_ad_code'] ?? '',
                'transition_show_progress' => $settings['transition_show_progress'] ?? '1',
                'transition_allow_skip' => $settings['transition_allow_skip'] ?? '1'
            ]);
        } catch (\Exception $e) {
            return $defaultConfig;
        }
    }
    
    /**
     * 检查表中是否存在指定字段
     */
    private function hasTableColumn($pdo, $tableName, $columnName)
    {
        try {
            $stmt = $pdo->prepare("SHOW COLUMNS FROM {$tableName} LIKE ?");
            $stmt->execute([$columnName]);
            return $stmt->rowCount() > 0;
        } catch (\Exception $e) {
            return false;
        }
    }
    
    /**
     * 获取分类和链接数据
     */
    private function getCategoriesWithLinks()
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 检查分类表是否有icon_color字段
            $hasIconColorField = $this->hasTableColumn($pdo, $tablePrefix . 'categorys', 'icon_color');
            
            // 根据字段存在性构建查询
            $iconColorSql = $hasIconColorField ? 
                "COALESCE(icon_color, '#6366f1') as icon_color" : 
                "'#6366f1' as icon_color";
            
            // 获取分类数据
            $stmt = $pdo->query("
                SELECT *, 
                       COALESCE(font_icon, 'fa-folder') as icon,
                       {$iconColorSql}
                FROM " . $tablePrefix . "categorys 
                WHERE property = 0 
                ORDER BY weight DESC, add_time ASC
            ");
            $categories = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            // 检查链接表是否有icon_color字段
            $hasLinkIconColorField = $this->hasTableColumn($pdo, $tablePrefix . 'links', 'icon_color');
            $linkIconColorSql = $hasLinkIconColorField ? 
                "COALESCE(icon_color, '#6b7280') as icon_color" : 
                "'#6b7280' as icon_color";
            
            // 为每个分类获取链接
            foreach ($categories as &$category) {
                $linkStmt = $pdo->prepare("
                    SELECT *, 
                           fid as category_id,
                           COALESCE(font_icon, 'fa-link') as icon,
                           {$linkIconColorSql}
                    FROM " . $tablePrefix . "links 
                    WHERE fid = ? AND property = 0 
                    ORDER BY weight DESC, add_time ASC
                ");
                $linkStmt->execute([$category['id']]);
                $category['links'] = $linkStmt->fetchAll(\PDO::FETCH_ASSOC);
            }
            
            return $categories;
        } catch (\Exception $e) {
            return [];
        }
    }
    
    /**
     * 渲染主题
     */
    private function renderTheme($theme, $data)
    {
        $themePath = dirname(dirname(__DIR__)) . "/public/themes/{$theme}/index.php";
        
        if (!file_exists($themePath)) {
            throw new \Exception("Theme template not found: $theme");
        }
        
        // 提取数据到变量
        extract($data);
        
        // 开始输出缓冲
        ob_start();
        
        // 包含主题模板
        include $themePath;
        
        // 获取输出内容
        $content = ob_get_clean();
        
        return new Response($content);
    }
    
    /**
     * 渲染错误页面
     */
    private function renderError($message)
    {
        $content = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>LinkHub - 错误</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
        .error { color: #d32f2f; }
    </style>
</head>
<body>
    <h1>LinkHub</h1>
    <div class="error">
        <h2>发生错误</h2>
        <p>' . htmlspecialchars($message) . '</p>
        <p><a href="/install.php">重新安装</a> | <a href="/">返回首页</a></p>
    </div>
</body>
</html>';
        
        return new Response($content, 500);
    }
    
    /**
     * 记录点击
     */
    private function recordClick($linkId, Request $request)
    {
        try {
            $pdo = $this->getDatabaseConnection();
            $tablePrefix = $this->getTablePrefix();
            
            // 更新链接点击数
            $stmt = $pdo->prepare("UPDATE " . $tablePrefix . "links SET click = click + 1 WHERE id = ?");
            $stmt->execute([$linkId]);
            
            // 记录点击日志
            $stmt = $pdo->prepare("
                INSERT INTO " . $tablePrefix . "clicks (link_id, ip, user_agent, referer, click_time) 
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $linkId,
                $request->server('REMOTE_ADDR', ''),
                $request->server('HTTP_USER_AGENT', ''),
                $request->server('HTTP_REFERER', ''),
                time()
            ]);
        } catch (\Exception $e) {
            // 静默处理错误
        }
    }
    
    /**
     * 获取网站图标
     */
    private function getFavicon($url)
    {
        $domain = parse_url($url, PHP_URL_HOST);
        if (!$domain) {
            return null;
        }
        
        // 尝试常见的图标路径
        $iconUrls = [
            "https://$domain/favicon.ico",
            "https://$domain/favicon.png",
            "http://$domain/favicon.ico",
            "http://$domain/favicon.png"
        ];
        
        foreach ($iconUrls as $iconUrl) {
            $headers = @get_headers($iconUrl);
            if ($headers && strpos($headers[0], '200') !== false) {
                return $iconUrl;
            }
        }
        
        return null;
    }
}