<?php

declare(strict_types=1);

namespace LinkHub\Models;

/**
 * 用户模型
 * 
 * @author OneNav Professional Team
 */
class User
{
    /**
     * @var int 用户ID
     */
    public \$id;
    
    /**
     * @var string 用户�?
     */
    public \$username;
    
    /**
     * @var string 密码哈希
     */
    public \$password;
    
    /**
     * @var string|null 邮箱
     */
    public \$email;
    
    /**
     * @var string|null API Token
     */
    public \$token;
    
    /**
     * @var int|null Token过期时间 (Unix时间�?
     */
    public \$token_expire;
    
    /**
     * @var int 角色 (1:管理�? 2:普通用�?
     */
    public \$role = 1;
    
    /**
     * @var int|null 创建时间 (Unix时间�?
     */
    public \$created_at;
    
    /**
     * @var int|null 最后登录时�?(Unix时间�?
     */
    public \$last_login_at;
    
    /**
     * @var string|null 最后登录IP
     */
    public \$last_login_ip;
    
    /**
     * 获取表名
     */
    public static function getTableName()
    {
        return 'on_users';
    }
    
    /**
     * 从数组创建模型实�?
     */
    public static function fromArray(array $data): self
    {
        $user = new self();
        
        foreach ($data as $key => $value) {
            if (property_exists($user, $key)) {
                $user->{$key} = $value;
            }
        }
        
        return $user;
    }
    
    /**
     * 转换为数�?
     */
    public function toArray(bool $excludeSensitive = true)
    {
        $data = get_object_vars($this);
        
        // 移除敏感数据
        if ($excludeSensitive) {
            unset($data['password']);
            unset($data['token']);
        }
        
        // 移除null�?
        return array_filter($data, function ($value) {
            return $value !== null;
        });
    }
    
    /**
     * 是否为管理员
     */
    public function isAdmin()
    {
        return $this->role === 1;
    }
    
    /**
     * 验证密码
     */
    public function verifyPassword(string $password)
    {
        // 支持旧版MD5密码
        if (strlen($this->password) === 32) {
            return md5($password) === $this->password;
        }
        
        // 支持新版密码哈希
        return password_verify($password, $this->password);
    }
    
    /**
     * 生成访问令牌
     */
    public function generateToken(int $expireSeconds = 3600)
    {
        $this->token = bin2hex(random_bytes(32));
        $this->token_expire = time() + $expireSeconds;
        
        return $this->token;
    }
    
    /**
     * 验证令牌是否有效
     */
    public function hasValidToken()
    {
        if (empty($this->token) || empty($this->token_expire)) {
            return false;
        }
        
        return $this->token_expire > time();
    }
    
    /**
     * 获取用户头像URL (Gravatar)
     */
    public function getAvatarUrl(int $size = 80)
    {
        if (empty($this->email)) {
            // 默认头像
            return 'https://www.gravatar.com/avatar/' . md5($this->username) . '?s=' . $size . '&d=mp';
        }
        
        return 'https://www.gravatar.com/avatar/' . md5(strtolower(trim($this->email))) . '?s=' . $size . '&d=mp';
    }
    
    /**
     * 获取格式化的最后登录时�?
     */
    public function getFormattedLastLoginTime(string $format = 'Y-m-d H:i:s')
    {
        return $this->last_login_at ? date($format, $this->last_login_at) : null;
    }
    
    /**
     * 更新最后登录信�?
     */
    public function updateLoginInfo(string $ip)
    {
        $this->last_login_at = time();
        $this->last_login_ip = $ip;
    }
}
