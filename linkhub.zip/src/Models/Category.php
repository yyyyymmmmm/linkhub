<?php

declare(strict_types=1);

namespace LinkHub\Models;

/**
 * 分类模型
 * 
 * @author OneNav Professional Team
 */
class Category
{
    /**
     * @var int 分类ID
     */
    public \$id;
    
    /**
     * @var string 分类名称
     */
    public \$name;
    
    /**
     * @var int 父分类ID (0表示顶级分类)
     */
    public \$fid;
    
    /**
     * @var int 属�?(0:公开, 1:私有)
     */
    public \$property;
    
    /**
     * @var int 权重(排序)
     */
    public \$weight;
    
    /**
     * @var string|null 描述
     */
    public \$description;
    
    /**
     * @var string|null 图标
     */
    public \$font_icon;
    
    /**
     * @var int 添加时间 (Unix时间�?
     */
    public \$add_time;
    
    /**
     * @var int|null 更新时间 (Unix时间�?
     */
    public \$up_time;
    
    /**
     * @var array|null 子分�?
     */
    public ?array $children = null;
    
    /**
     * @var array|null 分类下的链接
     */
    public ?array $links = null;
    
    /**
     * @var string|null 父分类名�?
     */
    public \$parent_name = null;
    
    /**
     * 获取表名
     */
    public static function getTableName()
    {
        return 'on_categorys';
    }
    
    /**
     * 从数组创建模型实�?
     */
    public static function fromArray(array $data): self
    {
        $category = new self();
        
        foreach ($data as $key => $value) {
            if (property_exists($category, $key)) {
                $category->{$key} = $value;
            }
        }
        
        return $category;
    }
    
    /**
     * 转换为数�?
     */
    public function toArray()
    {
        $data = get_object_vars($this);
        
        // 移除null�?
        return array_filter($data, function ($value) {
            return $value !== null;
        });
    }
    
    /**
     * 是否为公开分类
     */
    public function isPublic()
    {
        return $this->property === 0;
    }
    
    /**
     * 是否为顶级分�?
     */
    public function isTopLevel()
    {
        return $this->fid === 0;
    }
    
    /**
     * 是否有子分类
     */
    public function hasChildren()
    {
        return $this->children !== null && count($this->children) > 0;
    }
    
    /**
     * 是否有链�?
     */
    public function hasLinks()
    {
        return $this->links !== null && count($this->links) > 0;
    }
    
    /**
     * 添加子分�?
     */
    public function addChild(Category $child)
    {
        if ($this->children === null) {
            $this->children = [];
        }
        
        $this->children[] = $child;
    }
    
    /**
     * 添加链接
     */
    public function addLink(Link $link)
    {
        if ($this->links === null) {
            $this->links = [];
        }
        
        $this->links[] = $link;
    }
    
    /**
     * 获取图标HTML代码
     */
    public function getIconHtml()
    {
        if (empty($this->font_icon)) {
            return '<i class="fa fa-folder"></i>';
        }
        
        // 如果是Font Awesome图标
        if (strpos($this->font_icon, 'fa-') !== false) {
            return '<i class="fa ' . htmlspecialchars($this->font_icon) . '"></i>';
        }
        
        // 如果是图片URL
        if (strpos($this->font_icon, 'http') === 0 || strpos($this->font_icon, 'data/upload/') === 0) {
            return '<img src="' . htmlspecialchars($this->font_icon) . '" alt="' . htmlspecialchars($this->name) . '" class="category-icon">';
        }
        
        // 默认返回
        return '<i class="' . htmlspecialchars($this->font_icon) . '"></i>';
    }
    
    /**
     * 获取格式化的添加时间
     */
    public function getFormattedAddTime(string $format = 'Y-m-d H:i:s')
    {
        return date($format, $this->add_time);
    }
    
    /**
     * 获取格式化的更新时间
     */
    public function getFormattedUpTime(string $format = 'Y-m-d H:i:s')
    {
        return $this->up_time ? date($format, $this->up_time) : null;
    }
}
