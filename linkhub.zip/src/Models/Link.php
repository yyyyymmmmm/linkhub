<?php

declare(strict_types=1);

namespace LinkHub\Models;

/**
 * 链接模型
 * 
 * @author OneNav Professional Team
 */
class Link
{
    /**
     * @var int 链接ID
     */
    public \$id;
    
    /**
     * @var int 分类ID
     */
    public \$fid;
    
    /**
     * @var string 链接标题
     */
    public \$title;
    
    /**
     * @var string URL地址
     */
    public \$url;
    
    /**
     * @var string|null 备用URL地址
     */
    public \$url_standby;
    
    /**
     * @var string|null 链接描述/备注
     */
    public \$note;
    
    /**
     * @var int|null 链接图标
     */
    public \$font_icon;
    
    /**
     * @var int 属�?(0:公开, 1:私有)
     */
    public \$property;
    
    /**
     * @var int 权重(排序)
     */
    public \$weight;
    
    /**
     * @var int 添加时间 (Unix时间�?
     */
    public \$add_time;
    
    /**
     * @var int|null 更新时间 (Unix时间�?
     */
    public \$up_time;
    
    /**
     * @var int 点击次数
     */
    public \$click = 0;
    
    /**
     * @var string|null 所属分类名�?
     */
    public \$category_name = null;
    
    /**
     * @var Category|null 所属分类对�?
     */
    public ?Category $category = null;
    
    /**
     * 获取表名
     */
    public static function getTableName()
    {
        return 'on_links';
    }
    
    /**
     * 从数组创建模型实�?
     */
    public static function fromArray(array $data): self
    {
        $link = new self();
        
        foreach ($data as $key => $value) {
            if (property_exists($link, $key)) {
                $link->{$key} = $value;
            }
        }
        
        return $link;
    }
    
    /**
     * 转换为数�?
     */
    public function toArray()
    {
        $data = get_object_vars($this);
        
        // 移除category对象，避免循环引�?
        unset($data['category']);
        
        // 移除null�?
        return array_filter($data, function ($value) {
            return $value !== null;
        });
    }
    
    /**
     * 是否为公开链接
     */
    public function isPublic()
    {
        return $this->property === 0;
    }
    
    /**
     * 获取链接域名
     */
    public function getDomain()
    {
        $parts = parse_url($this->url);
        return $parts['host'] ?? '';
    }
    
    /**
     * 获取图标HTML代码
     */
    public function getIconHtml()
    {
        if (empty($this->font_icon)) {
            // 返回默认图标或网站favicon
            $domain = $this->getDomain();
            if (!empty($domain)) {
                return '<img src="https://favicon.yandex.net/favicon/' . $domain . '" alt="favicon" class="link-icon">';
            }
            return '<i class="fa fa-link"></i>';
        }
        
        // 如果是Font Awesome图标
        if (strpos($this->font_icon, 'fa-') !== false) {
            return '<i class="fa ' . htmlspecialchars($this->font_icon) . '"></i>';
        }
        
        // 如果是图片URL
        if (strpos($this->font_icon, 'http') === 0 || strpos($this->font_icon, 'data/upload/') === 0) {
            return '<img src="' . htmlspecialchars($this->font_icon) . '" alt="' . htmlspecialchars($this->title) . '" class="link-icon">';
        }
        
        // 默认返回
        return '<i class="' . htmlspecialchars($this->font_icon) . '"></i>';
    }
    
    /**
     * 获取格式化的添加时间
     */
    public function getFormattedAddTime(string $format = 'Y-m-d H:i:s')
    {
        return date($format, $this->add_time);
    }
    
    /**
     * 获取格式化的更新时间
     */
    public function getFormattedUpTime(string $format = 'Y-m-d H:i:s')
    {
        return $this->up_time ? date($format, $this->up_time) : null;
    }
    
    /**
     * 获取有效URL
     */
    public function getEffectiveUrl()
    {
        // 如果主URL无效但备用URL有效，则返回备用URL
        if (empty($this->url) && !empty($this->url_standby)) {
            return $this->url_standby;
        }
        
        return $this->url;
    }
    
    /**
     * 获取API跟踪URL
     */
    public function getTrackingUrl(string $baseUrl = '')
    {
        return $baseUrl . '/api/click?id=' . $this->id;
    }
}
