<?php

declare(strict_types=1);

namespace LinkHub\Models;

/**
 * 设置模型
 * 
 * @author OneNav Professional Team
 */
class Setting
{
    /**
     * @var int 设置ID
     */
    public \$id;
    
    /**
     * @var string 设置键名
     */
    public \$key;
    
    /**
     * @var string 设置�?
     */
    public \$value;
    
    /**
     * @var string|null 设置描述
     */
    public \$description;
    
    /**
     * @var string 设置类型 (text, textarea, select, radio, checkbox, switch)
     */
    public \$type = 'text';
    
    /**
     * @var string|null 设置选项 (用于select, radio, checkbox类型，JSON格式)
     */
    public \$options;
    
    /**
     * @var bool 是否系统设置
     */
    public bool $is_system = false;
    
    /**
     * @var string|null 设置分组
     */
    public \$group;
    
    /**
     * @var int 排序权重
     */
    public \$weight = 0;
    
    /**
     * 获取表名
     */
    public static function getTableName()
    {
        return 'on_options';
    }
    
    /**
     * 从数组创建模型实�?
     */
    public static function fromArray(array $data): self
    {
        $setting = new self();
        
        foreach ($data as $key => $value) {
            if (property_exists($setting, $key)) {
                $setting->{$key} = $value;
            }
        }
        
        return $setting;
    }
    
    /**
     * 转换为数�?
     */
    public function toArray()
    {
        $data = get_object_vars($this);
        
        // 移除null�?
        return array_filter($data, function ($value) {
            return $value !== null;
        });
    }
    
    /**
     * 获取选项数组
     */
    public function getOptionsArray()
    {
        if (empty($this->options)) {
            return [];
        }
        
        $options = json_decode($this->options, true);
        
        return is_array($options) ? $options : [];
    }
    
    /**
     * 解析设置�?
     */
    public function getTypedValue()
    {
        // 根据不同的类型解析�?
        switch ($this->type) {
            case 'number':
            case 'range':
                return (int) $this->value;
                
            case 'switch':
            case 'checkbox':
                return $this->value === '1' || $this->value === 'true';
                
            case 'json':
                $data = json_decode($this->value, true);
                return is_array($data) ? $data : [];
                
            case 'array':
                return explode(',', $this->value);
                
            default:
                return $this->value;
        }
    }
    
    /**
     * 设置类型化�?
     */
    public function setTypedValue($value)
    {
        // 根据不同的类型格式化�?
        switch ($this->type) {
            case 'number':
            case 'range':
                $this->value = (string) intval($value);
                break;
                
            case 'switch':
            case 'checkbox':
                $this->value = $value ? '1' : '0';
                break;
                
            case 'json':
                $this->value = is_string($value) ? $value : json_encode($value, JSON_UNESCAPED_UNICODE);
                break;
                
            case 'array':
                $this->value = is_array($value) ? implode(',', $value) : (string) $value;
                break;
                
            default:
                $this->value = (string) $value;
        }
    }
    
    /**
     * 是否为复杂类�?
     */
    public function isComplexType()
    {
        return in_array($this->type, ['json', 'array']);
    }
    
    /**
     * 是否为布尔类�?
     */
    public function isBooleanType()
    {
        return in_array($this->type, ['switch', 'checkbox']);
    }
}
