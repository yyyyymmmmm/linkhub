<?php

declare(strict_types=1);

namespace LinkHub\Models;

/**
 * 点击统计模型
 * 
 * @author OneNav Professional Team
 */
class Click
{
    /**
     * @var int 点击ID
     */
    public \$id;
    
    /**
     * @var int 链接ID
     */
    public \$link_id;
    
    /**
     * @var string|null 访问者IP
     */
    public \$ip;
    
    /**
     * @var string|null 用户代理
     */
    public \$user_agent;
    
    /**
     * @var string|null 来源页面
     */
    public \$referer;
    
    /**
     * @var int 点击时间 (Unix时间�?
     */
    public \$click_time;
    
    /**
     * @var Link|null 关联的链接对�?
     */
    public ?Link $link = null;
    
    /**
     * 获取表名
     */
    public static function getTableName()
    {
        return 'on_clicks';
    }
    
    /**
     * 从数组创建模型实�?
     */
    public static function fromArray(array $data): self
    {
        $click = new self();
        
        foreach ($data as $key => $value) {
            if (property_exists($click, $key)) {
                $click->{$key} = $value;
            }
        }
        
        return $click;
    }
    
    /**
     * 转换为数�?
     */
    public function toArray()
    {
        $data = get_object_vars($this);
        
        // 移除link对象，避免循环引�?
        unset($data['link']);
        
        // 移除null�?
        return array_filter($data, function ($value) {
            return $value !== null;
        });
    }
    
    /**
     * 获取浏览器信�?
     */
    public function getBrowser()
    {
        if (empty($this->user_agent)) {
            return 'Unknown';
        }
        
        $browsers = [
            'Chrome' => 'Chrome',
            'Firefox' => 'Firefox',
            'Safari' => 'Safari',
            'Opera' => 'Opera',
            'MSIE' => 'Internet Explorer',
            'Trident' => 'Internet Explorer',
            'Edge' => 'Microsoft Edge',
        ];
        
        foreach ($browsers as $key => $browser) {
            if (strpos($this->user_agent, $key) !== false) {
                return $browser;
            }
        }
        
        return 'Unknown';
    }
    
    /**
     * 获取操作系统信息
     */
    public function getOS()
    {
        if (empty($this->user_agent)) {
            return 'Unknown';
        }
        
        $os = [
            'Windows NT 10.0' => 'Windows 10',
            'Windows NT 6.3' => 'Windows 8.1',
            'Windows NT 6.2' => 'Windows 8',
            'Windows NT 6.1' => 'Windows 7',
            'Windows NT 6.0' => 'Windows Vista',
            'Windows NT 5.1' => 'Windows XP',
            'Windows NT 5.0' => 'Windows 2000',
            'Mac OS X' => 'macOS',
            'Linux' => 'Linux',
            'Ubuntu' => 'Ubuntu',
            'Android' => 'Android',
            'iPhone' => 'iOS',
            'iPad' => 'iOS',
        ];
        
        foreach ($os as $key => $name) {
            if (strpos($this->user_agent, $key) !== false) {
                return $name;
            }
        }
        
        return 'Unknown';
    }
    
    /**
     * 是否为移动设�?
     */
    public function isMobile()
    {
        if (empty($this->user_agent)) {
            return false;
        }
        
        $mobileKeywords = [
            'Mobile', 'Android', 'iPhone', 'iPad', 'Windows Phone', 
            'BlackBerry', 'Opera Mini', 'IEMobile'
        ];
        
        foreach ($mobileKeywords as $keyword) {
            if (strpos($this->user_agent, $keyword) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 获取格式化的点击时间
     */
    public function getFormattedClickTime(string $format = 'Y-m-d H:i:s')
    {
        return date($format, $this->click_time);
    }
    
    /**
     * 获取点击日期 (不含时间)
     */
    public function getClickDate(string $format = 'Y-m-d')
    {
        return date($format, $this->click_time);
    }
}
