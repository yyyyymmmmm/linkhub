<?php

declare(strict_types=1);

namespace LinkHub\Services;

use LinkHub\Core\Database\DatabaseManager;
use LinkHub\Core\Config\ConfigManager;

/**
 * 系统服务
 * 
 * @author OneNav Professional Team
 */
class SystemService
{
    protected \$db;
    protected ConfigManager $config;
    protected \$basePath;
    
    /**
     * 构造函�?
     */
    public function __construct(
        \$db,
        ConfigManager $config,
        string $basePath
    ) {
        $this->db = $db;
        $this->config = $config;
        $this->basePath = rtrim($basePath, '/');
    }
    
    /**
     * 获取系统信息
     */
    public function getSystemInfo()
    {
        return [
            'app' => [
                'name' => $this->config->get('app.name', 'OneNav Professional'),
                'version' => $this->config->get('app.version', '2.0.0'),
                'environment' => $this->config->get('app.env', 'production'),
                'debug' => (bool) $this->config->get('app.debug', false),
                'url' => $this->config->get('app.url', ''),
                'timezone' => $this->config->get('app.timezone', 'UTC'),
            ],
            'server' => [
                'php_version' => PHP_VERSION,
                'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                'server_os' => PHP_OS,
                'mysql_version' => $this->getMySQLVersion(),
                'max_execution_time' => ini_get('max_execution_time'),
                'memory_limit' => ini_get('memory_limit'),
                'upload_max_filesize' => ini_get('upload_max_filesize'),
                'post_max_size' => ini_get('post_max_size'),
            ],
            'paths' => [
                'base_path' => $this->basePath,
                'config_path' => $this->basePath . '/config',
                'storage_path' => $this->basePath . '/storage',
                'public_path' => $this->basePath . '/public',
            ],
            'database' => [
                'driver' => $this->config->get('database.default', 'mysql'),
                'database' => $this->config->get('database.connections.mysql.database', ''),
                'host' => $this->config->get('database.connections.mysql.host', 'localhost'),
            ],
            'extensions' => [
                'pdo_mysql' => extension_loaded('pdo_mysql'),
                'curl' => extension_loaded('curl'),
                'mbstring' => extension_loaded('mbstring'),
                'json' => extension_loaded('json'),
                'openssl' => extension_loaded('openssl'),
                'gd' => extension_loaded('gd'),
                'fileinfo' => extension_loaded('fileinfo'),
                'zip' => extension_loaded('zip'),
            ]
        ];
    }
    
    /**
     * 获取MySQL版本
     */
    protected function getMySQLVersion()
    {
        try {
            $result = $this->db->select("SELECT VERSION() as version");
            return $result[0]['version'] ?? 'Unknown';
        } catch (\Exception $e) {
            return 'Unknown';
        }
    }
    
    /**
     * 检查系统需�?
     */
    public function checkRequirements()
    {
        $requirements = [
            'php' => [
                'version' => PHP_VERSION,
                'required' => '7.4.0',
                'status' => version_compare(PHP_VERSION, '7.4.0', '>='),
            ],
            'extensions' => [
                'pdo_mysql' => extension_loaded('pdo_mysql'),
                'curl' => extension_loaded('curl'),
                'mbstring' => extension_loaded('mbstring'),
                'json' => extension_loaded('json'),
                'openssl' => extension_loaded('openssl'),
            ],
            'directories' => [
                'storage' => is_writable($this->basePath . '/storage'),
                'storage/cache' => is_writable($this->basePath . '/storage/cache'),
                'storage/logs' => is_writable($this->basePath . '/storage/logs'),
                'storage/uploads' => is_writable($this->basePath . '/storage/uploads'),
                'public/uploads' => is_writable($this->basePath . '/public/uploads'),
            ],
            'functions' => [
                'symlink' => function_exists('symlink'),
                'exec' => function_exists('exec'),
                'shell_exec' => function_exists('shell_exec'),
                'proc_open' => function_exists('proc_open'),
                'file_put_contents' => function_exists('file_put_contents'),
            ],
        ];
        
        $success = true;
        
        if (version_compare(PHP_VERSION, '7.4.0', '<')) {
            $success = false;
        }
        
        foreach ($requirements['extensions'] as $extension => $loaded) {
            if (!$loaded) {
                $success = false;
                break;
            }
        }
        
        foreach ($requirements['directories'] as $directory => $writable) {
            if (!$writable) {
                $success = false;
                break;
            }
        }
        
        return [
            'requirements' => $requirements,
            'success' => $success,
        ];
    }
    
    /**
     * 获取存储使用情况
     */
    public function getStorageUsage()
    {
        $storagePath = $this->basePath . '/storage';
        
        $totalSpace = disk_total_space($storagePath);
        $freeSpace = disk_free_space($storagePath);
        $usedSpace = $totalSpace - $freeSpace;
        
        $directories = [
            'cache' => $this->getDirSize($storagePath . '/cache'),
            'logs' => $this->getDirSize($storagePath . '/logs'),
            'uploads' => $this->getDirSize($storagePath . '/uploads'),
        ];
        
        return [
            'total' => $totalSpace,
            'free' => $freeSpace,
            'used' => $usedSpace,
            'usage_percent' => round(($usedSpace / $totalSpace) * 100, 2),
            'directories' => $directories,
        ];
    }
    
    /**
     * 获取目录大小
     */
    protected function getDirSize(string $path)
    {
        if (!is_dir($path)) {
            return 0;
        }
        
        $size = 0;
        $files = scandir($path);
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            
            $filePath = $path . '/' . $file;
            
            if (is_dir($filePath)) {
                $size += $this->getDirSize($filePath);
            } else {
                $size += filesize($filePath);
            }
        }
        
        return $size;
    }
    
    /**
     * 清理缓存
     */
    public function clearCache()
    {
        $cachePath = $this->basePath . '/storage/cache';
        
        if (!is_dir($cachePath)) {
            return false;
        }
        
        return $this->clearDirectory($cachePath);
    }
    
    /**
     * 清空目录
     */
    protected function clearDirectory(string $path, bool $keepDir = true)
    {
        if (!is_dir($path)) {
            return false;
        }
        
        $files = scandir($path);
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            
            $filePath = $path . '/' . $file;
            
            if (is_dir($filePath)) {
                $this->clearDirectory($filePath, false);
            } else {
                unlink($filePath);
            }
        }
        
        if (!$keepDir) {
            rmdir($path);
        }
        
        return true;
    }
    
    /**
     * 获取日志列表
     */
    public function getLogs(int $limit = 10, int $offset = 0)
    {
        $logsPath = $this->basePath . '/storage/logs';
        
        if (!is_dir($logsPath)) {
            return [];
        }
        
        $files = scandir($logsPath, SCANDIR_SORT_DESCENDING);
        $logFiles = [];
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..' || !str_ends_with($file, '.log')) {
                continue;
            }
            
            $logFiles[] = [
                'name' => $file,
                'size' => filesize($logsPath . '/' . $file),
                'modified' => filemtime($logsPath . '/' . $file),
            ];
        }
        
        // 分页
        $total = count($logFiles);
        $logFiles = array_slice($logFiles, $offset, $limit);
        
        return [
            'logs' => $logFiles,
            'total' => $total,
        ];
    }
    
    /**
     * 获取日志内容
     */
    public function getLogContent(string $filename)
    {
        $logsPath = $this->basePath . '/storage/logs';
        
        // 安全检查：确保文件名只包含字母、数字、下划线、横线和�?
        if (!preg_match('/^[a-zA-Z0-9_\-.]+\.log$/', $filename)) {
            throw new \InvalidArgumentException('Invalid log filename');
        }
        
        $filePath = $logsPath . '/' . $filename;
        
        if (!file_exists($filePath)) {
            throw new \InvalidArgumentException('Log file not found');
        }
        
        return file_get_contents($filePath);
    }
    
    /**
     * 清理日志
     */
    public function clearLogs(int $keepDays = 7)
    {
        $logsPath = $this->basePath . '/storage/logs';
        
        if (!is_dir($logsPath)) {
            return false;
        }
        
        $files = scandir($logsPath);
        $cutoffTime = time() - ($keepDays * 86400);
        $deleted = 0;
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..' || !str_ends_with($file, '.log')) {
                continue;
            }
            
            $filePath = $logsPath . '/' . $file;
            $modifiedTime = filemtime($filePath);
            
            if ($modifiedTime < $cutoffTime) {
                unlink($filePath);
                $deleted++;
            }
        }
        
        return $deleted > 0;
    }
    
    /**
     * 获取系统统计数据
     */
    public function getStats()
    {
        $stats = [
            'uptime' => $this->getUptime(),
            'memory' => [
                'used' => memory_get_usage(),
                'peak' => memory_get_peak_usage(),
            ],
            'storage' => $this->getStorageUsed(),
            'database' => [
                'size' => $this->getDatabaseSize(),
                'tables' => $this->getTableCount(),
                'queries' => $this->getQueryCount(),
            ],
        ];
        
        return $stats;
    }
    
    /**
     * 获取系统运行时间
     */
    public function getUptime(): float
    {
        if (function_exists('sys_getloadavg') && stristr(PHP_OS, 'win') === false) {
            return sys_getloadavg()[0];
        }
        
        return 0;
    }
    
    /**
     * 获取存储使用�?
     */
    public function getStorageUsed()
    {
        return $this->getDirSize($this->basePath . '/storage');
    }
    
    /**
     * 获取可用存储空间
     */
    public function getStorageAvailable()
    {
        $storagePath = $this->basePath . '/storage';
        return disk_free_space($storagePath);
    }
    
    /**
     * 获取存储使用百分�?
     */
    public function getStorageUsagePercentage(): float
    {
        $storagePath = $this->basePath . '/storage';
        $totalSpace = disk_total_space($storagePath);
        $freeSpace = disk_free_space($storagePath);
        $usedSpace = $totalSpace - $freeSpace;
        
        return round(($usedSpace / $totalSpace) * 100, 2);
    }
    
    /**
     * 获取数据库大�?
     */
    public function getDatabaseSize(): float
    {
        try {
            $driver = $this->config->get('database.default', 'mysql');
            
            if ($driver === 'sqlite') {
                $dbPath = $this->config->get('database.connections.sqlite.database');
                return file_exists($dbPath) ? filesize($dbPath) : 0;
            }
            
            // 获取MySQL数据库大�?
            $dbName = $this->config->get('database.connections.mysql.database');
            $sql = "SELECT SUM(data_length + index_length) AS size FROM information_schema.tables WHERE table_schema = ?";
            $result = $this->db->select($sql, [$dbName]);
            
            return (float) ($result[0]['size'] ?? 0);
        } catch (\Exception $e) {
            return 0;
        }
    }
    
    /**
     * 获取表数�?
     */
    public function getTableCount()
    {
        try {
            $driver = $this->config->get('database.default', 'mysql');
            
            if ($driver === 'sqlite') {
                $sql = "SELECT count(*) AS count FROM sqlite_master WHERE type='table'";
            } else {
                // MySQL
                $dbName = $this->config->get('database.connections.mysql.database');
                $sql = "SELECT count(*) AS count FROM information_schema.tables WHERE table_schema = ?";
                $result = $this->db->select($sql, [$dbName]);
            }
            
            return (int) ($result[0]['count'] ?? 0);
        } catch (\Exception $e) {
            return 0;
        }
    }
    
    /**
     * 获取查询次数
     */
    public function getQueryCount()
    {
        try {
            return count($this->db->getQueryLog());
        } catch (\Exception $e) {
            return 0;
        }
    }
    
    /**
     * 获取CPU使用�?
     */
    public function getCpuUsage(): float
    {
        if (function_exists('sys_getloadavg') && stristr(PHP_OS, 'win') === false) {
            return sys_getloadavg()[0];
        }
        
        return 0;
    }
    
    /**
     * 检查数据库连接
     */
    public function checkDatabase()
    {
        try {
            $this->db->select("SELECT 1");
            
            return [
                'status' => true,
                'message' => 'Database connection successful',
            ];
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => 'Database connection failed: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * 检查存储目�?
     */
    public function checkStorage()
    {
        $storagePath = $this->basePath . '/storage';
        $writablePaths = [
            'storage' => $storagePath,
            'cache' => $storagePath . '/cache',
            'logs' => $storagePath . '/logs',
            'uploads' => $storagePath . '/uploads',
        ];
        
        $errors = [];
        
        foreach ($writablePaths as $name => $path) {
            if (!is_dir($path)) {
                $errors[] = $name . ' directory does not exist';
                continue;
            }
            
            if (!is_writable($path)) {
                $errors[] = $name . ' directory is not writable';
            }
        }
        
        return [
            'status' => empty($errors),
            'message' => empty($errors) ? 'Storage directories are writable' : implode(', ', $errors),
        ];
    }
    
    /**
     * 检查缓�?
     */
    public function checkCache()
    {
        $cacheDriver = $this->config->get('cache.driver', 'file');
        
        if ($cacheDriver === 'file') {
            $cachePath = $this->basePath . '/storage/cache';
            
            if (!is_dir($cachePath)) {
                return [
                    'status' => false,
                    'message' => 'Cache directory does not exist',
                ];
            }
            
            if (!is_writable($cachePath)) {
                return [
                    'status' => false,
                    'message' => 'Cache directory is not writable',
                ];
            }
            
            // 测试写入
            $testFile = $cachePath . '/test.txt';
            $result = file_put_contents($testFile, 'test');
            
            if ($result === false) {
                return [
                    'status' => false,
                    'message' => 'Cache directory is not writable',
                ];
            }
            
            unlink($testFile);
            
            return [
                'status' => true,
                'message' => 'Cache is working',
            ];
        }
        
        return [
            'status' => true,
            'message' => 'Cache driver: ' . $cacheDriver,
        ];
    }
    
    /**
     * 检查日�?
     */
    public function checkLogs()
    {
        $logsPath = $this->basePath . '/storage/logs';
        
        if (!is_dir($logsPath)) {
            return [
                'status' => false,
                'message' => 'Logs directory does not exist',
            ];
        }
        
        if (!is_writable($logsPath)) {
            return [
                'status' => false,
                'message' => 'Logs directory is not writable',
            ];
        }
        
        // 测试写入
        $testFile = $logsPath . '/test.log';
        $result = file_put_contents($testFile, 'test');
        
        if ($result === false) {
            return [
                'status' => false,
                'message' => 'Logs directory is not writable',
            ];
        }
        
        unlink($testFile);
        
        return [
            'status' => true,
            'message' => 'Logs are working',
        ];
    }
    
    /**
     * 检查权�?
     */
    public function checkPermissions()
    {
        $paths = [
            'storage' => $this->basePath . '/storage',
            'public' => $this->basePath . '/public',
            'config' => $this->basePath . '/config',
        ];
        
        $errors = [];
        
        foreach ($paths as $name => $path) {
            if (!is_readable($path)) {
                $errors[] = $name . ' directory is not readable';
            }
            
            if ($name !== 'config' && !is_writable($path)) {
                $errors[] = $name . ' directory is not writable';
            }
        }
        
        return [
            'status' => empty($errors),
            'message' => empty($errors) ? 'Permissions are correct' : implode(', ', $errors),
        ];
    }
    
    /**
     * 获取最近错�?
     */
    public function getRecentErrors(int $limit = 5)
    {
        $logsPath = $this->basePath . '/storage/logs';
        
        if (!is_dir($logsPath)) {
            return [];
        }
        
        $files = scandir($logsPath, SCANDIR_SORT_DESCENDING);
        $errors = [];
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..' || !str_ends_with($file, '.log')) {
                continue;
            }
            
            $filePath = $logsPath . '/' . $file;
            $content = file_get_contents($filePath);
            
            // 解析日志文件，提取错误信�?
            preg_match_all('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] (.*?)\.ERROR: (.*?)(?:\s+{"exception|$)/s', $content, $matches, PREG_SET_ORDER);
            
            foreach ($matches as $match) {
                $errors[] = [
                    'date' => $match[1],
                    'channel' => $match[2],
                    'message' => $match[3],
                    'file' => $file,
                ];
                
                if (count($errors) >= $limit) {
                    break 2;
                }
            }
        }
        
        return $errors;
    }
}
