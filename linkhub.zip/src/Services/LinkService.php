<?php

declare(strict_types=1);

namespace LinkHub\Services;

use LinkHub\Models\Link;
use LinkHub\Repositories\LinkRepository;
use LinkHub\Repositories\CategoryRepository;
use LinkHub\Repositories\ClickRepository;
use LinkHub\Core\Exception\ValidationException;
use LinkHub\Core\Http\Request;

/**
 * 链接服务
 * 
 * @author OneNav Professional Team
 */
class LinkService
{
    protected \$linkRepository;
    protected \$categoryRepository;
    protected ClickRepository $clickRepository;
    
    public function __construct(
        \$linkRepository, 
        \$categoryRepository, 
        ClickRepository $clickRepository = null
    ) {
        $this->linkRepository = $linkRepository;
        $this->categoryRepository = $categoryRepository;
        $this->clickRepository = $clickRepository;
    }
    
    /**
     * 获取所有链�?
     */
    public function getAll(bool $includePrivate = false, int $limit = null, int $offset = null)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        return $this->linkRepository->getAll($conditions, ['weight' => 'DESC', 'id' => 'DESC'], $limit, $offset);
    }
    
    /**
     * 按分类ID获取链接
     */
    public function getByCategoryId(int $categoryId, bool $includePrivate = false, int $limit = null, int $offset = null)
    {
        $category = $this->categoryRepository->getById($categoryId);
        
        if (!$category) {
            throw new \InvalidArgumentException('Category not found');
        }
        
        // 如果分类是私有的，且不包括私有内容，则返回空数组
        if ($category->property === 1 && !$includePrivate) {
            return [];
        }
        
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        $links = $this->linkRepository->getByCategoryId($categoryId, $conditions, ['weight' => 'DESC', 'id' => 'DESC'], $limit, $offset);
        
        // 设置分类名称
        foreach ($links as $link) {
            $link->category_name = $category->name;
        }
        
        return $links;
    }
    
    /**
     * 按ID获取链接
     */
    public function getById(int $id, bool $includePrivate = false): ?Link
    {
        $link = $this->linkRepository->getById($id);
        
        if (!$link) {
            return null;
        }
        
        if ($link->property === 1 && !$includePrivate) {
            return null;
        }
        
        // 获取分类信息
        $category = $this->categoryRepository->getById($link->fid);
        
        if ($category) {
            $link->category_name = $category->name;
            
            // 如果分类是私有的且不包括私有内容，则返回�?
            if ($category->property === 1 && !$includePrivate) {
                return null;
            }
        }
        
        return $link;
    }
    
    /**
     * 创建链接
     */
    public function create(array $data): Link
    {
        // 验证数据
        $this->validateLinkData($data);
        
        // 检查分类是否存�?
        $category = $this->categoryRepository->getById($data['fid']);
        
        if (!$category) {
            throw new \InvalidArgumentException('Category not found');
        }
        
        $link = new Link();
        $link->fid = $data['fid'];
        $link->title = $data['title'];
        $link->url = $data['url'];
        $link->url_standby = $data['url_standby'] ?? null;
        $link->note = $data['note'] ?? null;
        $link->font_icon = $data['font_icon'] ?? null;
        $link->property = $data['property'] ?? 0;
        $link->weight = $data['weight'] ?? 0;
        $link->add_time = time();
        
        $id = $this->linkRepository->create($link);
        
        return $this->linkRepository->getById($id);
    }
    
    /**
     * 更新链接
     */
    public function update(int $id, array $data): Link
    {
        // 获取链接
        $link = $this->linkRepository->getById($id);
        
        if (!$link) {
            throw new \InvalidArgumentException('Link not found');
        }
        
        // 验证数据
        $this->validateLinkData($data);
        
        // 检查分类是否存�?
        if (isset($data['fid'])) {
            $category = $this->categoryRepository->getById($data['fid']);
            
            if (!$category) {
                throw new \InvalidArgumentException('Category not found');
            }
        }
        
        // 更新字段
        if (isset($data['fid'])) {
            $link->fid = $data['fid'];
        }
        
        if (isset($data['title'])) {
            $link->title = $data['title'];
        }
        
        if (isset($data['url'])) {
            $link->url = $data['url'];
        }
        
        if (isset($data['url_standby'])) {
            $link->url_standby = $data['url_standby'];
        }
        
        if (isset($data['note'])) {
            $link->note = $data['note'];
        }
        
        if (isset($data['font_icon'])) {
            $link->font_icon = $data['font_icon'];
        }
        
        if (isset($data['property'])) {
            $link->property = $data['property'];
        }
        
        if (isset($data['weight'])) {
            $link->weight = $data['weight'];
        }
        
        $this->linkRepository->update($link);
        
        return $link;
    }
    
    /**
     * 删除链接
     */
    public function delete(int $id)
    {
        // 获取链接
        $link = $this->linkRepository->getById($id);
        
        if (!$link) {
            throw new \InvalidArgumentException('Link not found');
        }
        
        return $this->linkRepository->delete($id);
    }
    
    /**
     * 批量移动链接到指定分�?
     */
    public function batchMove(array $ids, int $categoryId)
    {
        // 检查分类是否存�?
        $category = $this->categoryRepository->getById($categoryId);
        
        if (!$category) {
            throw new \InvalidArgumentException('Category not found');
        }
        
        return $this->linkRepository->batchMove($ids, $categoryId);
    }
    
    /**
     * 批量设置链接属�?公开/私有)
     */
    public function batchSetProperty(array $ids, int $property)
    {
        if (!in_array($property, [0, 1])) {
            throw new \InvalidArgumentException('Property must be either 0 or 1');
        }
        
        return $this->linkRepository->batchSetProperty($ids, $property);
    }
    
    /**
     * 批量更新排序
     */
    public function updateOrder(array $ordering)
    {
        return $this->linkRepository->updateOrder($ordering);
    }
    
    /**
     * 获取链接数量
     */
    public function count(bool $includePrivate = true)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        return $this->linkRepository->count($conditions);
    }
    
    /**
     * 获取最近添加的链接
     */
    public function getRecent(int $limit = 10, bool $includePrivate = true)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        $links = $this->linkRepository->getRecent($limit);
        
        // 过滤私有链接
        if (!$includePrivate) {
            $links = array_filter($links, function ($link) {
                return $link->property === 0;
            });
        }
        
        // 获取分类名称
        foreach ($links as $link) {
            $category = $this->categoryRepository->getById($link->fid);
            if ($category) {
                $link->category_name = $category->name;
            }
        }
        
        return $links;
    }
    
    /**
     * 搜索链接
     */
    public function search(string $keyword, bool $includePrivate = false)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        $links = $this->linkRepository->search($keyword, $conditions);
        
        // 获取分类名称和过滤私有分类的链接
        foreach ($links as $key => $link) {
            $category = $this->categoryRepository->getById($link->fid);
            
            if ($category) {
                $link->category_name = $category->name;
                
                // 如果分类是私有的且不包括私有内容，则移除该链�?
                if ($category->property === 1 && !$includePrivate) {
                    unset($links[$key]);
                    continue;
                }
            }
        }
        
        return array_values($links);
    }
    
    /**
     * 验证链接数据
     */
    protected function validateLinkData(array $data)
    {
        $errors = [];
        
        if (empty($data['title'])) {
            $errors['title'] = 'Link title cannot be empty';
        } elseif (mb_strlen($data['title']) > 100) {
            $errors['title'] = 'Link title cannot exceed 100 characters';
        }
        
        if (empty($data['url'])) {
            $errors['url'] = 'URL cannot be empty';
        } elseif (!$this->isValidUrl($data['url'])) {
            $errors['url'] = 'URL is not valid';
        }
        
        if (!empty($data['url_standby']) && !$this->isValidUrl($data['url_standby'])) {
            $errors['url_standby'] = 'Standby URL is not valid';
        }
        
        if (isset($data['property']) && !in_array($data['property'], [0, 1])) {
            $errors['property'] = 'Property must be either 0 or 1';
        }
        
        if (isset($data['weight']) && (!is_numeric($data['weight']) || $data['weight'] < 0 || $data['weight'] > 999)) {
            $errors['weight'] = 'Weight must be a number between 0 and 999';
        }
        
        if (isset($data['note']) && mb_strlen($data['note']) > 500) {
            $errors['note'] = 'Note cannot exceed 500 characters';
        }
        
        if (!empty($errors)) {
            throw new ValidationException($errors);
        }
    }
    
    /**
     * 验证URL是否合法
     */
    protected function isValidUrl(string $url)
    {
        // 支持http/https/ftp/ftps/magnet:?|ed2k|tcp/udp/thunder/rtsp/rtmp/sftp
        $pattern = "/^(http:\/\/|https:\/\/|ftp:\/\/|ftps:\/\/|magnet:?|ed2k:\/\/|tcp:\/\/|udp:\/\/|thunder:\/\/|rtsp:\/\/|rtmp:\/\/|sftp:\/\/).+/";
        return preg_match($pattern, $url);
    }
    
    /**
     * 记录链接点击
     */
    public function recordClick(int $linkId, array $data = [])
    {
        // 增加链接点击次数
        $this->linkRepository->incrementClickCount($linkId);
        
        // 如果没有配置点击仓储，则只增加计�?
        if (!$this->clickRepository) {
            return true;
        }
        
        // 记录详细点击信息
        return $this->clickRepository->recordClick($linkId, $data);
    }
    
    /**
     * 获取点击量最高的链接
     */
    public function getTopClicked(int $limit = 10, bool $includePrivate = false)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        $links = $this->linkRepository->getTopClicked($limit, $conditions);
        
        // 获取分类名称和过滤私有分类的链接
        foreach ($links as $key => $link) {
            $category = $this->categoryRepository->getById($link->fid);
            
            if ($category) {
                $link->category_name = $category->name;
                
                // 如果分类是私有的且不包括私有内容，则移除该链�?
                if ($category->property === 1 && !$includePrivate) {
                    unset($links[$key]);
                    continue;
                }
            }
        }
        
        return array_values($links);
    }
    
    /**
     * 导入链接
     */
    public function importFromHtml(string $htmlContent, int $categoryId, int $property = 0)
    {
        $category = $this->categoryRepository->getById($categoryId);
        
        if (!$category) {
            throw new \InvalidArgumentException('Category not found');
        }
        
        $pattern = "/<A.*<\/A>/i";
        preg_match_all($pattern, $htmlContent, $arr);
        
        $total = count($arr[0]);
        $success = 0;
        $fail = 0;
        
        foreach ($arr[0] as $link) {
            $urlPattern = "/http.*\"? ADD_DATE/i";
            preg_match($urlPattern, $link, $urls);
            
            if (empty($urls)) {
                $fail++;
                continue;
            }
            
            $url = str_replace('" ADD_DATE', '', $urls[0]);
            
            $titlePattern = "/>.*<\/a>$/i";
            preg_match($titlePattern, $link, $titles);
            
            if (empty($titles)) {
                $fail++;
                continue;
            }
            
            $title = str_replace('>', '', $titles[0]);
            $title = str_replace('</A', '', $title);
            
            // 如果标题或者链接为空，则不导入
            if (empty($title) || empty($url)) {
                $fail++;
                continue;
            }
            
            try {
                $this->create([
                    'fid' => $categoryId,
                    'title' => $title,
                    'url' => $url,
                    'property' => $property,
                    'weight' => 0,
                ]);
                
                $success++;
            } catch (\Throwable $e) {
                $fail++;
            }
        }
        
        return [
            'total' => $total,
            'success' => $success,
            'failed' => $fail
        ];
    }
    
    /**
     * 获取链接信息 (从URL抓取标题和描�?
     */
    public function fetchLinkInfo(string $url)
    {
        if (!$this->isValidUrl($url)) {
            throw new \InvalidArgumentException('URL is not valid');
        }
        
        $info = [
            'title' => '',
            'description' => '',
        ];
        
        try {
            // 获取网站内容
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36');
            
            $data = curl_exec($ch);
            curl_close($ch);
            
            // 检测编码并转换为UTF-8
            if (strpos($data, 'utf-8') === false && strpos($data, 'UTF-8') === false) {
                $data = mb_convert_encoding($data, 'UTF-8', 'GBK,GB2312,UTF-8');
            }
            
            // 提取标题
            preg_match('/<title>(.*?)<\/title>/is', $data, $title);
            if (!empty($title[1])) {
                $info['title'] = trim($title[1]);
            }
            
            // 提取描述
            preg_match('/<meta\s+name="description"\s+content="(.*?)"/is', $data, $description);
            if (!empty($description[1])) {
                $info['description'] = trim($description[1]);
            }
        } catch (\Throwable $e) {
            // 抓取失败，使用URL作为标题
            $info['title'] = parse_url($url, PHP_URL_HOST);
        }
        
        return $info;
    }
}
