<?php

declare(strict_types=1);

namespace LinkHub\Services;

use LinkHub\Core\Http\Request;
use LinkHub\Models\User;
use LinkHub\Repositories\UserRepository;
use LinkHub\Core\Exception\AuthenticationException;

/**
 * 认证服务
 * 
 * @author OneNav Professional Team
 */
class AuthService
{
    protected \$userRepository;
    protected \$tokenExpiration;
    protected \$maxLoginAttempts;
    protected \$lockoutTime;
    
    /**
     * 构造函�?
     */
    public function __construct(
        \$userRepository,
        int $tokenExpiration = 3600,
        int $maxLoginAttempts = 5,
        int $lockoutTime = 900
    ) {
        $this->userRepository = $userRepository;
        $this->tokenExpiration = $tokenExpiration;
        $this->maxLoginAttempts = $maxLoginAttempts;
        $this->lockoutTime = $lockoutTime;
    }
    
    /**
     * 尝试登录
     */
    public function attempt(string $username, string $password, Request $request)
    {
        // 检查是否达到尝试次数上�?
        if ($this->tooManyAttempts($request)) {
            return [
                'success' => false,
                'message' => 'Too many login attempts. Please try again later.',
            ];
        }
        
        // 获取用户
        $user = $this->userRepository->getByUsername($username);
        
        if (!$user) {
            $this->recordAttempt($request);
            return [
                'success' => false,
                'message' => 'Invalid username or password',
            ];
        }
        
        // 验证密码
        if (!$user->verifyPassword($password)) {
            $this->recordAttempt($request);
            return [
                'success' => false,
                'message' => 'Invalid username or password',
            ];
        }
        
        // 生成令牌
        $token = $user->generateToken($this->tokenExpiration);
        $this->userRepository->update($user);
        
        // 更新最后登录信�?
        $user->updateLoginInfo($request->getClientIp());
        $this->userRepository->update($user);
        
        // 设置会话
        $this->setUserSession($user, $request);
        
        return [
            'success' => true,
            'message' => 'Login successful',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'username' => $user->username,
                'email' => $user->email,
                'role' => $user->role,
            ]
        ];
    }
    
    /**
     * 用户登出
     */
    public function logout(Request $request)
    {
        // 清除Cookie
        setcookie('auth_key', '', time() - 3600, '/');
        
        // 清除Session
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        
        return true;
    }
    
    /**
     * 检查用户是否已认证
     */
    public function check(Request $request)
    {
        // 从会话中获取用户ID
        $userId = $this->getUserIdFromSession($request);
        
        if ($userId) {
            return true;
        }
        
        // 从请求头中获取Token
        $token = $this->getTokenFromRequest($request);
        
        if ($token) {
            $user = $this->userRepository->getByToken($token);
            
            if ($user && $user->hasValidToken()) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 获取当前用户
     */
    public function user(Request $request)
    {
        // 从会话中获取用户ID
        $userId = $this->getUserIdFromSession($request);
        
        if ($userId) {
            $user = $this->userRepository->getById($userId);
            
            if ($user) {
                return $user->toArray();
            }
        }
        
        // 从请求头中获取Token
        $token = $this->getTokenFromRequest($request);
        
        if ($token) {
            $user = $this->userRepository->getByToken($token);
            
            if ($user && $user->hasValidToken()) {
                return $user->toArray();
            }
        }
        
        return null;
    }
    
    /**
     * 刷新令牌
     */
    public function refresh(Request $request)
    {
        $token = $this->getTokenFromRequest($request);
        
        if (!$token) {
            throw new AuthenticationException('No token provided');
        }
        
        $user = $this->userRepository->getByToken($token);
        
        if (!$user || !$user->hasValidToken()) {
            throw new AuthenticationException('Invalid or expired token');
        }
        
        // 生成新令�?
        $newToken = $user->generateToken($this->tokenExpiration);
        $this->userRepository->update($user);
        
        return $newToken;
    }
    
    /**
     * 更新用户密码
     */
    public function updatePassword(int $userId, string $newPassword)
    {
        $user = $this->userRepository->getById($userId);
        
        if (!$user) {
            throw new AuthenticationException('User not found');
        }
        
        // 使用更安全的密码哈希算法
        $user->password = password_hash($newPassword, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536, // 64 MB
            'time_cost' => 4,       // 4 iterations
            'threads' => 3,         // 3 threads
        ]);
        
        return $this->userRepository->update($user);
    }
    
    /**
     * 验证密码是否匹配
     */
    public function verifyPassword(string $password, string $hash)
    {
        // 支持旧版MD5密码
        if (strlen($hash) === 32) {
            return md5($password) === $hash;
        }
        
        // 支持新版密码哈希
        return password_verify($password, $hash);
    }
    
    /**
     * 设置用户会话
     */
    protected function setUserSession(User $user, Request $request)
    {
        $key = md5($user->username . $user->password . 'onenav' . $request->getUserAgent());
        
        // 设置Cookie，有效期�?小时
        setcookie('auth_key', $key, time() + 7200, '/');
        
        // 如果session未启动，则启动session
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        $_SESSION['user_id'] = $user->id;
    }
    
    /**
     * 从会话中获取用户ID
     */
    protected function getUserIdFromSession(Request $request)
    {
        $authKey = $request->cookie('auth_key');
        
        if (!$authKey) {
            return null;
        }
        
        // 从session中获取用户ID
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        return $_SESSION['user_id'] ?? null;
    }
    
    /**
     * 从请求中获取Token
     */
    protected function getTokenFromRequest(Request $request)
    {
        // 从请求头中获取Token
        $token = $request->header('X-Token');
        
        if ($token) {
            return $token;
        }
        
        // 从请求参数中获取Token
        return $request->query('token') ?? $request->request('token');
    }
    
    /**
     * 记录登录尝试
     */
    public function recordAttempt(Request $request)
    {
        $ip = $request->getClientIp();
        $key = 'login_attempts:' . $ip;
        
        // 如果session未启动，则启动session
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = [
                'count' => 0,
                'last_attempt' => 0
            ];
        }
        
        $_SESSION[$key]['count']++;
        $_SESSION[$key]['last_attempt'] = time();
    }
    
    /**
     * 清除登录尝试记录
     */
    public function clearAttempts(Request $request)
    {
        $ip = $request->getClientIp();
        $key = 'login_attempts:' . $ip;
        
        // 如果session未启动，则启动session
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        unset($_SESSION[$key]);
    }
    
    /**
     * 检查是否达到尝试次数上�?
     */
    public function tooManyAttempts(Request $request)
    {
        $ip = $request->getClientIp();
        $key = 'login_attempts:' . $ip;
        
        // 如果session未启动，则启动session
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        if (!isset($_SESSION[$key])) {
            return false;
        }
        
        $attempts = $_SESSION[$key];
        
        // 如果达到锁定时间，清除尝试记�?
        if (time() - $attempts['last_attempt'] > $this->lockoutTime) {
            unset($_SESSION[$key]);
            return false;
        }
        
        return $attempts['count'] >= $this->maxLoginAttempts;
    }
    
    /**
     * 获取剩余锁定时间
     */
    public function getRemainingLockoutTime(Request $request)
    {
        $ip = $request->getClientIp();
        $key = 'login_attempts:' . $ip;
        
        // 如果session未启动，则启动session
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        
        if (!isset($_SESSION[$key])) {
            return 0;
        }
        
        $attempts = $_SESSION[$key];
        
        if ($attempts['count'] < $this->maxLoginAttempts) {
            return 0;
        }
        
        $remainingTime = $this->lockoutTime - (time() - $attempts['last_attempt']);
        
        return $remainingTime > 0 ? $remainingTime : 0;
    }
}
