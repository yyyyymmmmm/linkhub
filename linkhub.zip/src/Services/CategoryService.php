<?php

declare(strict_types=1);

namespace LinkHub\Services;

use LinkHub\Models\Category;
use LinkHub\Repositories\CategoryRepository;
use LinkHub\Repositories\LinkRepository;
use LinkHub\Core\Exception\ValidationException;

/**
 * 分类服务
 * 
 * @author OneNav Professional Team
 */
class CategoryService
{
    protected \$categoryRepository;
    protected \$linkRepository;
    
    public function __construct(\$categoryRepository, \$linkRepository)
    {
        $this->categoryRepository = $categoryRepository;
        $this->linkRepository = $linkRepository;
    }
    
    /**
     * 获取所有分�?
     */
    public function getAll(bool $includePrivate = false)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        return $this->categoryRepository->getAll($conditions);
    }
    
    /**
     * 获取层次化的分类�?
     */
    public function getHierarchical(bool $includePrivate = false)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        return $this->categoryRepository->getHierarchical($conditions);
    }
    
    /**
     * 按ID获取分类
     */
    public function getById(int $id, bool $includePrivate = false): ?Category
    {
        $category = $this->categoryRepository->getById($id);
        
        if ($category && (!$includePrivate && $category->property === 1)) {
            return null;
        }
        
        return $category;
    }
    
    /**
     * 创建分类
     */
    public function create(array $data): Category
    {
        // 验证数据
        $this->validateCategoryData($data);
        
        // 检查父分类是否存在
        if (!empty($data['fid']) && $data['fid'] > 0) {
            $parentCategory = $this->categoryRepository->getById($data['fid']);
            
            if (!$parentCategory) {
                throw new \InvalidArgumentException('Parent category not found');
            }
            
            // 检查父分类是否为二级分�?
            if ($parentCategory->fid > 0) {
                throw new \InvalidArgumentException('Cannot create subcategory under a subcategory');
            }
        }
        
        // 检查同级分类名称是否已存在
        $existingCategory = $this->categoryRepository->getByName($data['name'], $data['fid'] ?? 0);
        
        if ($existingCategory) {
            throw new \InvalidArgumentException('Category name already exists');
        }
        
        $category = new Category();
        $category->name = $data['name'];
        $category->fid = $data['fid'] ?? 0;
        $category->property = $data['property'] ?? 0;
        $category->weight = $data['weight'] ?? 0;
        $category->description = $data['description'] ?? null;
        $category->font_icon = $data['font_icon'] ?? null;
        $category->add_time = time();
        
        $id = $this->categoryRepository->create($category);
        
        return $this->categoryRepository->getById($id);
    }
    
    /**
     * 更新分类
     */
    public function update(int $id, array $data): Category
    {
        // 获取分类
        $category = $this->categoryRepository->getById($id);
        
        if (!$category) {
            throw new \InvalidArgumentException('Category not found');
        }
        
        // 验证数据
        $this->validateCategoryData($data);
        
        // 检查父分类是否存在
        if (isset($data['fid']) && $data['fid'] > 0) {
            $parentCategory = $this->categoryRepository->getById($data['fid']);
            
            if (!$parentCategory) {
                throw new \InvalidArgumentException('Parent category not found');
            }
            
            // 检查父分类是否为二级分�?
            if ($parentCategory->fid > 0) {
                throw new \InvalidArgumentException('Cannot set parent category as a subcategory');
            }
            
            // 检查分类是否有子分类，如果有则不允许设置为子分�?
            if ($data['fid'] > 0 && $this->categoryRepository->hasChildren($id)) {
                throw new \InvalidArgumentException('Cannot set category with children as a subcategory');
            }
            
            // 检查是否将分类设置为自己的子分�?
            if ($data['fid'] == $id) {
                throw new \InvalidArgumentException('Cannot set category as its own subcategory');
            }
        }
        
        // 检查同级分类名称是否已存在
        $existingCategory = $this->categoryRepository->getByName(
            $data['name'], 
            isset($data['fid']) ? $data['fid'] : $category->fid
        );
        
        if ($existingCategory && $existingCategory->id !== $id) {
            throw new \InvalidArgumentException('Category name already exists');
        }
        
        // 更新字段
        if (isset($data['name'])) {
            $category->name = $data['name'];
        }
        
        if (isset($data['fid'])) {
            $category->fid = $data['fid'];
        }
        
        if (isset($data['property'])) {
            $category->property = $data['property'];
        }
        
        if (isset($data['weight'])) {
            $category->weight = $data['weight'];
        }
        
        if (isset($data['description'])) {
            $category->description = $data['description'];
        }
        
        if (isset($data['font_icon'])) {
            $category->font_icon = $data['font_icon'];
        }
        
        $this->categoryRepository->update($category);
        
        return $category;
    }
    
    /**
     * 删除分类
     */
    public function delete(int $id)
    {
        // 获取分类
        $category = $this->categoryRepository->getById($id);
        
        if (!$category) {
            throw new \InvalidArgumentException('Category not found');
        }
        
        // 首先删除该分类下的所有链�?
        $links = $this->linkRepository->getByCategoryId($id);
        
        foreach ($links as $link) {
            $this->linkRepository->delete($link->id);
        }
        
        // 删除该分�?
        return $this->categoryRepository->delete($id);
    }
    
    /**
     * 批量更新排序
     */
    public function updateOrder(array $ordering)
    {
        return $this->categoryRepository->updateOrder($ordering);
    }
    
    /**
     * 获取分类数量
     */
    public function count(bool $includePrivate = true)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        return $this->categoryRepository->count($conditions);
    }
    
    /**
     * 验证分类数据
     */
    protected function validateCategoryData(array $data)
    {
        $errors = [];
        
        if (empty($data['name'])) {
            $errors['name'] = 'Category name cannot be empty';
        } elseif (mb_strlen($data['name']) > 50) {
            $errors['name'] = 'Category name cannot exceed 50 characters';
        }
        
        if (isset($data['property']) && !in_array($data['property'], [0, 1])) {
            $errors['property'] = 'Property must be either 0 or 1';
        }
        
        if (isset($data['weight']) && (!is_numeric($data['weight']) || $data['weight'] < 0 || $data['weight'] > 999)) {
            $errors['weight'] = 'Weight must be a number between 0 and 999';
        }
        
        if (isset($data['description']) && mb_strlen($data['description']) > 255) {
            $errors['description'] = 'Description cannot exceed 255 characters';
        }
        
        if (!empty($errors)) {
            throw new ValidationException($errors);
        }
    }
    
    /**
     * 获取最近添加的分类
     */
    public function getRecent(int $limit = 10, bool $includePrivate = true)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        $categories = $this->categoryRepository->getRecent($limit);
        
        // 过滤私有分类
        if (!$includePrivate) {
            $categories = array_filter($categories, function ($category) {
                return $category->property === 0;
            });
        }
        
        return $categories;
    }
    
    /**
     * 搜索分类
     */
    public function search(string $keyword, bool $includePrivate = false)
    {
        $conditions = [];
        
        if (!$includePrivate) {
            $conditions['property'] = 0;
        }
        
        return $this->categoryRepository->search($keyword, $conditions);
    }
    
    /**
     * 获取带有链接数量的分类列�?
     */
    public function getCategoriesWithLinkCount(bool $includePrivate = false)
    {
        $categories = $this->getAll($includePrivate);
        
        foreach ($categories as $category) {
            $conditions = [];
            
            if (!$includePrivate) {
                $conditions['property'] = 0;
            }
            
            $category->link_count = $this->linkRepository->countByCategoryId($category->id, $conditions);
        }
        
        return $categories;
    }
}
