<?php

declare(strict_types=1);

namespace LinkHub\Repositories;

use LinkHub\Models\Link;
use LinkHub\Core\Database\DatabaseManager;

/**
 * 链接仓储
 * 
 * @author OneNav Professional Team
 */
class LinkRepository
{
    protected \$db;
    protected \$table;
    
    public function __construct(\$db)
    {
        $this->db = $db;
        $this->table = Link::getTableName();
    }
    
    /**
     * 获取所有链�?
     */
    public function getAll(array $conditions = [], array $order = ['weight' => 'DESC', 'id' => 'DESC'], int $limit = null, int $offset = null)
    {
        $query = $this->db->table($this->table);
        
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        
        foreach ($order as $field => $direction) {
            $query->orderBy($field, $direction);
        }
        
        if ($limit !== null) {
            $query->limit($limit);
            
            if ($offset !== null) {
                $query->offset($offset);
            }
        }
        
        $results = $query->get();
        
        // 转换为模型对�?
        return array_map(function ($data) {
            return Link::fromArray($data);
        }, $results);
    }
    
    /**
     * 按分类ID获取链接
     */
    public function getByCategoryId(int $categoryId, array $conditions = [], array $order = ['weight' => 'DESC', 'id' => 'DESC'], int $limit = null, int $offset = null)
    {
        $conditions['fid'] = $categoryId;
        return $this->getAll($conditions, $order, $limit, $offset);
    }
    
    /**
     * 按ID获取链接
     */
    public function getById(int $id): ?Link
    {
        $data = $this->db->table($this->table)->where('id', $id)->first();
        
        if (!$data) {
            return null;
        }
        
        return Link::fromArray($data);
    }
    
    /**
     * 按URL获取链接
     */
    public function getByUrl(string $url, int $categoryId = null): ?Link
    {
        $query = $this->db->table($this->table)->where('url', $url);
        
        if ($categoryId !== null) {
            $query->where('fid', $categoryId);
        }
        
        $data = $query->first();
        
        if (!$data) {
            return null;
        }
        
        return Link::fromArray($data);
    }
    
    /**
     * 创建链接
     */
    public function create(Link $link)
    {
        // 设置添加时间
        if (empty($link->add_time)) {
            $link->add_time = time();
        }
        
        $id = $this->db->table($this->table)->insert($link->toArray());
        $link->id = $id;
        
        return $id;
    }
    
    /**
     * 更新链接
     */
    public function update(Link $link)
    {
        // 设置更新时间
        $link->up_time = time();
        
        $result = $this->db->table($this->table)
            ->where('id', $link->id)
            ->update($link->toArray());
        
        return $result > 0;
    }
    
    /**
     * 删除链接
     */
    public function delete(int $id)
    {
        return $this->db->table($this->table)
            ->where('id', $id)
            ->delete() > 0;
    }
    
    /**
     * 获取链接数量
     */
    public function count(array $conditions = [])
    {
        $query = $this->db->table($this->table);
        
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        
        return $query->count();
    }
    
    /**
     * 按分类ID获取链接数量
     */
    public function countByCategoryId(int $categoryId, array $conditions = [])
    {
        $conditions['fid'] = $categoryId;
        return $this->count($conditions);
    }
    
    /**
     * 批量更新链接排序
     */
    public function updateOrder(array $ordering)
    {
        $this->db->beginTransaction();
        
        try {
            foreach ($ordering as $id => $weight) {
                $this->db->table($this->table)
                    ->where('id', $id)
                    ->update(['weight' => $weight]);
            }
            
            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            $this->db->rollback();
            return false;
        }
    }
    
    /**
     * 获取最近添加的链接
     */
    public function getRecent(int $limit = 10)
    {
        $results = $this->db->table($this->table)
            ->orderBy('add_time', 'DESC')
            ->limit($limit)
            ->get();
        
        return array_map(function ($data) {
            return Link::fromArray($data);
        }, $results);
    }
    
    /**
     * 搜索链接
     */
    public function search(string $keyword, array $conditions = [])
    {
        $query = $this->db->table($this->table);
        
        $query->where(function($q) use ($keyword) {
            $q->where('title', 'LIKE', "%{$keyword}%")
              ->orWhere('url', 'LIKE', "%{$keyword}%")
              ->orWhere('note', 'LIKE', "%{$keyword}%");
        });
        
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        
        $query->orderBy('weight', 'DESC');
        $query->orderBy('id', 'DESC');
        
        $results = $query->get();
        
        return array_map(function ($data) {
            return Link::fromArray($data);
        }, $results);
    }
    
    /**
     * 批量移动链接到指定分�?
     */
    public function batchMove(array $ids, int $categoryId)
    {
        return $this->db->table($this->table)
            ->whereIn('id', $ids)
            ->update(['fid' => $categoryId]);
    }
    
    /**
     * 批量设置链接属�?公开/私有)
     */
    public function batchSetProperty(array $ids, int $property)
    {
        return $this->db->table($this->table)
            ->whereIn('id', $ids)
            ->update(['property' => $property]);
    }
    
    /**
     * 增加点击次数
     */
    public function incrementClickCount(int $id)
    {
        return $this->db->table($this->table)
            ->where('id', $id)
            ->increment('click') > 0;
    }
    
    /**
     * 按点击次数获取链�?
     */
    public function getTopClicked(int $limit = 10, array $conditions = [])
    {
        $query = $this->db->table($this->table);
        
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        
        $results = $query->orderBy('click', 'DESC')
            ->limit($limit)
            ->get();
        
        return array_map(function ($data) {
            return Link::fromArray($data);
        }, $results);
    }
}
