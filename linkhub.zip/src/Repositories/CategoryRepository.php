<?php

declare(strict_types=1);

namespace LinkHub\Repositories;

use LinkHub\Models\Category;
use LinkHub\Core\Database\DatabaseManager;

/**
 * 分类仓储
 * 
 * @author OneNav Professional Team
 */
class CategoryRepository
{
    protected \$db;
    protected \$table;
    
    public function __construct(\$db)
    {
        $this->db = $db;
        $this->table = Category::getTableName();
    }
    
    /**
     * 获取所有分�?
     */
    public function getAll(array $conditions = [], array $order = ['weight' => 'DESC', 'id' => 'DESC'])
    {
        $query = $this->db->table($this->table);
        
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        
        foreach ($order as $field => $direction) {
            $query->orderBy($field, $direction);
        }
        
        $results = $query->get();
        
        // 转换为模型对�?
        return array_map(function ($data) {
            return Category::fromArray($data);
        }, $results);
    }
    
    /**
     * 获取顶级分类
     */
    public function getTopLevel(array $conditions = [], array $order = ['weight' => 'DESC', 'id' => 'DESC'])
    {
        $conditions['fid'] = 0;
        return $this->getAll($conditions, $order);
    }
    
    /**
     * 获取子分�?
     */
    public function getChildren(int $parentId, array $conditions = [], array $order = ['weight' => 'DESC', 'id' => 'DESC'])
    {
        $conditions['fid'] = $parentId;
        return $this->getAll($conditions, $order);
    }
    
    /**
     * 按ID获取分类
     */
    public function getById(int $id): ?Category
    {
        $data = $this->db->table($this->table)->where('id', $id)->first();
        
        if (!$data) {
            return null;
        }
        
        return Category::fromArray($data);
    }
    
    /**
     * 按名称获取分�?
     */
    public function getByName(string $name, int $fid = null): ?Category
    {
        $query = $this->db->table($this->table)->where('name', $name);
        
        if ($fid !== null) {
            $query->where('fid', $fid);
        }
        
        $data = $query->first();
        
        if (!$data) {
            return null;
        }
        
        return Category::fromArray($data);
    }
    
    /**
     * 创建分类
     */
    public function create(Category $category)
    {
        // 设置添加时间
        if (empty($category->add_time)) {
            $category->add_time = time();
        }
        
        $id = $this->db->table($this->table)->insert($category->toArray());
        $category->id = $id;
        
        return $id;
    }
    
    /**
     * 更新分类
     */
    public function update(Category $category)
    {
        // 设置更新时间
        $category->up_time = time();
        
        $result = $this->db->table($this->table)
            ->where('id', $category->id)
            ->update($category->toArray());
        
        return $result > 0;
    }
    
    /**
     * 删除分类
     */
    public function delete(int $id)
    {
        return $this->db->table($this->table)
            ->where('id', $id)
            ->delete() > 0;
    }
    
    /**
     * 获取分类数量
     */
    public function count(array $conditions = [])
    {
        $query = $this->db->table($this->table);
        
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        
        return $query->count();
    }
    
    /**
     * 检查分类是否有子分�?
     */
    public function hasChildren(int $id)
    {
        return $this->db->table($this->table)
            ->where('fid', $id)
            ->count() > 0;
    }
    
    /**
     * 获取层次化的分类�?
     */
    public function getHierarchical(array $conditions = [])
    {
        // 首先获取所有顶级分�?
        $topLevel = $this->getTopLevel($conditions);
        
        // 然后获取每个顶级分类的子分类
        foreach ($topLevel as $category) {
            $children = $this->getChildren($category->id, $conditions);
            $category->children = $children;
        }
        
        return $topLevel;
    }
    
    /**
     * 批量更新分类排序
     */
    public function updateOrder(array $ordering)
    {
        $this->db->beginTransaction();
        
        try {
            foreach ($ordering as $id => $weight) {
                $this->db->table($this->table)
                    ->where('id', $id)
                    ->update(['weight' => $weight]);
            }
            
            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            $this->db->rollback();
            return false;
        }
    }
    
    /**
     * 获取最近添加的分类
     */
    public function getRecent(int $limit = 10)
    {
        $results = $this->db->table($this->table)
            ->orderBy('add_time', 'DESC')
            ->limit($limit)
            ->get();
        
        return array_map(function ($data) {
            return Category::fromArray($data);
        }, $results);
    }
    
    /**
     * 搜索分类
     */
    public function search(string $keyword, array $conditions = [])
    {
        $query = $this->db->table($this->table);
        
        $query->where(function($q) use ($keyword) {
            $q->where('name', 'LIKE', "%{$keyword}%")
              ->orWhere('description', 'LIKE', "%{$keyword}%");
        });
        
        foreach ($conditions as $field => $value) {
            $query->where($field, $value);
        }
        
        $query->orderBy('weight', 'DESC');
        $query->orderBy('id', 'DESC');
        
        $results = $query->get();
        
        return array_map(function ($data) {
            return Category::fromArray($data);
        }, $results);
    }
}
