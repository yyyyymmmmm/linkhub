<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>OneNav Professional 安装向导</title>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/static/bootstrap4/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
        }
        
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
        }
        
        .install-container {
            max-width: 900px;
            margin: 50px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .install-header {
            background: var(--primary-color);
            color: #fff;
            padding: 25px;
            text-align: center;
            position: relative;
        }
        
        .install-header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
        }
        
        .install-header .version {
            position: absolute;
            bottom: 5px;
            right: 10px;
            font-size: 12px;
            opacity: 0.8;
        }
        
        .install-body {
            padding: 30px;
        }
        
        .install-footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: right;
            border-top: 1px solid #eee;
        }
        
        .steps {
            display: flex;
            margin-bottom: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
        }
        
        .step {
            flex: 1;
            text-align: center;
            position: relative;
        }
        
        .step:not(:last-child):after {
            content: '';
            position: absolute;
            top: 15px;
            right: -50%;
            width: 100%;
            height: 2px;
            background: #ddd;
            z-index: 0;
        }
        
        .step-number {
            width: 34px;
            height: 34px;
            background: #ddd;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 8px;
            position: relative;
            z-index: 1;
            font-weight: bold;
        }
        
        .step.active .step-number {
            background: var(--primary-color);
            color: #fff;
        }
        
        .step.completed .step-number {
            background: var(--secondary-color);
            color: #fff;
        }
        
        .step-name {
            font-size: 14px;
            color: #777;
        }
        
        .step.active .step-name {
            color: var(--primary-color);
            font-weight: 500;
        }
        
        .step.completed .step-name {
            color: var(--secondary-color);
        }
        
        .requirement-item {
            margin-bottom: 12px;
            padding: 12px 15px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .requirement-item.success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .requirement-item.warning {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .requirement-item.danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .requirement-item .status {
            font-size: 18px;
        }
        
        .db-type-selector {
            margin-bottom: 25px;
        }
        
        .db-type-selector .btn {
            width: 100%;
            text-align: left;
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #ddd;
            background-color: #fff;
            transition: all 0.3s ease;
        }
        
        .db-type-selector .btn.active {
            background-color: #e9f7fe;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }
        
        .db-type-selector .btn i {
            margin-right: 10px;
            font-size: 20px;
            width: 24px;
            text-align: center;
        }
        
        .db-type-selector .btn .badge {
            float: right;
            margin-top: 2px;
        }
        
        .success-icon {
            font-size: 80px;
            color: var(--secondary-color);
            text-align: center;
            margin-bottom: 30px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        
        .btn-secondary {
            background-color: #95a5a6;
            border-color: #95a5a6;
        }
        
        .btn-secondary:hover {
            background-color: #7f8c8d;
            border-color: #7f8c8d;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        .next-steps {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 20px;
            margin-top: 20px;
        }
        
        .next-steps h5 {
            margin-bottom: 15px;
            color: var(--dark-color);
        }
        
        .next-steps ul {
            padding-left: 20px;
        }
        
        .next-steps li {
            margin-bottom: 10px;
        }
        
        @media (max-width: 768px) {
            .install-container {
                margin: 20px;
            }
            
            .steps {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .step {
                margin-bottom: 15px;
                display: flex;
                align-items: center;
            }
            
            .step:not(:last-child):after {
                display: none;
            }
            
            .step-number {
                margin-bottom: 0;
                margin-right: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="install-container">
        <div class="install-header">
            <h1>OneNav Professional 安装向导</h1>
            <div class="version">v2.0.0</div>
        </div>
        
        <div class="install-body">
            <div class="steps">
                <div class="step <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 1 ? '<i class="fa fa-check"></i>' : '1'; ?></div>
                    <div class="step-name">环境检查</div>
                </div>
                <div class="step <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 2 ? '<i class="fa fa-check"></i>' : '2'; ?></div>
                    <div class="step-name">数据库配置</div>
                </div>
                <div class="step <?php echo $step >= 3 ? 'active' : ''; ?> <?php echo $step > 3 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 3 ? '<i class="fa fa-check"></i>' : '3'; ?></div>
                    <div class="step-name">管理员设置</div>
                </div>
                <div class="step <?php echo $step >= 4 ? 'active' : ''; ?>">
                    <div class="step-number"><?php echo $step > 4 ? '<i class="fa fa-check"></i>' : '4'; ?></div>
                    <div class="step-name">安装完成</div>
                </div>
            </div>
            
            <?php if (isset($error) && !empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fa fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php echo $content ?? ''; ?>
        </div>
        
        <?php if (!isset($hideFooter) || !$hideFooter): ?>
        <div class="install-footer">
            <?php if (isset($prevUrl)): ?>
                <a href="<?php echo $prevUrl; ?>" class="btn btn-secondary mr-2">
                    <i class="fa fa-arrow-left"></i> 上一步
                </a>
            <?php endif; ?>
            
            <?php if (isset($nextUrl)): ?>
                <a href="<?php echo $nextUrl; ?>" class="btn btn-primary">
                    下一步 <i class="fa fa-arrow-right"></i>
                </a>
            <?php endif; ?>
            
            <?php if (isset($submitForm)): ?>
                <button type="submit" form="<?php echo $submitForm; ?>" class="btn btn-primary">
                    <?php echo $submitText ?? '下一步'; ?> <i class="fa fa-arrow-right"></i>
                </button>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/bootstrap4/js/bootstrap.bundle.min.js"></script>
    <?php echo $scripts ?? ''; ?>
</body>
</html>


