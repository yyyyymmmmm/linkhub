<?php
$dbType = $db_type ?? 'sqlite';

$scripts = <<<EOT
<script>
    // 数据库类型切换
    $(document).ready(function() {
        const sqliteBtn = $('#sqlite-btn');
        const mysqlBtn = $('#mysql-btn');
        const dbTypeInput = $('#db_type');
        const sqliteConfig = $('#sqlite-config');
        const mysqlConfig = $('#mysql-config');
        
        sqliteBtn.on('click', function() {
            dbTypeInput.val('sqlite');
            sqliteConfig.removeClass('d-none');
            mysqlConfig.addClass('d-none');
            sqliteBtn.addClass('active');
            mysqlBtn.removeClass('active');
        });
        
        mysqlBtn.on('click', function() {
            dbTypeInput.val('mysql');
            sqliteConfig.addClass('d-none');
            mysqlConfig.removeClass('d-none');
            sqliteBtn.removeClass('active');
            mysqlBtn.addClass('active');
        });
    });
</script>
EOT;

$content = <<<EOT
<h3 class="mb-4">数据库配置</h3>

<form action="/install/database" method="post" id="database-form">
    <div class="db-type-selector">
        <h5 class="mb-3">选择数据库类型</h5>
        <div class="row">
            <div class="col-md-6">
                <button type="button" class="btn {$dbType != 'mysql' ? 'active' : ''}" id="sqlite-btn" data-type="sqlite">
                    <i class="fa fa-database"></i> SQLite
                    <span class="badge badge-success">推荐</span>
                </button>
            </div>
            <div class="col-md-6">
                <button type="button" class="btn {$dbType == 'mysql' ? 'active' : ''}" id="mysql-btn" data-type="mysql">
                    <i class="fa fa-server"></i> MySQL / MariaDB
                </button>
            </div>
        </div>
        <div class="mt-2 text-muted small">
            <i class="fa fa-info-circle"></i> SQLite适合个人使用或小型站点，MySQL适合大型站点或高并发场景。
        </div>
    </div>
    
    <input type="hidden" name="db_type" id="db_type" value="{$dbType}">
    
    <div id="sqlite-config" class="{$dbType == 'mysql' ? 'd-none' : ''}">
        <div class="alert alert-info">
            <i class="fa fa-info-circle"></i> SQLite数据库将存储在 <code>storage/database/onenav.db3</code> 文件中，无需额外配置。
        </div>
    </div>
    
    <div id="mysql-config" class="{$dbType != 'mysql' ? 'd-none' : ''}">
        <div class="form-group">
            <label for="db_host">数据库主机</label>
            <input type="text" class="form-control" id="db_host" name="db_host" value="{$db_host ?? 'localhost'}" placeholder="localhost">
            <small class="form-text text-muted">通常为localhost或127.0.0.1</small>
        </div>
        
        <div class="form-group">
            <label for="db_port">端口</label>
            <input type="number" class="form-control" id="db_port" name="db_port" value="{$db_port ?? '3306'}" placeholder="3306">
            <small class="form-text text-muted">MySQL默认端口为3306</small>
        </div>
        
        <div class="form-group">
            <label for="db_name">数据库名称</label>
            <input type="text" class="form-control" id="db_name" name="db_name" value="{$db_name ?? 'onenav'}" placeholder="onenav">
            <small class="form-text text-muted">如果数据库不存在，将尝试创建</small>
        </div>
        
        <div class="form-group">
            <label for="db_user">用户名</label>
            <input type="text" class="form-control" id="db_user" name="db_user" value="{$db_user ?? 'root'}" placeholder="root">
        </div>
        
        <div class="form-group">
            <label for="db_pass">密码</label>
            <input type="password" class="form-control" id="db_pass" name="db_pass" value="{$db_pass ?? ''}" placeholder="请输入数据库密码">
        </div>
    </div>
    
    <div class="form-group">
        <label for="db_prefix">表前缀</label>
        <input type="text" class="form-control" id="db_prefix" name="db_prefix" value="{$db_prefix ?? 'on_'}" placeholder="on_">
        <small class="form-text text-muted">如果您在一个数据库中安装多个OneNav，可以修改表前缀</small>
    </div>
</form>
EOT;

$prevUrl = '/install/requirements';
$submitForm = 'database-form';

include __DIR__ . '/layout.php';
?>


