<?php
$content = <<<EOT
<div class="text-center mb-4">
    <img src="/static/images/logo.png" alt="OneNav Logo" style="max-width: 150px; margin-bottom: 20px;">
    <h2>欢迎使用 OneNav Professional</h2>
    <p class="lead">专业的书签管理和导航系统</p>
</div>

<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <i class="fa fa-info-circle"></i> 安装说明
    </div>
    <div class="card-body">
        <p>感谢您选择 OneNav Professional！在开始安装之前，请确保您的服务器满足以下要求：</p>
        <ul>
            <li>PHP 7.4 或更高版本</li>
            <li>PDO 扩展（支持 SQLite 或 MySQL）</li>
            <li>JSON 扩展</li>
            <li>MBString 扩展</li>
            <li>存储目录的写入权限</li>
        </ul>
        <p>安装过程将引导您完成以下步骤：</p>
        <ol>
            <li>环境检查 - 验证您的服务器是否满足系统要求</li>
            <li>数据库配置 - 设置数据库连接</li>
            <li>管理员设置 - 创建管理员账户</li>
            <li>完成安装 - 开始使用 OneNav Professional</li>
        </ol>
    </div>
</div>

<div class="alert alert-info">
    <i class="fa fa-lightbulb-o"></i> <strong>提示：</strong> 安装过程中如遇问题，请参考<a href="https://github.com/your-username/onenav/wiki" target="_blank">官方文档</a>或<a href="https://github.com/your-username/onenav/issues" target="_blank">提交问题</a>。
</div>
EOT;

$nextUrl = '/install/requirements';

include __DIR__ . '/layout.php';
?>


