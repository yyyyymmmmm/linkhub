<?php
$content = <<<EOT
<h3 class="mb-4">环境检查</h3>
<p>OneNav Professional 需要以下环境支持：</p>

<div class="requirement-section">
    <h5 class="mt-4 mb-3">PHP版本</h5>
    <div class="requirement-item {$requirements['php']['status'] ? 'success' : 'danger'}">
        <div>
            <strong>PHP版本 >= 7.4.0</strong>
        </div>
        <div class="status">
            当前版本: {$requirements['php']['version']}
            {$requirements['php']['status'] ? '<i class="fa fa-check-circle text-success"></i>' : '<i class="fa fa-times-circle text-danger"></i>'}
        </div>
    </div>
    
    <h5 class="mt-4 mb-3">必要扩展</h5>
EOT;

foreach ($requirements['extensions'] as $name => $installed) {
    $statusClass = $installed ? 'success' : 'danger';
    $icon = $installed ? '<i class="fa fa-check-circle text-success"></i>' : '<i class="fa fa-times-circle text-danger"></i>';
    
    $content .= <<<EOT
    <div class="requirement-item {$statusClass}">
        <div>
            <strong>{$name}</strong>
        </div>
        <div class="status">
            {$icon}
        </div>
    </div>
EOT;
}

$content .= <<<EOT
    <h5 class="mt-4 mb-3">目录权限</h5>
EOT;

foreach ($requirements['directories'] as $name => $writable) {
    $statusClass = $writable ? 'success' : 'danger';
    $icon = $writable ? '<i class="fa fa-check-circle text-success"></i>' : '<i class="fa fa-times-circle text-danger"></i>';
    
    $content .= <<<EOT
    <div class="requirement-item {$statusClass}">
        <div>
            <strong>{$name}</strong>
        </div>
        <div class="status">
            {$icon}
        </div>
    </div>
EOT;
}

$content .= <<<EOT
</div>

<div class="alert alert-info mt-4">
    <i class="fa fa-info-circle"></i> 如果您的环境不满足以上要求，请先解决这些问题再继续安装。
</div>
EOT;

$prevUrl = '/install';
$nextUrl = $requirements['success'] ? '/install/database' : null;

include __DIR__ . '/layout.php';
?>


