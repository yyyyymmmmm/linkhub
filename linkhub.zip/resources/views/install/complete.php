<?php
$hideFooter = true;

$content = <<<EOT
<div class="text-center">
    <div class="success-icon">
        <i class="fa fa-check-circle"></i>
    </div>
    
    <h2 class="mb-4">恭喜！OneNav Professional 安装成功</h2>
    <p class="lead mb-4">您现在可以开始使用OneNav管理您的书签和导航链接了。</p>
    
    <div class="alert alert-success mb-4">
        <strong>管理员账户信息</strong><br>
        用户名: {$username}
    </div>
    
    <div class="next-steps text-left mb-4">
        <h5><i class="fa fa-list-ul"></i> 后续步骤</h5>
        <ul>
            <li>登录到管理后台，开始添加分类和链接</li>
            <li>设置网站基本信息和偏好设置</li>
            <li>选择并配置您喜欢的主题</li>
            <li>备份您的数据</li>
            <li>探索更多高级功能</li>
        </ul>
    </div>
    
    <div class="alert alert-warning mb-4">
        <i class="fa fa-exclamation-triangle"></i> <strong>安全提示</strong><br>
        为了安全起见，请确保删除或重命名安装目录，以防止他人重新安装。
    </div>
    
    <div class="mt-4">
        <a href="/" class="btn btn-lg btn-outline-primary mr-3">
            <i class="fa fa-home"></i> 访问首页
        </a>
        <a href="/admin" class="btn btn-lg btn-primary">
            <i class="fa fa-dashboard"></i> 进入管理后台
        </a>
    </div>
</div>
EOT;

include __DIR__ . '/layout.php';
?>


