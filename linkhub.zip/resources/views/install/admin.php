<?php
$content = <<<EOT
<h3 class="mb-4">管理员账户设置</h3>

<div class="alert alert-info mb-4">
    <i class="fa fa-info-circle"></i> 请创建您的管理员账户。这将是系统的超级管理员，拥有所有权限。
</div>

<form action="/install/admin" method="post" id="admin-form">
    <div class="form-group">
        <label for="username">用户名</label>
        <input type="text" class="form-control {isset($errors['username']) ? 'is-invalid' : ''}" id="username" name="username" value="{$username ?? ''}" placeholder="请输入管理员用户名" required>
        {isset($errors['username']) ? '<div class="invalid-feedback">'.$errors['username'].'</div>' : ''}
        <small class="form-text text-muted">用户名长度为3-20个字符</small>
    </div>
    
    <div class="form-group">
        <label for="password">密码</label>
        <input type="password" class="form-control {isset($errors['password']) ? 'is-invalid' : ''}" id="password" name="password" placeholder="请输入密码" required>
        {isset($errors['password']) ? '<div class="invalid-feedback">'.$errors['password'].'</div>' : ''}
        <small class="form-text text-muted">密码长度不能少于6个字符</small>
    </div>
    
    <div class="form-group">
        <label for="confirm_password">确认密码</label>
        <input type="password" class="form-control {isset($errors['confirm_password']) ? 'is-invalid' : ''}" id="confirm_password" name="confirm_password" placeholder="请再次输入密码" required>
        {isset($errors['confirm_password']) ? '<div class="invalid-feedback">'.$errors['confirm_password'].'</div>' : ''}
    </div>
    
    <div class="form-group">
        <label for="email">电子邮箱 <span class="text-muted">(可选)</span></label>
        <input type="email" class="form-control {isset($errors['email']) ? 'is-invalid' : ''}" id="email" name="email" value="{$email ?? ''}" placeholder="请输入电子邮箱">
        {isset($errors['email']) ? '<div class="invalid-feedback">'.$errors['email'].'</div>' : ''}
        <small class="form-text text-muted">用于接收系统通知和找回密码</small>
    </div>
    
    <div class="alert alert-warning">
        <i class="fa fa-exclamation-triangle"></i> <strong>安全提示：</strong> 请使用强密码保护您的账户安全。强密码应包含大小写字母、数字和特殊字符。
    </div>
</form>
EOT;

$prevUrl = '/install/database';
$submitForm = 'admin-form';
$submitText = '完成安装';

include __DIR__ . '/layout.php';
?>


