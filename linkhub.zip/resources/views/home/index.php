<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OneNav Professional</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            color: #3498db;
        }
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            margin: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>OneNav Professional</h1>
        <p>专业的书签管理和导航系统</p>
        
        <div class="success-message">
            恭喜！OneNav Professional 已成功安装。
        </div>
        
        <div>
            <a href="/admin" class="btn">进入管理后台</a>
        </div>
    </div>
</body>
</html>


