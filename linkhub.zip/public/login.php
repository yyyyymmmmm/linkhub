<?php
session_start();

// 如果已经登录，重定向到管理面板
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in']) {
    $redirectUrl = $_GET['redirect'] ?? '/admin/';
    header('Location: ' . $redirectUrl);
    exit;
}

// 数据库连接
require_once dirname(__DIR__) . '/config/database_connection.php';
$pdo = getDatabaseConnection();
$tablePrefix = getTablePrefix();

$error = '';
$success = '';

// 检查是否启用注册功能
$stmt = $pdo->prepare("SELECT `value` FROM " . $tablePrefix . "settings WHERE `key` = 'enable_register'");
$stmt->execute();
$enableRegister = $stmt->fetchColumn();
$enableRegister = ($enableRegister === '1'); // 转换为布尔值

// 处理注册
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'register') {
    // 首先检查是否启用注册
    if (!$enableRegister) {
        $error = '系统管理员已关闭用户注册功能';
    } else {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $email = trim($_POST['email'] ?? '');
    
    if (empty($username) || empty($password)) {
        $error = '请输入用户名和密码';
    } elseif ($password !== $confirmPassword) {
        $error = '两次输入的密码不一致';
    } elseif (strlen($password) < 6) {
        $error = '密码长度至少6位';
    } else {
        try {
            // 检查用户名是否已存在
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetchColumn() > 0) {
                $error = '用户名已存在';
            } else {
                // 创建新用户（角色2=普通用户）
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    INSERT INTO " . $tablePrefix . "users (username, password, email, role, status, add_time) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$username, $hashedPassword, $email, 2, 1, time()]);
                
                $success = '注册成功！请使用新账户登录。';
            }
        } catch (Exception $e) {
            $error = '注册失败：' . $e->getMessage();
        }
    }
    } // 结束 enable_register 检查
}

// 处理登录
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = '请输入用户名和密码';
    } else {
        try {
            // 查找用户（兼容新旧表结构）
            try {
                $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "users WHERE username = ? AND (status = 1 OR status IS NULL)");
            } catch (Exception $e) {
                // 如果没有status字段，使用简单查询
                $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "users WHERE username = ?");
            }
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                // 登录成功
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_user_id'] = $user['id'];
                $_SESSION['admin_username'] = $user['username'];
                $_SESSION['admin_role'] = $user['role'];
                
                // 更新最后登录时间
                try {
                    $stmt = $pdo->prepare("UPDATE " . $tablePrefix . "users SET last_login_at = ?, last_login_ip = ? WHERE id = ?");
                    $stmt->execute([time(), $_SERVER['REMOTE_ADDR'] ?? '', $user['id']]);
                } catch (Exception $e) {
                    // 如果字段不存在，忽略错误
                }
                
                // 设置记住登录cookie（可选）
                if (isset($_POST['remember']) && $_POST['remember']) {
                    $token = bin2hex(random_bytes(32));
                    setcookie('admin_token', $token, time() + (30 * 24 * 60 * 60), '/'); // 30天
                    
                    // 保存token到数据库（这里简化处理）
                    $stmt = $pdo->prepare("UPDATE " . $tablePrefix . "users SET remember_token = ? WHERE id = ?");
                    $stmt->execute([$token, $user['id']]);
                }
                
                $redirectUrl = $_GET['redirect'] ?? '/admin/';
                header('Location: ' . $redirectUrl);
                exit;
            } else {
                $error = '用户名或密码错误';
            }
        } catch (Exception $e) {
            $error = '登录失败：' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkHub - 管理员登录</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .login-header {
            margin-bottom: 30px;
        }

        .login-header h1 {
            color: #333;
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #666;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
        }

        .checkbox-group input[type="checkbox"] {
            margin-right: 8px;
            width: auto;
            padding: 0;
        }

        .checkbox-group label {
            margin: 0;
            font-size: 14px;
            color: #666;
            cursor: pointer;
        }

        .login-button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        .login-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .login-button:active {
            transform: translateY(0);
        }

        .alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }

        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }

        .back-link {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .back-link a {
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: color 0.3s ease;
        }

        .back-link a:hover {
            color: #764ba2;
        }

        .toggle-btn {
            background: none;
            border: none;
            color: #667eea;
            cursor: pointer;
            font-size: 14px;
            text-decoration: underline;
            transition: color 0.3s ease;
        }

        .toggle-btn:hover {
            color: #764ba2;
        }

        @media (max-width: 480px) {
            .login-container {
                margin: 20px;
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1><i class="fas fa-shield-alt"></i> LinkHub</h1>
            <p>管理员登录</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <!-- 登录表单 -->
        <form method="POST" id="loginForm">
            <input type="hidden" name="action" value="login">
            
            <div class="form-group">
                <label for="username">用户名</label>
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" placeholder="请输入用户名" 
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label for="password">密码</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" placeholder="请输入密码" required>
                </div>
            </div>

            <div class="checkbox-group">
                <input type="checkbox" id="remember" name="remember" value="1">
                <label for="remember">记住登录状态（30天）</label>
            </div>

            <button type="submit" class="login-button">
                <i class="fas fa-sign-in-alt"></i> 登录
            </button>
        </form>

        <?php if ($enableRegister): ?>
        <!-- 注册表单 -->
        <form method="POST" id="registerForm" style="display: none;">
            <input type="hidden" name="action" value="register">
            
            <div class="form-group">
                <label for="reg_username">用户名</label>
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="reg_username" name="username" placeholder="请输入用户名" required>
                </div>
            </div>

            <div class="form-group">
                <label for="reg_email">邮箱</label>
                <div class="input-wrapper">
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="reg_email" name="email" placeholder="请输入邮箱">
                </div>
            </div>

            <div class="form-group">
                <label for="reg_password">密码</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="reg_password" name="password" placeholder="请输入密码（至少6位）" required>
                </div>
            </div>

            <div class="form-group">
                <label for="confirm_password">确认密码</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="请再次输入密码" required>
                </div>
            </div>

            <button type="submit" class="login-button">
                <i class="fas fa-user-plus"></i> 注册
            </button>
        </form>
        <?php endif; ?>

        <!-- 切换按钮 -->
        <?php if ($enableRegister): ?>
        <div style="text-align: center; margin-top: 15px;">
            <button type="button" id="toggleForm" class="toggle-btn">
                还没有账户？点击注册
            </button>
        </div>
        <?php endif; ?>

        <div class="back-link">
            <a href="/">
                <i class="fas fa-arrow-left"></i> 返回网站首页
            </a>
        </div>
    </div>

    <script>
        let isLoginForm = true;

        // 自动聚焦到用户名输入框
        document.addEventListener('DOMContentLoaded', function() {
            const usernameInput = document.getElementById('username');
            if (usernameInput && !usernameInput.value) {
                usernameInput.focus();
            }

            // 切换表单功能
            const enableRegister = <?= json_encode($enableRegister) ?>;
            const toggleBtn = document.getElementById('toggleForm');
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerForm');
            const loginHeader = document.querySelector('.login-header h1');
            const loginSubtitle = document.querySelector('.login-header p');

            // 如果注册功能未启用或元素不存在，直接返回
            if (!enableRegister || !toggleBtn || !registerForm) {
                return;
            }

            toggleBtn.addEventListener('click', function() {
                if (isLoginForm) {
                    // 切换到注册表单
                    loginForm.style.display = 'none';
                    registerForm.style.display = 'block';
                    loginHeader.innerHTML = '<i class="fas fa-user-plus"></i> LinkHub';
                    loginSubtitle.textContent = '用户注册';
                    toggleBtn.textContent = '已有账户？点击登录';
                    document.getElementById('reg_username').focus();
                    isLoginForm = false;
                } else {
                    // 切换到登录表单
                    registerForm.style.display = 'none';
                    loginForm.style.display = 'block';
                    loginHeader.innerHTML = '<i class="fas fa-shield-alt"></i> LinkHub';
                    loginSubtitle.textContent = '管理员登录';
                    toggleBtn.textContent = '还没有账户？点击注册';
                    document.getElementById('username').focus();
                    isLoginForm = true;
                }
            });
        });

        // 回车键快捷提交
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const activeForm = isLoginForm ? document.getElementById('loginForm') : document.getElementById('registerForm');
                activeForm.submit();
            }
        });

        // 注册表单密码确认验证
        const confirmPasswordInput = document.getElementById('confirm_password');
        if (confirmPasswordInput) {
            confirmPasswordInput.addEventListener('input', function() {
            const password = document.getElementById('reg_password').value;
            const confirmPassword = this.value;
            
            if (password && confirmPassword && password !== confirmPassword) {
                this.setCustomValidity('密码不一致');
                this.style.borderColor = '#e74c3c';
            } else {
                this.setCustomValidity('');
                this.style.borderColor = '#e1e5e9';
            }
        });
        }
    </script>
</body>
</html>
