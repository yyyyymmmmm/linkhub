<?php
/**
 * 高级过渡页面
 * 在跳转到目标网站前显示过渡页面
 */

// 启动会话
session_start();

// 引入数据库连接
require_once '../config/database_connection.php';

try {
    $pdo = getDatabaseConnection();
    $tablePrefix = getTablePrefix();
    
    // 获取系统设置
    $stmt = $pdo->query("SELECT `key`, `value` FROM " . $tablePrefix . "settings");
    $settingsData = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // 获取过渡页面配置
    $transitionTime = intval($settingsData['transition_time'] ?? 3);
    $transitionColor = $settingsData['transition_theme_color'] ?? '#6366f1';
    $transitionTitle = $settingsData['transition_title'] ?? '正在跳转中...';
    $transitionMessage = $settingsData['transition_message'] ?? '即将为您跳转到目标网站，请稍候...';
    $transitionAdCode = $settingsData['transition_ad_code'] ?? '';
    $showProgress = ($settingsData['transition_show_progress'] ?? '1') === '1';
    $allowSkip = ($settingsData['transition_allow_skip'] ?? '1') === '1';
    $siteName = $settingsData['site_name'] ?? 'LinkHub';
    
} catch (Exception $e) {
    // 如果数据库连接失败，使用默认值
    $transitionTime = 3;
    $transitionColor = '#6366f1';
    $transitionTitle = '正在跳转中...';
    $transitionMessage = '即将为您跳转到目标网站，请稍候...';
    $transitionAdCode = '';
    $showProgress = true;
    $allowSkip = true;
    $siteName = 'LinkHub';
}

// 获取URL参数
$targetUrl = $_GET['url'] ?? '';
$siteName = $_GET['site'] ?? $siteName;

// 验证URL
if (empty($targetUrl)) {
    // 如果没有目标URL，跳转回首页
    header('Location: /');
    exit;
}

// 确保URL是有效的
if (!filter_var($targetUrl, FILTER_VALIDATE_URL)) {
    // 如果URL无效，尝试添加http://前缀
    if (!preg_match('/^https?:\/\//', $targetUrl)) {
        $targetUrl = 'http://' . $targetUrl;
    }
    
    // 再次验证
    if (!filter_var($targetUrl, FILTER_VALIDATE_URL)) {
        header('Location: /');
        exit;
    }
}

// 记录点击统计（如果启用）
if (($settingsData['enable_click_stats'] ?? '1') === '1') {
    try {
        // 尝试记录点击
        $linkId = $_GET['link_id'] ?? null;
        if ($linkId) {
            $stmt = $pdo->prepare("UPDATE " . $tablePrefix . "links SET click = click + 1 WHERE id = ?");
            $stmt->execute([$linkId]);
            
            // 记录点击日志（如果有clicks表）
            try {
                $stmt = $pdo->prepare("INSERT INTO " . $tablePrefix . "clicks (link_id, ip, user_agent, referer, click_time) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $linkId,
                    $_SERVER['REMOTE_ADDR'] ?? '',
                    $_SERVER['HTTP_USER_AGENT'] ?? '',
                    $_SERVER['HTTP_REFERER'] ?? '',
                    time()
                ]);
            } catch (Exception $e) {
                // 忽略点击日志错误
            }
        }
    } catch (Exception $e) {
        // 忽略统计错误
    }
}

// 安全头设置
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= htmlspecialchars($transitionTitle) ?> - <?= htmlspecialchars($siteName) ?></title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, <?= $transitionColor ?>20, <?= $transitionColor ?>40);
            color: #333;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .transition-container {
            text-align: center;
            background: white;
            border-radius: 20px;
            padding: 3rem 2rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 90%;
            position: relative;
            overflow: hidden;
        }

        .transition-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: <?= $transitionColor ?>;
        }

        .icon {
            width: 80px;
            height: 80px;
            background: <?= $transitionColor ?>;
            border-radius: 50%;
            margin: 0 auto 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: pulse 2s infinite;
        }

        .icon svg {
            width: 40px;
            height: 40px;
            fill: white;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .title {
            font-size: 1.8rem;
            font-weight: 600;
            color: #1a1a1a;
            margin-bottom: 0.5rem;
        }

        .message {
            font-size: 1rem;
            color: #666;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .target-info {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 2rem;
            border-left: 4px solid <?= $transitionColor ?>;
        }

        .target-label {
            font-size: 0.875rem;
            color: #888;
            margin-bottom: 0.5rem;
        }

        .target-url {
            font-size: 0.95rem;
            color: #333;
            word-break: break-all;
            font-weight: 500;
        }

        .progress-container {
            margin-bottom: 2rem;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background: #e9ecef;
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 1rem;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, <?= $transitionColor ?>, <?= $transitionColor ?>80);
            border-radius: 3px;
            width: 0%;
            transition: width 0.1s ease;
        }

        .countdown {
            font-size: 1.1rem;
            font-weight: 600;
            color: <?= $transitionColor ?>;
        }

        .actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s ease;
        }

        .btn-primary {
            background: <?= $transitionColor ?>;
            color: white;
        }

        .btn-primary:hover {
            background: <?= $transitionColor ?>dd;
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-1px);
        }

        .ad-container {
            margin: 1.5rem 0;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px dashed #dee2e6;
        }

        @media (max-width: 480px) {
            .transition-container {
                padding: 2rem 1.5rem;
            }
            
            .title {
                font-size: 1.5rem;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="transition-container">
        <div class="icon">
            <svg viewBox="0 0 24 24">
                <path d="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z"/>
            </svg>
        </div>

        <h1 class="title"><?= htmlspecialchars($transitionTitle) ?></h1>
        <p class="message"><?= htmlspecialchars($transitionMessage) ?></p>

        <div class="target-info">
            <div class="target-label">目标网站：</div>
            <div class="target-url"><?= htmlspecialchars($targetUrl) ?></div>
        </div>

        <?php if ($showProgress): ?>
        <div class="progress-container">
            <div class="progress-bar">
                <div class="progress-fill" id="progressFill"></div>
            </div>
            <div class="countdown" id="countdown"><?= $transitionTime ?> 秒后自动跳转</div>
        </div>
        <?php endif; ?>

        <?php if (!empty($transitionAdCode)): ?>
        <div class="ad-container">
            <?= $transitionAdCode ?>
        </div>
        <?php endif; ?>

        <div class="actions">
            <button class="btn btn-primary" onclick="jumpNow()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z"/>
                </svg>
                立即跳转
            </button>
            
            <?php if ($allowSkip): ?>
            <a href="/" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z"/>
                </svg>
                返回首页
            </a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        const targetUrl = <?= json_encode($targetUrl) ?>;
        const transitionTime = <?= $transitionTime ?>;
        const showProgress = <?= json_encode($showProgress) ?>;
        
        let countdown = transitionTime;
        let progressFill = document.getElementById('progressFill');
        let countdownEl = document.getElementById('countdown');
        
        function jumpNow() {
            window.location.href = targetUrl;
        }
        
        function updateProgress() {
            if (showProgress && progressFill && countdownEl) {
                const progress = ((transitionTime - countdown) / transitionTime) * 100;
                progressFill.style.width = progress + '%';
                
                if (countdown > 0) {
                    countdownEl.textContent = countdown + ' 秒后自动跳转';
                } else {
                    countdownEl.textContent = '正在跳转...';
                }
            }
        }
        
        function startCountdown() {
            updateProgress();
            
            if (countdown <= 0) {
                jumpNow();
                return;
            }
            
            countdown--;
            setTimeout(startCountdown, 1000);
        }
        
        // 开始倒计时
        if (transitionTime > 0) {
            setTimeout(startCountdown, 100);
        } else {
            // 如果时间为0，立即跳转
            jumpNow();
        }
        
        // 键盘快捷键
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                jumpNow();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                window.location.href = '/';
            }
        });
        
        // 防止页面被嵌套
        if (window.top !== window.self) {
            window.top.location = window.location;
        }
    </script>
</body>
</html>
