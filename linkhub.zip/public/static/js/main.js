/**
 * LinkHub - 主JS文件
 */

(function() {
    'use strict';

    // 文档加载完成后执行
    document.addEventListener('DOMContentLoaded', function() {
        // 初始化搜索引擎切换
        initSearchEngines();
        
        // 初始化分类折叠
        initCategoryCollapse();
        
        // 初始化链接点击跟踪
        initLinkTracking();
        
        // 检查暗黑模式
        checkDarkMode();
    });

    /**
     * 初始化搜索引擎切换
     */
    function initSearchEngines() {
        const engineItems = document.querySelectorAll('.search-engine-item');
        const searchForm = document.querySelector('.search-form');
        
        if (!engineItems.length || !searchForm) return;
        
        // 默认激活第一个搜索引擎
        engineItems[0].classList.add('active');
        
        engineItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                
                // 更新表单提交地址
                const engineUrl = this.getAttribute('data-url');
                searchForm.setAttribute('action', engineUrl);
                
                // 更新激活状态
                engineItems.forEach(item => item.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }

    /**
     * 初始化分类折叠
     */
    function initCategoryCollapse() {
        const categoryHeaders = document.querySelectorAll('.category-header');
        
        if (!categoryHeaders.length) return;
        
        categoryHeaders.forEach(header => {
            header.addEventListener('click', function() {
                const target = this.getAttribute('data-target');
                const content = document.querySelector(target);
                
                if (content) {
                    const isExpanded = content.classList.contains('show');
                    
                    if (isExpanded) {
                        content.classList.remove('show');
                        this.setAttribute('aria-expanded', 'false');
                    } else {
                        content.classList.add('show');
                        this.setAttribute('aria-expanded', 'true');
                    }
                }
            });
        });
    }

    /**
     * 初始化链接点击跟踪
     */
    function initLinkTracking() {
        const links = document.querySelectorAll('.link-item');
        
        if (!links.length) return;
        
        links.forEach(link => {
            link.addEventListener('click', function(e) {
                // 检查是否有追踪URL
                const trackUrl = this.getAttribute('data-track');
                
                if (!trackUrl) return;
                
                e.preventDefault();
                
                // 发送跟踪请求
                const targetUrl = this.getAttribute('href');
                
                fetch(trackUrl, {
                    method: 'GET',
                    credentials: 'same-origin'
                }).then(() => {
                    // 跳转到目标URL
                    window.open(targetUrl, '_blank');
                }).catch(() => {
                    // 如果跟踪失败，仍然跳转
                    window.open(targetUrl, '_blank');
                });
            });
        });
    }

    /**
     * 检查暗黑模式
     */
    function checkDarkMode() {
        // 检查系统是否为暗黑模式
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.body.classList.add('dark-mode');
        }
        
        // 监听系统暗黑模式变化
        if (window.matchMedia) {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
                if (event.matches) {
                    document.body.classList.add('dark-mode');
                } else {
                    document.body.classList.remove('dark-mode');
                }
            });
        }
        
        // 添加切换按钮功能
        const darkModeToggle = document.querySelector('.dark-mode-toggle');
        
        if (darkModeToggle) {
            darkModeToggle.addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                
                // 保存用户偏好
                const isDarkMode = document.body.classList.contains('dark-mode');
                localStorage.setItem('darkMode', isDarkMode ? 'true' : 'false');
            });
            
            // 读取用户偏好
            const savedDarkMode = localStorage.getItem('darkMode');
            if (savedDarkMode === 'true') {
                document.body.classList.add('dark-mode');
            } else if (savedDarkMode === 'false') {
                document.body.classList.remove('dark-mode');
            }
        }
    }
})();


