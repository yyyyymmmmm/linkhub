<?php
/**
 * LinkHub API 入口文件
 * 
 * 提供RESTful API接口，支持分类、链接管理，搜索和统计功能
 */

// 设置错误报告
error_reporting(E_ALL);
ini_set('display_errors', 0);

// 设置时区
date_default_timezone_set('Asia/Shanghai');

// CORS 处理
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-API-Key');
header('Content-Type: application/json; charset=utf-8');

// 处理 OPTIONS 请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 引入自动加载
$basePath = dirname(__DIR__);
$autoloadPath = $basePath . '/vendor/autoload.php';

if (file_exists($autoloadPath)) {
    require $autoloadPath;
} else {
    // 简单的自动加载器
    spl_autoload_register(function ($class) {
        if (strpos($class, 'LinkHub\\') === 0) {
            $path = dirname(__DIR__) . '/src/' . str_replace('\\', '/', substr($class, 7)) . '.php';
            if (file_exists($path)) {
                require $path;
                return true;
            }
        }
        return false;
    });
}

// 检查是否已安装
$envFile = $basePath . '/.env';
$installFile = $basePath . '/storage/installed';

if (!file_exists($envFile) && !file_exists($installFile)) {
    http_response_code(503);
    echo json_encode([
        'success' => false,
        'code' => 503,
        'message' => '系统未安装，请先访问 /install.php 完成安装',
        'timestamp' => time()
    ]);
    exit;
}

try {
    // 创建请求对象
    $request = new LinkHub\Core\Http\Request(
        $_GET,
        $_POST,
        $_SERVER,
        $_FILES
    );
    
    // 解析 JSON 请求体
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (strpos($contentType, 'application/json') !== false) {
        $jsonInput = json_decode(file_get_contents('php://input'), true);
        if ($jsonInput !== null) {
            $_POST = array_merge($_POST, $jsonInput);
            $request = new LinkHub\Core\Http\Request(
                $_GET,
                $_POST,
                $_SERVER,
                $_FILES
            );
        }
    }
    
    // 解析路由
    $requestUri = $_SERVER['REQUEST_URI'] ?? '';
    $path = parse_url($requestUri, PHP_URL_PATH);
    
    // 移除 /api 前缀
    $path = preg_replace('#^/api#', '', $path);
    $path = trim($path, '/');
    
    // 解析路由段
    $segments = empty($path) ? [] : explode('/', $path);
    $method = strtoupper($_SERVER['REQUEST_METHOD']);
    
    // API版本控制（可选）
    $version = 'v1';
    if (!empty($segments) && preg_match('/^v\d+$/', $segments[0])) {
        $version = array_shift($segments);
    }
    
    // 路由调度
    $response = null;
    
    if (empty($segments)) {
        // API 根路径 - 返回API信息
        $response = new LinkHub\Core\Http\Response(json_encode([
            'success' => true,
            'message' => 'LinkHub API ' . $version,
            'version' => $version,
            'endpoints' => [
                'categories' => '/api/categories',
                'links' => '/api/links',
                'search' => '/api/search',
                'stats' => '/api/stats'
            ],
            'timestamp' => time()
        ]));
        
    } elseif ($segments[0] === 'categories') {
        // 分类API路由
        $controller = new LinkHub\Http\Controllers\Api\CategoryController();
        $id = $segments[1] ?? null;
        
        switch ($method) {
            case 'GET':
                if ($id) {
                    $response = $controller->show($request, $id);
                } else {
                    $response = $controller->index($request);
                }
                break;
            case 'POST':
                $response = $controller->store($request);
                break;
            case 'PUT':
            case 'PATCH':
                if ($id) {
                    $response = $controller->update($request, $id);
                } else {
                    $response = error_response('缺少分类ID', 422);
                }
                break;
            case 'DELETE':
                if ($id) {
                    $response = $controller->destroy($request, $id);
                } else {
                    $response = error_response('缺少分类ID', 422);
                }
                break;
            default:
                $response = error_response('不支持的请求方法', 405);
        }
        
    } elseif ($segments[0] === 'links') {
        // 链接API路由
        $controller = new LinkHub\Http\Controllers\Api\LinkController();
        $id = $segments[1] ?? null;
        $action = $segments[2] ?? null;
        
        switch ($method) {
            case 'GET':
                if ($id) {
                    $response = $controller->show($request, $id);
                } else {
                    $response = $controller->index($request);
                }
                break;
            case 'POST':
                if ($id && $action === 'click') {
                    $response = $controller->click($request, $id);
                } elseif ($segments[1] === 'batch') {
                    $response = $controller->batch($request);
                } else {
                    $response = $controller->store($request);
                }
                break;
            case 'PUT':
            case 'PATCH':
                if ($id) {
                    $response = $controller->update($request, $id);
                } else {
                    $response = error_response('缺少链接ID', 422);
                }
                break;
            case 'DELETE':
                if ($id) {
                    $response = $controller->destroy($request, $id);
                } else {
                    $response = error_response('缺少链接ID', 422);
                }
                break;
            default:
                $response = error_response('不支持的请求方法', 405);
        }
        
    } elseif ($segments[0] === 'search') {
        // 搜索API路由
        $controller = new LinkHub\Http\Controllers\Api\SearchController();
        $action = $segments[1] ?? null;
        
        switch ($method) {
            case 'GET':
                if ($action === 'suggestions') {
                    $response = $controller->suggestions($request);
                } elseif ($action === 'hot') {
                    $response = $controller->hot($request);
                } else {
                    $response = $controller->search($request);
                }
                break;
            default:
                $response = error_response('不支持的请求方法', 405);
        }
        
    } elseif ($segments[0] === 'stats') {
        // 统计API路由
        $controller = new LinkHub\Http\Controllers\Api\StatsController();
        $action = $segments[1] ?? null;
        
        switch ($method) {
            case 'GET':
                switch ($action) {
                    case 'clicks':
                        $response = $controller->clicks($request);
                        break;
                    case 'popular':
                        $response = $controller->popular($request);
                        break;
                    case 'categories':
                        $response = $controller->categories($request);
                        break;
                    default:
                        $response = $controller->overview($request);
                }
                break;
            default:
                $response = error_response('不支持的请求方法', 405);
        }
        
    } else {
        // 404 - 路由未找到
        $response = error_response('API路由不存在', 404);
    }
    
    // 发送响应
    if ($response) {
        $response->send();
    } else {
        error_response('内部服务器错误', 500)->send();
    }
    
} catch (Exception $e) {
    // 记录错误日志
    error_log("API Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    error_log("Request URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A'));
    error_log("Request method: " . ($_SERVER['REQUEST_METHOD'] ?? 'N/A'));
    
    // 返回错误响应
    error_response('API服务异常: ' . $e->getMessage(), 500)->send();
}

/**
 * 快速创建错误响应
 */
function error_response($message, $code = 400)
{
    $data = json_encode([
        'success' => false,
        'code' => $code,
        'message' => $message,
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE);
    
    $response = new LinkHub\Core\Http\Response($data, $code);
    $response->setHeader('Content-Type', 'application/json; charset=utf-8');
    return $response;
}
