<?php
require_once 'auth.php';
checkPermission('editor');

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'data' => null];

try {
    $url = trim($_POST['url'] ?? '');
    
    if (empty($url)) {
        throw new Exception('URL不能为空');
    }
    
    // 验证URL格式
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        throw new Exception('请输入有效的URL地址');
    }
    
    // 解析URL
    $parsedUrl = parse_url($url);
    $domain = $parsedUrl['host'] ?? '';
    
    // 设置用户代理
    $userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36';
    
    // 设置cURL选项
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_USERAGENT => $userAgent,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding: gzip, deflate',
            'Connection: keep-alive',
            'Upgrade-Insecure-Requests: 1'
        ]
    ]);
    
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($html === false || !empty($error)) {
        throw new Exception('无法访问该网站：' . $error);
    }
    
    if ($httpCode >= 400) {
        throw new Exception('网站返回错误状态码：' . $httpCode);
    }
    
    // 解析HTML获取标题
    $title = '';
    if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $matches)) {
        $title = html_entity_decode(trim($matches[1]), ENT_QUOTES, 'UTF-8');
        $title = preg_replace('/\s+/', ' ', $title); // 清理多余空格
    }
    
    // 针对百度等特殊网站的标题处理
    if (empty($title) || $title === $domain || strlen($title) < 3) {
        // 尝试从知名网站获取标准名称
        $knownTitles = getKnownWebsiteTitle($domain);
        if ($knownTitles) {
            $title = $knownTitles;
        } else {
            // 尝试从h1标签获取
            if (preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $html, $matches)) {
                $title = html_entity_decode(strip_tags(trim($matches[1])), ENT_QUOTES, 'UTF-8');
            }
            
            // 尝试从meta description获取
            if (empty($title) && preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)["\'][^>]*>/i', $html, $matches)) {
                $description = html_entity_decode(trim($matches[1]), ENT_QUOTES, 'UTF-8');
                if (strlen($description) > 10 && strlen($description) < 100) {
                    $title = $description;
                }
            }
            
            // 尝试从og:title获取
            if (empty($title) && preg_match('/<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)["\'][^>]*>/i', $html, $matches)) {
                $title = html_entity_decode(trim($matches[1]), ENT_QUOTES, 'UTF-8');
            }
            
            // 最后使用美化的域名
            if (empty($title)) {
                $title = beautifyDomain($domain);
            }
        }
    }
    
    // 查找网站图标
    $iconUrl = '';
    $iconUrls = [];
    
    // 1. 查找各种favicon链接
    $faviconPatterns = [
        '/<link[^>]+rel=["\'](?:icon|shortcut icon|apple-touch-icon)["\'][^>]+href=["\']([^"\']+)["\'][^>]*>/i',
        '/<link[^>]+href=["\']([^"\']+)["\'][^>]+rel=["\'](?:icon|shortcut icon|apple-touch-icon)["\'][^>]*>/i'
    ];
    
    foreach ($faviconPatterns as $pattern) {
        if (preg_match_all($pattern, $html, $matches)) {
            foreach ($matches[1] as $match) {
                $iconUrls[] = $match;
            }
        }
    }
    
    // 2. 尝试默认favicon路径
    if (empty($iconUrls)) {
        $iconUrls[] = $parsedUrl['scheme'] . '://' . $domain . '/favicon.ico';
    }
    
    // 3. 验证图标URL并选择最佳的
    foreach ($iconUrls as $potentialIcon) {
        // 处理相对URL
        if (strpos($potentialIcon, '//') === 0) {
            $potentialIcon = $parsedUrl['scheme'] . ':' . $potentialIcon;
        } elseif (strpos($potentialIcon, '/') === 0) {
            $potentialIcon = $parsedUrl['scheme'] . '://' . $domain . $potentialIcon;
        } elseif (!preg_match('/^https?:\/\//', $potentialIcon)) {
            $potentialIcon = $parsedUrl['scheme'] . '://' . $domain . '/' . ltrim($potentialIcon, '/');
        }
        
        // 检查图标是否可访问
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $potentialIcon,
            CURLOPT_NOBODY => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_USERAGENT => $userAgent,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        curl_exec($ch);
        $iconHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($iconHttpCode === 200) {
            $iconUrl = $potentialIcon;
            break;
        }
    }
    
    // 4. 根据域名智能推荐图标
    $smartIcon = getSmartIcon($domain);
    
    $response = [
        'success' => true,
        'message' => '网站信息识别成功',
        'data' => [
            'title' => $title,
            'url' => $url,
            'domain' => $domain,
            'favicon' => $iconUrl,
            'smart_icon' => $smartIcon['icon'],
            'smart_color' => $smartIcon['color'],
            'description' => generateDescription($domain, $title)
        ]
    ];
    
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);

/**
 * 获取知名网站的标准标题
 */
function getKnownWebsiteTitle($domain) {
    $domain = strtolower($domain);
    
    $knownTitles = [
        'baidu.com' => '百度',
        'www.baidu.com' => '百度',
        'google.com' => 'Google',
        'www.google.com' => 'Google',
        'github.com' => 'GitHub',
        'www.github.com' => 'GitHub',
        'stackoverflow.com' => 'Stack Overflow',
        'www.stackoverflow.com' => 'Stack Overflow',
        'facebook.com' => 'Facebook',
        'www.facebook.com' => 'Facebook',
        'twitter.com' => 'Twitter',
        'www.twitter.com' => 'Twitter',
        'instagram.com' => 'Instagram',
        'www.instagram.com' => 'Instagram',
        'linkedin.com' => 'LinkedIn',
        'www.linkedin.com' => 'LinkedIn',
        'youtube.com' => 'YouTube',
        'www.youtube.com' => 'YouTube',
        'weibo.com' => '微博',
        'www.weibo.com' => '微博',
        'zhihu.com' => '知乎',
        'www.zhihu.com' => '知乎',
        'taobao.com' => '淘宝',
        'www.taobao.com' => '淘宝',
        'tmall.com' => '天猫',
        'www.tmall.com' => '天猫',
        'jd.com' => '京东',
        'www.jd.com' => '京东',
        'bilibili.com' => '哔哩哔哩',
        'www.bilibili.com' => '哔哩哔哩',
        'qq.com' => '腾讯QQ',
        'www.qq.com' => '腾讯QQ',
        'wechat.com' => '微信',
        'www.wechat.com' => '微信',
        'douyin.com' => '抖音',
        'www.douyin.com' => '抖音',
        'tiktok.com' => 'TikTok',
        'www.tiktok.com' => 'TikTok',
        'amazon.com' => 'Amazon',
        'www.amazon.com' => 'Amazon',
        'netflix.com' => 'Netflix',
        'www.netflix.com' => 'Netflix',
        'spotify.com' => 'Spotify',
        'www.spotify.com' => 'Spotify'
    ];
    
    // 检查精确匹配
    if (isset($knownTitles[$domain])) {
        return $knownTitles[$domain];
    }
    
    // 检查子域名匹配
    foreach ($knownTitles as $key => $value) {
        if (strpos($domain, $key) !== false) {
            return $value;
        }
    }
    
    return null;
}

/**
 * 美化域名显示
 */
function beautifyDomain($domain) {
    // 移除www前缀
    $domain = preg_replace('/^www\./', '', $domain);
    
    // 首字母大写
    $parts = explode('.', $domain);
    if (!empty($parts[0])) {
        return ucfirst($parts[0]);
    }
    
    return $domain;
}

/**
 * 根据域名智能推荐图标
 */
function getSmartIcon($domain) {
    $domain = strtolower($domain);
    
    // 知名网站图标映射
    $iconMap = [
        // 搜索引擎
        'google.com' => ['icon' => 'fa-google', 'color' => '#4285f4'],
        'baidu.com' => ['icon' => 'fa-search', 'color' => '#2932e1'],
        'bing.com' => ['icon' => 'fa-microsoft', 'color' => '#00a1f1'],
        
        // 社交媒体
        'facebook.com' => ['icon' => 'fa-facebook', 'color' => '#1877f2'],
        'twitter.com' => ['icon' => 'fa-twitter', 'color' => '#1da1f2'],
        'instagram.com' => ['icon' => 'fa-instagram', 'color' => '#e4405f'],
        'linkedin.com' => ['icon' => 'fa-linkedin', 'color' => '#0a66c2'],
        'youtube.com' => ['icon' => 'fa-youtube', 'color' => '#ff0000'],
        'tiktok.com' => ['icon' => 'fa-tiktok', 'color' => '#000000'],
        'weibo.com' => ['icon' => 'fa-weibo', 'color' => '#e6162d'],
        'wechat.com' => ['icon' => 'fa-wechat', 'color' => '#07c160'],
        
        // 开发工具
        'github.com' => ['icon' => 'fa-github', 'color' => '#181717'],
        'gitlab.com' => ['icon' => 'fa-gitlab', 'color' => '#fc6d26'],
        'stackoverflow.com' => ['icon' => 'fa-stack-overflow', 'color' => '#f48024'],
        'codepen.io' => ['icon' => 'fa-codepen', 'color' => '#000000'],
        
        // 云服务
        'aws.amazon.com' => ['icon' => 'fa-aws', 'color' => '#ff9900'],
        'azure.microsoft.com' => ['icon' => 'fa-microsoft', 'color' => '#0078d4'],
        'cloud.google.com' => ['icon' => 'fa-google', 'color' => '#4285f4'],
        
        // 购物
        'amazon.com' => ['icon' => 'fa-amazon', 'color' => '#ff9900'],
        'taobao.com' => ['icon' => 'fa-shopping-cart', 'color' => '#ff6a00'],
        'tmall.com' => ['icon' => 'fa-store', 'color' => '#ff0036'],
        'jd.com' => ['icon' => 'fa-shopping-bag', 'color' => '#e3101e'],
        
        // 邮箱
        'gmail.com' => ['icon' => 'fa-envelope', 'color' => '#ea4335'],
        'outlook.com' => ['icon' => 'fa-microsoft', 'color' => '#0078d4'],
        'qq.com' => ['icon' => 'fa-qq', 'color' => '#12b7f5'],
        
        // 音乐
        'spotify.com' => ['icon' => 'fa-spotify', 'color' => '#1db954'],
        'music.apple.com' => ['icon' => 'fa-apple', 'color' => '#000000'],
        'music.163.com' => ['icon' => 'fa-music', 'color' => '#c20c0c'],
        
        // 视频
        'netflix.com' => ['icon' => 'fa-film', 'color' => '#e50914'],
        'bilibili.com' => ['icon' => 'fa-video', 'color' => '#fb7299'],
        'youku.com' => ['icon' => 'fa-play-circle', 'color' => '#06a7e1']
    ];
    
    // 检查精确匹配
    if (isset($iconMap[$domain])) {
        return $iconMap[$domain];
    }
    
    // 检查子域名匹配
    foreach ($iconMap as $key => $value) {
        if (strpos($domain, $key) !== false) {
            return $value;
        }
    }
    
    // 根据域名关键词推荐
    $keywords = [
        'blog' => ['icon' => 'fa-blog', 'color' => '#2d3748'],
        'news' => ['icon' => 'fa-newspaper', 'color' => '#1a202c'],
        'shop' => ['icon' => 'fa-shopping-cart', 'color' => '#38a169'],
        'mail' => ['icon' => 'fa-envelope', 'color' => '#3182ce'],
        'music' => ['icon' => 'fa-music', 'color' => '#805ad5'],
        'video' => ['icon' => 'fa-video', 'color' => '#e53e3e'],
        'photo' => ['icon' => 'fa-camera', 'color' => '#d69e2e'],
        'game' => ['icon' => 'fa-gamepad', 'color' => '#38b2ac'],
        'edu' => ['icon' => 'fa-graduation-cap', 'color' => '#3182ce'],
        'tech' => ['icon' => 'fa-laptop-code', 'color' => '#4a5568'],
        'api' => ['icon' => 'fa-code', 'color' => '#2d3748']
    ];
    
    foreach ($keywords as $keyword => $iconData) {
        if (strpos($domain, $keyword) !== false) {
            return $iconData;
        }
    }
    
    // 默认图标（返回空，让前端显示首字母）
    return ['icon' => '', 'color' => '#6366f1'];
}

/**
 * 生成描述
 */
function generateDescription($domain, $title) {
    if ($title && $title !== $domain) {
        return "来自 {$domain} 的优质内容";
    }
    return "访问 {$domain} 获取更多信息";
}
?>
