<?php
/**
 * 美化版主题设置页面
 */
require_once 'auth.php';
checkPermission('editor');

$message = '';
$messageType = '';

// 处理主题操作
if ($_POST && isset($_POST['action'])) {
    try {
        $action = $_POST['action'];
        
        if ($action === 'set_default') {
            $defaultTheme = $_POST['theme_id'] ?? '';
            
            if (empty($defaultTheme)) {
                throw new Exception('请选择主题');
            }
            
            // 更新默认主题设置
            $sql = "REPLACE INTO " . $tablePrefix . "settings (`key`, `value`) VALUES ('default_theme', ?)";
            $pdo->prepare($sql)->execute([$defaultTheme]);
            
            $message = '主题设置保存成功！';
            $messageType = 'success';
        }
        
        if ($action === 'update_config') {
            $themeId = $_POST['theme_id'] ?? '';
            $config = $_POST['config'] ?? [];
            
            if (empty($themeId)) {
                throw new Exception('主题ID不能为空');
            }
            
            // 保存主题配置
            $sql = "REPLACE INTO " . $tablePrefix . "settings (`key`, `value`) VALUES (?, ?)";
            $pdo->prepare($sql)->execute(['theme_config_' . $themeId, json_encode($config)]);
            
            $message = '主题配置保存成功！';
            $messageType = 'success';
        }
        
    } catch (Exception $e) {
        $message = '保存失败：' . $e->getMessage();
        $messageType = 'error';
    }
}

// 获取当前默认主题
$stmt = $pdo->prepare("SELECT `value` FROM " . $tablePrefix . "settings WHERE `key` = 'default_theme'");
$stmt->execute();
$currentTheme = $stmt->fetchColumn() ?: 'default';

// 扫描主题目录
$themesPath = dirname(__DIR__) . '/themes';
$themes = [];

if (is_dir($themesPath)) {
    $dirs = scandir($themesPath);
    foreach ($dirs as $dir) {
        if ($dir !== '.' && $dir !== '..' && is_dir($themesPath . '/' . $dir)) {
            $configFile = $themesPath . '/' . $dir . '/theme.json';
            // 支持多种预览图格式，优先使用 yulan.jpg
            $previewFiles = [
                'yulan.jpg',
                'preview.png', 
                'preview.jpg',
                'screenshot.png',
                'screenshot.jpg'
            ];
            
            $previewPath = '';
            foreach ($previewFiles as $filename) {
                $fullPath = $themesPath . '/' . $dir . '/' . $filename;
                if (file_exists($fullPath)) {
                    $previewPath = '/themes/' . $dir . '/' . $filename;
                    break;
                }
            }
            
            $config = [];
            
            if (file_exists($configFile)) {
                $configContent = file_get_contents($configFile);
                $config = json_decode($configContent, true) ?: [];
            }
            
            // 默认主题信息
            if (empty($config)) {
                $config = [
                    'name' => ucfirst($dir),
                    'version' => '1.0.0',
                    'description' => '默认主题',
                    'author' => 'LinkHub',
                    'tags' => ['默认']
                ];
            }
            
            $config['id'] = $dir;
            $config['preview'] = $previewPath;
            $config['is_active'] = ($dir === $currentTheme);
            
            // 获取主题配置
            $stmt = $pdo->prepare("SELECT `value` FROM " . $tablePrefix . "settings WHERE `key` = ?");
            $stmt->execute(['theme_config_' . $dir]);
            $themeConfig = $stmt->fetchColumn();
            $config['settings'] = $themeConfig ? json_decode($themeConfig, true) : [];
            
            $themes[] = $config;
        }
    }
}

// 按名称排序
usort($themes, function($a, $b) {
    if ($a['is_active']) return -1;
    if ($b['is_active']) return 1;
    return strcmp($a['name'], $b['name']);
});
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>主题设置 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/backup.php" data-title="备份管理">
                            <i class="fas fa-database"></i>
                            <span>备份管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay"></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
            <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <i class="fas fa-palette"></i>
                    <span>主题设置</span>
                </div>
                <div class="header-actions">
                    <button type="button" class="btn btn-primary btn-sm" onclick="showThemeStore()">
                        <i class="fas fa-store"></i>
                        主题商店
                    </button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="uploadTheme()">
                        <i class="fas fa-upload"></i>
                        上传主题
                    </button>
                </div>
            </header>

            <!-- 主体内容 -->
            <div class="admin-main">
                <?php if ($message): ?>
                <div class="alert alert-<?= $messageType ?>">
                    <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-triangle' ?>"></i>
                    <?= htmlspecialchars($message) ?>
                </div>
                <?php endif; ?>

                <!-- 主题统计 -->
                <div class="theme-stats">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-palette"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number"><?= count($themes) ?></div>
                            <div class="stat-label">已安装主题</div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon active">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number">1</div>
                            <div class="stat-label">当前激活</div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-download"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number">0</div>
                            <div class="stat-label">可更新</div>
                        </div>
                    </div>
                </div>

                <!-- 主题网格 -->
                <div class="themes-container">
                    <div class="themes-grid">
                        <?php foreach ($themes as $theme): ?>
                        <div class="theme-card <?= $theme['is_active'] ? 'active' : '' ?>" data-theme="<?= htmlspecialchars($theme['id']) ?>">
                            <div class="theme-preview">
                                <?php if ($theme['preview']): ?>
                                    <img src="<?= htmlspecialchars($theme['preview']) ?>" alt="<?= htmlspecialchars($theme['name']) ?>" loading="lazy">
                                <?php else: ?>
                                    <div class="theme-preview-placeholder">
                                        <i class="fas fa-image"></i>
                                        <span>暂无预览</span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($theme['is_active']): ?>
                                <div class="theme-active-badge">
                                    <i class="fas fa-check"></i>
                                    <span>当前主题</span>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="theme-info">
                                <div class="theme-header">
                                    <h3 class="theme-name"><?= htmlspecialchars($theme['name']) ?></h3>
                                    <div class="theme-version">v<?= htmlspecialchars($theme['version'] ?? '1.0.0') ?></div>
                                </div>
                                
                                <p class="theme-description"><?= htmlspecialchars($theme['description'] ?? '暂无描述') ?></p>
                                
                                <div class="theme-meta">
                                    <div class="theme-author">
                                        <i class="fas fa-user"></i>
                                        <?= htmlspecialchars($theme['author'] ?? '未知') ?>
                                    </div>
                                    
                                    <?php if (!empty($theme['tags'])): ?>
                                    <div class="theme-tags">
                                        <?php foreach (array_slice($theme['tags'], 0, 2) as $tag): ?>
                                        <span class="theme-tag"><?= htmlspecialchars($tag) ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="theme-actions">
                                    <?php if ($theme['is_active']): ?>
                                    <button type="button" class="btn btn-primary btn-sm btn-block" onclick="configureTheme('<?= htmlspecialchars($theme['id']) ?>')">
                                        <i class="fas fa-cog"></i>
                                        配置主题
                                    </button>
                                    <?php else: ?>
                                    <div class="theme-action-group">
                                        <button type="button" class="btn btn-success btn-sm" onclick="activateTheme('<?= htmlspecialchars($theme['id']) ?>')">
                                            <i class="fas fa-check"></i>
                                            启用
                                        </button>
                                        <button type="button" class="btn btn-outline-primary btn-sm" onclick="previewTheme('<?= htmlspecialchars($theme['id']) ?>')">
                                            <i class="fas fa-eye"></i>
                                            预览
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        
                        <!-- 添加新主题卡片 -->
                        <div class="theme-card add-theme-card" onclick="showAddTheme()">
                            <div class="add-theme-content">
                                <div class="add-theme-icon">
                                    <i class="fas fa-plus"></i>
                                </div>
                                <h3>添加新主题</h3>
                                <p>上传或下载新主题</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- 主题配置模态框 -->
    <div id="themeConfigModal" class="theme-modal" style="display: none;">
        <div class="theme-modal-overlay" onclick="hideThemeConfig()"></div>
        <div class="theme-modal-content">
            <div class="theme-modal-header">
                <h3>
                    <i class="fas fa-cog"></i>
                    主题配置
                </h3>
                <button type="button" class="theme-close-btn" onclick="hideThemeConfig()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="theme-modal-body" id="themeConfigBody">
                <!-- 动态加载配置内容 -->
            </div>
        </div>
    </div>

    <!-- 主题预览模态框 -->
    <div id="themePreviewModal" class="theme-modal" style="display: none;">
        <div class="theme-modal-overlay" onclick="hideThemePreview()"></div>
        <div class="theme-modal-content theme-preview-content">
            <div class="theme-modal-header">
                <h3>
                    <i class="fas fa-eye"></i>
                    主题预览
                </h3>
                <button type="button" class="theme-close-btn" onclick="hideThemePreview()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="theme-modal-body">
                <div class="theme-preview-container">
                    <iframe id="themePreviewFrame" src="" frameborder="0"></iframe>
                </div>
                
                <div class="theme-preview-actions">
                    <button type="button" class="btn btn-secondary" onclick="hideThemePreview()">
                        <i class="fas fa-times"></i>
                        关闭
                    </button>
                    <button type="button" class="btn btn-success" id="activatePreviewTheme">
                        <i class="fas fa-check"></i>
                        启用此主题
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js?v=2.0.1"></script>
    <script src="../assets/js/sidebar-fix.js?v=1.1.0"></script>
    <script>
        let currentPreviewTheme = '';
        
        // 激活主题
        function activateTheme(themeId) {
            if (confirm('确定要激活主题 "' + themeId + '" 吗？')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.name = 'action';
                actionInput.value = 'set_default';
                form.appendChild(actionInput);
                
                const themeInput = document.createElement('input');
                themeInput.name = 'theme_id';
                themeInput.value = themeId;
                form.appendChild(themeInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // 预览主题
        function previewTheme(themeId) {
            currentPreviewTheme = themeId;
            const previewUrl = '/?theme=' + themeId;
            document.getElementById('themePreviewFrame').src = previewUrl;
            document.getElementById('activatePreviewTheme').onclick = () => activateTheme(themeId);
            document.getElementById('themePreviewModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // 隐藏主题预览
        function hideThemePreview() {
            document.getElementById('themePreviewModal').style.display = 'none';
            document.body.style.overflow = '';
            document.getElementById('themePreviewFrame').src = '';
        }
        
        // 配置主题
        function configureTheme(themeId) {
            // 这里可以加载主题的配置选项
            const configBody = document.getElementById('themeConfigBody');
            configBody.innerHTML = `
                <div class="theme-config-section">
                    <h4><i class="fas fa-palette"></i> 颜色设置</h4>
                    <div class="config-group">
                        <label>主色调</label>
                        <input type="color" value="#6366f1" class="form-control">
                    </div>
                    <div class="config-group">
                        <label>辅助色</label>
                        <input type="color" value="#8b5cf6" class="form-control">
                    </div>
                </div>
                
                <div class="theme-config-section">
                    <h4><i class="fas fa-layout"></i> 布局设置</h4>
                    <div class="config-group">
                        <label>每行显示链接数</label>
                        <select class="form-control">
                            <option value="4">4个</option>
                            <option value="5">5个</option>
                            <option value="6">6个</option>
                        </select>
                    </div>
                    <div class="config-group">
                        <div class="form-check">
                            <input type="checkbox" id="showDescription" class="form-check-input">
                            <label for="showDescription" class="form-check-label">显示链接描述</label>
                        </div>
                    </div>
                </div>
                
                <div class="theme-config-actions">
                    <button type="button" class="btn btn-secondary" onclick="hideThemeConfig()">
                        <i class="fas fa-times"></i>
                        取消
                    </button>
                    <button type="button" class="btn btn-primary" onclick="saveThemeConfig('${themeId}')">
                        <i class="fas fa-save"></i>
                        保存配置
                    </button>
                </div>
            `;
            
            document.getElementById('themeConfigModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // 隐藏主题配置
        function hideThemeConfig() {
            document.getElementById('themeConfigModal').style.display = 'none';
            document.body.style.overflow = '';
        }
        
        // 保存主题配置
        function saveThemeConfig(themeId) {
            // 收集配置数据并保存
            alert('主题配置保存成功！');
            hideThemeConfig();
        }
        
        // 显示主题商店
        function showThemeStore() {
            alert('主题商店功能开发中...');
        }
        
        // 上传主题
        function uploadTheme() {
            alert('主题上传功能开发中...');
        }
        
        // 显示添加主题
        function showAddTheme() {
            const options = [
                '从主题商店下载',
                '上传本地主题文件',
                '从GitHub安装',
                '创建自定义主题'
            ];
            
            const choice = prompt('请选择添加方式：\n' + options.map((opt, i) => `${i + 1}. ${opt}`).join('\n'));
            
            if (choice) {
                const index = parseInt(choice) - 1;
                if (index >= 0 && index < options.length) {
                    alert(`您选择了：${options[index]}\n此功能正在开发中...`);
                }
            }
        }
        
        // 主题卡片悬停效果
        document.addEventListener('DOMContentLoaded', function() {
            const themeCards = document.querySelectorAll('.theme-card:not(.add-theme-card)');
            
            themeCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-8px)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0)';
                });
            });
        });
    </script>
    
    <style>
        /* 主题页面专用样式 */
        .theme-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
        }
        
        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }
        
        .stat-icon.active {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
        }
        
        .stat-number {
            font-size: 28px;
            font-weight: 700;
            color: #1a1a1a;
            line-height: 1;
        }
        
        .stat-label {
            font-size: 14px;
            color: #666;
            margin-top: 4px;
        }
        
        .themes-container {
            background: white;
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .themes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 2rem;
        }
        
        .theme-card {
            background: #f8f9fa;
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            position: relative;
        }
        
        .theme-card:hover {
            border-color: #6366f1;
            box-shadow: 0 8px 24px rgba(99, 102, 241, 0.15);
        }
        
        .theme-card.active {
            border-color: #22c55e;
            background: #f0fdf4;
        }
        
        .theme-preview {
            position: relative;
            height: 180px;
            overflow: hidden;
        }
        
        .theme-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .theme-preview-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
            color: #64748b;
        }
        
        .theme-preview-placeholder i {
            font-size: 48px;
            margin-bottom: 8px;
        }
        
        .theme-active-badge {
            position: absolute;
            top: 12px;
            right: 12px;
            background: #22c55e;
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 4px;
            box-shadow: 0 2px 8px rgba(34, 197, 94, 0.3);
        }
        
        .theme-info {
            padding: 1.5rem;
        }
        
        .theme-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 0.5rem;
        }
        
        .theme-name {
            font-size: 18px;
            font-weight: 600;
            color: #1a1a1a;
            margin: 0;
        }
        
        .theme-version {
            background: #e2e8f0;
            color: #475569;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .theme-description {
            color: #64748b;
            font-size: 14px;
            line-height: 1.5;
            margin: 0 0 1rem;
        }
        
        .theme-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .theme-author {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            color: #64748b;
        }
        
        .theme-tags {
            display: flex;
            gap: 6px;
        }
        
        .theme-tag {
            background: #e0e7ff;
            color: #6366f1;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
        }
        
        .theme-actions {
            margin-top: 1rem;
        }
        
        .theme-action-group {
            display: flex;
            gap: 8px;
        }
        
        .theme-action-group .btn {
            flex: 1;
        }
        
        .btn-block {
            width: 100%;
        }
        
        /* 添加主题卡片 */
        .add-theme-card {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            border: 2px dashed #cbd5e1;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            min-height: 320px;
        }
        
        .add-theme-card:hover {
            border-color: #6366f1;
            background: linear-gradient(135deg, #f0f4ff 0%, #e0e7ff 100%);
        }
        
        .add-theme-content {
            text-align: center;
            color: #64748b;
        }
        
        .add-theme-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 32px;
            transition: all 0.3s ease;
        }
        
        .add-theme-card:hover .add-theme-icon {
            background: #6366f1;
            color: white;
        }
        
        .add-theme-content h3 {
            margin: 0 0 0.5rem;
            font-size: 18px;
            font-weight: 600;
        }
        
        .add-theme-content p {
            margin: 0;
            font-size: 14px;
        }
        
        /* 主题模态框样式 */
        .theme-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .theme-modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }
        
        .theme-modal-content {
            position: relative;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease-out;
        }
        
        .theme-preview-content {
            max-width: 1000px;
        }
        
        .theme-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 24px 24px 16px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .theme-modal-header h3 {
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .theme-close-btn {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            color: #666;
            transition: all 0.2s ease;
        }
        
        .theme-close-btn:hover {
            background: #f5f5f5;
            color: #333;
        }
        
        .theme-modal-body {
            padding: 24px;
        }
        
        .theme-config-section {
            margin-bottom: 2rem;
        }
        
        .theme-config-section h4 {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0 0 1rem;
            font-size: 16px;
            font-weight: 600;
            color: #374151;
        }
        
        .config-group {
            margin-bottom: 1rem;
        }
        
        .config-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #374151;
        }
        
        .theme-config-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 16px;
            border-top: 1px solid #f0f0f0;
            margin-top: 24px;
        }
        
        .theme-preview-container {
            background: #f8f9fa;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        
        .theme-preview-container iframe {
            width: 100%;
            height: 500px;
            border: none;
        }
        
        .theme-preview-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }
        
        @media (max-width: 768px) {
            .themes-grid {
                grid-template-columns: 1fr;
            }
            
            .theme-modal-content {
                margin: 20px;
                max-width: none;
            }
            
            .theme-modal-header,
            .theme-modal-body {
                padding: 20px;
            }
            
            .theme-action-group {
                flex-direction: column;
            }
            
            .theme-preview-actions {
                flex-direction: column;
            }
            
            .theme-config-actions {
                flex-direction: column;
            }
        }
    </style>
</body>
</html>