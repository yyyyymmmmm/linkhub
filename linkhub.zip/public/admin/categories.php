<?php
require_once 'auth.php';

// 检查权限（编辑权限以上才能管理分类）
checkPermission('editor');

// 处理操作
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$message = '';
$messageType = '';

try {
    switch ($action) {
        case 'add':
            if ($_POST) {
                $name = trim($_POST['name']);
                $fid = intval($_POST['fid']);
                $property = intval($_POST['property']);
                $weight = intval($_POST['weight']);
                $description = trim($_POST['description']);
                $font_icon = trim($_POST['font_icon']);
                $icon_color = trim($_POST['icon_color'] ?? '#6366f1');
                
                if (empty($name)) {
                    throw new Exception('分类名称不能为空');
                }
                
                // 插入分类数据 - 包含颜色字段
                $sql = "INSERT INTO " . $tablePrefix . "categorys (name, fid, property, weight, description, font_icon, icon_color, add_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $pdo->prepare($sql)->execute([$name, $fid, $property, $weight, $description, $font_icon, $icon_color, time()]);
                
                $message = '分类添加成功';
                $messageType = 'success';
                
                // 重定向到列表页面
                header('Location: /admin/categories.php');
                exit;
            }
            break;
            
        case 'edit':
            if ($_POST) {
                $id = intval($_POST['id']);
                
                // 检查是否只保存图标
                if (isset($_POST['save_icon']) && $_POST['save_icon'] == 1) {
                    $font_icon = trim($_POST['font_icon']);
                    $icon_color = trim($_POST['icon_color'] ?? '#6366f1');
                    
                    // 只更新图标 - 包含颜色
                    $sql = "UPDATE " . $tablePrefix . "categorys SET font_icon=?, icon_color=?, up_time=? WHERE id=?";
                    $pdo->prepare($sql)->execute([$font_icon, $icon_color, time(), $id]);
                    
                    $message = '图标更新成功';
                    $messageType = 'success';
                    
                    // 重定向到编辑页面
                    header('Location: /admin/categories.php?action=edit&id=' . $id);
                    exit;
                }
                
                // 常规编辑处理
                $name = trim($_POST['name']);
                $fid = intval($_POST['fid']);
                $property = intval($_POST['property']);
                $weight = intval($_POST['weight']);
                $description = trim($_POST['description']);
                $font_icon = trim($_POST['font_icon']);
                $icon_color = trim($_POST['icon_color'] ?? '#6366f1');
                
                if (empty($name)) {
                    throw new Exception('分类名称不能为空');
                }
                
                // 更新分类信息 - 包含颜色字段
                $sql = "UPDATE " . $tablePrefix . "categorys SET name=?, fid=?, property=?, weight=?, description=?, font_icon=?, icon_color=?, up_time=? WHERE id=?";
                $pdo->prepare($sql)->execute([$name, $fid, $property, $weight, $description, $font_icon, $icon_color, time(), $id]);
                
                $message = '分类更新成功';
                $messageType = 'success';
                
                // 重定向到列表页面
                header('Location: /admin/categories.php');
                exit;
            }
            break;
            
        case 'delete':
            $id = intval($_GET['id']);
            if ($id > 0) {
                // 检查是否有子分类
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "categorys WHERE fid = ?");
                $stmt->execute([$id]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('该分类下还有子分类，请先删除子分类');
                }
                
                // 检查是否有链接
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "links WHERE fid = ?");
                $stmt->execute([$id]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('该分类下还有链接，请先删除或移动链接');
                }
                
                $pdo->prepare("DELETE FROM " . $tablePrefix . "categorys WHERE id = ?")->execute([$id]);
                $message = '分类删除成功';
                $messageType = 'success';
            }
            break;
            
        case 'batch_delete':
            if (!empty($_POST['ids'])) {
                $ids = array_map('intval', $_POST['ids']);
                foreach ($ids as $id) {
                    // 检查子分类和链接
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "categorys WHERE fid = ?");
                    $stmt->execute([$id]);
                    if ($stmt->fetchColumn() > 0) continue;
                    
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "links WHERE fid = ?");
                    $stmt->execute([$id]);
                    if ($stmt->fetchColumn() > 0) continue;
                    
                    $pdo->prepare("DELETE FROM " . $tablePrefix . "categorys WHERE id = ?")->execute([$id]);
                }
                $message = '批量删除成功';
                $messageType = 'success';
            }
            break;
    }
} catch (Exception $e) {
    $message = $e->getMessage();
    $messageType = 'error';
}

// 获取分类列表（树形结构）
function getCategoryTree($pdo, $fid = 0, $level = 0) {
    global $tablePrefix;
    $sql = "SELECT * FROM " . $tablePrefix . "categorys WHERE fid = ? ORDER BY weight DESC, id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$fid]);
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $result = [];
    foreach ($categories as $category) {
        $category['level'] = $level;
        $result[] = $category;
        
        // 递归获取子分类
        $children = getCategoryTree($pdo, $category['id'], $level + 1);
        $result = array_merge($result, $children);
    }
    
    return $result;
}

$categories = getCategoryTree($pdo);

// 获取父分类列表（用于下拉选择）
$parentCategories = $pdo->query("SELECT * FROM " . $tablePrefix . "categorys ORDER BY weight DESC, name ASC")->fetchAll(PDO::FETCH_ASSOC);

// 如果是编辑模式，获取要编辑的分类数据
$editCategory = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $editId = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "categorys WHERE id = ?");
    $stmt->execute([$editId]);
    $editCategory = $stmt->fetch(PDO::FETCH_ASSOC);
}

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分类管理 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.0">
    <link rel="stylesheet" href="../assets/css/icon-picker.css?v=1.0.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* 图标选择器样式 */
        .icon-selector-wrapper {
            display: flex;
            align-items: center;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 8px;
        }
        
        .icon-preview {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 42px;
            background-color: #f3f4f6;
            border-right: 1px solid #d1d5db;
            cursor: pointer;
        }
        
        .icon-preview i {
            font-size: 20px;
        }
        
        .icon-input-container {
            flex: 1;
        }
        
        .icon-input-container input {
            border: none;
            border-radius: 0;
        }
        
        .icon-input-container input:focus {
            box-shadow: none;
        }
        
        .icon-actions {
            display: flex;
            gap: 8px;
            margin-bottom: 8px;
        }
        
        .icon-actions .btn {
            padding: 4px 8px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle"id="sidebarToggle"  id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/backup.php" data-title="备份恢复">
                            <i class="fas fa-database"></i>
                            <span>备份恢复</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay" ></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
            <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <i class="fas fa-folder"></i>
                    <span>分类管理</span>
                </div>
                <div class="header-actions">
                    <a href="/admin/categories.php?action=add" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i>
                        添加分类
                    </a>
                </div>
            </header>

            <!-- 主体内容 -->
            <div class="admin-main">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType ?>">
                        <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <!-- 添加/编辑分类表单 -->
                <?php if ($action === 'add' || ($action === 'edit' && $editCategory)): ?>
                <div class="card">
                    <div class="card-header">
                        <h3>
                            <i class="fas fa-<?= $action === 'add' ? 'plus' : 'edit' ?>"></i>
                            <?= $action === 'add' ? '添加分类' : '编辑分类' ?>
                        </h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="/admin/categories.php?action=<?= $action ?><?= $editCategory ? '&id=' . $editCategory['id'] : '' ?>">
                            <?php if ($editCategory): ?>
                                <input type="hidden" name="id" value="<?= $editCategory['id'] ?>">
                            <?php endif; ?>
                            
                            <div class="grid grid-cols-2">
                                <div class="form-group">
                                    <label class="form-label">分类名称 *</label>
                                    <input type="text" name="name" class="form-control" 
                                           value="<?= htmlspecialchars($editCategory['name'] ?? '') ?>" 
                                           placeholder="输入分类名称" required>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">父分类</label>
                                    <select name="fid" class="form-control form-select">
                                        <option value="0">根分类</option>
                                        <?php foreach ($parentCategories as $cat): ?>
                                            <?php if (!$editCategory || $cat['id'] != $editCategory['id']): ?>
                                                <option value="<?= $cat['id'] ?>" 
                                                        <?= ($editCategory['fid'] ?? 0) == $cat['id'] ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($cat['name']) ?>
                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                </div>
                                
                            <div class="grid grid-cols-3">
                                <div class="form-group">
                                    <label class="form-label">分类图标</label>
                                    <div class="icon-selector-wrapper">
                                        <div class="icon-preview">
                                            <i class="fas <?= htmlspecialchars($editCategory['font_icon'] ?? 'fa-folder') ?>" 
                                               style="color: <?= htmlspecialchars($editCategory['icon_color'] ?? '#6366f1') ?>;" 
                                               id="categoryIconPreview"></i>
                                        </div>
                                        <div class="icon-input-container">
                                            <input type="text" name="font_icon" id="categoryIcon" class="form-control" 
                                                   value="<?= htmlspecialchars($editCategory['font_icon'] ?? '') ?>" 
                                                   placeholder="点击选择图标" 
                                                   readonly>
                                            <input type="hidden" name="icon_color" id="categoryIconColor" 
                                                   value="<?= htmlspecialchars($editCategory['icon_color'] ?? '#6366f1') ?>">
                                        </div>
                                    </div>
                                    <div class="icon-actions">
                                        <button type="button" class="btn btn-sm btn-secondary" id="resetIconBtn">
                                            <i class="fas fa-undo"></i> 重置
                                        </button>
                                    </div>
                                    <small class="text-muted">点击选择分类图标和颜色，在选择器中点击"保存图标"按钮保存图标设置（不会保存整个分类）</small>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">权重</label>
                                    <input type="number" name="weight" class="form-control" 
                                           value="<?= $editCategory['weight'] ?? 0 ?>" 
                                           placeholder="0">
                                    <small class="text-muted">数值越大排序越靠前</small>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">属性</label>
                                    <select name="property" class="form-control form-select">
                                        <option value="0" <?= ($editCategory['property'] ?? 0) == 0 ? 'selected' : '' ?>>公开</option>
                                        <option value="1" <?= ($editCategory['property'] ?? 0) == 1 ? 'selected' : '' ?>>私有</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">分类描述</label>
                                <textarea name="description" class="form-control" rows="3" 
                                          placeholder="分类的详细描述（可选）"><?= htmlspecialchars($editCategory['description'] ?? '') ?></textarea>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i>
                                    <?= $action === 'add' ? '添加分类' : '更新分类' ?>
                                </button>
                                <a href="/admin/categories.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> 取消
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <!-- 分类列表 -->
                <?php if ($action !== 'add' && $action !== 'edit'): ?>
                <!-- 批量操作栏 -->
                <div class="batch-actions" id="batchActions" style="display: none;">
                    <div class="selected-info">
                        <span>已选择 <strong class="selected-count">0</strong> 个分类</span>
                        <div class="action-buttons">
                            <button type="button" class="btn btn-danger btn-sm" onclick="batchDelete()">
                                <i class="fas fa-trash"></i>
                                批量删除
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-list"></i>
                            分类列表
                            <small class="text-muted">(共 <?= count($categories) ?> 个分类)</small>
                        </h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($categories)): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th width="50">
                                                <input type="checkbox" class="select-all" onchange="toggleSelectAll()">
                                            </th>
                                            <th>分类信息</th>
                                            <th width="100">权重</th>
                                            <th width="80">属性</th>
                                            <th width="120">创建时间</th>
                                            <th width="120">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($categories as $category): ?>
                                        <tr class="search-item">
                                            <td>
                                                <input type="checkbox" class="select-item" value="<?= $category['id'] ?>" onchange="updateBatchActions()">
                                            </td>
                                            <td>
                                                <div class="category-info">
                                                    <div class="category-title">
                                                        <?php for ($i = 0; $i < $category['level']; $i++): ?>
                                                            <span style="margin-right: 1rem; color: var(--gray-400);">└─</span>
                                                        <?php endfor; ?>
                                                        
                                                        <?php if ($category['font_icon']): ?>
                                                            <i class="fas <?= htmlspecialchars($category['font_icon']) ?>" 
                                                               style="color: <?= htmlspecialchars($category['icon_color'] ?? '#6366f1') ?>;"></i>
                                                        <?php else: ?>
                                                            <i class="fas fa-folder" style="color: #6366f1;"></i>
                                                        <?php endif; ?>
                                                        <strong><?= htmlspecialchars($category['name']) ?></strong>
                                                    </div>
                                                    <?php if ($category['description']): ?>
                                                        <div class="category-desc">
                                                            <small class="text-muted"><?= htmlspecialchars($category['description']) ?></small>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td><span class="badge badge-primary"><?= $category['weight'] ?></span></td>
                                            <td>
                                                <span class="badge <?= $category['property'] == 0 ? 'badge-success' : 'badge-warning' ?>">
                                                    <?= $category['property'] == 0 ? '公开' : '私有' ?>
                                                </span>
                                            </td>
                                            <td><?= date('Y-m-d H:i', $category['add_time']) ?></td>
                                            <td>
                                                <div style="display: flex; gap: 0.25rem;">
                                                    <a href="/admin/categories.php?action=edit&id=<?= $category['id'] ?>" 
                                                       class="btn btn-secondary btn-sm" title="编辑">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="?action=delete&id=<?= $category['id'] ?>" 
                                                       class="btn btn-danger btn-sm delete-btn" title="删除" 
                                                       data-message="确定要删除分类「<?= htmlspecialchars($category['name']) ?>」吗？">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-folder"></i>
                                <p>暂无分类数据</p>
                                <a href="/admin/categories.php?action=add" class="btn btn-primary">添加第一个分类</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js?v=2.0.1"></script>
    <script src="../assets/js/icon-picker.js?v=1.0.0"></script>
    <script src="../assets/js/sidebar-fix.js?v=1.1.0"></script>
    <script src="../assets/js/icon-selector.js?v=1.0.0"></script>
    <script>
        // 图标选择器初始化
        let iconSelector = null;
        
        document.addEventListener('DOMContentLoaded', function() {
            // 确保现有图标格式正确
            const iconInput = document.getElementById('categoryIcon');
            let iconValue = iconInput.value || 'fa-folder';
            
            // 如果图标值不包含空格（没有前缀），添加"fas"前缀
            if (iconValue && !iconValue.includes(' ') && iconValue.startsWith('fa-')) {
                iconValue = 'fas ' + iconValue;
                iconInput.value = iconValue;
                
                // 更新预览
                const iconPreview = document.getElementById('categoryIconPreview');
                if (iconPreview) {
                    iconPreview.className = '';
                    iconValue.split(' ').forEach(cls => {
                        if (cls) iconPreview.classList.add(cls);
                    });
                }
            }
            
            // 初始化图标选择器
            iconSelector = new IconSelector({
                inputSelector: '#categoryIcon',
                previewSelector: '#categoryIconPreview',
                colorInputSelector: '#categoryIconColor'
            });
            
            // 保存初始图标和颜色值（用于重置）
            const initialIcon = iconInput.value || 'fas fa-folder';
            const initialColor = document.getElementById('categoryIconColor').value || '#6366f1';
            
            // 重置图标按钮点击事件
            document.getElementById('resetIconBtn').addEventListener('click', function() {
                const iconInput = document.getElementById('categoryIcon');
                const colorInput = document.getElementById('categoryIconColor');
                const iconPreview = document.getElementById('categoryIconPreview');
                
                // 恢复初始值
                iconInput.value = initialIcon;
                colorInput.value = initialColor;
                
                // 更新预览
                iconPreview.className = `fas ${initialIcon}`;
                iconPreview.style.color = initialColor;
                
                // 显示重置成功提示
                showNotification('图标设置已重置！', 'info');
            });

            // 显示通知
            function showNotification(message, type) {
                const notification = document.createElement('div');
                notification.className = `alert alert-${type}`;
                notification.innerHTML = `
                    <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                    ${message}
                `;
                
                const container = document.querySelector('.admin-main');
                container.insertBefore(notification, container.firstChild);
                
                setTimeout(() => {
                    notification.remove();
                }, 5000);
            }
            // 侧边栏控制由 sidebar-fix.js 处理
        });

        // 删除确认
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const message = this.dataset.message || '确定要删除这个分类吗？';
                if (confirm(message)) {
                    window.location.href = this.href;
                }
            });
        });
    </script>
</body>
</html>