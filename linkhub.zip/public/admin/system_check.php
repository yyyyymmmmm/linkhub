<?php
/**
 * 后台系统完整性检查页面
 * 通过浏览器访问以检查和修复系统问题
 */

// 防止直接访问，需要管理员权限
require_once 'auth.php';
checkPermission('admin');

$pageTitle = '系统检查';
$message = '';
$messageType = '';

// 执行修复操作
if (isset($_POST['action']) && $_POST['action'] === 'fix_database') {
    try {
        // 数据库连接
        require_once dirname(dirname(__DIR__)) . '/config/database_connection.php';
        $pdo_check = getDatabaseConnection();
        $tablePrefix = getTablePrefix();

        $fixes = [];
        
        // MySQL和SQLite兼容性检查已跳过
        $fixes[] = '数据库兼容性检查已跳过（MySQL/SQLite差异）';
        
        // 检查管理员账户（角色1=管理员）
        $stmt = $pdo_check->query("SELECT COUNT(*) FROM " . $tablePrefix . "users WHERE role = 1");
        $adminCount = $stmt->fetchColumn();
        
        if ($adminCount == 0) {
            $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $currentTime = time();
            $stmt = $pdo_check->prepare("INSERT INTO " . $tablePrefix . "users (username, password, role, add_time, status) VALUES (?, ?, 1, ?, 1)");
            $stmt->execute(['admin', $defaultPassword, $currentTime]);
            $fixes[] = '创建默认管理员账户 (admin/admin123)';
        }
        
        if (empty($fixes)) {
            $message = '数据库结构正常，无需修复';
            $messageType = 'success';
        } else {
            $message = '数据库修复完成：' . implode('、', $fixes);
            $messageType = 'success';
        }
        
    } catch (Exception $e) {
        $message = '修复失败：' . $e->getMessage();
        $messageType = 'error';
    }
}

// 检查系统状态
$checks = [
    '必需文件' => [
        'header.php' => file_exists(__DIR__ . '/header.php'),
        'footer.php' => file_exists(__DIR__ . '/footer.php'),
        'auth.php' => file_exists(__DIR__ . '/auth.php'),
        'login.php' => file_exists(dirname(__DIR__) . '/login.php'),
    ],
    '数据库表' => [],
    '权限检查' => [
        '当前用户角色' => $_SESSION['admin_role'] ?? '未知',
        '登录状态' => isset($_SESSION['admin_logged_in']) ? '已登录' : '未登录',
    ]
];

// 检查数据库表
try {
    $tables = ['" . $tablePrefix . "users', '" . $tablePrefix . "categorys', '" . $tablePrefix . "links', '" . $tablePrefix . "settings'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
        $count = $stmt->fetchColumn();
        $checks['数据库表'][$table] = $count . ' 条记录';
    }
} catch (Exception $e) {
    $checks['数据库表']['错误'] = $e->getMessage();
}

require_once 'header.php';
?>

<style>
.check-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.check-card {
    background: var(--bg-card);
    border-radius: var(--border-radius);
    padding: 20px;
    box-shadow: var(--shadow-sm);
    border: 1px solid var(--border-color);
}

.check-card h3 {
    margin: 0 0 15px 0;
    color: var(--primary-color);
    font-size: 18px;
    font-weight: 600;
}

.check-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid var(--border-color);
}

.check-item:last-child {
    border-bottom: none;
}

.check-status {
    font-weight: 500;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
}

.status-ok {
    background: #ecfdf5;
    color: #065f46;
}

.status-error {
    background: #fef2f2;
    color: #991b1b;
}

.status-warning {
    background: #fffbeb;
    color: #92400e;
}

.fix-button {
    background: var(--primary-color);
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: var(--border-radius);
    cursor: pointer;
    font-weight: 500;
    transition: var(--transition-fast);
}

.fix-button:hover {
    background: var(--primary-hover);
}
</style>

<div class="admin-content">
    <h2>系统检查</h2>
    
    <?php if ($message): ?>
        <div class="message <?= $messageType ?>">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>
    
    <div class="check-grid">
        <?php foreach ($checks as $category => $items): ?>
            <div class="check-card">
                <h3><?= $category ?></h3>
                <?php foreach ($items as $item => $status): ?>
                    <div class="check-item">
                        <span><?= htmlspecialchars($item) ?></span>
                        <span class="check-status <?= 
                            (is_bool($status) && $status) || (is_string($status) && !str_contains($status, '错误')) ? 'status-ok' : 
                            (is_bool($status) && !$status ? 'status-error' : 'status-warning') 
                        ?>">
                            <?= is_bool($status) ? ($status ? '✓ 正常' : '✗ 缺失') : htmlspecialchars($status) ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
    
    <div class="check-card" style="margin-top: 20px;">
        <h3>系统修复</h3>
        <p>如果发现问题，点击下面的按钮进行自动修复：</p>
        <form method="POST" style="margin-top: 15px;">
            <input type="hidden" name="action" value="fix_database">
            <button type="submit" class="fix-button" onclick="return confirm('确定要执行系统修复吗？')">
                <i class="fas fa-wrench"></i> 修复数据库问题
            </button>
        </form>
    </div>
    
    <div class="check-card" style="margin-top: 20px;">
        <h3>系统信息</h3>
        <div class="check-item">
            <span>PHP版本</span>
            <span class="check-status status-ok"><?= phpversion() ?></span>
        </div>
        <div class="check-item">
            <span>服务器软件</span>
            <span class="check-status status-ok"><?= $_SERVER['SERVER_SOFTWARE'] ?? '未知' ?></span>
        </div>
        <div class="check-item">
            <span>数据库位置</span>
            <span class="check-status status-ok"><?= '数据库文件路径' ?></span>
        </div>
        <div class="check-item">
            <span>当前时间</span>
            <span class="check-status status-ok"><?= date('Y-m-d H:i:s') ?></span>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>

