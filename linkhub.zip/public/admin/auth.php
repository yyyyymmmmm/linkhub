<?php
/**
 * 后台认证统一处理文件
 * 所有后台页面都需要包含此文件
 */

// 启动会话
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 数据库连接
require_once dirname(dirname(__DIR__)) . '/config/database_connection.php';
$pdo = getDatabaseConnection();
$tablePrefix = getTablePrefix();

/**
 * 检查登录状态
 */
function checkAdminAuth() {
    global $pdo, $tablePrefix;
    
    // 检查session登录状态
    if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in']) {
        // 重要安全检查：验证Session中的用户在数据库中是否真实存在
        if (isset($_SESSION['admin_user_id'])) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "users WHERE id = ? AND (status = 1 OR status IS NULL)");
                $stmt->execute([$_SESSION['admin_user_id']]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user) {
                    // 用户存在且状态正常，认证通过
                    return true;
                } else {
                    // 用户不存在或被禁用，清除Session
                    session_destroy();
                    setcookie('admin_token', '', time() - 3600, '/');
                    return false;
                }
            } catch (Exception $e) {
                // 数据库错误，清除Session
                session_destroy();
                setcookie('admin_token', '', time() - 3600, '/');
                return false;
            }
        } else {
            // Session中没有用户ID，清除无效Session
            session_destroy();
            return false;
        }
    }
    
    // 检查记住登录的cookie
    if (isset($_COOKIE['admin_token']) && !empty($_COOKIE['admin_token'])) {
        try {
            // 兼容新旧表结构
            try {
                $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "users WHERE remember_token = ? AND (status = 1 OR status IS NULL)");
            } catch (Exception $e) {
                // 如果没有status字段，使用简单查询
                $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "users WHERE remember_token = ?");
            }
            $stmt->execute([$_COOKIE['admin_token']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                // 自动登录
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_user_id'] = $user['id'];
                $_SESSION['admin_username'] = $user['username'];
                $_SESSION['admin_role'] = $user['role'];
                return true;
            } else {
                // 清除无效cookie
                setcookie('admin_token', '', time() - 3600, '/');
            }
        } catch (Exception $e) {
            // 数据库错误，清除cookie
            setcookie('admin_token', '', time() - 3600, '/');
        }
    }
    
    return false;
}

/**
 * 要求登录
 */
function requireLogin() {
    if (!checkAdminAuth()) {
        // 如果是AJAX请求，返回JSON
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'unauthorized', 'message' => '请先登录']);
            exit;
        }
        
        // 普通请求重定向到登录页面
        $currentUrl = $_SERVER['REQUEST_URI'];
        header('Location: ../login.php?redirect=' . urlencode($currentUrl));
        exit;
    }
}

/**
 * 检查权限
 */
function checkPermission($requiredRole = 'user') {
    requireLogin();
    
    $userRole = $_SESSION['admin_role'] ?? 'user';
    
    // 兼容数字和字符串角色类型
    if (is_numeric($userRole)) {
        // 数字角色转换为字符串角色（根据数据库schema: 1=管理员,2=普通用户）
        $roleMap = [1 => 'admin', 2 => 'user'];
        $userRole = $roleMap[$userRole] ?? 'user';
    }
    
    $roleHierarchy = ['user' => 1, 'editor' => 2, 'admin' => 3];
    
    $userLevel = $roleHierarchy[$userRole] ?? 0;
    $requiredLevel = $roleHierarchy[$requiredRole] ?? 1;
    
    if ($userLevel < $requiredLevel) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'forbidden', 'message' => '权限不足']);
            exit;
        }
        
        header('HTTP/1.1 403 Forbidden');
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>权限不足</title>
            <style>
                body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
                .error { background: #f8f8f8; padding: 30px; border-radius: 8px; margin: 50px auto; max-width: 600px; }
                h1 { color: #e74c3c; }
                a { color: #3498db; text-decoration: none; }
            </style>
        </head>
        <body>
            <div class="error">
                <h1>权限不足</h1>
                <p>您没有访问此页面的权限</p>
                <p><a href="/admin/">返回后台首页</a></p>
            </div>
        </body>
        </html>';
        exit;
    }
}

/**
 * 退出登录
 */
function logout() {
    // 清除session
    session_destroy();
    
    // 清除cookie
    if (isset($_COOKIE['admin_token'])) {
        setcookie('admin_token', '', time() - 3600, '/');
        
        // 从数据库清除token
        global $pdo;
        try {
            $stmt = $pdo->prepare("UPDATE " . $tablePrefix . "users SET remember_token = NULL WHERE remember_token = ?");
            $stmt->execute([$_COOKIE['admin_token']]);
        } catch (Exception $e) {
            // 忽略数据库错误
        }
    }
    
    // 重定向到登录页面
    header('Location: /login.php');
    exit;
}

/**
 * 获取当前用户信息
 */
function getCurrentUser() {
    requireLogin();
    
    global $pdo, $tablePrefix;
    $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "users WHERE id = ?");
    $stmt->execute([$_SESSION['admin_user_id']]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// 处理退出登录
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    logout();
}

// 自动要求登录（除非明确指定不需要）
if (!defined('NO_AUTH_REQUIRED')) {
    requireLogin();
}
?>
