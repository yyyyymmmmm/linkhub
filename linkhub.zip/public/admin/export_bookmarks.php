<?php
/**
 * 导出书签功能
 */
require_once 'auth.php';

// 检查权限
checkPermission('editor');

// 获取导出格式
$format = $_GET['format'] ?? 'html';
$categoryId = intval($_GET['category'] ?? 0);

try {
    // 构建查询条件
    $whereClause = "WHERE 1=1";
    $params = [];
    
    if ($categoryId > 0) {
        $whereClause .= " AND l.fid = ?";
        $params[] = $categoryId;
    }
    
    // 获取所有链接和分类信息
    $sql = "
        SELECT 
            l.id,
            l.title,
            l.url,
            l.note,
            l.font_icon,
            l.icon_color,
            l.weight,
            l.add_time,
            c.name as category_name,
            c.font_icon as category_icon
        FROM " . $tablePrefix . "links l
        LEFT JOIN " . $tablePrefix . "categorys c ON l.fid = c.id
        $whereClause
        ORDER BY c.weight ASC, c.id ASC, l.weight DESC, l.id ASC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $links = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($links)) {
        throw new Exception('没有找到要导出的书签');
    }
    
    // 按分类分组
    $groupedLinks = [];
    foreach ($links as $link) {
        $categoryName = $link['category_name'] ?: '未分类';
        if (!isset($groupedLinks[$categoryName])) {
            $groupedLinks[$categoryName] = [
                'category' => [
                    'name' => $categoryName,
                    'icon' => $link['category_icon'] ?? 'fas fa-folder'
                ],
                'links' => []
            ];
        }
        $groupedLinks[$categoryName]['links'][] = $link;
    }
    
    // 根据格式导出
    switch ($format) {
        case 'html':
            exportAsHtml($groupedLinks);
            break;
        case 'json':
            exportAsJson($groupedLinks);
            break;
        case 'csv':
            exportAsCsv($links);
            break;
        default:
            throw new Exception('不支持的导出格式');
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo "导出失败: " . $e->getMessage();
}

/**
 * 导出为HTML格式（标准书签格式）
 */
function exportAsHtml($groupedLinks) {
    $filename = 'LinkHub_Export_' . date('Y.n.j') . '.html';
    
    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
    
    echo '<!DOCTYPE NETSCAPE-Bookmark-file-1>' . "\n";
    echo '<!-- This is an automatically generated file. -->' . "\n";
    echo '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">' . "\n";
    echo '<TITLE>LinkHub 书签导出</TITLE>' . "\n";
    echo '<H1>LinkHub 书签导出</H1>' . "\n";
    echo '<DL><p>' . "\n";
    
    foreach ($groupedLinks as $categoryData) {
        $category = $categoryData['category'];
        $links = $categoryData['links'];
        
        echo '    <DT><H3 ADD_DATE="' . time() . '" LAST_MODIFIED="' . time() . '">' . htmlspecialchars($category['name']) . '</H3>' . "\n";
        echo '    <DL><p>' . "\n";
        
        foreach ($links as $link) {
            $addTime = $link['add_time'] ?: time();
            echo '        <DT><A HREF="' . htmlspecialchars($link['url']) . '" ADD_DATE="' . $addTime . '"';
            
            if (!empty($link['note'])) {
                echo ' DESCRIPTION="' . htmlspecialchars($link['note']) . '"';
            }
            
            if (!empty($link['font_icon'])) {
                echo ' ICON="' . htmlspecialchars($link['font_icon']) . '"';
            }
            
            echo '>' . htmlspecialchars($link['title']) . '</A>' . "\n";
        }
        
        echo '    </DL><p>' . "\n";
    }
    
    echo '</DL><p>' . "\n";
    echo '<!-- 导出时间: ' . date('Y-m-d H:i:s') . ' -->' . "\n";
    echo '<!-- 总计: ' . array_sum(array_map(function($cat) { return count($cat['links']); }, $groupedLinks)) . ' 个书签 -->' . "\n";
}

/**
 * 导出为JSON格式
 */
function exportAsJson($groupedLinks) {
    $filename = 'LinkHub_Export_' . date('Y.n.j') . '.json';
    
    header('Content-Type: application/json; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
    
    $exportData = [
        'export_info' => [
            'version' => 'LinkHub',
            'export_time' => date('Y-m-d H:i:s'),
            'total_categories' => count($groupedLinks),
            'total_links' => array_sum(array_map(function($cat) { return count($cat['links']); }, $groupedLinks))
        ],
        'categories' => []
    ];
    
    foreach ($groupedLinks as $categoryData) {
        $exportData['categories'][] = [
            'name' => $categoryData['category']['name'],
            'icon' => $categoryData['category']['icon'],
            'links' => array_map(function($link) {
                return [
                    'id' => $link['id'],
                    'title' => $link['title'],
                    'url' => $link['url'],
                    'note' => $link['note'],
                    'icon' => $link['font_icon'],
                    'icon_color' => $link['icon_color'],
                    'weight' => $link['weight'],
                    'add_time' => $link['add_time']
                ];
            }, $categoryData['links'])
        ];
    }
    
    echo json_encode($exportData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

/**
 * 导出为CSV格式
 */
function exportAsCsv($links) {
    $filename = 'LinkHub_Export_' . date('Y.n.j') . '.csv';
    
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
    
    // 输出BOM以支持Excel中文显示
    echo "\xEF\xBB\xBF";
    
    // 输出表头
    $headers = ['ID', '标题', '链接', '分类', '描述', '图标', '图标颜色', '权重', '添加时间'];
    echo '"' . implode('","', $headers) . '"' . "\n";
    
    // 输出数据
    foreach ($links as $link) {
        $row = [
            $link['id'],
            $link['title'],
            $link['url'],
            $link['category_name'] ?: '未分类',
            $link['note'],
            $link['font_icon'],
            $link['icon_color'],
            $link['weight'],
            $link['add_time'] ? date('Y-m-d H:i:s', $link['add_time']) : ''
        ];
        
        // 转义双引号
        $row = array_map(function($field) {
            return str_replace('"', '""', $field);
        }, $row);
        
        echo '"' . implode('","', $row) . '"' . "\n";
    }
}
?>
