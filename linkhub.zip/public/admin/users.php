<?php
require_once 'auth.php';

// 检查权限（管理员权限才能管理用户）
checkPermission('admin');

$message = '';
$messageType = '';

// 处理用户操作
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    try {
        switch ($action) {
            case 'add_user':
                $username = trim($_POST['username']);
                $password = $_POST['password'];
                $email = trim($_POST['email']);
                $role = $_POST['role'];
                
                if (empty($username) || empty($password)) {
                    throw new Exception('用户名和密码不能为空');
                }
                
                // 检查用户名是否已存在
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "users WHERE username = ?");
                $stmt->execute([$username]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('用户名已存在');
                }
                
                // 转换角色字符串为数字（根据数据库schema: 1=管理员,2=普通用户）
                $roleMap = ['admin' => 1, 'editor' => 1, 'user' => 2]; // editor当作管理员处理
                $roleNum = $roleMap[$role] ?? 2; // 默认为普通用户
                
                // 添加用户
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    INSERT INTO " . $tablePrefix . "users (username, password, email, role, status, add_time) 
                    VALUES (?, ?, ?, ?, 1, ?)
                ");
                $stmt->execute([$username, $hashedPassword, $email, $roleNum, time()]);
                
                $message = '用户添加成功';
                $messageType = 'success';
                break;
                
            case 'edit_user':
                $userId = intval($_POST['user_id']);
                $username = trim($_POST['username']);
                $email = trim($_POST['email']);
                $role = $_POST['role'];
                $status = intval($_POST['status']);
                
                if (empty($username)) {
                    throw new Exception('用户名不能为空');
                }
                
                // 检查用户名是否被其他用户使用
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "users WHERE username = ? AND id != ?");
                $stmt->execute([$username, $userId]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('用户名已被其他用户使用');
                }
                
                // 转换角色字符串为数字（根据数据库schema: 1=管理员,2=普通用户）
                $roleMap = ['admin' => 1, 'editor' => 1, 'user' => 2]; // editor当作管理员处理
                $roleNum = $roleMap[$role] ?? 2; // 默认为普通用户
                
                // 更新用户信息
                $stmt = $pdo->prepare("
                    UPDATE " . $tablePrefix . "users SET username = ?, email = ?, role = ?, status = ?
                    WHERE id = ?
                ");
                $stmt->execute([$username, $email, $roleNum, $status, $userId]);
                
                // 如果有新密码，则更新密码
                if (!empty($_POST['new_password'])) {
                    $hashedPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE " . $tablePrefix . "users SET password = ? WHERE id = ?");
                    $stmt->execute([$hashedPassword, $userId]);
                }
                
                $message = '用户信息更新成功';
                $messageType = 'success';
                break;
                
            case 'delete_user':
                $userId = intval($_POST['user_id']);
                
                // 不能删除自己
                if ($userId == getCurrentUser()['id']) {
                    throw new Exception('不能删除当前登录的用户');
                }
                
                $stmt = $pdo->prepare("DELETE FROM " . $tablePrefix . "users WHERE id = ?");
                $stmt->execute([$userId]);
                
                $message = '用户删除成功';
                $messageType = 'success';
                break;
                
            case 'batch_delete':
                if (!empty($_POST['user_ids'])) {
                    $userIds = array_map('intval', $_POST['user_ids']);
                    $currentUserId = getCurrentUser()['id'];
                    
                    // 过滤掉当前用户ID
                    $userIds = array_filter($userIds, function($id) use ($currentUserId) {
                        return $id != $currentUserId;
                    });
                    
                    if (!empty($userIds)) {
                        $placeholders = str_repeat('?,', count($userIds) - 1) . '?';
                        $stmt = $pdo->prepare("DELETE FROM " . $tablePrefix . "users WHERE id IN ($placeholders)");
                        $stmt->execute($userIds);
                        
                        $message = '批量删除成功，共删除 ' . count($userIds) . ' 个用户';
                        $messageType = 'success';
                    }
                }
                break;
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}

// 获取用户列表
$page = intval($_GET['page'] ?? 1);
$limit = 20;
$offset = ($page - 1) * $limit;

// 搜索条件
$search = trim($_GET['search'] ?? '');
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';

$whereConditions = [];
$params = [];

if ($search) {
    $whereConditions[] = "(username LIKE ? OR email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($roleFilter) {
    $whereConditions[] = "role = ?";
    // 转换字符串角色为数字进行查询
    $roleMap = ['admin' => 1, 'editor' => 1, 'user' => 2];
    $params[] = $roleMap[$roleFilter] ?? 2;
}

if ($statusFilter !== '') {
    $whereConditions[] = "status = ?";
    $params[] = intval($statusFilter);
}

$whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// 获取总数
$countSql = "SELECT COUNT(*) FROM " . $tablePrefix . "users $whereClause";
$totalCount = $pdo->prepare($countSql);
$totalCount->execute($params);
$totalCount = $totalCount->fetchColumn();

// 获取用户列表
$sql = "SELECT * FROM " . $tablePrefix . "users $whereClause ORDER BY id DESC LIMIT $limit OFFSET $offset";
$users = $pdo->prepare($sql);
$users->execute($params);
$users = $users->fetchAll(PDO::FETCH_ASSOC);

// 计算分页信息
$totalPages = ceil($totalCount / $limit);
$startNum = $offset + 1;
$endNum = min($offset + $limit, $totalCount);

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle"id="sidebarToggle"  id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/backup.php" data-title="备份恢复">
                            <i class="fas fa-database"></i>
                            <span>备份恢复</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay" ></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
        <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <i class="fas fa-users"></i>
                    <span>用户管理</span>
                </div>
                <div class="header-actions">
                    <button type="button" class="btn btn-primary btn-sm" onclick="showAddUserModal()">
                        <i class="fas fa-plus"></i>
                        添加用户
                </button>
            </div>
        </header>

            <!-- 主体内容 -->
            <div class="admin-main">
        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>">
                        <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

                <!-- 筛选和搜索 -->
                <div class="card">
                    <div class="card-body">
                        <form method="GET" class="filter-form">
                            <div style="display: grid; grid-template-columns: 1fr 150px 120px auto; gap: 1rem; align-items: end;">
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label class="form-label">搜索用户</label>
                                    <input type="text" name="search" class="form-control" 
                                           value="<?= htmlspecialchars($search) ?>" 
                                           placeholder="用户名或邮箱">
                </div>
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label class="form-label">角色筛选</label>
                                    <select name="role" class="form-control form-select">
                                        <option value="">全部角色</option>
                                        <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>管理员</option>
                                        <option value="editor" <?= $roleFilter === 'editor' ? 'selected' : '' ?>>编辑</option>
                                        <option value="user" <?= $roleFilter === 'user' ? 'selected' : '' ?>>用户</option>
                                    </select>
                </div>
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label class="form-label">状态筛选</label>
                                    <select name="status" class="form-control form-select">
                                        <option value="">全部</option>
                                        <option value="1" <?= $statusFilter === '1' ? 'selected' : '' ?>>正常</option>
                                        <option value="0" <?= $statusFilter === '0' ? 'selected' : '' ?>>禁用</option>
                                    </select>
            </div>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                        搜索
                                    </button>
                                    <a href="/admin/users.php" class="btn btn-secondary">
                                        <i class="fas fa-times"></i>
                                        重置
                                    </a>
                </div>
            </div>
                        </form>
                    </div>
                </div>

                <!-- 批量操作栏 -->
                <div class="batch-actions" id="batchActions" style="display: none;">
                    <div class="selected-info">
                        <span>已选择 <strong class="selected-count">0</strong> 个用户</span>
                        <div class="action-buttons">
                            <button type="button" class="btn btn-danger btn-sm" onclick="batchDeleteUsers()">
                                <i class="fas fa-trash"></i>
                                批量删除
                            </button>
                </div>
            </div>
        </div>

                <!-- 用户表格 -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                            <i class="fas fa-list"></i>
                            用户列表
                            <?php if ($totalCount > 0): ?>
                                <small class="text-muted">
                                    (显示第 <?= $startNum ?> - <?= $endNum ?> 条，共 <?= $totalCount ?> 条)
                                </small>
                            <?php endif; ?>
                </h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($users)): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                            <th width="50">
                                                <input type="checkbox" class="select-all" onchange="toggleSelectAll()">
                                            </th>
                                    <th>用户信息</th>
                                            <th width="100">角色</th>
                                            <th width="80">状态</th>
                                            <th width="120">注册时间</th>
                                            <th width="120">最后登录</th>
                                            <th width="120">操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                        <tr class="search-item">
                                            <td>
                                                <input type="checkbox" class="select-item" value="<?= $user['id'] ?>" 
                                                       onchange="updateBatchActions()"
                                                       <?= $user['id'] == $currentUser['id'] ? 'disabled' : '' ?>>
                                            </td>
                                        <td>
                                            <div class="user-info">
                                                    <div class="user-name">
                                                        <i class="fas fa-user"></i>
                                                        <strong><?= htmlspecialchars($user['username']) ?></strong>
                                                        <?php if ($user['id'] == $currentUser['id']): ?>
                                                            <span class="badge badge-info">当前用户</span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if ($user['email']): ?>
                                                        <div class="user-email">
                                                            <small class="text-muted">
                                                                <i class="fas fa-envelope"></i>
                                                                <?= htmlspecialchars($user['email']) ?>
                                                            </small>
                                                </div>
                                                    <?php endif; ?>
                                            </div>
                                        </td>
                                            <td>
                                                <?php
                                                // 转换数字角色为字符串显示
                                                $userRoleStr = ($user['role'] == 1) ? 'admin' : 'user';
                                                $badgeClass = ($user['role'] == 1) ? 'badge-danger' : 'badge-info';
                                                $roleNames = [1 => '管理员', 2 => '用户'];
                                                $roleName = $roleNames[$user['role']] ?? '未知';
                                                ?>
                                                <span class="badge <?= $badgeClass ?>">
                                                    <?= $roleName ?>
                                                </span>
                                        </td>
                                        <td>
                                                <span class="badge <?= $user['status'] == 1 ? 'badge-success' : 'badge-secondary' ?>">
                                                    <?= $user['status'] == 1 ? '正常' : '禁用' ?>
                                            </span>
                                        </td>
                                            <td>
                                                <?php if ($user['add_time']): ?>
                                                    <span title="<?= date('Y-m-d H:i:s', $user['add_time']) ?>">
                                                        <?= date('Y-m-d H:i', $user['add_time']) ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($user['last_login']): ?>
                                                    <span title="<?= date('Y-m-d H:i:s', $user['last_login']) ?>">
                                                        <?= date('Y-m-d H:i', $user['last_login']) ?>
                                                    </span>
                                                    <small class="text-muted d-block">
                                                        <?php
                                                        $diff = time() - $user['last_login'];
                                                        if ($diff < 60) echo '刚刚';
                                                        elseif ($diff < 3600) echo floor($diff/60) . '分钟前';
                                                        elseif ($diff < 86400) echo floor($diff/3600) . '小时前';
                                                        elseif ($diff < 2592000) echo floor($diff/86400) . '天前';
                                                        else echo '很久以前';
                                                        ?>
                                                    </small>
                                                <?php else: ?>
                                                    <span class="text-muted">从未登录</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div style="display: flex; gap: 0.25rem;">
                                                    <?php
                                                    // 为JavaScript转换数字角色为字符串角色
                                                    $userForJS = $user;
                                                    $userForJS['role'] = ($user['role'] == 1) ? 'admin' : 'user';
                                                    ?>
                                                    <button type="button" class="btn btn-secondary btn-sm" 
                                                            onclick="showEditUserModal(<?= htmlspecialchars(json_encode($userForJS)) ?>)" title="编辑">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <?php if ($user['id'] != $currentUser['id']): ?>
                                                        <button type="button" class="btn btn-danger btn-sm" 
                                                                onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>')" title="删除">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                            <!-- 分页 -->
                            <?php if ($totalPages > 1): ?>
                                <div class="pagination-wrapper">
                                    <nav class="pagination">
                                        <?php
                                        $queryParams = $_GET;
                                        unset($queryParams['page']);
                                        $baseQuery = http_build_query($queryParams);
                                        $baseUrl = '/admin/users.php?' . ($baseQuery ? $baseQuery . '&' : '');
                                        ?>
                                        
                                        <?php if ($page > 1): ?>
                                            <a href="<?= $baseUrl ?>page=<?= $page - 1 ?>" class="page-link">
                                                <i class="fas fa-chevron-left"></i>
                                                上一页
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php
                                        $startPage = max(1, $page - 2);
                                        $endPage = min($totalPages, $page + 2);
                                        ?>
                                        
                                        <?php if ($startPage > 1): ?>
                                            <a href="<?= $baseUrl ?>page=1" class="page-link">1</a>
                                            <?php if ($startPage > 2): ?>
                                                <span class="page-ellipsis">...</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                                            <a href="<?= $baseUrl ?>page=<?= $i ?>" 
                                               class="page-link <?= $i == $page ? 'active' : '' ?>">
                                                <?= $i ?>
                                            </a>
                                        <?php endfor; ?>
                                        
                                        <?php if ($endPage < $totalPages): ?>
                                            <?php if ($endPage < $totalPages - 1): ?>
                                                <span class="page-ellipsis">...</span>
                                            <?php endif; ?>
                                            <a href="<?= $baseUrl ?>page=<?= $totalPages ?>" class="page-link"><?= $totalPages ?></a>
                                        <?php endif; ?>
                                        
                                        <?php if ($page < $totalPages): ?>
                                            <a href="<?= $baseUrl ?>page=<?= $page + 1 ?>" class="page-link">
                                                下一页
                                                <i class="fas fa-chevron-right"></i>
                                            </a>
                                        <?php endif; ?>
                                    </nav>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-users"></i>
                                <p><?= $search || $roleFilter || $statusFilter !== '' ? '没有找到符合条件的用户' : '暂无用户数据' ?></p>
                                <button type="button" class="btn btn-primary" onclick="showAddUserModal()">添加第一个用户</button>
                            </div>
                <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

        <!-- 添加用户模态框 -->
    <div id="addUserModal" class="modal" style="display: none;">
            <div class="modal-content">
                <div class="modal-header">
                <h3>添加用户</h3>
                <button type="button" class="modal-close" onclick="hideModal('addUserModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_user">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">用户名 *</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">密码 *</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">邮箱</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">角色</label>
                        <select name="role" class="form-control form-select">
                            <option value="user">用户</option>
                            <option value="editor">编辑</option>
                            <option value="admin">管理员</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="hideModal('addUserModal')">取消</button>
                    <button type="submit" class="btn btn-primary">添加用户</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 编辑用户模态框 -->
    <div id="editUserModal" class="user-modal" style="display: none;">
        <div class="user-modal-overlay" onclick="hideModal('editUserModal')"></div>
        <div class="user-modal-content">
            <div class="user-modal-header">
                <div class="user-modal-title">
                    <div class="user-modal-icon">
                        <i class="fas fa-user-edit"></i>
                    </div>
                    <h3>编辑用户信息</h3>
                </div>
                <button type="button" class="user-close-btn" onclick="hideModal('editUserModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" class="user-form">
                <input type="hidden" name="action" value="edit_user">
                <input type="hidden" name="user_id" id="editUserId">
                
                <div class="user-modal-body">
                    <div class="user-form-section">
                        <h4 class="section-title">
                            <i class="fas fa-user"></i>
                            基本信息
                        </h4>
                    
                    <div class="form-row">
                        <div class="form-group">
                                <label class="form-label">
                                    <i class="fas fa-user"></i>
                                    用户名 *
                                </label>
                                <input type="text" name="username" id="editUsername" class="form-control" required 
                                       placeholder="请输入用户名">
                                <div class="form-help">用户登录时使用的唯一标识</div>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">
                                    <i class="fas fa-envelope"></i>
                                    邮箱地址
                                </label>
                                <input type="email" name="email" id="editEmail" class="form-control" 
                                       placeholder="请输入邮箱地址">
                                <div class="form-help">用于接收系统通知和密码重置</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="user-form-section">
                        <h4 class="section-title">
                            <i class="fas fa-shield-alt"></i>
                            权限设置
                        </h4>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">
                                    <i class="fas fa-user-tag"></i>
                                    用户角色 *
                                </label>
                                <select name="role" id="editRole" class="form-control" required>
                                    <option value="">请选择角色</option>
                                    <option value="admin">管理员 - 拥有所有权限</option>
                                    <option value="editor">编辑者 - 可管理内容</option>
                                    <option value="user">普通用户 - 基础权限</option>
                                </select>
                                <div class="form-help">不同角色拥有不同的系统权限</div>
                            </div>
                            
                        <div class="form-group">
                                <label class="form-label">
                                    <i class="fas fa-toggle-on"></i>
                                    账户状态 *
                                </label>
                                <select name="status" id="editStatus" class="form-control" required>
                                    <option value="">请选择状态</option>
                                    <option value="1">正常 - 可正常使用</option>
                                    <option value="0">禁用 - 无法登录系统</option>
                                </select>
                                <div class="form-help">禁用后用户将无法登录系统</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="user-form-section">
                        <h4 class="section-title">
                            <i class="fas fa-key"></i>
                            安全设置
                        </h4>
                        
                        <div class="form-group">
                            <label class="form-label">
                                <i class="fas fa-lock"></i>
                                新密码
                            </label>
                            <div class="password-input-group">
                                <input type="password" name="new_password" id="newPassword" class="form-control" 
                                       placeholder="留空则不修改密码">
                                <button type="button" class="password-toggle" onclick="togglePassword('newPassword')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="form-help">
                                <i class="fas fa-info-circle"></i>
                                密码长度至少6位，建议包含字母、数字和特殊字符
                            </div>
                        </div>
                        
                        <div class="security-notice">
                            <div class="notice-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="notice-content">
                                <strong>安全提示</strong>
                                <p>修改用户信息后，该用户可能需要重新登录。请确保操作的准确性。</p>
                            </div>
                        </div>
                        </div>
                    </div>
                    
                <div class="user-modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="hideModal('editUserModal')">
                        <i class="fas fa-times"></i>
                        取消
                    </button>
                        <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        保存更改
                        </button>
                    </div>
                </form>
            </div>
        </div>

    <script src="../assets/js/admin.js?v=2.0.1"></script>
    <script src="../assets/js/sidebar-fix.js?v=1.0.0"></script>
    <script>
        // 显示添加用户模态框
        function showAddUserModal() {
            showModal('addUserModal');
        }

        // 显示编辑用户模态框
        function showEditUserModal(user) {
            document.getElementById('editUserId').value = user.id;
            document.getElementById('editUsername').value = user.username;
            document.getElementById('editEmail').value = user.email || '';
            document.getElementById('editRole').value = user.role;
            document.getElementById('editStatus').value = user.status;
            showModal('editUserModal');
        }

        // 显示模态框
        function showModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        }

        // 隐藏模态框
        function hideModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = '';
            }
        }
        
        // 切换密码显示
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const button = input.nextElementSibling;
            const icon = button.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }

        // 删除用户
        function deleteUser(userId, username) {
            if (confirm(`确定要删除用户「${username}」吗？此操作无法撤销。`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.name = 'action';
                actionInput.value = 'delete_user';
                form.appendChild(actionInput);
                
                const userIdInput = document.createElement('input');
                userIdInput.name = 'user_id';
                userIdInput.value = userId;
                form.appendChild(userIdInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }

        // 批量删除用户
        function batchDeleteUsers() {
            const selectedItems = document.querySelectorAll('.select-item:checked:not([disabled])');
            if (selectedItems.length === 0) {
                alert('请选择要删除的用户');
                return;
            }

            if (!confirm(`确定要删除选中的 ${selectedItems.length} 个用户吗？此操作无法撤销。`)) {
                return;
            }

            const ids = Array.from(selectedItems).map(item => item.value);
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';

            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'batch_delete';
            form.appendChild(actionInput);

            ids.forEach(id => {
                const idInput = document.createElement('input');
                idInput.name = 'user_ids[]';
                idInput.value = id;
                form.appendChild(idInput);
            });

            document.body.appendChild(form);
            form.submit();
        }

        // 点击模态框背景关闭
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });
        });
    </script>

    <style>
        /* 用户模态框样式 */
        .user-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .user-modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }
        
        .user-modal-content {
            position: relative;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            max-width: 700px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease-out;
        }
        
        .user-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 24px 24px 16px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .user-modal-title {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .user-modal-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
        }
        
        .user-modal-title h3 {
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .user-close-btn {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            color: #666;
            transition: all 0.2s ease;
        }
        
        .user-close-btn:hover {
            background: #f5f5f5;
            color: #333;
        }
        
        .user-modal-body {
            padding: 24px;
        }
        
        .user-form-section {
            margin-bottom: 2rem;
        }
        
        .user-form-section:last-child {
            margin-bottom: 0;
        }
        
        .section-title {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0 0 1.5rem;
            font-size: 16px;
            font-weight: 600;
            color: #374151;
            padding-bottom: 8px;
            border-bottom: 2px solid #f1f5f9;
        }
        
        .section-title i {
            color: #6366f1;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }
        
        .user-form-section .form-group {
            margin-bottom: 1.5rem;
        }
        
        .user-form-section .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            margin-bottom: 8px;
            color: #374151;
        }
        
        .user-form-section .form-label i {
            color: #6366f1;
            font-size: 14px;
        }
        
        .form-help {
            font-size: 12px;
            color: #6b7280;
            margin-top: 4px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .password-input-group {
            position: relative;
            display: flex;
            align-items: center;
        }
        
        .password-input-group input {
            padding-right: 50px;
        }
        
        .password-toggle {
            position: absolute;
            right: 12px;
            background: none;
            border: none;
            color: #6b7280;
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            transition: all 0.2s ease;
        }
        
        .password-toggle:hover {
            color: #374151;
            background: #f3f4f6;
        }
        
        .security-notice {
            background: #fef3c7;
            border: 1px solid #f59e0b;
            border-radius: 8px;
            padding: 16px;
            display: flex;
            gap: 12px;
            margin-top: 1rem;
        }
        
        .notice-icon {
            color: #f59e0b;
            font-size: 20px;
            flex-shrink: 0;
        }
        
        .notice-content {
            flex: 1;
        }
        
        .notice-content strong {
            color: #92400e;
            display: block;
            margin-bottom: 4px;
        }
        
        .notice-content p {
            color: #92400e;
            margin: 0;
            font-size: 14px;
            line-height: 1.4;
        }
        
        .user-modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding: 16px 24px 24px;
            border-top: 1px solid #f0f0f0;
        }
        
        .user-form {
            margin: 0;
        }
        
        @media (max-width: 768px) {
            .user-modal-content {
                margin: 20px;
                max-width: none;
            }
            
            .user-modal-header,
            .user-modal-body {
                padding: 20px;
            }
            
            .user-modal-footer {
                padding: 16px 20px 20px;
                flex-direction: column;
            }
            
            .form-row {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .user-modal-title {
                gap: 8px;
            }
            
            .user-modal-icon {
                width: 40px;
                height: 40px;
                font-size: 18px;
            }
            
            .user-modal-title h3 {
                font-size: 18px;
            }
        }
        
        /* 模态框样式 */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-content {
            background: var(--white);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-xl);
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow: hidden;
        }

        .modal-header {
            padding: var(--spacing-lg) var(--spacing-xl);
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: var(--gray-50);
        }

        .modal-header h3 {
            margin: 0;
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--gray-800);
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--gray-500);
            cursor: pointer;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-close:hover {
            color: var(--gray-700);
        }

        .modal-body {
            padding: var(--spacing-xl);
            max-height: 60vh;
            overflow-y: auto;
        }

        .modal-footer {
            padding: var(--spacing-lg) var(--spacing-xl);
            border-top: 1px solid var(--gray-200);
            display: flex;
            gap: var(--spacing);
            justify-content: flex-end;
            background: var(--gray-50);
        }

        .user-info {
            min-width: 0;
        }

        .user-name {
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
            margin-bottom: var(--spacing-xs);
            font-weight: 500;
        }

        .user-email {
            font-size: 0.8125rem;
            color: var(--gray-500);
        }

        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                margin: var(--spacing);
            }
        }
    </style>
</body>
</html>