<?php
require_once 'auth.php';

// 检查权限
checkPermission('editor');

// $pdo 已在 auth.php 中定义

$message = '';
$messageType = '';

// 处理设置保存
if ($_POST) {
    try {
        // 定义允许保存的站点设置字段
        $allowedSettings = [
            'site_name',
            'site_subtitle', 
            'site_keywords',
            'site_description',
            'site_logo',
            'site_favicon',
            'site_icp',
            'admin_email',
            'custom_header',
            'custom_footer',
            'site_statistics',
            'links_per_page',
            'enable_register',
            'enable_public_links',
            'enable_click_stats',
            'enable_seo_friendly',
            'smtp_host',
            'smtp_port',
            'smtp_user',
            'smtp_pass',
            'smtp_secure',
            'backup_auto',
            'backup_interval',
            'backup_keep_days',
            // 过渡页相关设置
            'enable_transition_page',
            'transition_time',
            'transition_theme_color',
            'transition_title',
            'transition_message',
            'transition_ad_code',
            'transition_show_progress',
            'transition_allow_skip'
        ];
        
        // 处理复选框特殊情况 - 未选中时不会提交值
        $checkboxSettings = [
            'enable_register',
            'enable_public_links',
            'enable_click_stats',
            'enable_seo_friendly',
            'enable_transition_page',
            'transition_show_progress',
            'transition_allow_skip'
        ];
        
        // 先将所有复选框设置为0（未选中）
        foreach ($checkboxSettings as $checkbox) {
            if (in_array($checkbox, $allowedSettings)) {
                $sql = "REPLACE INTO " . $tablePrefix . "settings (`key`, `value`) VALUES (?, '0')";
                $pdo->prepare($sql)->execute([$checkbox]);
            }
        }
        
        // 处理文件上传
        $uploadDir = dirname(__DIR__) . '/data/upload/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // 处理Logo上传
        if (isset($_FILES['logo_upload']) && $_FILES['logo_upload']['error'] === UPLOAD_ERR_OK) {
            $logoFile = $_FILES['logo_upload'];
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];
            
            if (in_array($logoFile['type'], $allowedTypes)) {
                $fileExt = pathinfo($logoFile['name'], PATHINFO_EXTENSION);
                $fileName = 'logo_' . time() . '.' . $fileExt;
                $filePath = $uploadDir . $fileName;
                
                if (move_uploaded_file($logoFile['tmp_name'], $filePath)) {
                    $_POST['site_logo'] = '/data/upload/' . $fileName;
                    
                    // 删除旧的logo文件
                    $oldLogo = $settings['site_logo'] ?? '';
                    if (!empty($oldLogo) && file_exists(dirname(__DIR__) . $oldLogo)) {
                        unlink(dirname(__DIR__) . $oldLogo);
                    }
                }
            }
        }
        
        // 处理Favicon上传
        if (isset($_FILES['favicon_upload']) && $_FILES['favicon_upload']['error'] === UPLOAD_ERR_OK) {
            $faviconFile = $_FILES['favicon_upload'];
            $allowedTypes = ['image/x-icon', 'image/vnd.microsoft.icon', 'image/png'];
            
            if (in_array($faviconFile['type'], $allowedTypes) || pathinfo($faviconFile['name'], PATHINFO_EXTENSION) === 'ico') {
                $fileExt = pathinfo($faviconFile['name'], PATHINFO_EXTENSION);
                $fileName = 'favicon_' . time() . '.' . $fileExt;
                $filePath = $uploadDir . $fileName;
                
                if (move_uploaded_file($faviconFile['tmp_name'], $filePath)) {
                    $_POST['site_favicon'] = '/data/upload/' . $fileName;
                    
                    // 删除旧的favicon文件
                    $oldFavicon = $settings['site_favicon'] ?? '';
                    if (!empty($oldFavicon) && file_exists(dirname(__DIR__) . $oldFavicon)) {
                        unlink(dirname(__DIR__) . $oldFavicon);
                    }
                }
            }
        }
        
        // 然后处理所有提交的设置
        foreach ($_POST as $key => $value) {
            if ($key === 'action') continue;
            
            // 只保存允许的设置字段
            if (in_array($key, $allowedSettings)) {
                // 更新或插入设置
                $sql = "REPLACE INTO " . $tablePrefix . "settings (`key`, `value`) VALUES (?, ?)";
                $pdo->prepare($sql)->execute([$key, $value]);
            }
        }
        
        // 调试信息
        error_log("Settings saved. enable_transition_page: " . ($_POST['enable_transition_page'] ?? '0'));
        
        $message = '设置保存成功';
        $messageType = 'success';
        
    } catch (Exception $e) {
        $message = '保存失败：' . $e->getMessage();
        $messageType = 'error';
    }
}

// 获取所有设置
$settings = [];
$settingsData = $pdo->query("SELECT `key`, `value` FROM " . $tablePrefix . "settings")->fetchAll(PDO::FETCH_ASSOC);
foreach ($settingsData as $setting) {
    $settings[$setting['key']] = $setting['value'];
}

// 获取当前主题
$currentTheme = $settings['default_theme'] ?? 'default';

// 设置默认值
$defaults = [
    'site_name' => 'LinkHub',
    'site_subtitle' => '专业的书签管理和导航系统',
    'site_keywords' => 'LinkHub,书签,导航,网址导航',
    'site_description' => 'LinkHub - 专业的书签管理和导航系统',
    'site_icp' => '',
    'site_statistics' => '',
    'admin_email' => '',
    'enable_register' => '0',
    'enable_public_links' => '1',
    'links_per_page' => '20',
    'enable_click_stats' => '1',
    'enable_seo_friendly' => '1',
    'smtp_host' => '',
    'smtp_port' => '587',
    'smtp_username' => '',
    'smtp_password' => '',
    'smtp_encryption' => 'tls',
    'cache_enabled' => '1',
    'cache_time' => '3600',
    // 过渡页默认设置
    'enable_transition_page' => '0',
    'transition_time' => '3',
    'transition_theme_color' => '#6366f1',
    'transition_title' => '正在跳转中...',
    'transition_message' => '即将为您跳转到目标网站，请稍候...',
    'transition_ad_code' => '',
    'transition_show_progress' => '1',
    'transition_allow_skip' => '1'
];

foreach ($defaults as $key => $value) {
    if (!isset($settings[$key])) {
        $settings[$key] = $value;
    }
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统设置 - LinkHub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.0">
    <style>
        /* 重置和覆盖样式 - 使用!important确保优先级 */
        /* 文件上传样式 */
        .upload-preview {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            background: #fafafa;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .upload-preview:hover {
            border-color: #007bff;
            background: #f0f8ff;
        }
        
        .upload-preview.dragover {
            border-color: #007bff;
            background: #e3f2fd;
        }
        
        .file-upload {
            display: none !important;
        }
        
        .upload-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s ease;
            border: none;
            font-size: 14px;
            text-decoration: none;
            user-select: none;
        }
        
        .upload-btn:hover {
            background: #0056b3;
        }
        
        .current-logo, .current-favicon {
            margin-bottom: 15px;
            padding: 10px;
            background: white;
            border-radius: 6px;
            border: 1px solid #e9ecef;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .current-logo img, .current-favicon img {
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .remove-logo {
            padding: 4px 8px !important;
            font-size: 12px !important;
            border-radius: 4px !important;
        }
        
        .upload-preview .text-muted {
            margin-top: 10px;
            font-size: 12px;
        }
        
        /* 设置标签页样式 */
        .settings-tabs {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .tab-nav {
            display: flex;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .tab-btn {
            flex: 1;
            padding: 15px 20px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
        }
        
        .tab-btn:hover {
            background: #e9ecef;
            color: #495057;
        }
        
        .tab-btn.active {
            background: white;
            color: #007bff;
            border-bottom-color: #007bff;
        }
        
        .tab-btn i {
            font-size: 16px;
        }
        
        .tab-content {
            display: none;
            padding: 20px;
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* 卡片样式已在admin-modern.css中定义 */
        
        /* 表单样式已在admin-modern.css中定义 */
        
        /* 网格布局、复选框、按钮、提醒样式已在admin-modern.css中定义 */
        
        /* 移动端导航栏样式 */
        .mobile-sidebar-toggle {
            display: none !important;
            background: none !important;
            border: none !important;
            color: #495057 !important;
            font-size: 18px !important;
            padding: 8px !important;
            border-radius: 6px !important;
            cursor: pointer !important;
            transition: all 0.3s ease !important;
            margin-right: 10px !important;
        }
        
        .mobile-sidebar-toggle:hover {
            background: #f8f9fa !important;
            color: #007bff !important;
        }
        
        .mobile-sidebar-toggle:active {
            background: #e9ecef !important;
        }
        
        /* 响应式设计 */
        @media (max-width: 768px) {
            .mobile-sidebar-toggle {
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
            }
            
            /* 移动端侧边栏样式已在admin-modern.css中定义 */
        }
        
        /* 顶部导航栏样式已在admin-modern.css中定义 */
        
        /* 侧边栏样式已使用admin-modern.css，此处删除重复定义 */
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/backup.php" data-title="备份恢复">
                            <i class="fas fa-database"></i>
                            <span>备份恢复</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay"></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
            <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <i class="fas fa-cog"></i>
                    <span>系统设置</span>
                </div>
                <div class="header-actions">
                    <button type="submit" form="settingsForm" class="btn btn-primary btn-sm">
                        <i class="fas fa-save"></i>
                        保存设置
                    </button>
                </div>
            </header>

            <!-- 主体内容 -->
            <div class="admin-main">
                <?php
require_once 'auth.php';

// 检查权�?
checkPermission('editor');
 if ($message): ?>
                    <div class="alert alert-<?= $messageType ?>">
                        <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php
require_once 'auth.php';

// 检查权�?
checkPermission('editor');
 endif; ?>

                <form method="POST" id="settingsForm" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="save">
                    
                    <!-- 设置标签页 -->
                    <div class="settings-tabs">
                        <div class="tab-nav">
                            <button type="button" class="tab-btn active" data-tab="general">
                                <i class="fas fa-cog"></i>
                                基本设置
                            </button>
                            <button type="button" class="tab-btn" data-tab="display">
                                <i class="fas fa-desktop"></i>
                                显示设置
                            </button>
                            <button type="button" class="tab-btn" data-tab="email">
                                <i class="fas fa-envelope"></i>
                                邮件设置
                            </button>
                            <button type="button" class="tab-btn" data-tab="advanced">
                                <i class="fas fa-tools"></i>
                                高级设置
                            </button>
                        </div>
                        
                        <!-- 基本设置 -->
                        <div class="tab-content active" id="general">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-info-circle"></i>
                                        网站信息
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="grid grid-cols-2">
                                        <div class="form-group">
                                            <label class="form-label">网站名称</label>
                                            <input type="text" name="site_name" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['site_name']) ?>" 
                                                   placeholder="LinkHub">
                                            <small class="text-muted">显示在浏览器标题栏和页面头部</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">网站副标题</label>
                                            <input type="text" name="site_subtitle" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['site_subtitle']) ?>" 
                                                   placeholder="专业的书签管理和导航系统">
                                            <small class="text-muted">网站的简短描述</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">网站关键词</label>
                                            <input type="text" name="site_keywords" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['site_keywords']) ?>" 
                                                   placeholder="LinkHub,书签,导航,网址导航">
                                            <small class="text-muted">SEO关键词，用逗号分隔</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">管理员邮箱</label>
                                            <input type="email" name="admin_email" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['admin_email']) ?>" 
                                                   placeholder="admin@example.com">
                                            <small class="text-muted">用于接收系统通知</small>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label">网站描述</label>
                                        <textarea name="site_description" class="form-control" rows="3" 
                                                  placeholder="LinkHub - 专业的书签管理和导航系统"><?= htmlspecialchars($settings['site_description']) ?></textarea>
                                        <small class="text-muted">网站的详细描述，用于SEO</small>
                                    </div>
                                    
                                                        <!-- Logo和图标设置 -->
                    <div class="grid grid-cols-2">
                        <div class="form-group">
                            <label class="form-label">网站Logo</label>
                            <div class="upload-preview">
                                <?php if (!empty($settings['site_logo'])): ?>
                                    <div class="current-logo">
                                        <img src="<?= htmlspecialchars($settings['site_logo']) ?>" alt="当前Logo" style="max-height: 60px; max-width: 200px;">
                                        <button type="button" class="btn btn-danger btn-sm remove-logo" data-type="logo">删除</button>
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="logo_upload" class="file-upload" accept="image/*" id="logoUpload">
                                <input type="hidden" name="site_logo" value="<?= htmlspecialchars($settings['site_logo']) ?>" id="logoPath">
                                <label for="logoUpload" class="upload-btn">
                                    <i class="fas fa-upload"></i>
                                    <?= empty($settings['site_logo']) ? '上传Logo' : '更换Logo' ?>
                                </label>
                            </div>
                            <small class="text-muted">推荐尺寸：200x60px，支持PNG、JPG、SVG格式</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">网站图标(Favicon)</label>
                            <div class="upload-preview">
                                <?php if (!empty($settings['site_favicon'])): ?>
                                    <div class="current-favicon">
                                        <img src="<?= htmlspecialchars($settings['site_favicon']) ?>" alt="当前图标" style="width: 32px; height: 32px;">
                                        <button type="button" class="btn btn-danger btn-sm remove-logo" data-type="favicon">删除</button>
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="favicon_upload" class="file-upload" accept="image/png,image/x-icon,image/vnd.microsoft.icon" id="faviconUpload">
                                <input type="hidden" name="site_favicon" value="<?= htmlspecialchars($settings['site_favicon']) ?>" id="faviconPath">
                                <label for="faviconUpload" class="upload-btn">
                                    <i class="fas fa-upload"></i>
                                    <?= empty($settings['site_favicon']) ? '上传图标' : '更换图标' ?>
                                </label>
                            </div>
                            <small class="text-muted">推荐尺寸：32x32px或16x16px，支持ICO、PNG格式</small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">备案号</label>
                        <input type="text" name="site_icp" class="form-control" 
                               value="<?= htmlspecialchars($settings['site_icp']) ?>" 
                               placeholder="京ICP备xxxxxxxx号">
                        <small class="text-muted">网站备案号，显示在页面底部</small>
                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 显示设置 -->
                        <div class="tab-content" id="display">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-eye"></i>
                                        显示选项
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="grid grid-cols-2">
                                        <div class="form-group">
                                            <label class="form-label">每页链接数</label>
                                            <input type="number" name="links_per_page" class="form-control" min="5" max="100"
                                                   value="<?= htmlspecialchars($settings['links_per_page']) ?>" 
                                                   placeholder="20">
                                            <small class="text-muted">前台每页显示的链接数量</small>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="checkbox-label">
                                            <input type="checkbox" name="enable_public_links" value="1" 
                                                   <?= $settings['enable_public_links'] == '1' ? 'checked' : '' ?>>
                                            <span class="checkmark"></span>
                                            显示公开链接
                                        </label>
                                        <small class="text-muted">是否在前台显示公开的链接</small>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="checkbox-label">
                                            <input type="checkbox" name="enable_register" value="1" 
                                                   <?= $settings['enable_register'] == '1' ? 'checked' : '' ?>>
                                            <span class="checkmark"></span>
                                            开启用户注册
                                        </label>
                                        <small class="text-muted">允许新用户注册账户</small>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="checkbox-label">
                                            <input type="checkbox" name="enable_click_stats" value="1" 
                                                   <?= $settings['enable_click_stats'] == '1' ? 'checked' : '' ?>>
                                            <span class="checkmark"></span>
                                            启用点击统计
                                        </label>
                                        <small class="text-muted">记录链接点击次数和统计信息</small>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="checkbox-label">
                                            <input type="checkbox" name="enable_seo_friendly" value="1" 
                                                   <?= $settings['enable_seo_friendly'] == '1' ? 'checked' : '' ?>>
                                            <span class="checkmark"></span>
                                            SEO友好URL
                                        </label>
                                        <small class="text-muted">启用搜索引擎友好的URL格式</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 过渡页设置 -->
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-clock"></i>
                                        过渡页配置
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="checkbox-label">
                                            <input type="checkbox" name="enable_transition_page" value="1" 
                                                   <?= ($settings['enable_transition_page'] ?? '0') == '1' ? 'checked' : '' ?>
                                                   id="enableTransitionPage">
                                            <span class="checkmark"></span>
                                            启用过渡页
                                        </label>
                                        <small class="text-muted">用户访问外部链接时显示过渡页面</small>
                                    </div>
                                    
                                    <div class="transition-settings" style="<?= ($settings['enable_transition_page'] ?? '0') == '1' ? '' : 'display: none;' ?>">
                                        <div class="grid grid-cols-2">
                                            <div class="form-group">
                                                <label class="form-label">过渡时间（秒）</label>
                                                <input type="number" name="transition_time" class="form-control" min="1" max="30"
                                                       value="<?= htmlspecialchars($settings['transition_time'] ?? '3') ?>" 
                                                       placeholder="3">
                                                <small class="text-muted">过渡页显示的时间长度</small>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label class="form-label">页面主题色</label>
                                                <input type="color" name="transition_theme_color" class="form-control" 
                                                       value="<?= htmlspecialchars($settings['transition_theme_color'] ?? '#6366f1') ?>">
                                                <small class="text-muted">过渡页的主题颜色</small>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">过渡页标题</label>
                                            <input type="text" name="transition_title" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['transition_title'] ?? '正在跳转中...') ?>" 
                                                   placeholder="正在跳转中...">
                                            <small class="text-muted">过渡页面显示的主标题</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">提示文字</label>
                                            <textarea name="transition_message" class="form-control" rows="3" 
                                                      placeholder="即将为您跳转到目标网站，请稍候..."><?= htmlspecialchars($settings['transition_message'] ?? '即将为您跳转到目标网站，请稍候...') ?></textarea>
                                            <small class="text-muted">过渡页面显示的提示信息</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">广告代码</label>
                                            <textarea name="transition_ad_code" class="form-control" rows="6" 
                                                      placeholder="在此输入广告HTML代码或JavaScript代码"><?= htmlspecialchars($settings['transition_ad_code'] ?? '') ?></textarea>
                                            <small class="text-muted">在过渡页面显示的广告内容（HTML/JS代码）</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="checkbox-label">
                                                <input type="checkbox" name="transition_show_progress" value="1" 
                                                       <?= ($settings['transition_show_progress'] ?? '1') == '1' ? 'checked' : '' ?>>
                                                <span class="checkmark"></span>
                                                显示进度条
                                            </label>
                                            <small class="text-muted">在过渡页面显示倒计时进度条</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="checkbox-label">
                                                <input type="checkbox" name="transition_allow_skip" value="1" 
                                                       <?= ($settings['transition_allow_skip'] ?? '1') == '1' ? 'checked' : '' ?>>
                                                <span class="checkmark"></span>
                                                允许跳过
                                            </label>
                                            <small class="text-muted">允许用户点击按钮立即跳转</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 页脚设置 -->
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-code"></i>
                                        自定义代码
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="form-label">自定义头部代码</label>
                                        <textarea name="custom_header" class="form-control" rows="6" 
                                                  placeholder="自定义HTML/CSS/JavaScript代码，将插入到页面头部"><?= htmlspecialchars($settings['custom_header']) ?></textarea>
                                        <small class="text-muted">可以插入CSS样式、JavaScript脚本等，将插入到页面 &lt;head&gt; 标签内</small>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label">自定义页脚代码</label>
                                        <textarea name="custom_footer" class="form-control" rows="4" 
                                                  placeholder="自定义页脚HTML代码"><?= htmlspecialchars($settings['custom_footer']) ?></textarea>
                                        <small class="text-muted">页脚HTML代码，支持链接、版权信息等，应用到所有主题</small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-chart-line"></i>
                                        统计代码
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="form-label">统计代码</label>
                                        <textarea name="site_statistics" class="form-control" rows="6" 
                                                  placeholder="Google Analytics、百度统计等JavaScript代码"><?= htmlspecialchars($settings['site_statistics']) ?></textarea>
                                        <small class="text-muted">第三方统计代码，将插入到页面头部</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 邮件设置 -->
                        <div class="tab-content" id="email">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-envelope"></i>
                                        SMTP邮件配置
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="grid grid-cols-2">
                                        <div class="form-group">
                                            <label class="form-label">SMTP服务器</label>
                                            <input type="text" name="smtp_host" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['smtp_host']) ?>" 
                                                   placeholder="smtp.gmail.com">
                                            <small class="text-muted">邮件服务器地址</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">SMTP端口</label>
                                            <input type="number" name="smtp_port" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['smtp_port']) ?>" 
                                                   placeholder="587">
                                            <small class="text-muted">通常为25、65、87</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">用户名</label>
                                            <input type="text" name="smtp_username" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['smtp_username']) ?>" 
                                                   placeholder="username@example.com">
                                            <small class="text-muted">SMTP认证用户名</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">密码</label>
                                            <input type="password" name="smtp_password" class="form-control" 
                                                   value="<?= htmlspecialchars($settings['smtp_password']) ?>" 
                                                   placeholder="••••••••">
                                            <small class="text-muted">SMTP认证密码</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">加密方式</label>
                                            <select name="smtp_encryption" class="form-control form-select">
                                                <option value="none" <?= $settings['smtp_encryption'] === 'none' ? 'selected' : '' ?>>无加密</option>
                                                <option value="tls" <?= $settings['smtp_encryption'] === 'tls' ? 'selected' : '' ?>>TLS</option>
                                                <option value="ssl" <?= $settings['smtp_encryption'] === 'ssl' ? 'selected' : '' ?>>SSL</option>
                                            </select>
                                            <small class="text-muted">推荐使用TLS加密</small>
                                        </div>
                                    </div>
                                    
                                    <div style="margin-top: 1rem;">
                                        <button type="button" class="btn btn-secondary" onclick="testEmail()">
                                            <i class="fas fa-paper-plane"></i>
                                            发送测试邮件
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 高级设置 -->
                        <div class="tab-content" id="advanced">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-database"></i>
                                        缓存设置
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="grid grid-cols-2">
                                        <div class="form-group">
                                            <label class="checkbox-label">
                                                <input type="checkbox" name="cache_enabled" value="1" 
                                                       <?= $settings['cache_enabled'] == '1' ? 'checked' : '' ?>>
                                                <span class="checkmark"></span>
                                                启用缓存
                                            </label>
                                            <small class="text-muted">开启缓存可以提高页面加载速度</small>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label class="form-label">缓存时间（秒）</label>
                                            <input type="number" name="cache_time" class="form-control" min="60" max="86400"
                                                   value="<?= htmlspecialchars($settings['cache_time']) ?>" 
                                                   placeholder="3600">
                                            <small class="text-muted">缓存有效期，单位为秒</small>
                                        </div>
                                    </div>
                                    
                                    <div style="margin-top: 1rem;">
                                        <button type="button" class="btn btn-warning" onclick="clearCache()">
                                            <i class="fas fa-trash"></i>
                                            清除缓存
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-shield-alt"></i>
                                        安全设置
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle"></i>
                                        安全设置功能正在开发中，敬请期待！
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 底部操作按钮 -->
                    <div style="margin-top: 2rem; text-align: center;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            保存所有设置
                        </button>
                        <button type="reset" class="btn btn-secondary" onclick="resetSettings()">
                            <i class="fas fa-undo"></i>
                            重置设置
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script src="../assets/js/admin.js?v=2.0.1"></script>
    <script src="../assets/js/sidebar-fix.js?v=1.0.0"></script>
    <script>
        // 侧边栏控制由 sidebar-fix.js 处理
        document.addEventListener('DOMContentLoaded', function() {
            
            // 标签页功能
            setupTabs();
            
            // 过渡页设置切换
            setupTransitionPageToggle();
            
            // 文件上传功能
            setupFileUpload();
            
            // 移动端侧边栏切换
            setupMobileSidebar();
        });

        // 设置标签页功能
        function setupTabs() {
            const tabBtns = document.querySelectorAll('.tab-btn');
            const tabContents = document.querySelectorAll('.tab-content');
            
            tabBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const tabId = this.dataset.tab;
                    
                    // 移除所有活动状态
                    tabBtns.forEach(b => b.classList.remove('active'));
                    tabContents.forEach(c => c.classList.remove('active'));
                    
                    // 激活当前标签
                    this.classList.add('active');
                    document.getElementById(tabId).classList.add('active');
                });
            });
        }

        // 过渡页设置切换
        function setupTransitionPageToggle() {
            const enableTransitionPage = document.getElementById('enableTransitionPage');
            const transitionSettings = document.querySelector('.transition-settings');
            
            if (enableTransitionPage && transitionSettings) {
                enableTransitionPage.addEventListener('change', function() {
                    if (this.checked) {
                        transitionSettings.style.display = 'block';
                        // 添加淡入动画
                        transitionSettings.style.opacity = '0';
                        setTimeout(() => {
                            transitionSettings.style.opacity = '1';
                            transitionSettings.style.transition = 'opacity 0.3s ease';
                        }, 10);
                    } else {
                        transitionSettings.style.opacity = '0';
                        transitionSettings.style.transition = 'opacity 0.3s ease';
                        setTimeout(() => {
                            transitionSettings.style.display = 'none';
                        }, 300);
                    }
                });
            }
        }

        // 测试邮件
        function testEmail() {
            const adminEmail = document.querySelector('input[name="admin_email"]').value;
            if (!adminEmail) {
                alert('请先设置管理员邮箱');
                return;
            }
            
            // 这里可以发送AJAX请求测试邮件配置
            alert('测试邮件功能正在开发中');
        }

        // 清除缓存
        function clearCache() {
            if (confirm('确定要清除所有缓存吗？')) {
                // 这里可以发送AJAX请求清除缓存
                alert('缓存清除功能正在开发中');
            }
        }

        // 重置设置
        function resetSettings() {
            if (confirm('确定要重置所有设置吗？此操作无法撤销！')) {
                document.getElementById('settingsForm').reset();
            }
        }
        
        // 文件上传功能
        function setupFileUpload() {
            console.log('正在初始化文件上传功能...');
            
            // Logo上传预览
            const logoUpload = document.getElementById('logoUpload');
            const logoBtn = document.querySelector('label[for="logoUpload"]');
            console.log('Logo元素:', logoUpload, logoBtn);
            
            if (logoUpload) {
                logoUpload.addEventListener('change', function(e) {
                    console.log('Logo文件选择变化:', e.target.files);
                    previewImage(e.target, 'logo');
                });
                
                // 确保label点击能触发文件选择
                if (logoBtn) {
                    logoBtn.addEventListener('click', function(e) {
                        console.log('Logo按钮被点击');
                        e.preventDefault();
                        logoUpload.click();
                    });
                }
            }
            
            // Favicon上传预览
            const faviconUpload = document.getElementById('faviconUpload');
            const faviconBtn = document.querySelector('label[for="faviconUpload"]');
            console.log('Favicon元素:', faviconUpload, faviconBtn);
            
            if (faviconUpload) {
                faviconUpload.addEventListener('change', function(e) {
                    console.log('Favicon文件选择变化:', e.target.files);
                    previewImage(e.target, 'favicon');
                });
                
                // 确保label点击能触发文件选择
                if (faviconBtn) {
                    faviconBtn.addEventListener('click', function(e) {
                        console.log('Favicon按钮被点击');
                        e.preventDefault();
                        faviconUpload.click();
                    });
                }
            }
            
            // 删除按钮功能
            document.querySelectorAll('.remove-logo').forEach(btn => {
                btn.addEventListener('click', function() {
                    const type = this.getAttribute('data-type');
                    removeUploadedFile(type);
                });
            });
        }
        
        // 图片预览功能
        function previewImage(input, type) {
            console.log('开始预览图片:', type, input.files);
            
            if (input.files && input.files[0]) {
                const file = input.files[0];
                console.log('选择的文件:', file.name, file.type, file.size);
                
                // 检查文件类型
                const allowedTypes = type === 'logo' 
                    ? ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml']
                    : ['image/x-icon', 'image/vnd.microsoft.icon', 'image/png'];
                
                if (!allowedTypes.includes(file.type) && !(type === 'favicon' && file.name.endsWith('.ico'))) {
                    alert('文件格式不支持！请选择正确的图片格式。');
                    input.value = '';
                    return;
                }
                
                // 检查文件大小 (5MB限制)
                if (file.size > 5 * 1024 * 1024) {
                    alert('文件大小不能超过5MB！');
                    input.value = '';
                    return;
                }
                
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    console.log('文件读取完成');
                    const previewContainer = input.parentElement;
                    let currentDiv = previewContainer.querySelector('.current-' + type);
                    
                    if (!currentDiv) {
                        currentDiv = document.createElement('div');
                        currentDiv.className = 'current-' + type;
                        currentDiv.style.cssText = 'margin-bottom: 15px; padding: 10px; background: white; border-radius: 6px; border: 1px solid #e9ecef; display: flex; align-items: center; gap: 10px;';
                        previewContainer.insertBefore(currentDiv, input);
                    }
                    
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.alt = '预览';
                    img.style.cssText = type === 'favicon' ? 'width: 32px; height: 32px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'max-height: 60px; max-width: 200px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);';
                    
                    const removeBtn = document.createElement('button');
                    removeBtn.type = 'button';
                    removeBtn.className = 'btn btn-danger btn-sm remove-logo';
                    removeBtn.setAttribute('data-type', type);
                    removeBtn.innerHTML = '删除';
                    removeBtn.style.cssText = 'padding: 4px 8px !important; font-size: 12px !important; border-radius: 4px !important;';
                    removeBtn.onclick = function() { removeUploadedFile(type); };
                    
                    currentDiv.innerHTML = '';
                    currentDiv.appendChild(img);
                    currentDiv.appendChild(removeBtn);
                    
                    // 更新上传按钮文字
                    const uploadBtn = previewContainer.querySelector('.upload-btn');
                    if (uploadBtn) {
                        uploadBtn.innerHTML = `<i class="fas fa-upload"></i> 更换${type === 'logo' ? 'Logo' : '图标'}`;
                    }
                    
                    console.log('预览显示完成');
                };
                
                reader.onerror = function() {
                    console.error('文件读取失败');
                    alert('文件读取失败，请重试！');
                };
                
                reader.readAsDataURL(file);
            } else {
                console.log('没有选择文件');
            }
        }
        
        // 删除已上传文件
        function removeUploadedFile(type) {
            if (confirm('确定要删除这个' + (type === 'logo' ? 'Logo' : '图标') + '吗？')) {
                const container = document.querySelector('.current-' + type);
                if (container) {
                    container.remove();
                }
                
                // 清空对应的hidden input
                const hiddenInput = document.getElementById(type === 'logo' ? 'logoPath' : 'faviconPath');
                if (hiddenInput) {
                    hiddenInput.value = '';
                }
                
                // 重置文件输入
                const fileInput = document.getElementById(type === 'logo' ? 'logoUpload' : 'faviconUpload');
                if (fileInput) {
                    fileInput.value = '';
                }
                
                // 更新上传按钮文字
                const uploadBtn = fileInput.parentElement.querySelector('.upload-btn');
                uploadBtn.innerHTML = `<i class="fas fa-upload"></i> 上传${type === 'logo' ? 'Logo' : '图标'}`;
            }
        }
        
        // 移动端侧边栏切换功能
        function setupMobileSidebar() {
            const toggleBtn = document.getElementById('mobileSidebarToggle');
            const sidebar = document.querySelector('.admin-sidebar');
            
            if (toggleBtn && sidebar) {
                toggleBtn.addEventListener('click', function() {
                    console.log('移动端侧边栏切换');
                    sidebar.classList.toggle('active');
                });
                
                // 点击页面其他地方关闭侧边栏
                document.addEventListener('click', function(e) {
                    if (window.innerWidth <= 768) {
                        if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
                            sidebar.classList.remove('active');
                        }
                    }
                });
                
                // 窗口大小改变时处理
                window.addEventListener('resize', function() {
                    if (window.innerWidth > 768) {
                        sidebar.classList.remove('active');
                    }
                });
            }
        }
    </script>
</body>
</html>
