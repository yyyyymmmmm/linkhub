<?php
require_once 'auth.php';
checkPermission('editor');

$message = '';
$messageType = '';

// 处理导入操作
if ($_POST && isset($_POST['action'])) {
    try {
        if ($_POST['action'] === 'import_bookmarks' && isset($_FILES['bookmark_file'])) {
            $file = $_FILES['bookmark_file'];
            if ($file['error'] === UPLOAD_ERR_OK) {
                $content = file_get_contents($file['tmp_name']);
                
                // 解析HTML书签文件
                $bookmarks = parseBookmarksFile($content);
                
                // 调试信息
                $totalParsed = count($bookmarks);
                if ($totalParsed === 0) {
                    throw new Exception("未能解析到任何书签。请检查书签文件格式是否正确。");
                }
                
                $importCount = 0;
                $skipCount = 0;
                $categoryMap = [];
                $newCategoryCount = 0;
                
                // 获取导入模式
                $importMode = $_POST['import_mode'] ?? 'smart';
                $targetCategoryId = intval($_POST['target_category'] ?? 0);
                $skipDuplicates = isset($_POST['skip_duplicates']);
                
                foreach ($bookmarks as $bookmark) {
                    $url = trim($bookmark['url']);
                    $title = trim($bookmark['title']);
                    $folder = $bookmark['folder'];
                    
                    if (!empty($url) && !empty($title)) {
                        // 检查是否已存在
                        if ($skipDuplicates) {
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM " . $tablePrefix . "links WHERE url = ?");
                        $stmt->execute([$url]);
                            
                            if ($stmt->fetchColumn() > 0) {
                                $skipCount++;
                                continue;
                            }
                        }
                        
                        // 确定分类ID
                        if ($importMode === 'smart') {
                            // 智能分类模式：根据文件夹创建分类
                            $categoryId = getOrCreateCategory($pdo, $folder, $categoryMap, $newCategoryCount);
                        } else {
                            // 统一分类模式：使用指定分类
                            $categoryId = $targetCategoryId > 0 ? $targetCategoryId : 1; // 默认第一个分类
                        }
                        
                        // 智能获取网站信息
                        $siteInfo = getSmartSiteInfo($url, $title);
                        
                        // 插入书签
                        $stmt = $pdo->prepare("INSERT INTO " . $tablePrefix . "links (fid, title, url, note, font_icon, property, weight, add_time, up_time) VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?)");
                        $currentTime = time();
                        $stmt->execute([
                            $categoryId, 
                            $siteInfo['title'], 
                            $url, 
                            $siteInfo['description'], 
                            $siteInfo['icon'], 
                            $currentTime, 
                            $currentTime
                        ]);
                        $importCount++;
                    }
                }
                
                $message = "导入完成！共解析 $totalParsed 个书签，成功导入 $importCount 个";
                if ($skipCount > 0) $message .= "，跳过 $skipCount 个重复项";
                if ($importMode === 'smart' && $newCategoryCount > 0) $message .= "，新建 $newCategoryCount 个分类";
                $message .= "！";
                $messageType = 'success';
            } else {
                throw new Exception('文件上传失败');
            }
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}

// 获取分类列表
$categories = $pdo->query("SELECT * FROM " . $tablePrefix . "categorys ORDER BY weight DESC, name ASC")->fetchAll(PDO::FETCH_ASSOC);

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>导入书签 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle"id="sidebarToggle"  id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/backup.php" data-title="备份恢复">
                            <i class="fas fa-database"></i>
                            <span>备份恢复</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay" ></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
        <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <i class="fas fa-upload"></i>
                    <span>导入书签</span>
                </div>
                <div class="header-actions">
                    <span class="text-sm text-gray-600">欢迎，<?= htmlspecialchars($currentUser['username']) ?></span>
                    <a href="/admin/links.php" class="btn btn-secondary btn-sm">
                        <i class="fas fa-list"></i>
                        查看链接
                    </a>
            </div>
        </header>

            <!-- 主体内容 -->
            <div class="admin-main">
        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>">
                        <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

                <!-- 导入向导 -->
        <div class="card">
            <div class="card-header">
                        <h3>
                            <i class="fas fa-file-import"></i>
                            导入HTML书签文件
                </h3>
            </div>
            <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>支持的浏览器导出格式：</strong>
                            <ul style="margin: 0.5rem 0 0 1.5rem;">
                                <li><strong>Chrome：</strong>设置 → 书签 → 书签管理器 → 导出书签</li>
                                <li><strong>Firefox：</strong>书签 → 管理书签 → 导入和备份 → 导出书签为HTML</li>
                                <li><strong>Safari：</strong>文件 → 导出书签</li>
                                <li><strong>Edge：</strong>设置 → 导入或导出 → 导出到文件</li>
                            </ul>
                        </div>
                
                <form method="POST" enctype="multipart/form-data" class="import-form">
                    <input type="hidden" name="action" value="import_bookmarks">
                    
                            <div class="form-group">
                                <label class="form-label">选择HTML书签文件</label>
                    <div class="file-upload-area">
                                    <input type="file" name="bookmark_file" id="bookmarkFile" 
                                           accept=".html,.htm" required class="file-input">
                                    <label for="bookmarkFile" class="file-upload-label">
                                        <div class="file-upload-content">
                            <i class="fas fa-cloud-upload-alt"></i>
                                            <div class="file-upload-text">
                                                <span class="file-upload-title">点击选择文件或拖拽到此处</span>
                                                <span class="file-upload-subtitle">支持 .html 和 .htm 格式</span>
                                            </div>
                                        </div>
                                    </label>
                                    <div class="file-upload-info" style="display: none;">
                                        <i class="fas fa-file-alt"></i>
                                        <span class="file-name"></span>
                                        <span class="file-size"></span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">导入模式</label>
                                <div class="import-mode-options">
                                    <label class="radio-option">
                                        <input type="radio" name="import_mode" value="smart" checked>
                                        <span class="radio-mark"></span>
                                        <div class="radio-content">
                                            <strong>智能分类导入</strong>
                                            <small>根据书签文件夹自动创建分类</small>
                                        </div>
                                    </label>
                                    <label class="radio-option">
                                        <input type="radio" name="import_mode" value="single">
                                        <span class="radio-mark"></span>
                                        <div class="radio-content">
                                            <strong>统一分类导入</strong>
                                            <small>所有书签导入到指定分类</small>
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <div class="form-group target-category-group" style="display: none;">
                                <label class="form-label">导入到分类</label>
                                <select name="target_category" class="form-control form-select">
                                    <option value="0">未分类</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?= $category['id'] ?>">
                                            <?= htmlspecialchars($category['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="text-muted">选择要导入书签的目标分类</small>
                            </div>

                            <div class="form-group">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="skip_duplicates" value="1" checked>
                                    <span class="checkmark"></span>
                                    跳过重复的链接
                                </label>
                                <small class="text-muted">如果链接已存在，将跳过不导入</small>
                            </div>

                            <!-- 导入进度 -->
                            <div class="import-progress" style="display: none;">
                                <div class="progress-header">
                                    <span class="progress-title">正在导入书签...</span>
                                    <span class="progress-count">0 / 0</span>
                                </div>
                                <div class="progress-bar">
                                    <div class="progress-fill"></div>
                                </div>
                                <div class="progress-details">
                                    <div class="progress-item">
                                        <i class="fas fa-check-circle text-success"></i>
                                        <span class="success-count">0</span> 成功导入
                                    </div>
                                    <div class="progress-item">
                                        <i class="fas fa-exclamation-circle text-warning"></i>
                                        <span class="skip-count">0</span> 跳过重复
                                    </div>
                                    <div class="progress-item">
                                        <i class="fas fa-folder-plus text-info"></i>
                                        <span class="category-count">0</span> 新建分类
                        </div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                                <button type="submit" class="btn btn-primary" id="importBtn">
                                    <i class="fas fa-upload"></i>
                                    开始导入
                        </button>
                                <a href="/admin/links.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i>
                                    取消
                                </a>
                    </div>
                </form>
            </div>
        </div>

                <!-- 智能导入功能说明 -->
                <div class="card">
            <div class="card-header">
                        <h3>
                            <i class="fas fa-magic"></i>
                            智能导入功能
                </h3>
            </div>
            <div class="card-body">
                        <div class="grid grid-cols-3">
                            <div class="feature-highlight">
                                <div class="feature-icon">
                                    <i class="fas fa-folder-plus"></i>
                                </div>
                                <h4>自动分类创建</h4>
                                <p>根据书签文件夹自动创建对应分类，并智能分配图标和颜色</p>
                            </div>
                            <div class="feature-highlight">
                                <div class="feature-icon">
                                    <i class="fas fa-palette"></i>
                                </div>
                                <h4>智能图标识别</h4>
                                <p>自动识别网站类型，为每个书签推荐合适的图标和品牌色彩</p>
                            </div>
                            <div class="feature-highlight">
                                <div class="feature-icon">
                                    <i class="fas fa-edit"></i>
                                </div>
                                <h4>标题优化</h4>
                                <p>自动清理和优化书签标题，移除浏览器后缀和无用信息</p>
                            </div>
                        </div>
                        <div class="smart-import-stats">
                            <div class="stat-item">
                                <span class="stat-number">40+</span>
                                <span class="stat-label">知名网站识别</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number">200+</span>
                                <span class="stat-label">智能图标库</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number">15+</span>
                                <span class="stat-label">分类模板</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 导入说明 -->
                <div class="card">
                    <div class="card-header">
                        <h3>
                            <i class="fas fa-question-circle"></i>
                            如何导出浏览器书签？
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="grid grid-cols-2">
                            <div class="browser-guide">
                                <h4>
                                    <i class="fab fa-chrome"></i>
                                    Chrome浏览器
                                </h4>
                                <ol>
                                    <li>点击右上角的三个点菜单</li>
                                    <li>选择"书签" → "书签管理器"</li>
                                    <li>点击右上角的三个点</li>
                                    <li>选择"导出书签"</li>
                                    <li>保存HTML文件</li>
                                </ol>
                            </div>

                            <div class="browser-guide">
                                <h4>
                            <i class="fab fa-firefox"></i>
                                    Firefox浏览器
                                </h4>
                                <ol>
                                    <li>点击菜单按钮（三条横线）</li>
                                    <li>选择"书签" → "管理书签"</li>
                                    <li>点击"导入和备份"</li>
                                    <li>选择"导出书签为HTML"</li>
                                    <li>保存HTML文件</li>
                                </ol>
                            </div>

                            <div class="browser-guide">
                                <h4>
                                    <i class="fab fa-safari"></i>
                                    Safari浏览器
                                </h4>
                                <ol>
                                    <li>打开Safari浏览器</li>
                                    <li>点击顶部菜单"文件"</li>
                                    <li>选择"导出书签"</li>
                                    <li>选择保存位置</li>
                                    <li>点击"保存"</li>
                                </ol>
                            </div>

                            <div class="browser-guide">
                                <h4>
                                    <i class="fab fa-edge"></i>
                                    Edge浏览器
                                </h4>
                                <ol>
                                    <li>点击右上角的三个点菜单</li>
                                    <li>选择"收藏夹" → "管理收藏夹"</li>
                                    <li>点击"导入或导出"</li>
                                    <li>选择"导出到文件"</li>
                                    <li>保存HTML文件</li>
                                </ol>
                        </div>
                        </div>
                    </div>
                        </div>

                <!-- 导入统计 -->
                <?php if (!empty($categories)): ?>
                <div class="card">
                    <div class="card-header">
                        <h3>
                            <i class="fas fa-chart-bar"></i>
                            当前数据统计
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="stats-grid">
                            <?php
                            $totalLinks = $pdo->query("SELECT COUNT(*) FROM " . $tablePrefix . "links")->fetchColumn();
                            $totalCategories = $pdo->query("SELECT COUNT(*) FROM " . $tablePrefix . "categorys")->fetchColumn();
                            ?>
                            <div class="stat-card">
                                <div class="stat-icon" style="background: var(--gradient-primary);">
                                    <i class="fas fa-link"></i>
                                </div>
                                <div>
                                    <div class="stat-number"><?= number_format($totalLinks) ?></div>
                                    <div class="stat-label">总链接数</div>
                                </div>
                            </div>
                            
                            <div class="stat-card">
                                <div class="stat-icon" style="background: var(--gradient-success);">
                                    <i class="fas fa-folder"></i>
                                </div>
                                <div>
                                    <div class="stat-number"><?= number_format($totalCategories) ?></div>
                                    <div class="stat-label">分类数量</div>
                                </div>
                        </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
        </div>

    <script src="../assets/js/admin.js?v=2.0.1"></script>
    <script src="../assets/js/sidebar-fix.js?v=1.0.0"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const fileInput = document.getElementById('bookmarkFile');
            const fileLabel = document.querySelector('.file-upload-label');
            const fileInfo = document.querySelector('.file-upload-info');
            const form = document.querySelector('.import-form');
            const importBtn = document.getElementById('importBtn');
            const progressDiv = document.querySelector('.import-progress');
            const importModeRadios = document.querySelectorAll('input[name="import_mode"]');
            const targetCategoryGroup = document.querySelector('.target-category-group');

            // 导入模式切换处理
            importModeRadios.forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.value === 'smart') {
                        targetCategoryGroup.style.display = 'none';
                    } else {
                        targetCategoryGroup.style.display = 'block';
                    }
                });
            });

            // 文件选择处理
            fileInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    showFileInfo(file);
                }
            });

            // 拖拽上传
            fileLabel.addEventListener('dragover', function(e) {
                e.preventDefault();
                e.stopPropagation();
                this.classList.add('drag-over');
            });

            fileLabel.addEventListener('dragleave', function(e) {
                e.preventDefault();
                e.stopPropagation();
                this.classList.remove('drag-over');
            });

            fileLabel.addEventListener('drop', function(e) {
                e.preventDefault();
                e.stopPropagation();
                this.classList.remove('drag-over');
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    const file = files[0];
                    if (file.type === 'text/html' || file.name.endsWith('.html') || file.name.endsWith('.htm')) {
                        fileInput.files = files;
                        showFileInfo(file);
                    } else {
                        showAlert('请选择HTML格式的书签文件', 'error');
                    }
                }
            });

            // 表单提交处理
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (!fileInput.files.length) {
                    showAlert('请先选择书签文件', 'error');
                    return;
                }

                // 显示进度条
                showProgress();
                
                // 模拟进度更新（实际应该通过AJAX实现）
                simulateProgress();
                
                // 延迟提交表单（给用户看到进度）
                setTimeout(() => {
                    form.submit();
                }, 1000);
            });

            function showFileInfo(file) {
                const fileName = file.name;
                const fileSize = formatFileSize(file.size);
                
                fileLabel.style.display = 'none';
                fileInfo.style.display = 'flex';
                fileInfo.querySelector('.file-name').textContent = fileName;
                fileInfo.querySelector('.file-size').textContent = fileSize;
            }

            function formatFileSize(bytes) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            }

            function showProgress() {
                progressDiv.style.display = 'block';
                importBtn.disabled = true;
                importBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 正在导入...';
            }

            function simulateProgress() {
                const progressFill = document.querySelector('.progress-fill');
                const progressCount = document.querySelector('.progress-count');
                let progress = 0;
                
                const interval = setInterval(() => {
                    progress += Math.random() * 15;
                    if (progress > 95) {
                        progress = 95;
                        clearInterval(interval);
                    }
                    
                    progressFill.style.width = progress + '%';
                    progressCount.textContent = Math.floor(progress) + '%';
                }, 100);
            }

            function showAlert(message, type) {
                // 简单的alert提示，可以替换为更好的提示组件
                alert(message);
            }
        });
    </script>

    <style>
        /* 文件上传样式 */
        .file-upload-area {
            position: relative;
            border: 2px dashed var(--gray-300);
            border-radius: var(--radius-lg);
            transition: var(--transition);
        }

        .file-upload-area.drag-over {
            border-color: var(--primary-color);
            background: var(--primary-light);
        }

        .file-input {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        .file-upload-label {
            display: block;
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
        }

        .file-upload-label:hover {
            background: var(--gray-50);
        }

        .file-upload-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
        }

        .file-upload-content i {
            font-size: 3rem;
            color: var(--gray-400);
        }

        .file-upload-title {
            font-weight: 600;
            color: var(--gray-700);
        }

        .file-upload-subtitle {
            font-size: 0.875rem;
            color: var(--gray-500);
        }

        .file-upload-info {
            display: none;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
            background: var(--gray-50);
            border-radius: var(--radius);
        }

        .file-upload-info i {
            color: var(--primary-color);
            font-size: 1.25rem;
        }

        .browser-guide {
            padding: 1rem;
            background: var(--gray-50);
            border-radius: var(--radius-lg);
            margin-bottom: 1rem;
        }

        .browser-guide h4 {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
            color: var(--gray-800);
        }

        .browser-guide h4 i {
            font-size: 1.25rem;
        }

        .browser-guide ol {
            margin: 0;
            padding-left: 1.5rem;
        }

        .browser-guide li {
            margin-bottom: 0.5rem;
            color: var(--gray-600);
        }

        .import-form .form-actions {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid var(--gray-200);
        }

        /* 智能导入功能样式 */
        .feature-highlight {
            text-align: center;
            padding: 1.5rem;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, var(--primary-light) 0%, rgba(255,255,255,0.1) 100%);
            transition: var(--transition);
        }

        .feature-highlight:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .feature-icon {
            width: 60px;
            height: 60px;
            margin: 0 auto 1rem;
            background: var(--primary-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 1.5rem;
        }

        .feature-highlight h4 {
            margin: 0 0 0.5rem 0;
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--gray-800);
        }

        .feature-highlight p {
            margin: 0;
            font-size: 0.875rem;
            color: var(--gray-600);
            line-height: 1.5;
        }

        .smart-import-stats {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--gray-200);
        }

        .stat-item {
            text-align: center;
        }

        .stat-number {
            display: block;
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
            line-height: 1;
        }

        .stat-label {
            display: block;
            font-size: 0.875rem;
            color: var(--gray-600);
            margin-top: 0.25rem;
        }

        /* 导入模式选择样式 */
        .import-mode-options {
            display: grid;
            gap: 1rem;
            margin-top: 0.5rem;
        }

        .radio-option {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            padding: 1rem;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius-lg);
            cursor: pointer;
            transition: var(--transition);
            background: var(--white);
        }

        .radio-option:hover {
            border-color: var(--primary-light);
            background: var(--primary-light);
        }

        .radio-option input[type="radio"] {
            display: none;
        }

        .radio-option input[type="radio"]:checked + .radio-mark {
            background: var(--primary-color);
            border-color: var(--primary-color);
        }

        .radio-option input[type="radio"]:checked + .radio-mark:after {
            opacity: 1;
        }

        .radio-option input[type="radio"]:checked ~ .radio-content {
            color: var(--primary-dark);
        }

        .radio-mark {
            width: 20px;
            height: 20px;
            border: 2px solid var(--gray-300);
            border-radius: 50%;
            background: var(--white);
            position: relative;
            transition: var(--transition);
            flex-shrink: 0;
            margin-top: 2px;
        }

        .radio-mark:after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--white);
            opacity: 0;
            transition: var(--transition);
        }

        .radio-content {
            flex: 1;
            transition: var(--transition);
        }

        .radio-content strong {
            display: block;
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 0.25rem;
        }

        .radio-content small {
            color: var(--gray-600);
            font-size: 0.875rem;
            line-height: 1.4;
        }

        .target-category-group {
            transition: all 0.3s ease;
        }

        /* 导入进度样式 */
        .import-progress {
            margin: 2rem 0;
            padding: 1.5rem;
            background: var(--gray-50);
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-200);
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .progress-title {
            font-weight: 600;
            color: var(--gray-800);
        }

        .progress-count {
            font-size: 0.875rem;
            color: var(--gray-600);
            background: var(--white);
            padding: 0.25rem 0.75rem;
            border-radius: var(--radius);
            border: 1px solid var(--gray-200);
        }

        .progress-bar {
            height: 8px;
            background: var(--gray-200);
            border-radius: var(--radius);
            overflow: hidden;
            margin-bottom: 1rem;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            border-radius: var(--radius);
            transition: width 0.3s ease;
            width: 0%;
        }

        .progress-details {
            display: flex;
            gap: 1.5rem;
            justify-content: center;
        }

        .progress-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
            color: var(--gray-600);
        }

        .progress-item i {
            font-size: 1rem;
        }

        .text-success {
            color: var(--success-color) !important;
        }

        .text-warning {
            color: var(--warning-color) !important;
        }

        .text-info {
            color: var(--info-color) !important;
        }

        @media (max-width: 768px) {
            .grid.grid-cols-3 {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .smart-import-stats {
                flex-direction: column;
                gap: 1rem;
            }
            
            .stat-number {
                font-size: 1.5rem;
            }

            .progress-details {
                flex-direction: column;
                gap: 0.75rem;
            }

            .progress-header {
                flex-direction: column;
                gap: 0.5rem;
                align-items: flex-start;
            }
        }
    </style>
</body>
</html>

<?php
/**
 * 解析HTML书签文件
 */
function parseBookmarksFile($content) {
    $bookmarks = [];
    $currentFolder = '未分类';
    
    // 统一换行符，保持原有的行结构
    $content = str_replace(["\r\n", "\r"], "\n", $content);
    $lines = explode("\n", $content);
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        
        // 匹配文件夹/目录（H3标签）
        if (preg_match('/<H3[^>]*>([^<]+)<\/H3>/i', $line, $folderMatch)) {
            $currentFolder = trim($folderMatch[1]);
            if (empty($currentFolder) || $currentFolder === 'Bookmarks') {
                $currentFolder = '未分类';
            }
            continue;
        }
        
        // 匹配书签链接 - 支持LinkHub导出格式
        // 匹配 <DT><A HREF="url">title</a></DT> 格式
        if (preg_match('/<DT><A[^>]*HREF="([^"]*)"[^>]*>([^<]*)<\/[aA]>/i', $line, $linkMatch)) {
            $url = trim($linkMatch[1]);
            $title = trim($linkMatch[2]);
            
            // 清理标题
            $title = html_entity_decode($title, ENT_QUOTES, 'UTF-8');
            $title = strip_tags($title);
            
            // 验证URL和标题
            if (!empty($url) && !empty($title) && filter_var($url, FILTER_VALIDATE_URL)) {
                $bookmarks[] = [
                    'url' => $url,
                    'title' => $title,
                    'folder' => $currentFolder
                ];
            }
        }
        // 兼容其他可能的格式
        elseif (preg_match('/<A[^>]*HREF="([^"]*)"[^>]*>([^<]*)/i', $line, $linkMatch)) {
            $url = trim($linkMatch[1]);
            $title = trim($linkMatch[2]);
            
            // 如果标题中包含结束标签，移除它
            $title = preg_replace('/<\/[aA]>.*$/i', '', $title);
            
            // 清理标题
            $title = html_entity_decode($title, ENT_QUOTES, 'UTF-8');
            $title = strip_tags($title);
            
            // 验证URL和标题
            if (!empty($url) && !empty($title) && filter_var($url, FILTER_VALIDATE_URL)) {
                $bookmarks[] = [
                    'url' => $url,
                    'title' => $title,
                    'folder' => $currentFolder
                ];
            }
        }
    }
    
    return $bookmarks;
}

/**
 * 获取或创建分类
 */
function getOrCreateCategory($pdo, $folderName, &$categoryMap, &$newCategoryCount = 0) {
    global $tablePrefix;
    
    // 清理分类名称
    $folderName = trim($folderName);
    if (empty($folderName) || $folderName === 'Bookmarks' || $folderName === '书签栏') {
        $folderName = '未分类';
    }
    
    // 检查缓存
    if (isset($categoryMap[$folderName])) {
        return $categoryMap[$folderName];
    }
    
    // 查找现有分类
    $stmt = $pdo->prepare("SELECT id FROM " . $tablePrefix . "categorys WHERE name = ?");
    $stmt->execute([$folderName]);
    $existingCategory = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existingCategory) {
        $categoryMap[$folderName] = $existingCategory['id'];
        return $existingCategory['id'];
    }
    
    // 创建新分类
    $icon = getCategoryIcon($folderName);
    $stmt = $pdo->prepare("INSERT INTO " . $tablePrefix . "categorys (name, fid, font_icon, property, weight, add_time) VALUES (?, 0, ?, 0, 0, ?)");
    $stmt->execute([$folderName, $icon['icon'], time()]);
    
    $newCategoryId = $pdo->lastInsertId();
    $categoryMap[$folderName] = $newCategoryId;
    $newCategoryCount++; // 增加新建分类计数
    
    return $newCategoryId;
}

/**
 * 根据分类名称获取合适的图标
 */
function getCategoryIcon($categoryName) {
    $name = strtolower($categoryName);
    
    $iconMap = [
        // 开发相关
        '开发' => ['icon' => 'fa-code', 'color' => '#2563eb'],
        '编程' => ['icon' => 'fa-code', 'color' => '#2563eb'],
        'dev' => ['icon' => 'fa-code', 'color' => '#2563eb'],
        'development' => ['icon' => 'fa-code', 'color' => '#2563eb'],
        'github' => ['icon' => 'fa-github', 'color' => '#181717'],
        
        // 工具类
        '工具' => ['icon' => 'fa-tools', 'color' => '#6b7280'],
        'tools' => ['icon' => 'fa-tools', 'color' => '#6b7280'],
        '实用' => ['icon' => 'fa-wrench', 'color' => '#6b7280'],
        'utilities' => ['icon' => 'fa-wrench', 'color' => '#6b7280'],
        
        // 学习相关
        '学习' => ['icon' => 'fa-graduation-cap', 'color' => '#059669'],
        '教程' => ['icon' => 'fa-book', 'color' => '#059669'],
        '文档' => ['icon' => 'fa-file-alt', 'color' => '#059669'],
        'learning' => ['icon' => 'fa-graduation-cap', 'color' => '#059669'],
        'tutorial' => ['icon' => 'fa-book', 'color' => '#059669'],
        'docs' => ['icon' => 'fa-file-alt', 'color' => '#059669'],
        
        // 娱乐类
        '娱乐' => ['icon' => 'fa-gamepad', 'color' => '#dc2626'],
        '游戏' => ['icon' => 'fa-gamepad', 'color' => '#dc2626'],
        '音乐' => ['icon' => 'fa-music', 'color' => '#7c3aed'],
        '视频' => ['icon' => 'fa-video', 'color' => '#dc2626'],
        'entertainment' => ['icon' => 'fa-gamepad', 'color' => '#dc2626'],
        'music' => ['icon' => 'fa-music', 'color' => '#7c3aed'],
        'video' => ['icon' => 'fa-video', 'color' => '#dc2626'],
        
        // 新闻资讯
        '新闻' => ['icon' => 'fa-newspaper', 'color' => '#1f2937'],
        '资讯' => ['icon' => 'fa-rss', 'color' => '#1f2937'],
        'news' => ['icon' => 'fa-newspaper', 'color' => '#1f2937'],
        
        // 购物
        '购物' => ['icon' => 'fa-shopping-cart', 'color' => '#f59e0b'],
        'shopping' => ['icon' => 'fa-shopping-cart', 'color' => '#f59e0b'],
        
        // 社交
        '社交' => ['icon' => 'fa-users', 'color' => '#3b82f6'],
        'social' => ['icon' => 'fa-users', 'color' => '#3b82f6'],
        
        // 工作相关
        '工作' => ['icon' => 'fa-briefcase', 'color' => '#374151'],
        'work' => ['icon' => 'fa-briefcase', 'color' => '#374151'],
        'business' => ['icon' => 'fa-building', 'color' => '#374151'],
    ];
    
    // 精确匹配
    if (isset($iconMap[$name])) {
        return $iconMap[$name];
    }
    
    // 模糊匹配
    foreach ($iconMap as $keyword => $icon) {
        if (strpos($name, $keyword) !== false) {
            return $icon;
        }
    }
    
    // 默认图标
    return ['icon' => 'fa-folder', 'color' => '#6366f1'];
}

/**
 * 智能获取网站信息
 */
function getSmartSiteInfo($url, $originalTitle) {
    // 解析域名
    $parsedUrl = parse_url($url);
    $domain = $parsedUrl['host'] ?? '';
    
    // 获取智能推荐的图标和颜色
    $smartIcon = getSmartIconForDomain($domain);
    
    // 优化标题
    $optimizedTitle = optimizeTitle($originalTitle, $domain);
    
    // 生成描述
    $description = generateDescription($domain, $optimizedTitle);
    
    return [
        'title' => $optimizedTitle,
        'description' => $description,
        'icon' => $smartIcon['icon'],
        'color' => $smartIcon['color']
    ];
}

/**
 * 根据域名获取智能图标推荐
 */
function getSmartIconForDomain($domain) {
    $domain = strtolower($domain);
    
    // 移除www前缀
    $domain = preg_replace('/^www\./', '', $domain);
    
    $iconMap = [
        // 搜索引擎
        'google.com' => ['icon' => 'fa-google', 'color' => '#4285f4'],
        'baidu.com' => ['icon' => 'fa-search', 'color' => '#2932e1'],
        'bing.com' => ['icon' => 'fa-microsoft', 'color' => '#00a1f1'],
        
        // 社交媒体
        'facebook.com' => ['icon' => 'fa-facebook', 'color' => '#1877f2'],
        'twitter.com' => ['icon' => 'fa-twitter', 'color' => '#1da1f2'],
        'instagram.com' => ['icon' => 'fa-instagram', 'color' => '#e4405f'],
        'linkedin.com' => ['icon' => 'fa-linkedin', 'color' => '#0a66c2'],
        'youtube.com' => ['icon' => 'fa-youtube', 'color' => '#ff0000'],
        'weibo.com' => ['icon' => 'fa-weibo', 'color' => '#e6162d'],
        
        // 开发工具
        'github.com' => ['icon' => 'fa-github', 'color' => '#181717'],
        'gitlab.com' => ['icon' => 'fa-gitlab', 'color' => '#fc6d26'],
        'stackoverflow.com' => ['icon' => 'fa-stack-overflow', 'color' => '#f48024'],
        'codepen.io' => ['icon' => 'fa-codepen', 'color' => '#000000'],
        
        // 云服务
        'amazonaws.com' => ['icon' => 'fa-aws', 'color' => '#ff9900'],
        'azure.com' => ['icon' => 'fa-microsoft', 'color' => '#0078d4'],
        'console.cloud.google.com' => ['icon' => 'fa-google', 'color' => '#4285f4'],
        
        // 购物
        'amazon.com' => ['icon' => 'fa-amazon', 'color' => '#ff9900'],
        'taobao.com' => ['icon' => 'fa-shopping-cart', 'color' => '#ff6a00'],
        'tmall.com' => ['icon' => 'fa-store', 'color' => '#ff0036'],
        'jd.com' => ['icon' => 'fa-shopping-bag', 'color' => '#e3101e'],
        
        // 邮箱
        'gmail.com' => ['icon' => 'fa-envelope', 'color' => '#ea4335'],
        'outlook.com' => ['icon' => 'fa-microsoft', 'color' => '#0078d4'],
        'qq.com' => ['icon' => 'fa-qq', 'color' => '#12b7f5'],
        
        // 娱乐
        'netflix.com' => ['icon' => 'fa-film', 'color' => '#e50914'],
        'bilibili.com' => ['icon' => 'fa-video', 'color' => '#fb7299'],
        'youku.com' => ['icon' => 'fa-play-circle', 'color' => '#06a7e1'],
        'spotify.com' => ['icon' => 'fa-spotify', 'color' => '#1db954'],
    ];
    
    // 精确匹配
    if (isset($iconMap[$domain])) {
        return $iconMap[$domain];
    }
    
    // 模糊匹配
    foreach ($iconMap as $key => $icon) {
        if (strpos($domain, $key) !== false) {
            return $icon;
        }
    }
    
    // 根据域名关键词推荐
    $keywords = [
        'blog' => ['icon' => 'fa-blog', 'color' => '#2d3748'],
        'news' => ['icon' => 'fa-newspaper', 'color' => '#1a202c'],
        'shop' => ['icon' => 'fa-shopping-cart', 'color' => '#38a169'],
        'mail' => ['icon' => 'fa-envelope', 'color' => '#3182ce'],
        'music' => ['icon' => 'fa-music', 'color' => '#805ad5'],
        'video' => ['icon' => 'fa-video', 'color' => '#e53e3e'],
        'photo' => ['icon' => 'fa-camera', 'color' => '#d69e2e'],
        'game' => ['icon' => 'fa-gamepad', 'color' => '#38b2ac'],
        'edu' => ['icon' => 'fa-graduation-cap', 'color' => '#3182ce'],
        'doc' => ['icon' => 'fa-file-alt', 'color' => '#4a5568'],
        'wiki' => ['icon' => 'fa-wikipedia-w', 'color' => '#000000'],
        'forum' => ['icon' => 'fa-comments', 'color' => '#718096'],
        'cloud' => ['icon' => 'fa-cloud', 'color' => '#4299e1'],
        'tool' => ['icon' => 'fa-tools', 'color' => '#6b7280'],
        'api' => ['icon' => 'fa-code', 'color' => '#2d3748']
    ];
    
    foreach ($keywords as $keyword => $icon) {
        if (strpos($domain, $keyword) !== false) {
            return $icon;
        }
    }
    
    // 默认图标（返回空，让前端显示首字母）
    return ['icon' => '', 'color' => '#6366f1'];
}

/**
 * 优化标题
 */
function optimizeTitle($title, $domain) {
    // 移除常见的后缀
    $suffixes = [
        ' - Google Chrome',
        ' | Chrome Store',
        ' - Mozilla Firefox',
        ' - Safari',
        ' - Microsoft Edge',
        ' - 百度',
        ' - Google',
        ' - Bing'
    ];
    
    foreach ($suffixes as $suffix) {
        if (strpos($title, $suffix) !== false) {
            $title = str_replace($suffix, '', $title);
        }
    }
    
    // 清理标题
    $title = trim($title);
    
    // 如果标题为空或太短，使用域名
    if (empty($title) || strlen($title) < 3) {
        $title = ucfirst(str_replace('www.', '', $domain));
    }
    
    return $title;
}

/**
 * 生成描述
 */
function generateDescription($domain, $title) {
    if ($title !== $domain && !empty($title)) {
        return "来自 {$domain} 的优质内容";
    }
    return "访问 {$domain} 获取更多信息";
}
?>