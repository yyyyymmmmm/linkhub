<?php
require_once 'auth.php';

// auth.php已自动处理登录检查

// 获取网站统计数据
$stmt = $pdo->query("SELECT COUNT(*) FROM " . $tablePrefix . "categorys");
$categoryCount = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM " . $tablePrefix . "links");
$linkCount = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM " . $tablePrefix . "users");
$userCount = $stmt->fetchColumn();

// 获取数据库版本信息
$databaseVersion = 'Unknown';
try {
    // 检查数据库类型并获取版本
    $envFile = dirname(dirname(__DIR__)) . '/.env';
    if (file_exists($envFile)) {
        $envContent = file_get_contents($envFile);
        if (strpos($envContent, 'DB_CONNECTION=mysql') !== false) {
            // MySQL
            $databaseVersion = 'MySQL ' . $pdo->query('SELECT VERSION()')->fetchColumn();
        } else {
            // SQLite
            $databaseVersion = 'SQLite ' . $pdo->query('SELECT sqlite_version()')->fetchColumn();
        }
    } else {
        // 默认SQLite
        $databaseVersion = 'SQLite ' . $pdo->query('SELECT sqlite_version()')->fetchColumn();
    }
} catch (Exception $e) {
    $databaseVersion = 'Unknown';
}

// 获取系统信息
$systemInfo = [
    'php_version' => phpversion(),
    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'database_version' => $databaseVersion,
    'disk_space' => formatBytes(disk_total_space(__DIR__)),
    'disk_free' => formatBytes(disk_free_space(__DIR__)),
    'memory_limit' => ini_get('memory_limit'),
    'max_execution_time' => ini_get('max_execution_time')
];

// 获取最近添加的链接
$stmt = $pdo->query("SELECT id, title, url, add_time FROM " . $tablePrefix . "links ORDER BY id DESC LIMIT 5");
$recentLinks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 获取最近注册的用户
$stmt = $pdo->query("SELECT id, username, add_time FROM " . $tablePrefix . "users ORDER BY add_time DESC LIMIT 5");
$recentUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 获取链接点击统计
$stmt = $pdo->query("SELECT title, click FROM " . $tablePrefix . "links WHERE click > 0 ORDER BY click DESC LIMIT 5");
$popularLinks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 格式化字节大小
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    for ($i = 0; $bytes > 1024; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>控制台 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=<?= time() ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" class="active" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/backup.php" data-title="备份恢复">
                            <i class="fas fa-database"></i>
                            <span>备份恢复</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay"></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
            <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1>控制台</h1>
                </div>
                <div class="header-actions">
                    <span class="user-info">
                        <i class="fas fa-user"></i>
                        <?= htmlspecialchars($_SESSION['admin_username'] ?? 'Administrator') ?>
                    </span>
                                        </div>
            </header>

            <!-- 页面内容 -->
            <div class="page-content">
                <!-- 统计卡片 -->
                <div class="stats-grid">
                    <div class="stat-card blue">
                        <div class="stat-icon">
                            <i class="fas fa-folder"></i>
                                    </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $categoryCount ?></div>
                            <div class="stat-label">分类数量</div>
                                </div>
                        <div class="stat-action">
                            <a href="/admin/categories.php" class="btn btn-sm btn-primary">管理</a>
                                </div>
                            </div>

                    <div class="stat-card green">
                        <div class="stat-icon">
                            <i class="fas fa-link"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $linkCount ?></div>
                            <div class="stat-label">链接数量</div>
                                        </div>
                        <div class="stat-action">
                            <a href="/admin/links.php" class="btn btn-sm btn-success">管理</a>
                                    </div>
                                </div>

                    <div class="stat-card orange">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                                </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $userCount ?></div>
                            <div class="stat-label">用户数量</div>
                        </div>
                        <div class="stat-action">
                            <a href="/admin/users.php" class="btn btn-sm btn-warning">管理</a>
                            </div>
                        </div>
                        
                    <div class="stat-card purple">
                        <div class="stat-icon">
                            <i class="fas fa-chart-line"></i>
                                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= array_sum(array_column($popularLinks, 'click')) ?></div>
                            <div class="stat-label">总点击数</div>
                                    </div>
                        <div class="stat-action">
                            <a href="/admin/links.php" class="btn btn-sm btn-info">查看</a>
                                </div>
                            </div>
                        </div>
                        
                <!-- 快速操作区域 - 提升优先级 -->
                <div class="mb-4">
                    <div class="card quick-actions-card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-rocket text-warning"></i>
                                快速操作
                            </h3>
                            <small class="text-muted">常用功能快捷入口</small>
                        </div>
                        <div class="card-body">
                            <div class="row g-3 quick-actions">
                                <div class="col-3">
                                    <a href="/admin/links.php?action=add" class="btn btn-primary" style="width: 100%; height: 60px; display: flex; align-items: center; justify-content: center; text-decoration: none; border-radius: 8px; font-weight: 500; gap: 8px;">
                                        <i class="fas fa-plus" style="font-size: 16px;"></i>
                                        <span style="font-size: 14px;">添加链接</span>
                                    </a>
                                        </div>
                                <div class="col-3">
                                    <a href="/admin/categories.php?action=add" class="btn btn-success" style="width: 100%; height: 60px; display: flex; align-items: center; justify-content: center; text-decoration: none; border-radius: 8px; font-weight: 500; gap: 8px;">
                                        <i class="fas fa-folder-plus" style="font-size: 16px;"></i>
                                        <span style="font-size: 14px;">添加分类</span>
                                    </a>
                                    </div>
                                <div class="col-3">
                                    <a href="/admin/import.php" class="btn btn-info" style="width: 100%; height: 60px; display: flex; align-items: center; justify-content: center; text-decoration: none; border-radius: 8px; font-weight: 500; gap: 8px;">
                                        <i class="fas fa-file-import" style="font-size: 16px;"></i>
                                        <span style="font-size: 14px;">导入书签</span>
                                    </a>
                                </div>
                                <div class="col-3">
                                    <a href="/" target="_blank" class="btn btn-outline-primary" style="width: 100%; height: 60px; display: flex; align-items: center; justify-content: center; text-decoration: none; border-radius: 8px; font-weight: 500; gap: 8px;">
                                        <i class="fas fa-external-link-alt" style="font-size: 16px;"></i>
                                        <span style="font-size: 14px;">查看前台</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 动态信息区域 -->
                <div class="row">
                    <!-- 最近添加的链接 -->
                    <div class="col-lg-8">
                        <div class="card timeline-card h-100">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-clock text-primary"></i>
                                    最近动态
                                </h3>
                                <a href="/admin/links.php" class="btn btn-sm btn-outline-primary">管理链接</a>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($recentLinks)): ?>
                                    <div class="timeline">
                                        <?php foreach ($recentLinks as $index => $link): ?>
                                        <div class="timeline-item <?= $index >= 3 ? 'd-none d-lg-block' : '' ?>">
                                            <div class="timeline-marker bg-primary"></div>
                                            <div class="timeline-content">
                                                <div class="d-flex justify-content-between align-items-start">
                                                    <div class="flex-fill">
                                                        <h6 class="mb-1"><?= htmlspecialchars($link['title']) ?></h6>
                                                        <p class="text-muted mb-1 small"><?= htmlspecialchars(substr($link['url'], 0, 60)) ?><?= strlen($link['url']) > 60 ? '...' : '' ?></p>
                                                        <small class="text-muted">
                                                            <i class="fas fa-clock"></i>
                                                            <?= date('Y-m-d H:i', $link['add_time']) ?>
                                                        </small>
                                                    </div>
                                                    <div class="ms-3">
                                                        <a href="/admin/links.php?action=edit&id=<?= $link['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="empty-state">
                                        <i class="fas fa-inbox"></i>
                                        <h5>还没有添加任何链接</h5>
                                        <p>开始创建您的第一个链接来组织您的书签</p>
                                        <a href="/admin/links.php?action=add" class="btn btn-primary">
                                            <i class="fas fa-plus me-2"></i>添加第一个链接
                                        </a>
                                    </div>
                                <?php endif; ?>
            </div>
        </div>
    </div>
    
                    <!-- 侧边信息栏 -->
                    <div class="col-lg-4">
                        <div class="row g-3">
                            <!-- 热门链接 -->
                            <div class="col-12">
            <div class="card">
                <div class="card-header">
                                        <h3 class="card-title">
                                            <i class="fas fa-fire text-danger"></i>
                                            热门链接
                                        </h3>
                </div>
                <div class="card-body">
                                        <?php if (!empty($popularLinks)): ?>
                                            <?php foreach (array_slice($popularLinks, 0, 3) as $index => $link): ?>
                                            <div class="popular-links-item d-flex align-items-center">
                                                <div class="me-3">
                                                    <span class="badge bg-danger rounded-pill"><?= $index + 1 ?></span>
                                                </div>
                                                <div class="flex-fill">
                                                    <h6 class="mb-0 small"><?= htmlspecialchars($link['title']) ?></h6>
                                                    <small class="text-muted">
                                                        <i class="fas fa-mouse-pointer"></i>
                                                        <?= number_format($link['click']) ?> 次
                                                    </small>
                                                </div>
                                            </div>
                                <?php endforeach; ?>
                                            <div class="text-center mt-3">
                                                <a href="/admin/links.php?order=click" class="btn btn-sm btn-outline-danger">查看更多</a>
                    </div>
                                        <?php else: ?>
                                            <div class="empty-state py-3">
                                                <i class="fas fa-chart-line" style="font-size: 2rem;"></i>
                                                <p class="mb-0 small">暂无点击统计</p>
                </div>
                                        <?php endif; ?>
                </div>
            </div>
        </div>
        
                            <!-- 最近用户 -->
                            <div class="col-12">
            <div class="card">
                <div class="card-header">
                                        <h3 class="card-title">
                                            <i class="fas fa-user-plus text-success"></i>
                                            最近用户
                                        </h3>
                </div>
                <div class="card-body">
                                        <?php if (!empty($recentUsers)): ?>
                                            <?php foreach (array_slice($recentUsers, 0, 3) as $user): ?>
                                            <div class="recent-users-item d-flex align-items-center">
                                                <div class="me-3">
                                                    <div class="avatar avatar-sm bg-success text-white">
                                                        <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                                    </div>
                                                </div>
                                                <div class="flex-fill">
                                                    <h6 class="mb-0 small"><?= htmlspecialchars($user['username']) ?></h6>
                                                    <small class="text-muted"><?= date('m-d H:i', $user['add_time']) ?></small>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                            <div class="text-center mt-2">
                                                <a href="/admin/users.php" class="btn btn-sm btn-outline-success">用户管理</a>
                                            </div>
                                        <?php else: ?>
                                            <div class="empty-state py-3">
                                                <i class="fas fa-users" style="font-size: 2rem;"></i>
                                                <p class="mb-0 small">暂无用户</p>
                    </div>
                                        <?php endif; ?>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    
                <!-- 系统信息 -->
                <div class="mt-4">
                    <div class="card system-info-card">
                <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-server text-info"></i>
                                系统信息
                            </h3>
                            <small class="text-muted">服务器运行状态</small>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                                    <table class="table table-sm table-borderless">
                                <tbody>
                                    <tr>
                                                <td class="text-muted">PHP 版本</td>
                                                <td class="fw-semibold"><?= $systemInfo['php_version'] ?></td>
                                    </tr>
                                    <tr>
                                                <td class="text-muted">数据库</td>
                                                <td class="fw-semibold">SQLite <?= $systemInfo['database_version'] ?></td>
                                    </tr>
                                    <tr>
                                                <td class="text-muted">内存限制</td>
                                                <td class="fw-semibold"><?= $systemInfo['memory_limit'] ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-6">
                                    <table class="table table-sm table-borderless">
                                <tbody>
                                    <tr>
                                                <td class="text-muted">服务器</td>
                                                <td class="fw-semibold"><?= htmlspecialchars(substr($systemInfo['server_software'], 0, 20)) ?></td>
                                    </tr>
                                    <tr>
                                                <td class="text-muted">磁盘可用</td>
                                                <td class="fw-semibold"><?= $systemInfo['disk_free'] ?></td>
                                    </tr>
                                    <tr>
                                                <td class="text-muted">执行时间</td>
                                                <td class="fw-semibold"><?= $systemInfo['max_execution_time'] ?>s</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        </main>
</div>

    <!-- 快速操作按钮移动端优化 -->
    <style>
    @media (max-width: 768px) {
        .quick-actions .col-3 {
            flex: 0 0 50% !important;
            max-width: 50% !important;
            margin-bottom: 0.5rem !important;
        }
        .quick-actions .btn {
            height: 50px !important;
            font-size: 13px !important;
        }
        .quick-actions .btn i {
            font-size: 14px !important;
        }
        .quick-actions .btn span {
            font-size: 12px !important;
        }
    }
    
    @media (max-width: 480px) {
        .quick-actions .col-3 {
            flex: 0 0 100% !important;
            max-width: 100% !important;
        }
    }
    </style>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="../assets/js/admin.js?v=<?= time() ?>"></script>
    <script src="../assets/js/sidebar-fix.js?v=<?= time() ?>"></script>
    <script>
        $(document).ready(function() {
            // 统计卡片动画
            $('.stat-number').each(function() {
                const target = parseInt($(this).text());
                $(this).text('0');
                $(this).animate({
                    Counter: target
                }, {
                    duration: 1000,
                    easing: 'swing',
                    step: function(now) {
                        $(this).text(Math.ceil(now));
                    }
                });
            });

            // 工具提示
            $('[data-title]').hover(
                function() {
                    const title = $(this).attr('data-title');
                    if (title) {
                        $(this).attr('title', title);
                    }
                }
            );
            
            // 调试信息
            console.log('Dashboard loaded with external sidebar control');
        });
    </script>
</body>
</html>