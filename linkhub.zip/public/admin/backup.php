<?php
/**
 * 新的备份管理页面
 */
require_once 'auth.php';
checkPermission('admin'); // 备份需要管理员权限

$message = '';
$messageType = '';

// 备份存储目录
$backupDir = dirname(dirname(__DIR__)) . '/storage/backups/';
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// 处理操作
$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'create_backup':
            $backupTypes = $_POST['backup_types'] ?? [];
            if (empty($backupTypes)) {
                throw new Exception('请至少选择一种备份类型');
            }
            
            $backupData = createSelectiveBackup($backupTypes);
            $filename = 'linkhub_backup_' . date('Y-m-d_H-i-s') . '_' . implode('-', $backupTypes) . '.json';
            $filepath = $backupDir . $filename;
            
            file_put_contents($filepath, $backupData);
            $message = '备份创建成功！文件：' . $filename;
            $messageType = 'success';
            break;
            
        case 'download_backup':
            $filename = $_GET['file'] ?? '';
            $filepath = $backupDir . $filename;
            
            if (!$filename || !file_exists($filepath) || strpos($filename, '..') !== false) {
                throw new Exception('备份文件不存在');
            }
                
                header('Content-Type: application/json');
                header('Content-Disposition: attachment; filename=' . $filename);
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
                exit;
                break;
                
        case 'delete_backup':
            $filename = $_POST['file'] ?? '';
            $filepath = $backupDir . $filename;
            
            if (!$filename || !file_exists($filepath) || strpos($filename, '..') !== false) {
                throw new Exception('备份文件不存在');
            }
            
            unlink($filepath);
            $message = '备份文件删除成功！';
            $messageType = 'success';
            break;
            
        case 'restore_backup':
            $filename = $_POST['file'] ?? '';
            $filepath = $backupDir . $filename;
            
            if (!$filename || !file_exists($filepath)) {
                throw new Exception('备份文件不存在');
            }
            
            $content = file_get_contents($filepath);
            $data = json_decode($content, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('备份文件格式错误');
            }
            
            restoreBackup($data);
            $message = '数据恢复成功！';
            $messageType = 'success';
            break;
            
        case 'upload_restore':
                if (!isset($_FILES['backup_file']) || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK) {
                    throw new Exception('请选择有效的备份文件');
                }
                
                $file = $_FILES['backup_file'];
                $content = file_get_contents($file['tmp_name']);
                $data = json_decode($content, true);
                
                if (json_last_error() !== JSON_ERROR_NONE) {
                    throw new Exception('备份文件格式错误');
                }
                
                restoreBackup($data);
                $message = '数据恢复成功！';
                $messageType = 'success';
                break;
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }

// 获取备份列表
function getBackupList($backupDir) {
    $backups = [];
    if (is_dir($backupDir)) {
        $files = glob($backupDir . '*.json');
        foreach ($files as $file) {
            $filename = basename($file);
            $backups[] = [
                'filename' => $filename,
                'filepath' => $file,
                'size' => filesize($file),
                'created' => filemtime($file),
                'types' => parseBackupTypes($filename)
            ];
        }
        
        // 按时间倒序排列
        usort($backups, function($a, $b) {
            return $b['created'] - $a['created'];
        });
    }
    return $backups;
}

// 解析备份类型
function parseBackupTypes($filename) {
    if (preg_match('/_([a-z-]+)\.json$/', $filename, $matches)) {
        return explode('-', $matches[1]);
    }
    return ['all'];
}

// 创建选择性备份
function createSelectiveBackup($types) {
    global $pdo, $tablePrefix;
    
    $backup = [
        'version' => '1.0',
        'created_at' => date('Y-m-d H:i:s'),
        'types' => $types,
        'data' => []
    ];
    
    foreach ($types as $type) {
        switch ($type) {
            case 'categories':
                $backup['data']['categories'] = $pdo->query("SELECT * FROM " . $tablePrefix . "categorys ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
                break;
                
            case 'links':
                $backup['data']['links'] = $pdo->query("SELECT * FROM " . $tablePrefix . "links ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
                break;
                
            case 'users':
                $backup['data']['users'] = $pdo->query("SELECT * FROM " . $tablePrefix . "users ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
                break;
                
            case 'settings':
                $backup['data']['settings'] = $pdo->query("SELECT * FROM " . $tablePrefix . "settings ORDER BY `key`")->fetchAll(PDO::FETCH_ASSOC);
                break;
                
            case 'statistics':
                // 备份点击统计等数据
                try {
                    $backup['data']['clicks'] = $pdo->query("SELECT * FROM " . $tablePrefix . "clicks ORDER BY id DESC LIMIT 10000")->fetchAll(PDO::FETCH_ASSOC);
                } catch (Exception $e) {
                    // 如果表不存在，忽略
                }
                break;
        }
    }
    
    return json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// 恢复备份
function restoreBackup($data) {
    global $pdo, $tablePrefix;
    
    if (!isset($data['data'])) {
        throw new Exception('备份数据格式错误');
    }
    
    $pdo->beginTransaction();
    
    try {
        foreach ($data['data'] as $table => $records) {
            switch ($table) {
                case 'categories':
            $pdo->exec("DELETE FROM " . $tablePrefix . "categorys");
                    foreach ($records as $record) {
                        $sql = "INSERT INTO " . $tablePrefix . "categorys (id, name, font_icon, description, weight, property, add_time) VALUES (?, ?, ?, ?, ?, ?, ?)";
                        $pdo->prepare($sql)->execute([
                            $record['id'], $record['name'], $record['font_icon'] ?? '', 
                            $record['description'] ?? '', $record['weight'] ?? 0, 
                            $record['property'] ?? 0, $record['add_time']
                        ]);
                    }
                    break;
                    
                case 'links':
                    $pdo->exec("DELETE FROM " . $tablePrefix . "links");
                    foreach ($records as $record) {
                        $sql = "INSERT INTO " . $tablePrefix . "links (id, fid, title, url, note, font_icon, weight, property, click, add_time, up_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                        $pdo->prepare($sql)->execute([
                            $record['id'], $record['fid'], $record['title'], $record['url'],
                            $record['note'] ?? '', $record['font_icon'] ?? '', 
                            $record['weight'] ?? 0, $record['property'] ?? 0, 
                            $record['click'] ?? 0, $record['add_time'], $record['up_time']
                        ]);
                    }
                    break;
                    
                case 'users':
                    $pdo->exec("DELETE FROM " . $tablePrefix . "users WHERE id > 1"); // 保留管理员账户
                    foreach ($records as $record) {
                        if ($record['id'] == 1) continue; // 跳过管理员账户
                        $sql = "INSERT INTO " . $tablePrefix . "users (id, username, password, email, role, status, add_time, up_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        $pdo->prepare($sql)->execute([
                            $record['id'], $record['username'], $record['password'],
                            $record['email'] ?? '', $record['role'] ?? 'user',
                            $record['status'] ?? 1, $record['add_time'], $record['up_time']
                        ]);
                    }
                    break;
                    
                case 'settings':
                    foreach ($records as $record) {
                        $sql = "REPLACE INTO " . $tablePrefix . "settings (`key`, `value`) VALUES (?, ?)";
                        $pdo->prepare($sql)->execute([$record['key'], $record['value']]);
                    }
                    break;
                    
                case 'clicks':
                    try {
                        $pdo->exec("DELETE FROM " . $tablePrefix . "clicks");
                        foreach ($records as $record) {
                            $sql = "INSERT INTO " . $tablePrefix . "clicks (id, link_id, ip, user_agent, referer, click_time) VALUES (?, ?, ?, ?, ?, ?)";
                            $pdo->prepare($sql)->execute([
                                $record['id'], $record['link_id'], $record['ip'],
                                $record['user_agent'] ?? '', $record['referer'] ?? '',
                                $record['click_time']
                            ]);
                        }
                    } catch (Exception $e) {
                        // 如果表不存在，忽略
                    }
                    break;
            }
        }
        
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollback();
        throw $e;
    }
}

$backups = getBackupList($backupDir);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>备份管理 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="/admin/backup.php" data-title="备份管理">
                            <i class="fas fa-database"></i>
                            <span>备份管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay"></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
            <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <i class="fas fa-database"></i>
                    <span>备份管理</span>
                </div>
                <div class="header-actions">
                    <button type="button" class="btn btn-primary btn-sm" onclick="showCreateBackup()">
                        <i class="fas fa-plus"></i>
                        创建备份
                    </button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="showUploadRestore()">
                        <i class="fas fa-upload"></i>
                        上传恢复
                    </button>
                </div>
            </header>

            <!-- 主体内容 -->
            <div class="admin-main">
        <?php if ($message): ?>
            <div class="alert alert-<?= $messageType ?>">
                <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-triangle' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

                <!-- 备份统计 -->
                <div class="stats-grid">
                <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-archive"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number"><?= count($backups) ?></div>
                            <div class="stat-label">备份文件</div>
                        </div>
                </div>
                    
                <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-hdd"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number"><?= formatBytes(array_sum(array_column($backups, 'size'))) ?></div>
                            <div class="stat-label">总大小</div>
                        </div>
                </div>
                    
                <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number"><?= !empty($backups) ? date('m-d H:i', $backups[0]['created']) : '--' ?></div>
                            <div class="stat-label">最新备份</div>
                </div>
            </div>
        </div>

                <!-- 备份列表 -->
                <div class="card">
            <div class="card-header">
                        <h3>备份文件列表</h3>
                    </div>
                    <div class="card-body">
                        <?php if (empty($backups)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">
                                <i class="fas fa-archive"></i>
                            </div>
                            <h4>暂无备份文件</h4>
                            <p>点击上方"创建备份"按钮开始备份数据</p>
                        </div>
                        <?php else: ?>
                        <div class="backup-list">
                            <?php foreach ($backups as $backup): ?>
                            <div class="backup-item">
                                <div class="backup-info">
                                    <div class="backup-name">
                                        <i class="fas fa-file-archive"></i>
                                        <?= htmlspecialchars($backup['filename']) ?>
                                    </div>
                                    <div class="backup-meta">
                                        <span class="backup-size">
                                            <i class="fas fa-hdd"></i>
                                            <?= formatBytes($backup['size']) ?>
                                        </span>
                                        <span class="backup-date">
                                            <i class="fas fa-calendar"></i>
                                            <?= date('Y-m-d H:i:s', $backup['created']) ?>
                                        </span>
                                        <span class="backup-types">
                                            <i class="fas fa-tags"></i>
                                            <?= implode(', ', array_map('ucfirst', $backup['types'])) ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="backup-actions">
                                    <a href="?action=download_backup&file=<?= urlencode($backup['filename']) ?>" 
                                       class="btn btn-sm btn-success" title="下载">
                                        <i class="fas fa-download"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-primary" 
                                            onclick="confirmRestore('<?= htmlspecialchars($backup['filename']) ?>')" title="恢复">
                                        <i class="fas fa-undo"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger" 
                                            onclick="confirmDelete('<?= htmlspecialchars($backup['filename']) ?>')" title="删除">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- 创建备份模态框 -->
    <div id="createBackupModal" class="backup-modal" style="display: none;">
        <div class="backup-modal-overlay" onclick="hideCreateBackup()"></div>
        <div class="backup-modal-content">
            <div class="backup-modal-header">
                <h3>
                    <i class="fas fa-plus"></i>
                    创建备份
                </h3>
                <button type="button" class="backup-close-btn" onclick="hideCreateBackup()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="backup-modal-body">
                <form id="createBackupForm" method="POST" action="?action=create_backup">
                    <div class="backup-types-grid">
                        <div class="backup-type-card">
                            <div class="backup-type-check">
                                <input type="checkbox" id="type_categories" name="backup_types[]" value="categories" checked>
                                <label for="type_categories"></label>
                            </div>
                            <div class="backup-type-icon">
                                <i class="fas fa-folder"></i>
                            </div>
                            <div class="backup-type-info">
                                <h4>分类数据</h4>
                                <p>备份所有分类信息</p>
                            </div>
                        </div>
                        
                        <div class="backup-type-card">
                            <div class="backup-type-check">
                                <input type="checkbox" id="type_links" name="backup_types[]" value="links" checked>
                                <label for="type_links"></label>
                            </div>
                            <div class="backup-type-icon">
                                <i class="fas fa-link"></i>
                            </div>
                            <div class="backup-type-info">
                                <h4>链接数据</h4>
                                <p>备份所有链接信息</p>
                            </div>
                        </div>
                        
                        <div class="backup-type-card">
                            <div class="backup-type-check">
                                <input type="checkbox" id="type_users" name="backup_types[]" value="users">
                                <label for="type_users"></label>
                            </div>
                            <div class="backup-type-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="backup-type-info">
                                <h4>用户数据</h4>
                                <p>备份用户账户信息</p>
                            </div>
                        </div>
                        
                        <div class="backup-type-card">
                            <div class="backup-type-check">
                                <input type="checkbox" id="type_settings" name="backup_types[]" value="settings" checked>
                                <label for="type_settings"></label>
                            </div>
                            <div class="backup-type-icon">
                                <i class="fas fa-cog"></i>
                            </div>
                            <div class="backup-type-info">
                                <h4>系统设置</h4>
                                <p>备份系统配置信息</p>
                            </div>
                        </div>
                        
                        <div class="backup-type-card">
                            <div class="backup-type-check">
                                <input type="checkbox" id="type_statistics" name="backup_types[]" value="statistics">
                                <label for="type_statistics"></label>
                            </div>
                            <div class="backup-type-icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                            <div class="backup-type-info">
                                <h4>统计数据</h4>
                                <p>备份点击统计信息</p>
            </div>
            </div>
        </div>

                    <div class="backup-modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="hideCreateBackup()">
                            <i class="fas fa-times"></i>
                            取消
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i>
                            创建备份
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 上传恢复模态框 -->
    <div id="uploadRestoreModal" class="backup-modal" style="display: none;">
        <div class="backup-modal-overlay" onclick="hideUploadRestore()"></div>
        <div class="backup-modal-content">
            <div class="backup-modal-header">
                <h3>
                    <i class="fas fa-upload"></i>
                    上传并恢复备份
                </h3>
                <button type="button" class="backup-close-btn" onclick="hideUploadRestore()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="backup-modal-body">
                <form id="uploadRestoreForm" method="POST" action="?action=upload_restore" enctype="multipart/form-data">
                    <div class="upload-area" id="uploadArea">
                        <div class="upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <div class="upload-text">
                            <h4>选择备份文件</h4>
                            <p>拖拽文件到此处或点击选择文件</p>
                            <small>支持 .json 格式的备份文件</small>
                        </div>
                        <input type="file" id="backupFile" name="backup_file" accept=".json" style="display: none;">
                </div>
                
                    <div class="upload-warning">
                        <div class="warning-icon">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="warning-text">
                            <strong>注意：</strong>恢复备份将覆盖现有数据，请确保已做好数据备份！
                        </div>
                </div>
                
                    <div class="backup-modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="hideUploadRestore()">
                            <i class="fas fa-times"></i>
                            取消
                        </button>
                        <button type="submit" class="btn btn-danger" id="restoreBtn" disabled>
                            <i class="fas fa-undo"></i>
                            恢复数据
                </button>
                    </div>
            </form>
            </div>
        </div>
        </div>

    <script src="../assets/js/admin.js?v=2.0.1"></script>
    <script src="../assets/js/sidebar-fix.js?v=1.1.0"></script>
    <script>
        // 显示创建备份模态框
        function showCreateBackup() {
            document.getElementById('createBackupModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // 隐藏创建备份模态框
        function hideCreateBackup() {
            document.getElementById('createBackupModal').style.display = 'none';
            document.body.style.overflow = '';
        }
        
        // 显示上传恢复模态框
        function showUploadRestore() {
            document.getElementById('uploadRestoreModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // 隐藏上传恢复模态框
        function hideUploadRestore() {
            document.getElementById('uploadRestoreModal').style.display = 'none';
            document.body.style.overflow = '';
        }
        
        // 确认恢复
        function confirmRestore(filename) {
            if (confirm('确定要恢复备份 "' + filename + '" 吗？\n这将覆盖现有数据，请确保已做好备份！')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '?action=restore_backup';
                form.style.display = 'none';
                
                const fileInput = document.createElement('input');
                fileInput.name = 'file';
                fileInput.value = filename;
                form.appendChild(fileInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // 确认删除
        function confirmDelete(filename) {
            if (confirm('确定要删除备份 "' + filename + '" 吗？\n此操作无法撤销！')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '?action=delete_backup';
                form.style.display = 'none';
                
                const fileInput = document.createElement('input');
                fileInput.name = 'file';
                fileInput.value = filename;
                form.appendChild(fileInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // 文件上传处理
        document.addEventListener('DOMContentLoaded', function() {
            const uploadArea = document.getElementById('uploadArea');
            const fileInput = document.getElementById('backupFile');
            const restoreBtn = document.getElementById('restoreBtn');
            
            // 点击上传区域选择文件
            uploadArea.addEventListener('click', function() {
                fileInput.click();
            });
            
            // 文件选择处理
            fileInput.addEventListener('change', function() {
                if (this.files.length > 0) {
                    const file = this.files[0];
                    uploadArea.querySelector('.upload-text h4').textContent = file.name;
                    uploadArea.querySelector('.upload-text p').textContent = '文件已选择，点击恢复数据按钮开始恢复';
                    uploadArea.classList.add('file-selected');
                    restoreBtn.disabled = false;
                }
            });
            
            // 拖拽上传
            uploadArea.addEventListener('dragover', function(e) {
                e.preventDefault();
                uploadArea.classList.add('drag-over');
            });
            
            uploadArea.addEventListener('dragleave', function(e) {
                e.preventDefault();
                uploadArea.classList.remove('drag-over');
            });
            
            uploadArea.addEventListener('drop', function(e) {
                e.preventDefault();
                uploadArea.classList.remove('drag-over');
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    fileInput.files = files;
                    fileInput.dispatchEvent(new Event('change'));
                }
            });
        });
    </script>
    
    <style>
        /* 备份页面专用样式 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
        }
        
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            color: #1a1a1a;
        }
        
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
        }
        
        .empty-icon {
            font-size: 48px;
            color: #d1d5db;
            margin-bottom: 1rem;
        }
        
        .empty-state h4 {
            margin: 0 0 0.5rem;
            color: #374151;
        }
        
        .empty-state p {
            margin: 0;
            color: #6b7280;
        }
        
        .backup-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .backup-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }
        
        .backup-info {
            flex: 1;
        }
        
        .backup-name {
            font-weight: 600;
            color: #1a1a1a;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .backup-name i {
            color: #6366f1;
        }
        
        .backup-meta {
            display: flex;
            gap: 1.5rem;
            font-size: 13px;
            color: #666;
        }
        
        .backup-meta span {
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .backup-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        /* 备份模态框样式 */
        .backup-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .backup-modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }
        
        .backup-modal-content {
            position: relative;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            max-width: 700px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease-out;
        }
        
        .backup-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 24px 24px 16px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .backup-modal-header h3 {
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .backup-close-btn {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            color: #666;
            transition: all 0.2s ease;
        }
        
        .backup-close-btn:hover {
            background: #f5f5f5;
            color: #333;
        }
        
        .backup-modal-body {
            padding: 24px;
        }
        
        .backup-types-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .backup-type-card {
            position: relative;
            background: #f8f9fa;
            border: 2px solid transparent;
            border-radius: 12px;
            padding: 20px 16px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .backup-type-card:hover {
            border-color: #6366f1;
            background: #f0f4ff;
        }
        
        .backup-type-check {
            position: absolute;
            top: 12px;
            right: 12px;
        }
        
        .backup-type-check input[type="checkbox"] {
            display: none;
        }
        
        .backup-type-check label {
            display: block;
            width: 20px;
            height: 20px;
            border: 2px solid #d1d5db;
            border-radius: 4px;
            background: white;
            cursor: pointer;
            position: relative;
        }
        
        .backup-type-check input[type="checkbox"]:checked + label {
            background: #6366f1;
            border-color: #6366f1;
        }
        
        .backup-type-check input[type="checkbox"]:checked + label::after {
            content: '✓';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 12px;
            font-weight: bold;
        }
        
        .backup-type-icon {
            font-size: 32px;
            color: #6366f1;
            margin-bottom: 12px;
        }
        
        .backup-type-info h4 {
            margin: 0 0 8px;
            font-size: 16px;
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .backup-type-info p {
            margin: 0;
            font-size: 13px;
            color: #666;
            line-height: 1.4;
        }
        
        .backup-modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 16px;
            border-top: 1px solid #f0f0f0;
            margin-top: 24px;
        }
        
        .upload-area {
            border: 2px dashed #d1d5db;
            border-radius: 12px;
            padding: 3rem 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-bottom: 1.5rem;
        }
        
        .upload-area:hover,
        .upload-area.drag-over {
            border-color: #6366f1;
            background: #f0f4ff;
        }
        
        .upload-area.file-selected {
            border-color: #22c55e;
            background: #f0fdf4;
        }
        
        .upload-icon {
            font-size: 48px;
            color: #9ca3af;
            margin-bottom: 1rem;
        }
        
        .upload-text h4 {
            margin: 0 0 0.5rem;
            font-size: 18px;
            color: #374151;
        }
        
        .upload-text p {
            margin: 0 0 0.5rem;
            color: #6b7280;
        }
        
        .upload-text small {
            color: #9ca3af;
        }
        
        .upload-warning {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            background: #fef3c7;
            border: 1px solid #f59e0b;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        
        .warning-icon {
            color: #f59e0b;
            font-size: 18px;
            flex-shrink: 0;
        }
        
        .warning-text {
            font-size: 14px;
            color: #92400e;
            line-height: 1.4;
        }
        
        @media (max-width: 640px) {
            .backup-types-grid {
                grid-template-columns: 1fr;
            }
            
            .backup-modal-content {
                margin: 20px;
                max-width: none;
            }
            
            .backup-modal-header,
            .backup-modal-body {
                padding: 20px;
            }
            
            .backup-meta {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .backup-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .backup-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }
    </style>
</body>
</html>

<?php
// 格式化字节大小
function formatBytes($size, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
        $size /= 1024;
    }
    return round($size, $precision) . ' ' . $units[$i];
}
?>
