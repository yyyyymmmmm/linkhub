<?php
require_once 'auth.php';

// 检查权限
checkPermission('admin');

// 设置超时时间
set_time_limit(300); // 5分钟
ini_set('max_execution_time', 300);
ini_set('memory_limit', '256M');

/**
 * 图标缓存系统
 * 
 * 此脚本用于：
 * 1. 创建和管理图标缓存
 * 2. 为所有链接预先获取图标并存储在本地
 * 3. 生成图标缓存映射文件供前端使用
 */

// 显示头部
echo '<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>图标缓存管理 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
        }
        .card {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            padding: 15px 20px;
            border-bottom: 1px solid #e5e7eb;
        }
        .card-body {
            padding: 20px;
        }
        .progress-container {
            margin: 20px 0;
            background-color: #f3f4f6;
            border-radius: 8px;
            overflow: hidden;
        }
        .progress-bar {
            height: 10px;
            background-color: #6366f1;
            width: 0%;
            transition: width 0.3s ease;
        }
        .progress-text {
            margin-top: 10px;
            text-align: center;
            font-size: 14px;
            color: #6b7280;
        }
        .log-container {
            max-height: 400px;
            overflow-y: auto;
            background-color: #f9fafb;
            border-radius: 6px;
            padding: 15px;
            margin-top: 20px;
            font-family: monospace;
            font-size: 13px;
        }
        .log-entry {
            margin-bottom: 8px;
            padding-bottom: 8px;
            border-bottom: 1px solid #e5e7eb;
        }
        .log-entry:last-child {
            border-bottom: none;
        }
        .log-entry.success {
            color: #065f46;
        }
        .log-entry.error {
            color: #b91c1c;
        }
        .log-entry.info {
            color: #0369a1;
        }
        .log-entry.warning {
            color: #92400e;
        }
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .summary {
            margin-top: 20px;
            padding: 15px;
            background-color: #f3f4f6;
            border-radius: 6px;
        }
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding-bottom: 8px;
            border-bottom: 1px solid #e5e7eb;
        }
        .summary-item:last-child {
            border-bottom: none;
        }
        .summary-label {
            font-weight: 500;
        }
        .summary-value {
            font-weight: 600;
        }
        .summary-value.success {
            color: #065f46;
        }
        .summary-value.error {
            color: #b91c1c;
        }
        .icon-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
            gap: 10px;
            margin-top: 20px;
        }
        .icon-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 10px;
            background: #f9fafb;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
            text-align: center;
        }
        .icon-preview {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 5px;
        }
        .icon-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        .icon-name {
            font-size: 11px;
            color: #6b7280;
            word-break: break-all;
            overflow: hidden;
            text-overflow: ellipsis;
            max-height: 32px;
            line-height: 16px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
        .settings-form {
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #d1d5db;
            border-radius: 4px;
            margin-bottom: 5px;
        }
        .form-text {
            font-size: 12px;
            color: #6b7280;
        }
        .checkbox-group {
            margin-top: 5px;
        }
        .checkbox-group label {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
            cursor: pointer;
        }
        .checkbox-group input[type="checkbox"] {
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-images"></i> 图标缓存管理</h2>
                <p>创建和管理网站图标缓存，提高前台加载速度</p>
            </div>
            <div class="card-body">';

// 处理表单提交
$processCache = isset($_POST['process']) && $_POST['process'] === '1';
$cacheType = isset($_POST['cache_type']) ? $_POST['cache_type'] : 'all';
$cacheExpiry = isset($_POST['cache_expiry']) ? (int)$_POST['cache_expiry'] : 7;
$forceRefresh = isset($_POST['force_refresh']) && $_POST['force_refresh'] === '1';

// 创建缓存目录
$cachePath = dirname(__DIR__) . '/cache/icons';
if (!file_exists($cachePath)) {
    mkdir($cachePath, 0777, true);
}

// 创建缓存映射文件
$cacheMapPath = dirname(__DIR__) . '/cache/icon_map.json';

// 显示设置表单
if (!$processCache) {
    echo '<form method="POST" action="" class="settings-form">
            <input type="hidden" name="process" value="1">
            
            <div class="form-group">
                <label class="form-label">缓存类型</label>
                <select name="cache_type" class="form-control">
                    <option value="all">所有图标（URL图标和Font Awesome图标）</option>
                    <option value="url_only">仅URL图标</option>
                    <option value="fa_only">仅Font Awesome图标</option>
                </select>
                <small class="form-text">选择要缓存的图标类型</small>
            </div>
            
            <div class="form-group">
                <label class="form-label">缓存有效期（天）</label>
                <input type="number" name="cache_expiry" class="form-control" value="7" min="1" max="30">
                <small class="form-text">缓存自动过期时间，建议设置为7天</small>
            </div>
            
            <div class="form-group">
                <div class="checkbox-group">
                    <label>
                        <input type="checkbox" name="force_refresh" value="1"> 强制刷新现有缓存
                    </label>
                    <small class="form-text">勾选此项将重新获取所有图标，即使已有缓存</small>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-sync"></i> 开始生成缓存
            </button>
        </form>';
} else {
    // 开始处理缓存
    try {
        // 获取所有链接
        $stmt = $pdo->query("SELECT id, title, url, font_icon, icon_url, icon_color FROM " . $tablePrefix . "links ORDER BY id ASC");
        $links = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $totalLinks = count($links);
        $processedCount = 0;
        $successCount = 0;
        $errorCount = 0;
        $skippedCount = 0;
        
        // 创建或加载缓存映射
        $iconMap = [];
        if (file_exists($cacheMapPath) && !$forceRefresh) {
            $iconMap = json_decode(file_get_contents($cacheMapPath), true) ?: [];
        }
        
        echo '<div class="progress-container">
                <div class="progress-bar" id="progressBar"></div>
              </div>
              <div class="progress-text" id="progressText">准备处理...</div>
              <div class="log-container" id="logContainer"></div>';
        
        // 输出JavaScript用于更新进度
        echo '<script>
                function updateProgress(percent, text) {
                    document.getElementById("progressBar").style.width = percent + "%";
                    document.getElementById("progressText").textContent = text;
                }
                
                function addLogEntry(message, type = "info") {
                    const logContainer = document.getElementById("logContainer");
                    const logEntry = document.createElement("div");
                    logEntry.className = "log-entry " + type;
                    logEntry.textContent = message;
                    logContainer.appendChild(logEntry);
                    logContainer.scrollTop = logContainer.scrollHeight;
                }
              </script>';
        
        // 刷新输出缓冲区，确保进度条可见
        ob_flush();
        flush();
        
        echo '<script>updateProgress(0, "正在处理图标 0/' . $totalLinks . '...");</script>';
        ob_flush();
        flush();
        
        // 处理每个链接的图标
        foreach ($links as $index => $link) {
            $id = $link['id'];
            $url = $link['url'];
            $title = $link['title'];
            $icon = $link['icon'] ?? '';
            $iconUrl = $link['icon_url'] ?? '';
            $iconColor = $link['icon_color'] ?? '#6b7280';
            
            // 更新进度
            $percent = ($index + 1) / $totalLinks * 100;
            echo '<script>
                    updateProgress(' . $percent . ', "正在处理图标 ' . ($index + 1) . '/' . $totalLinks . '...");
                    addLogEntry("处理链接 #' . $id . ': ' . htmlspecialchars($title) . '");
                  </script>';
            ob_flush();
            flush();
            
            try {
                $cacheKey = 'link_' . $id;
                $cacheFile = $cachePath . '/' . $cacheKey . '.png';
                $cacheData = [
                    'id' => $id,
                    'title' => $title,
                    'type' => '',
                    'value' => '',
                    'color' => $iconColor,
                    'cache_path' => '',
                    'cache_url' => '',
                    'updated_at' => time()
                ];
                
                // 根据缓存类型处理
                if (!empty($iconUrl) && ($cacheType === 'all' || $cacheType === 'url_only')) {
                    // 处理URL图标
                    $cacheData['type'] = 'url';
                    $cacheData['value'] = $iconUrl;
                    
                    // 检查是否需要刷新缓存
                    $needRefresh = true;
                    if (isset($iconMap[$cacheKey]) && !$forceRefresh) {
                        $existingCache = $iconMap[$cacheKey];
                        if (isset($existingCache['updated_at']) && 
                            (time() - $existingCache['updated_at'] < $cacheExpiry * 86400) &&
                            file_exists($cachePath . '/' . $cacheKey . '.png')) {
                            // 缓存有效，跳过
                            $skippedCount++;
                            $cacheData = $existingCache;
                            $needRefresh = false;
                            echo '<script>addLogEntry("- 使用现有缓存: ' . $cacheKey . '.png", "info");</script>';
                        }
                    }
                    
                    if ($needRefresh) {
                        // 下载图标并保存到缓存
                        $iconData = file_get_contents($iconUrl);
                        if ($iconData !== false) {
                            file_put_contents($cacheFile, $iconData);
                            $cacheData['cache_path'] = $cacheFile;
                            $cacheData['cache_url'] = '/cache/icons/' . $cacheKey . '.png';
                            $successCount++;
                            echo '<script>addLogEntry("- 图标缓存成功: ' . $cacheKey . '.png", "success");</script>';
                        } else {
                            // 下载失败，使用文字图标
                            $cacheData['type'] = 'text';
                            $cacheData['value'] = mb_substr($title, 0, 1, 'UTF-8');
                            $errorCount++;
                            echo '<script>addLogEntry("- 图标下载失败，使用文字图标", "error");</script>';
                        }
                    }
                } elseif (!empty($icon) && $icon !== 'fas fa-link' && ($cacheType === 'all' || $cacheType === 'fa_only')) {
                    // 处理Font Awesome图标
                    $cacheData['type'] = 'fa';
                    $cacheData['value'] = $icon;
                    $successCount++;
                    echo '<script>addLogEntry("- 使用Font Awesome图标: ' . htmlspecialchars($icon) . '", "success");</script>';
                } else {
                    // 使用文字图标
                    $cacheData['type'] = 'text';
                    $cacheData['value'] = mb_substr($title, 0, 1, 'UTF-8');
                    $skippedCount++;
                    echo '<script>addLogEntry("- 使用文字图标: ' . htmlspecialchars(mb_substr($title, 0, 1, 'UTF-8')) . '", "info");</script>';
                }
                
                // 更新缓存映射
                $iconMap[$cacheKey] = $cacheData;
                $processedCount++;
                
                ob_flush();
                flush();
                
            } catch (Exception $e) {
                $errorCount++;
                echo '<script>addLogEntry("✗ 图标处理失败: ' . htmlspecialchars($e->getMessage()) . '", "error");</script>';
                ob_flush();
                flush();
            }
            
            // 短暂暂停，避免请求过于频繁
            usleep(50000); // 0.05秒
        }
        
        // 保存缓存映射
        file_put_contents($cacheMapPath, json_encode($iconMap, JSON_PRETTY_PRINT));
        
        // 显示处理完成
        echo '<script>updateProgress(100, "处理完成");</script>';
        echo '<script>addLogEntry("✓ 缓存映射文件已保存到: ' . $cacheMapPath . '", "success");</script>';
        
        // 显示摘要
        echo '<div class="summary">
                <h3>处理摘要</h3>
                <div class="summary-item">
                    <span class="summary-label">总链接数</span>
                    <span class="summary-value">' . $totalLinks . '</span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">处理数</span>
                    <span class="summary-value">' . $processedCount . '</span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">成功缓存</span>
                    <span class="summary-value success">' . $successCount . '</span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">跳过</span>
                    <span class="summary-value">' . $skippedCount . '</span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">失败</span>
                    <span class="summary-value error">' . $errorCount . '</span>
                </div>
              </div>';
        
        // 显示部分缓存图标预览
        echo '<h3>缓存图标预览</h3>';
        echo '<div class="icon-grid">';
        
        $previewCount = 0;
        foreach ($iconMap as $key => $data) {
            if ($previewCount >= 20) break; // 最多显示20个
            
            if ($data['type'] === 'url' && !empty($data['cache_url'])) {
                echo '<div class="icon-item">
                        <div class="icon-preview">
                            <img src="' . htmlspecialchars($data['cache_url']) . '" alt="' . htmlspecialchars($data['title']) . '">
                        </div>
                        <div class="icon-name">' . htmlspecialchars($data['title']) . '</div>
                      </div>';
                $previewCount++;
            }
        }
        
        echo '</div>';
        
        // 显示操作按钮
        echo '<div class="btn-group">
                <a href="icon_cache.php" class="btn btn-primary">
                    <i class="fas fa-redo"></i> 重新配置
                </a>
                <a href="/admin/links.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> 返回链接管理
                </a>
              </div>';
        
    } catch (Exception $e) {
        echo '<div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> 错误: ' . htmlspecialchars($e->getMessage()) . '
              </div>';
    }
}

echo '      </div>
        </div>
    </div>
</body>
</html>';
?>
