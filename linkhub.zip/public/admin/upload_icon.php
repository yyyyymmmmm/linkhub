<?php
require_once 'auth.php';
checkPermission('editor');

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'data' => null];

try {
    // 检查是否有文件上传
    if (!isset($_FILES['icon']) || $_FILES['icon']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('文件上传失败：' . ($_FILES['icon']['error'] ?? '未知错误'));
    }
    
    $file = $_FILES['icon'];
    
    // 验证文件类型
    $allowedTypes = ['image/png', 'image/jpeg', 'image/gif', 'image/svg+xml'];
    $fileType = mime_content_type($file['tmp_name']);
    
    if (!in_array($fileType, $allowedTypes)) {
        throw new Exception('不支持的文件类型，请上传PNG、JPG、GIF或SVG图片');
    }
    
    // 验证文件大小（限制为2MB）
    if ($file['size'] > 2 * 1024 * 1024) {
        throw new Exception('文件大小不能超过2MB');
    }
    
    // 创建上传目录
    $uploadDir = '../uploads/icons/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // 生成唯一文件名
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = uniqid('icon_') . '.' . $extension;
    $targetPath = $uploadDir . $fileName;
    
    // 移动上传的文件
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new Exception('文件保存失败');
    }
    
    // 返回成功响应
    $response = [
        'success' => true,
        'message' => '图标上传成功',
        'data' => [
            'url' => '/uploads/icons/' . $fileName,
            'name' => $fileName,
            'type' => $fileType
        ]
    ];
    
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>