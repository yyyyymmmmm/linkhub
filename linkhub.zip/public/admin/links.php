<?php
require_once 'auth.php';

// 检查权限
checkPermission('editor');


// $pdo 已在 auth.php 中定义

// 处理操作
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$message = '';
$messageType = '';

// 分页参数
$page = intval($_GET['page'] ?? 1);
$limit = 20;
$offset = ($page - 1) * $limit;

// 搜索参数
$search = trim($_GET['search'] ?? '');
$categoryFilter = intval($_GET['category'] ?? 0);
$propertyFilter = $_GET['property'] ?? '';

try {
    switch ($action) {
        case 'add':
        case 'create':
            if ($_POST) {
                $title = trim($_POST['title'] ?? '');
                $url = trim($_POST['url'] ?? '');
                $fid = intval($_POST['fid'] ?? 0);
                $note = trim($_POST['note'] ?? '');
                $font_icon = trim($_POST['font_icon'] ?? '');
                $icon_color = trim($_POST['icon_color'] ?? '#6366f1');
                $weight = intval($_POST['weight'] ?? 0);
                
                if (empty($title) || empty($url)) {
                    throw new Exception('标题和链接不能为空');
                }
                
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    throw new Exception('请输入有效的URL地址');
                }
                
                // 获取图标URL
                $icon_url = trim($_POST['icon_url'] ?? '');
                $icon_type = trim($_POST['icon_type'] ?? 'url');
                
                $stmt = $pdo->prepare("INSERT INTO " . $tablePrefix . "links (fid, title, url, note, font_icon, icon_url, icon_color, weight, property, add_time, up_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)");
                $currentTime = time();
                $stmt->execute([$fid, $title, $url, $note, $font_icon, $icon_url, $icon_color, $weight, $currentTime, $currentTime]);
                
                $message = '链接添加成功';
                $messageType = 'success';
                
                // 添加成功后重定向到列表页面
                header('Location: /admin/links.php');
                exit;
            }
            break;
            
        case 'edit':
        case 'update':
            $editId = intval($_GET['id'] ?? $_POST['id'] ?? 0);
            if ($_POST) {
                $title = trim($_POST['title'] ?? '');
                $url = trim($_POST['url'] ?? '');
                $fid = intval($_POST['fid'] ?? 0);
                $note = trim($_POST['note'] ?? '');
                $font_icon = trim($_POST['font_icon'] ?? '');
                $icon_color = trim($_POST['icon_color'] ?? '#6366f1');
                $weight = intval($_POST['weight'] ?? 0);
                
                if (empty($title) || empty($url)) {
                    throw new Exception('标题和链接不能为空');
                }
                
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    throw new Exception('请输入有效的URL地址');
                }
                
                // 获取图标URL
                $icon_url = trim($_POST['icon_url'] ?? '');
                $icon_type = trim($_POST['icon_type'] ?? 'url');
                
                $stmt = $pdo->prepare("UPDATE " . $tablePrefix . "links SET fid = ?, title = ?, url = ?, note = ?, font_icon = ?, icon_url = ?, icon_color = ?, weight = ?, up_time = ? WHERE id = ?");
                $stmt->execute([$fid, $title, $url, $note, $font_icon, $icon_url, $icon_color, $weight, time(), $editId]);
                
                $message = '链接更新成功';
                $messageType = 'success';
                
                // 更新成功后重定向到列表页面
                header('Location: /admin/links.php');
                exit;
            }
            break;
            
        case 'delete':
            $id = intval($_GET['id']);
            if ($id > 0) {
                $pdo->prepare("DELETE FROM " . $tablePrefix . "links WHERE id = ?")->execute([$id]);
                $message = '链接删除成功';
                $messageType = 'success';
            }
            break;
            
        case 'batch_delete':
            if (!empty($_POST['ids'])) {
                $ids = array_map('intval', $_POST['ids']);
                $placeholders = str_repeat('?,', count($ids) - 1) . '?';
                $pdo->prepare("DELETE FROM " . $tablePrefix . "links WHERE id IN ($placeholders)")->execute($ids);
                $message = '批量删除成功，共删除 ' . count($ids) . ' 个链接';
                $messageType = 'success';
            }
            break;
            
        case 'update_property':
            if (!empty($_POST['ids']) && isset($_POST['property'])) {
                $ids = array_map('intval', $_POST['ids']);
                $property = intval($_POST['property']);
                $placeholders = str_repeat('?,', count($ids) - 1) . '?';
                $params = array_merge([$property], $ids);
                $pdo->prepare("UPDATE " . $tablePrefix . "links SET property = ? WHERE id IN ($placeholders)")->execute($params);
                $message = '批量更新属性成功';
                $messageType = 'success';
            }
            break;
    }
} catch (Exception $e) {
    $message = $e->getMessage();
    $messageType = 'error';
}

// 构建查询条件
$whereConditions = [];
$params = [];

if ($search) {
    $whereConditions[] = "(l.title LIKE ? OR l.url LIKE ? OR l.note LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($categoryFilter > 0) {
    $whereConditions[] = "l.fid = ?";
    $params[] = $categoryFilter;
}

if ($propertyFilter !== '') {
    $whereConditions[] = "l.property = ?";
    $params[] = intval($propertyFilter);
}

$whereClause = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// 获取总数
$countSql = "SELECT COUNT(*) FROM " . $tablePrefix . "links l $whereClause";
$totalCount = $pdo->prepare($countSql);
$totalCount->execute($params);
$totalCount = $totalCount->fetchColumn();

// 获取链接列表
$sql = "
    SELECT l.*, c.name as category_name
    FROM " . $tablePrefix . "links l 
    LEFT JOIN " . $tablePrefix . "categorys c ON l.fid = c.id 
    $whereClause
    ORDER BY l.weight DESC, l.id DESC 
    LIMIT $limit OFFSET $offset
";
$links = $pdo->prepare($sql);
$links->execute($params);
$links = $links->fetchAll(PDO::FETCH_ASSOC);

// 获取分类列表用于筛选
$categories = $pdo->query("SELECT id, name FROM " . $tablePrefix . "categorys ORDER BY weight DESC, name ASC")->fetchAll(PDO::FETCH_ASSOC);

// 如果是编辑模式，获取要编辑的链接数据
$editLink = null;
if (($action === 'edit' || $action === 'add') && isset($_GET['id'])) {
    $editId = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT * FROM " . $tablePrefix . "links WHERE id = ?");
    $stmt->execute([$editId]);
    $editLink = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // 如果数据库没有icon_url和icon_color字段，设置默认值
    if ($editLink && !array_key_exists('icon_url', $editLink)) {
        $editLink['icon_url'] = '';
    }
    if ($editLink && !array_key_exists('icon_color', $editLink)) {
        $editLink['icon_color'] = '#6b7280';
    }
}

// 计算分页信息
$totalPages = ceil($totalCount / $limit);
$startNum = $offset + 1;
$endNum = min($offset + $limit, $totalCount);

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>链接管理 - LinkHub</title>
    <link rel="stylesheet" href="../assets/css/admin-modern.css?v=2.0.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* 链接表单样式 */
        .link-form {
            margin: 0;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }
        
        @media (max-width: 992px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
        
        .form-col {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        
        .form-section {
            background-color: #f9fafb;
            border-radius: 8px;
            padding: 1.25rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        
        .section-title {
            font-size: 1rem;
            font-weight: 600;
            color: #374151;
            margin-top: 0;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #4b5563;
        }
        
        .form-label .required {
            color: #ef4444;
            margin-left: 2px;
        }
        
        .form-control {
            width: 100%;
            padding: 0.5rem 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            font-size: 0.875rem;
        }
        
        .input-group {
            display: flex;
            width: 100%;
        }
        
        .input-group .form-control {
            flex: 1;
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }
        
        .input-group-text {
            display: flex;
            align-items: center;
            padding: 0.5rem 0.75rem;
            background-color: #f3f4f6;
            border: 1px solid #d1d5db;
            border-right: none;
            border-radius: 0.375rem 0 0 0.375rem;
            color: #6b7280;
        }
        
        .input-group-append .btn {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }
        
        .form-helper {
            margin-top: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .form-actions {
            margin-top: 1.5rem;
            display: flex;
            gap: 0.75rem;
        }
        
        /* 图标选择器选项卡样式 */
        .icon-tabs {
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 1rem;
        }
        
        .icon-tab-buttons {
            display: flex;
            border-bottom: 1px solid #e5e7eb;
            background-color: #f3f4f6;
        }
        
        .icon-tab-btn {
            flex: 1;
            padding: 8px 12px;
            text-align: center;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            color: #6b7280;
            transition: all 0.2s;
        }
        
        .icon-tab-btn:not(:last-child) {
            border-right: 1px solid #e5e7eb;
        }
        
        .icon-tab-btn.active {
            background-color: #fff;
            color: #6366f1;
            border-bottom: 2px solid #6366f1;
            margin-bottom: -1px;
        }
        
        .icon-tab-content {
            padding: 15px;
            background-color: #fff;
        }
        
        .icon-tab-pane {
            display: none;
        }
        
        .icon-tab-pane.active {
            display: block;
        }
        
        /* 图标上传样式 */
        .icon-upload-container {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .icon-preview-area {
            width: 64px;
            height: 64px;
            border: 1px dashed #d1d5db;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background-color: #fff;
        }
        
        .icon-preview-area img {
            max-width: 100%;
            max-height: 100%;
        }
        
        .icon-preview-placeholder {
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #9ca3af;
        }
        
        .icon-preview-placeholder i {
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .icon-preview-placeholder span {
            font-size: 12px;
        }
        
        .icon-upload-controls {
            flex: 1;
        }
        
        /* 图标URL预览 */
        .icon-url-preview {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 0.75rem;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 侧边栏 -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-compass"></i>
                </div>
                <div class="brand">LinkHub</div>
                <button class="sidebar-toggle"id="sidebarToggle"  id="sidebarToggle">
                    <i class="fas fa-chevron-left"></i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="/admin/" data-title="控制台">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>控制台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php" data-title="分类管理">
                            <i class="fas fa-folder"></i>
                            <span>分类管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php" data-title="链接管理">
                            <i class="fas fa-link"></i>
                            <span>链接管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/links.php?action=add" data-title="添加链接">
                            <i class="fas fa-plus"></i>
                            <span>添加链接</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/categories.php?action=add" data-title="添加分类">
                            <i class="fas fa-folder-plus"></i>
                            <span>添加分类</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/import.php" data-title="导入书签">
                            <i class="fas fa-upload"></i>
                            <span>导入书签</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/users.php" data-title="用户管理">
                            <i class="fas fa-users"></i>
                            <span>用户管理</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/settings.php" data-title="系统设置">
                            <i class="fas fa-cog"></i>
                            <span>系统设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/themes.php" data-title="主题设置">
                            <i class="fas fa-palette"></i>
                            <span>主题设置</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/backup.php" data-title="备份恢复">
                            <i class="fas fa-database"></i>
                            <span>备份恢复</span>
                        </a>
                    </li>
                    <li>
                        <a href="/" target="_blank" data-title="查看前台">
                            <i class="fas fa-external-link-alt"></i>
                            <span>查看前台</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/?action=logout" data-title="退出登录">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>退出登录</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- 遮罩层 -->
        <div class="sidebar-overlay" ></div>

        <!-- 主内容区域 -->
        <main class="admin-content">
            <!-- 顶部导航栏 -->
            <header class="admin-header">
                <div class="header-title">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <i class="fas fa-link"></i>
                    <span>链接管理</span>
                </div>
                <div class="header-actions">
                    <a href="/admin/links.php?action=add" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i>
                        添加链接
                    </a>
                    <a href="/admin/import.php" class="btn btn-secondary btn-sm">
                        <i class="fas fa-upload"></i>
                        导入书签
                    </a>
                    <button type="button" class="btn btn-success btn-sm" onclick="showExportOptions()">
                        <i class="fas fa-download"></i>
                        导出书签
                    </button>
                </div>
            </header>

            <!-- 主体内容 -->
            <div class="admin-main">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType ?>">
                        <i class="fas fa-<?= $messageType === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>
                
                <?php if (strpos($message, 'SQLSTATE[HY000]: General error: 1 no such column: icon_url') !== false): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-database"></i>
                        <strong>数据库需要升级：</strong> 系统检测到您的数据库需要更新以支持新功能。
                        <a href="/admin/update_database.php" class="btn btn-sm btn-warning ml-2">
                            <i class="fas fa-sync"></i> 立即升级数据库
                        </a>
                    </div>
                <?php
 endif; ?>

                <!-- 添加/编辑链接表单 -->
                <?php if ($action === 'add' || $action === 'edit'): ?>
                <div class="card">
                    <div class="card-header">
                        <h3>
                            <i class="fas <?= $action === 'add' ? 'fa-plus-circle' : 'fa-edit' ?>"></i>
                            <?= $action === 'add' ? '添加链接' : '编辑链接' ?>
                        </h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="/admin/links.php?action=<?= $action === 'add' ? 'create' : 'update' ?><?= $editLink ? '&id=' . $editLink['id'] : '' ?>" class="link-form">
                            <?php if ($editLink): ?>
                                <input type="hidden" name="id" value="<?= $editLink['id'] ?>">
                            <?php endif; ?>
                            
                            <div class="form-row">
                                <div class="form-col">
                                    <!-- 基本信息 -->
                                    <div class="form-section">
                                        <h4 class="section-title">基本信息</h4>
                                        
                                <div class="form-group">
                                            <label class="form-label">链接标题 <span class="required">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-heading"></i></span>
                                    <input type="text" name="title" class="form-control" 
                                           value="<?= htmlspecialchars($editLink['title'] ?? '') ?>" 
                                           placeholder="输入链接标题" required>
                                            </div>
                                </div>
                                
                                <div class="form-group">
                                            <label class="form-label">链接地址 <span class="required">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-link"></i></span>
                                                <input type="url" name="url" id="linkUrl" class="form-control" 
                                           value="<?= htmlspecialchars($editLink['url'] ?? '') ?>" 
                                           placeholder="https://example.com" required>
                                </div>
                                            <div class="form-helper">
                                                <button type="button" class="btn btn-outline-primary btn-sm" id="autoRecognizeBtn">
                                                    <i class="fas fa-magic"></i> 智能识别网站信息
                                                </button>
                                                <small class="text-muted">自动获取网站标题、图标和描述</small>
                                            </div>
                            </div>
                            
                                <div class="form-group">
                                    <label class="form-label">所属分类</label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-folder"></i></span>
                                    <select name="fid" class="form-control form-select">
                                        <option value="0">无分类</option>
                                        <?php foreach ($categories as $cat): ?>
                                            <option value="<?= $cat['id'] ?>" <?= ($editLink['fid'] ?? 0) == $cat['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($cat['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                            </div>
                                </div>
                                
                                <div class="form-group">
                                            <label class="form-label">备注描述</label>
                                            <textarea name="note" class="form-control" rows="3" 
                                                placeholder="链接的详细描述（可选）"><?= htmlspecialchars($editLink['note'] ?? '') ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-col">
                                    <!-- 图标设置 -->
                                    <div class="form-section">
                                        <h4 class="section-title">图标设置</h4>
                                        
                                        <div class="icon-tabs">
                                            <div class="icon-tab-buttons">
                                                <button type="button" class="icon-tab-btn active" data-tab="icon-tab-1">上传图标</button>
                                                <button type="button" class="icon-tab-btn" data-tab="icon-tab-2">图标链接</button>
                                            </div>
                                            
                                            <div class="icon-tab-content">
                                                <!-- 上传图标选项卡 -->
                                                <div class="icon-tab-pane active" id="icon-tab-1">
                                                    <div class="icon-upload-container">
                                                        <div class="icon-preview-area">
                                                            <?php if (!empty($editLink['icon_url'])): ?>
                                                                <img src="<?= htmlspecialchars($editLink['icon_url']) ?>" alt="图标预览" id="uploadedIconPreview">
                                                            <?php else: ?>
                                                                <div class="icon-preview-placeholder" id="uploadedIconPreview">
                                                                    <i class="fas fa-image"></i>
                                                                    <span>图标预览</span>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="icon-upload-controls">
                                                            <input type="file" id="iconUploadInput" accept="image/png,image/jpeg,image/gif,image/svg+xml" style="display: none;">
                                                            <button type="button" class="btn btn-outline-primary btn-sm" id="selectFileBtn">
                                                                <i class="fas fa-upload"></i> 选择图片
                                                            </button>
                                                            <small class="text-muted d-block mt-2">支持PNG、JPG、GIF、SVG格式，建议尺寸32×32像素</small>
                                                        </div>
                                                    </div>
                                                    <input type="hidden" id="iconUrlInput" value="<?= htmlspecialchars($editLink['icon_url'] ?? '') ?>">
                                                </div>
                                                
                                                <!-- 图标链接选项卡 -->
                                                <div class="icon-tab-pane" id="icon-tab-2">
                                                    <div class="input-group">
                                                        <span class="input-group-text"><i class="fas fa-link"></i></span>
                                                        <input type="text" class="form-control" id="iconUrlExternal" name="icon_url"
                                                            placeholder="输入图标URL或网站favicon地址" 
                                                            value="<?= htmlspecialchars($editLink['icon_url'] ?? '') ?>">
                                                    </div>
                                                    <div class="icon-url-preview mt-2">
                                                        <?php if (!empty($editLink['icon_url'])): ?>
                                                            <img src="<?= htmlspecialchars($editLink['icon_url']) ?>" alt="图标预览" id="externalIconPreview" style="max-width: 32px; max-height: 32px;">
                                                        <?php else: ?>
                                                            <div class="icon-preview-placeholder" id="externalIconPreview">
                                                                <i class="fas fa-link"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <small class="text-muted d-block mt-2">直接输入图标URL地址</small>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <input type="hidden" name="icon_type" id="iconTypeInput" value="<?= htmlspecialchars($editLink['icon_type'] ?? 'url') ?>">
                                        <!-- 保留这些字段但设为空值，确保兼容性 -->
                                        <input type="hidden" name="font_icon" id="linkIcon" value="">
                                        <input type="hidden" name="icon_color" id="linkIconColor" value="">
                                    </div>
                                    
                                    <!-- 高级设置 -->
                                    <div class="form-section">
                                        <h4 class="section-title">高级设置</h4>
                                
                                <div class="form-group">
                                    <label class="form-label">权重</label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-sort-amount-up"></i></span>
                                    <input type="number" name="weight" class="form-control" 
                                           value="<?= $editLink['weight'] ?? 0 ?>" 
                                           placeholder="0">
                                </div>
                                            <small class="text-muted">数值越大排序越靠前</small>
                            </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> 
                                    <?= $action === 'add' ? '添加链接' : '更新链接' ?>
                                </button>
                                <a href="/admin/links.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> 取消
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <!-- 筛选和搜索 -->
                <?php if ($action !== 'add' && $action !== 'edit'): ?>
                <div class="card">
                    <div class="card-body">
                        <form method="GET" class="filter-form">
                            <div style="display: grid; grid-template-columns: 1fr 200px 150px auto; gap: 1rem; align-items: end;">
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label class="form-label">搜索链接</label>
                                    <input type="text" name="search" class="form-control" 
                                           value="<?= htmlspecialchars($search) ?>" 
                                           placeholder="标题、URL或备注">
                                </div>
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label class="form-label">分类筛选</label>
                                    <select name="category" class="form-control form-select">
                                        <option value="0">全部分类</option>
                                        <?php foreach ($categories as $cat): ?>
                                            <option value="<?= $cat['id'] ?>" <?= $categoryFilter == $cat['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($cat['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group" style="margin-bottom: 0;">
                                    <label class="form-label">属性筛选</label>
                                    <select name="property" class="form-control form-select">
                                        <option value="">全部</option>
                                        <option value="0" <?= $propertyFilter === '0' ? 'selected' : '' ?>>公开</option>
                                        <option value="1" <?= $propertyFilter === '1' ? 'selected' : '' ?>>私有</option>
                                    </select>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                        搜索
                                    </button>
                                    <a href="/admin/links.php" class="btn btn-secondary">
                                        <i class="fas fa-times"></i>
                                        重置
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- 批量操作栏 -->
                <div class="batch-actions" id="batchActions" style="display: none;">
                    <div class="selected-info">
                        <span>已选择 <strong class="selected-count">0</strong> 个链接</span>
                        <div class="action-buttons">
                            <button type="button" class="btn btn-warning btn-sm" onclick="batchUpdateProperty(0)">
                                <i class="fas fa-eye"></i>
                                设为公开
                            </button>
                            <button type="button" class="btn btn-secondary btn-sm" onclick="batchUpdateProperty(1)">
                                <i class="fas fa-eye-slash"></i>
                                设为私有
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" onclick="batchDelete()">
                                <i class="fas fa-trash"></i>
                                批量删除
                            </button>
                        </div>
                    </div>
                </div>

                <!-- 链接表格 -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-list"></i>
                            链接列表
                            <?php if ($totalCount > 0): ?>
                                <small class="text-muted">
                                    (显示第 <?= $startNum ?> - <?= $endNum ?> 条，共 <?= $totalCount ?> 条)
                                </small>
                            <?php endif; ?>
                        </h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($links)): ?>
                            <div class="table-responsive" style="min-width: 1000px; overflow-x: auto;">
                                <table class="table" style="min-width: 1000px; table-layout: fixed;">
                                    <thead>
                                        <tr>
                                            <th width="50" style="min-width: 50px;">
                                                <input type="checkbox" class="select-all" onchange="toggleSelectAll()">
                                            </th>
                                            <th style="min-width: 200px;">链接信息</th>
                                            <th width="120" style="min-width: 120px; white-space: nowrap;">分类</th>
                                            <th width="80" style="min-width: 80px; white-space: nowrap;">权重</th>
                                            <th width="80" style="min-width: 80px; white-space: nowrap;">属性</th>
                                            <th width="80" style="min-width: 80px; white-space: nowrap;">点击数</th>
                                            <th width="120" style="min-width: 120px; white-space: nowrap;">添加时间</th>
                                            <th width="120" style="min-width: 120px; white-space: nowrap;">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($links as $link): ?>
                                        <tr class="search-item">
                                            <td>
                                                <input type="checkbox" class="select-item" value="<?= $link['id'] ?>" onchange="updateBatchActions()">
                                            </td>
                                            <td>
                                                <div class="link-info">
                                                    <div class="link-title">
                                                        <?php if (!empty($link['icon_url'])): ?>
                                                            <img src="<?= htmlspecialchars($link['icon_url']) ?>" alt="" style="width: 16px; height: 16px;">
                                                        <?php elseif ($link['font_icon']): ?>
                                                            <?php if (strpos($link['font_icon'], 'fa-') !== false): ?>
                                                                <i class="fa <?= htmlspecialchars($link['font_icon']) ?>" style="color: <?= htmlspecialchars($link['icon_color'] ?? '#6366f1') ?>;"></i>
                                                            <?php else: ?>
                                                                <img src="<?= htmlspecialchars($link['font_icon']) ?>" alt="" style="width: 16px; height: 16px;">
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <i class="fas fa-link"></i>
                                                        <?php endif; ?>
                                                        <strong><?= htmlspecialchars($link['title']) ?></strong>
                                                    </div>
                                                    <div class="link-url">
                                                        <a href="<?= htmlspecialchars($link['url']) ?>" target="_blank" class="text-muted">
                                                            <?= htmlspecialchars($link['url']) ?>
                                                        </a>
                                                    </div>
                                                    <?php if ($link['note']): ?>
                                                        <div class="link-note">
                                                            <small class="text-muted"><?= htmlspecialchars($link['note']) ?></small>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td style="white-space: nowrap;">
                                                <span class="badge badge-info">
                                                    <?= $link['category_name'] ?: '未分类' ?>
                                                </span>
                                            </td>
                                            <td style="white-space: nowrap;"><span class="badge badge-primary"><?= $link['weight'] ?></span></td>
                                            <td style="white-space: nowrap;">
                                                <span class="badge <?= $link['property'] == 0 ? 'badge-success' : 'badge-warning' ?>">
                                                    <?= $link['property'] == 0 ? '公开' : '私有' ?>
                                                </span>
                                            </td>
                                            <td style="white-space: nowrap;"><span class="badge badge-secondary"><?= number_format($link['click']) ?></span></td>
                                            <td style="white-space: nowrap;"><?= date('Y-m-d H:i', $link['add_time']) ?></td>
                                            <td>
                                                <div style="display: flex; gap: 0.25rem;">
                                                    <a href="<?= htmlspecialchars($link['url']) ?>" target="_blank" 
                                                       class="btn btn-info btn-sm" title="访问">
                                                        <i class="fas fa-external-link-alt"></i>
                                                    </a>
                                                    <a href="/admin/links.php?action=edit&id=<?= $link['id'] ?>" 
                                                       class="btn btn-secondary btn-sm" title="编辑">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="?action=delete&id=<?= $link['id'] ?>" 
                                                       class="btn btn-danger btn-sm delete-btn" title="删除" 
                                                       data-message="确定要删除链接「<?= htmlspecialchars($link['title']) ?>」吗？">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- 分页 -->
                            <?php if ($totalPages > 1): ?>
                                <div class="pagination-wrapper">
                                    <nav class="pagination">
                                        <?php

                                        $queryParams = $_GET;
                                        unset($queryParams['page']);
                                        $baseQuery = http_build_query($queryParams);
                                        $baseUrl = '/admin/links.php?' . ($baseQuery ? $baseQuery . '&' : '');
                                        ?>
                                        
                                        <?php if ($page > 1): ?>
                                            <a href="<?= $baseUrl ?>page=<?= $page - 1 ?>" class="page-link">
                                                <i class="fas fa-chevron-left"></i>
                                                上一页
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php

                                        $startPage = max(1, $page - 2);
                                        $endPage = min($totalPages, $page + 2);
                                        ?>
                                        
                                        <?php
 if ($startPage > 1): ?>
                                            <a href="<?= $baseUrl ?>page=1" class="page-link">1</a>
                                            <?php
 if ($startPage > 2): ?>
                                                <span class="page-ellipsis">...</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <?php
 for ($i = $startPage; $i <= $endPage; $i++): ?>
                                            <a href="<?= $baseUrl ?>page=<?= $i ?>" 
                                               class="page-link <?= $i == $page ? 'active' : '' ?>">
                                                <?= $i ?>
                                            </a>
                                        <?php
 endfor; ?>
                                        
                                        <?php
 if ($endPage < $totalPages): ?>
                                            <?php
 if ($endPage < $totalPages - 1): ?>
                                                <span class="page-ellipsis">...</span>
                                            <?php endif; ?>
                                            <a href="<?= $baseUrl ?>page=<?= $totalPages ?>" class="page-link"><?= $totalPages ?></a>
                                        <?php endif; ?>
                                        
                                        <?php
 if ($page < $totalPages): ?>
                                            <a href="<?= $baseUrl ?>page=<?= $page + 1 ?>" class="page-link">
                                                下一页
                                                <i class="fas fa-chevron-right"></i>
                                            </a>
                                        <?php endif; ?>
                                    </nav>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-link"></i>
                                <p><?= $search || $categoryFilter || $propertyFilter !== '' ? '没有找到符合条件的链接' : '暂无链接数据' ?></p>
                                <a href="/admin/links.php?action=add" class="btn btn-primary">添加第一个链接</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- 导出选项模态框 -->
    <div id="exportModal" class="export-modal" style="display: none;">
        <div class="export-modal-overlay" onclick="hideExportOptions()"></div>
        <div class="export-modal-content">
            <div class="export-modal-header">
                <h3>
                    <i class="fas fa-download"></i>
                    导出书签
                </h3>
                <button type="button" class="export-close-btn" onclick="hideExportOptions()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="export-modal-body">
                <div class="export-format-grid">
                    <div class="export-format-card" onclick="quickExport('html')">
                        <div class="export-format-icon">
                            <i class="fas fa-file-code"></i>
                        </div>
                        <div class="export-format-info">
                            <h4>HTML格式</h4>
                            <p>标准书签文件，可直接导入浏览器</p>
                        </div>
                    </div>
                    
                    <div class="export-format-card" onclick="quickExport('json')">
                        <div class="export-format-icon">
                            <i class="fas fa-code"></i>
                        </div>
                        <div class="export-format-info">
                            <h4>JSON格式</h4>
                            <p>结构化数据，适合程序处理</p>
                        </div>
                    </div>
                    
                    <div class="export-format-card" onclick="quickExport('csv')">
                        <div class="export-format-icon">
                            <i class="fas fa-file-csv"></i>
                        </div>
                        <div class="export-format-info">
                            <h4>CSV格式</h4>
                            <p>Excel兼容，方便查看编辑</p>
                        </div>
                    </div>
                </div>
                
                <div class="export-divider">
                    <span>或者</span>
                </div>
                
                <div class="export-advanced">
                    <button type="button" class="btn btn-outline-primary btn-block" onclick="showAdvancedExport()">
                        <i class="fas fa-cog"></i>
                        高级导出选项
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 高级导出模态框 -->
    <div id="advancedExportModal" class="export-modal" style="display: none;">
        <div class="export-modal-overlay" onclick="hideAdvancedExport()"></div>
        <div class="export-modal-content">
            <div class="export-modal-header">
                <h3>
                    <i class="fas fa-cog"></i>
                    高级导出设置
                </h3>
                <button type="button" class="export-close-btn" onclick="hideAdvancedExport()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="export-modal-body">
                <form id="advancedExportForm">
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-file-alt"></i>
                            导出格式
                        </label>
                        <select name="format" class="form-control" required>
                            <option value="html">HTML格式（标准书签文件）</option>
                            <option value="json">JSON格式（结构化数据）</option>
                            <option value="csv">CSV格式（Excel兼容）</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-folder"></i>
                            选择分类
                        </label>
                        <select name="category" class="form-control">
                            <option value="0">全部分类</option>
                            <?php
                            try {
                                $categories = $pdo->query("SELECT id, name FROM " . $tablePrefix . "categorys ORDER BY weight ASC, id ASC")->fetchAll();
                                foreach ($categories as $cat) {
                                    echo '<option value="' . $cat['id'] . '">' . htmlspecialchars($cat['name']) . '</option>';
                                }
                            } catch (Exception $e) {
                                echo '<option value="0">无法加载分类</option>';
                            }
                            ?>
                        </select>
                        <small class="text-muted">选择要导出的分类，或选择"全部分类"导出所有书签</small>
                    </div>
                    
                    <div class="form-group">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="includePrivate" name="include_private" checked>
                            <label class="form-check-label" for="includePrivate">
                                <i class="fas fa-eye-slash"></i>
                                包含私有链接
                            </label>
                        </div>
                        <small class="text-muted">是否包含标记为私有的链接</small>
                    </div>
                </form>
                
                <div class="export-modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="hideAdvancedExport()">
                        <i class="fas fa-times"></i>
                        取消
                    </button>
                    <button type="button" class="btn btn-primary" onclick="startAdvancedExport()">
                        <i class="fas fa-download"></i>
                        开始导出
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 导出进度模态框 -->
    <div id="exportProgressModal" class="export-modal" style="display: none;">
        <div class="export-modal-overlay"></div>
        <div class="export-modal-content" style="max-width: 500px;">
            <div class="export-modal-header">
                <h3>
                    <i class="fas fa-download"></i>
                    正在导出
                </h3>
            </div>
            
            <div class="export-modal-body">
                <div class="export-progress-container">
                    <div class="export-progress-icon">
                        <i class="fas fa-file-export"></i>
                    </div>
                    
                    <div class="export-progress-info">
                        <div id="exportProgressText" class="export-progress-text">
                            正在准备导出...
                        </div>
                        
                        <div class="export-progress-bar-container">
                            <div class="export-progress-bar-bg">
                                <div id="exportProgressBar" class="export-progress-bar"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="export-progress-tips">
                    <div class="tip-item">
                        <i class="fas fa-info-circle"></i>
                        <span>导出完成后文件将自动下载</span>
                    </div>
                    <div class="tip-item">
                        <i class="fas fa-shield-alt"></i>
                        <span>导出的数据已加密处理，确保安全</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js?v=2.0.1"></script>
    <script src="../assets/js/sidebar-fix.js?v=1.0.0"></script>
    <script>
        // 页面加载时初始化
        document.addEventListener('DOMContentLoaded', function() {
            // 侧边栏控制由 sidebar-fix.js 处理

            // 初始化变量
            const autoRecognizeBtn = document.getElementById('autoRecognizeBtn');
            const linkUrl = document.getElementById('linkUrl');
            const linkTitle = document.querySelector('input[name="title"]');
            
            // 图标选项卡切换功能
            const iconTabBtns = document.querySelectorAll('.icon-tab-btn');
            const iconTabPanes = document.querySelectorAll('.icon-tab-pane');
            const iconTypeInput = document.getElementById('iconTypeInput');
            
            // 根据当前选择的图标类型激活对应选项卡
            function activateTabByIconType() {
                const iconType = iconTypeInput.value || 'upload';
                let tabIndex = 0;
                
                switch(iconType) {
                    case 'upload':
                        tabIndex = 0;
                        break;
                    case 'url':
                        tabIndex = 1;
                        break;
                }
                
                // 激活对应的选项卡
                iconTabBtns.forEach(btn => btn.classList.remove('active'));
                iconTabPanes.forEach(pane => pane.classList.remove('active'));
                
                if (iconTabBtns[tabIndex]) iconTabBtns[tabIndex].classList.add('active');
                if (iconTabPanes[tabIndex]) iconTabPanes[tabIndex].classList.add('active');
            }
            
            // 初始化时激活对应选项卡
            activateTabByIconType();
            
            // 选项卡切换事件
            iconTabBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const tabId = this.getAttribute('data-tab');
                    
                    // 移除所有选项卡的活动状态
                    iconTabBtns.forEach(b => b.classList.remove('active'));
                    iconTabPanes.forEach(p => p.classList.remove('active'));
                    
                    // 激活当前选项卡
                    this.classList.add('active');
                    document.getElementById(tabId).classList.add('active');
                    
                    // 更新图标类型
                    switch(tabId) {
                        case 'icon-tab-1':
                            iconTypeInput.value = 'upload';
                            break;
                        case 'icon-tab-2':
                            iconTypeInput.value = 'url';
                            break;
                    }
                });
            });
            
            // 添加表单提交事件，确保正确设置icon_url
            document.querySelector('.link-form').addEventListener('submit', function(e) {
                // 获取当前激活的选项卡
                const activeTab = document.querySelector('.icon-tab-btn.active');
                if (activeTab) {
                    const tabId = activeTab.getAttribute('data-tab');
                    let iconUrl = '';
                    
                    // 根据选项卡类型获取正确的图标URL
                    if (tabId === 'icon-tab-1') {
                        // 上传图标
                        iconUrl = document.getElementById('iconUrlInput').value;
                    } else if (tabId === 'icon-tab-2') {
                        // 图标链接
                        iconUrl = document.getElementById('iconUrlExternal').value;
                    }
                    
                    // 创建或更新隐藏的icon_url字段
                    let iconUrlField = this.querySelector('input[name="icon_url"]');
                    if (!iconUrlField) {
                        iconUrlField = document.createElement('input');
                        iconUrlField.type = 'hidden';
                        iconUrlField.name = 'icon_url';
                        this.appendChild(iconUrlField);
                    }
                    iconUrlField.value = iconUrl;
                }
            });
            
            // 图标上传功能
            const selectFileBtn = document.getElementById('selectFileBtn');
            const iconUploadInput = document.getElementById('iconUploadInput');
            const uploadedIconPreview = document.getElementById('uploadedIconPreview');
            const iconUrlInput = document.getElementById('iconUrlInput');
            
            if (selectFileBtn && iconUploadInput) {
                selectFileBtn.addEventListener('click', function() {
                    iconUploadInput.click();
                });
                
                iconUploadInput.addEventListener('change', function() {
                    if (this.files && this.files[0]) {
                        const file = this.files[0];
                        
                        // 检查文件类型
                        const validTypes = ['image/png', 'image/jpeg', 'image/gif', 'image/svg+xml'];
                        if (!validTypes.includes(file.type)) {
                            showNotification('请选择有效的图片文件（PNG、JPG、GIF、SVG）', 'error');
                            return;
                        }
                        
                        // 检查文件大小（限制为2MB）
                        if (file.size > 2 * 1024 * 1024) {
                            showNotification('图片大小不能超过2MB', 'error');
                            return;
                        }
                        
                        // 显示上传中状态
                        selectFileBtn.disabled = true;
                        selectFileBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 上传中...';
                        
                        // 创建FormData对象
                        const formData = new FormData();
                        formData.append('icon', file);
                        
                        // 发送上传请求
                        fetch('upload_icon.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // 更新预览图片
                                if (uploadedIconPreview) {
                                    if (uploadedIconPreview.tagName === 'IMG') {
                                        uploadedIconPreview.src = data.data.url;
                                    } else {
                                        // 替换占位符为图片
                                        const img = document.createElement('img');
                                        img.src = data.data.url;
                                        img.alt = '图标预览';
                                        img.id = 'uploadedIconPreview';
                                        uploadedIconPreview.parentNode.replaceChild(img, uploadedIconPreview);
                                    }
                                }
                                
                                // 更新隐藏输入框的值
                                iconUrlInput.value = data.data.url;
                                
                                // 显示成功消息
                                showNotification('图标上传成功！', 'success');
                            } else {
                                showNotification('上传失败：' + data.message, 'error');
                            }
                        })
                        .catch(error => {
                            console.error('Upload error:', error);
                            showNotification('上传失败，请重试', 'error');
                        })
                        .finally(() => {
                            // 恢复按钮状态
                            selectFileBtn.disabled = false;
                            selectFileBtn.innerHTML = '<i class="fas fa-upload"></i> 选择图片';
                        });
                    }
                });
            }
            
            // 图标URL输入和获取favicon功能
            const iconUrlExternal = document.getElementById('iconUrlExternal');
            const fetchFaviconBtn = document.getElementById('fetchFaviconBtn');
            const externalIconPreview = document.getElementById('externalIconPreview');
            
            if (iconUrlExternal) {
                iconUrlExternal.addEventListener('input', function() {
                    const url = this.value.trim();
                    if (url) {
                        // 更新隐藏输入框的值
                        iconUrlInput.value = url;
                        
                        // 更新预览
                        updateExternalIconPreview(url);
                    }
                });
            }
            
            function updateExternalIconPreview(url) {
                if (!externalIconPreview) return;
                
                if (url) {
                    // 检查是否已经是img元素
                    if (externalIconPreview.tagName === 'IMG') {
                        externalIconPreview.src = url;
                    } else {
                        // 替换占位符为图片
                        const img = document.createElement('img');
                        img.src = url;
                        img.alt = '图标预览';
                        img.id = 'externalIconPreview';
                        img.style.maxWidth = '32px';
                        img.style.maxHeight = '32px';
                        externalIconPreview.parentNode.replaceChild(img, externalIconPreview);
                    }
                }
            }
            
            // 获取网站favicon功能
            if (fetchFaviconBtn) {
                fetchFaviconBtn.addEventListener('click', function() {
                    const url = linkUrl.value.trim();
                    if (!url) {
                        showNotification('请先输入链接地址', 'warning');
                        return;
                    }
                    
                    // 显示加载状态
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 获取中...';
                    this.disabled = true;
                    
                    // 发送识别请求
                    const formData = new FormData();
                    formData.append('url', url);
                    
                    fetch('recognize_website.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.data.favicon) {
                            // 更新图标URL输入框
                            iconUrlExternal.value = data.data.favicon;
                            
                            // 更新隐藏输入框的值
                            iconUrlInput.value = data.data.favicon;
                            
                            // 更新预览
                            updateExternalIconPreview(data.data.favicon);
                            
                            // 自动切换到URL选项卡
                            iconTabBtns[2].click();
                            
                            showNotification('成功获取网站图标！', 'success');
                        } else {
                            showNotification('未能获取网站图标：' + (data.message || '该网站可能没有设置图标'), 'warning');
                        }
                    })
                    .catch(error => {
                        console.error('Favicon fetch error:', error);
                        showNotification('获取图标失败，请重试', 'error');
                    })
                    .finally(() => {
                        // 恢复按钮状态
                        this.innerHTML = originalText;
                        this.disabled = false;
                    });
                });
            }

            // 移除了Font Awesome图标选择器相关代码

            // 智能识别功能
            if (autoRecognizeBtn) {
                autoRecognizeBtn.addEventListener('click', function() {
                    const url = linkUrl.value.trim();
                    if (!url) {
                        showNotification('请先输入链接地址', 'warning');
                        return;
                    }

                    // 显示加载状态
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 识别中...';
                    this.disabled = true;

                    // 发送识别请求
                    const formData = new FormData();
                    formData.append('url', url);

                    fetch('recognize_website.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // 更新表单字段
                            if (data.data.title && (!linkTitle.value || linkTitle.value.trim() === '')) {
                                linkTitle.value = data.data.title;
                            }
                            
                            // 更新图标URL
                            if (data.data.favicon) {
                                // 更新图标URL
                                iconUrlExternal.value = data.data.favicon;
                                iconUrlInput.value = data.data.favicon;
                                
                                // 创建或更新隐藏的icon_url字段
                                let iconUrlField = document.querySelector('.link-form input[name="icon_url"]');
                                if (!iconUrlField) {
                                    iconUrlField = document.createElement('input');
                                    iconUrlField.type = 'hidden';
                                    iconUrlField.name = 'icon_url';
                                    document.querySelector('.link-form').appendChild(iconUrlField);
                                }
                                iconUrlField.value = data.data.favicon;
                                
                                updateExternalIconPreview(data.data.favicon);
                                
                                // 自动切换到URL选项卡
                                iconTabBtns[1].click();
                            }
                            
                            // 更新描述
                            const noteTextarea = document.querySelector('textarea[name="note"]');
                            if (noteTextarea && data.data.description && (!noteTextarea.value || noteTextarea.value.trim() === '')) {
                                noteTextarea.value = data.data.description;
                            }
                            
                            showNotification('成功识别网站信息！已自动填充标题、图标和描述', 'success');
                        } else {
                            showNotification('识别失败：' + data.message, 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Recognition error:', error);
                        showNotification('识别失败，请重试', 'error');
                    })
                    .finally(() => {
                        // 恢复按钮状态
                        this.innerHTML = originalText;
                        this.disabled = false;
                    });
                });
            }

            // 显示通知
            function showNotification(message, type) {
                const notification = document.createElement('div');
                notification.className = `alert alert-${type}`;
                notification.innerHTML = `
                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : 'exclamation-circle'}"></i>
                    ${message}
                `;
                
                const container = document.querySelector('.admin-main');
                container.insertBefore(notification, container.firstChild);
                
                setTimeout(() => {
                    notification.remove();
                }, 5000);
            }
        });

        // 全选/取消全选
        function toggleSelectAll() {
            const selectAll = document.querySelector('.select-all');
            const selectItems = document.querySelectorAll('.select-item');
            
            selectItems.forEach(item => {
                item.checked = selectAll.checked;
            });
            
            updateBatchActions();
        }

        // 更新批量操作状态
        function updateBatchActions() {
            const selectedItems = document.querySelectorAll('.select-item:checked');
            const batchActions = document.getElementById('batchActions');
            const selectedCount = document.querySelector('.selected-count');
            
            if (selectedItems.length > 0) {
                batchActions.style.display = 'block';
                selectedCount.textContent = selectedItems.length;
            } else {
                batchActions.style.display = 'none';
            }
            
            // 更新全选状态
            const selectAll = document.querySelector('.select-all');
            const totalItems = document.querySelectorAll('.select-item');
            selectAll.checked = selectedItems.length === totalItems.length;
        }

        // 批量更新属性
        function batchUpdateProperty(property) {
            const selectedItems = document.querySelectorAll('.select-item:checked');
            if (selectedItems.length === 0) return;
            
            const ids = Array.from(selectedItems).map(item => item.value);
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'update_property';
            form.appendChild(actionInput);
            
            const propertyInput = document.createElement('input');
            propertyInput.name = 'property';
            propertyInput.value = property;
            form.appendChild(propertyInput);
            
            ids.forEach(id => {
                const idInput = document.createElement('input');
                idInput.name = 'ids[]';
                idInput.value = id;
                form.appendChild(idInput);
            });
            
            document.body.appendChild(form);
            form.submit();
        }

        // 批量删除
        function batchDelete() {
            const selectedItems = document.querySelectorAll('.select-item:checked');
            if (selectedItems.length === 0) return;
            
            if (!confirm(`确定要删除选中的 ${selectedItems.length} 个链接吗？此操作无法撤销。`)) return;
            
            const ids = Array.from(selectedItems).map(item => item.value);
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'batch_delete';
            form.appendChild(actionInput);
            
            ids.forEach(id => {
                const idInput = document.createElement('input');
                idInput.name = 'ids[]';
                idInput.value = id;
                form.appendChild(idInput);
            });
            
            document.body.appendChild(form);
            form.submit();
        }

        // 删除确认
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const message = this.dataset.message || '确定要删除这个链接吗？';
                if (confirm(message)) {
                    window.location.href = this.href;
                }
            });
        });
        
        // 显示导出选项
        function showExportOptions() {
            document.getElementById('exportModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // 隐藏导出选项
        function hideExportOptions() {
            document.getElementById('exportModal').style.display = 'none';
            document.body.style.overflow = '';
        }
        
        // 快速导出
        function quickExport(format) {
            hideExportOptions();
            startExportProcess(format, 0, '1');
        }
        
        // 显示高级导出
        function showAdvancedExport() {
            hideExportOptions();
            document.getElementById('advancedExportModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // 隐藏高级导出
        function hideAdvancedExport() {
            document.getElementById('advancedExportModal').style.display = 'none';
            document.body.style.overflow = '';
        }
        
        // 开始高级导出
        function startAdvancedExport() {
            const form = document.getElementById('advancedExportForm');
            const formData = new FormData(form);
            
            const format = formData.get('format');
            const category = formData.get('category');
            const includePrivate = formData.get('include_private') ? '1' : '0';
            
            hideAdvancedExport();
            startExportProcess(format, category, includePrivate);
        }
        
        // 导出处理函数
        function startExportProcess(format, category, includePrivate) {
            // 显示进度提示
            showExportProgress();
            
            // 构建导出URL
            const params = new URLSearchParams({
                format: format,
                category: category || '0',
                include_private: includePrivate
            });
            
            const exportUrl = '/admin/export_bookmarks.php?' + params.toString();
            
            // 模拟进度条
            let progress = 0;
            const progressBar = document.getElementById('exportProgressBar');
            const progressText = document.getElementById('exportProgressText');
            
            const progressInterval = setInterval(() => {
                progress += Math.random() * 15 + 5; // 随机增加5-20%
                if (progress > 90) {
                    progress = 90;
                }
                
                progressBar.style.width = progress + '%';
                progressText.textContent = '正在导出数据... ' + Math.round(progress) + '%';
            }, 200);
            
            // 创建隐藏的下载链接
            const link = document.createElement('a');
            link.href = exportUrl;
            link.download = '';
            link.style.display = 'none';
            document.body.appendChild(link);
            
            // 延迟点击，让用户看到进度
            setTimeout(() => {
                link.click();
                document.body.removeChild(link);
                
                // 完成进度
                clearInterval(progressInterval);
                progressBar.style.width = '100%';
                progressText.textContent = '导出完成！文件开始下载...';
                
                // 2秒后隐藏进度框
                setTimeout(() => {
                    hideExportProgress();
                }, 2000);
            }, 1500);
        }
        
        // 显示导出进度
        function showExportProgress() {
            document.getElementById('exportProgressModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
            
            // 重置进度
            document.getElementById('exportProgressBar').style.width = '0%';
            document.getElementById('exportProgressText').textContent = '正在准备导出...';
        }
        
        // 隐藏导出进度
        function hideExportProgress() {
            document.getElementById('exportProgressModal').style.display = 'none';
            document.body.style.overflow = '';
        }
        
        // Bootstrap 5 Dropdown 初始化（如果需要）
        document.addEventListener('DOMContentLoaded', function() {
            // 确保下拉菜单正常工作
            const dropdowns = document.querySelectorAll('.dropdown-toggle');
            dropdowns.forEach(dropdown => {
                dropdown.addEventListener('click', function(e) {
                    e.preventDefault();
                    const menu = this.nextElementSibling;
                    const isOpen = menu.classList.contains('show');
                    
                    // 关闭所有其他下拉菜单
                    document.querySelectorAll('.dropdown-menu.show').forEach(m => {
                        m.classList.remove('show');
                    });
                    
                    // 切换当前下拉菜单
                    if (!isOpen) {
                        menu.classList.add('show');
                    }
                });
            });
            
            // 点击外部关闭下拉菜单
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.btn-group')) {
                    document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
                        menu.classList.remove('show');
                    });
                }
            });
        });
    </script>
    
    <style>
        .alert {
            padding: 0.75rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .alert-success {
            background: rgba(79, 172, 254, 0.1);
            border-color: rgba(79, 172, 254, 0.2);
            color: var(--success-color);
        }
        
        .alert-error {
            background: rgba(255, 107, 107, 0.1);
            border-color: rgba(255, 107, 107, 0.2);
            color: var(--danger-color);
        }
        
        .alert-warning {
            background: rgba(255, 193, 7, 0.1);
            border-color: rgba(255, 193, 7, 0.2);
            color: #856404;
        }
        
        .ml-2 {
            margin-left: 0.5rem;
        }
        
        .text-muted {
            color: var(--medium-gray) !important;
            font-size: 0.8125rem;
        }

        .link-info {
            min-width: 0;
        }

        .link-title {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.25rem;
        }

        .link-url {
            margin-bottom: 0.25rem;
        }

        .link-url a {
            font-size: 0.8125rem;
            text-decoration: none;
            max-width: 300px;
            display: inline-block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .pagination-wrapper {
            margin-top: 1.5rem;
            display: flex;
            justify-content: center;
        }

        .pagination {
            display: flex;
            gap: 0.25rem;
            align-items: center;
        }

        .page-link {
            padding: 0.5rem 0.75rem;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            color: var(--primary-color);
            text-decoration: none;
            border-radius: 4px;
            transition: var(--transition);
        }

        .page-link:hover {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .page-link.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .page-ellipsis {
            padding: 0.5rem;
            color: var(--medium-gray);
        }

        @media (max-width: 768px) {
            .filter-form > div {
                grid-template-columns: 1fr !important;
            }
            
            .pagination {
                flex-wrap: wrap;
                justify-content: center;
            }
        }
        
        /* 下拉菜单样式 */
        .btn-group {
            position: relative;
            display: inline-block;
        }
        
        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            min-width: 160px;
            padding: 0.5rem 0;
            margin: 0.125rem 0 0;
            background-color: white;
            border: 1px solid rgba(0,0,0,0.15);
            border-radius: 0.375rem;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.175);
        }
        
        .dropdown-menu.show {
            display: block;
        }
        
        .dropdown-item {
            display: block;
            width: 100%;
            padding: 0.375rem 1rem;
            color: #212529;
            text-decoration: none;
            white-space: nowrap;
            border: 0;
            background: transparent;
        }
        
        .dropdown-item:hover,
        .dropdown-item:focus {
            background-color: #f8f9fa;
            color: #212529;
        }
        
        .dropdown-divider {
            height: 0;
            margin: 0.5rem 0;
            overflow: hidden;
            border-top: 1px solid rgba(0,0,0,0.15);
        }
        
        /* 导出模态框样式 */
        .export-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .export-modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
        }
        
        .export-modal-content {
            position: relative;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease-out;
        }
        
        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-20px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        .export-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 24px 24px 16px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .export-modal-header h3 {
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .export-modal-header h3 i {
            color: #22c55e;
        }
        
        .export-close-btn {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            color: #666;
            transition: all 0.2s ease;
        }
        
        .export-close-btn:hover {
            background: #f5f5f5;
            color: #333;
        }
        
        .export-modal-body {
            padding: 24px;
        }
        
        .export-format-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .export-format-card {
            background: #f8f9fa;
            border: 2px solid transparent;
            border-radius: 12px;
            padding: 20px 16px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
            overflow: hidden;
        }
        
        .export-format-card:hover {
            border-color: #22c55e;
            background: #f0fdf4;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(34, 197, 94, 0.1);
        }
        
        .export-format-icon {
            font-size: 32px;
            color: #22c55e;
            margin-bottom: 12px;
        }
        
        .export-format-info h4 {
            margin: 0 0 8px;
            font-size: 16px;
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .export-format-info p {
            margin: 0;
            font-size: 13px;
            color: #666;
            line-height: 1.4;
        }
        
        .export-divider {
            text-align: center;
            margin: 24px 0;
            position: relative;
        }
        
        .export-divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #e5e5e5;
        }
        
        .export-divider span {
            background: white;
            padding: 0 16px;
            color: #666;
            font-size: 14px;
            position: relative;
        }
        
        .export-advanced {
            text-align: center;
        }
        
        .btn-block {
            width: 100%;
        }
        
        .btn-outline-primary {
            background: transparent;
            border: 2px solid #6366f1;
            color: #6366f1;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .btn-outline-primary:hover {
            background: #6366f1;
            color: white;
            transform: translateY(-1px);
        }
        
        .export-modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 16px;
            border-top: 1px solid #f0f0f0;
            margin-top: 24px;
        }
        
        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            margin-bottom: 8px;
            color: #374151;
        }
        
        .form-label i {
            color: #6366f1;
        }
        
        .form-check-label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }
        
        .form-check-label i {
            color: #f59e0b;
        }
        
        /* 导出进度样式 */
        .export-progress-container {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .export-progress-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #22c55e, #16a34a);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            flex-shrink: 0;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 0 0 10px rgba(34, 197, 94, 0);
            }
        }
        
        .export-progress-info {
            flex: 1;
        }
        
        .export-progress-text {
            font-size: 16px;
            font-weight: 500;
            color: #1a1a1a;
            margin-bottom: 12px;
        }
        
        .export-progress-bar-container {
            width: 100%;
        }
        
        .export-progress-bar-bg {
            width: 100%;
            height: 8px;
            background: #f1f5f9;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .export-progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #22c55e, #16a34a);
            border-radius: 4px;
            transition: width 0.3s ease;
            width: 0%;
            position: relative;
        }
        
        .export-progress-bar::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 1.5s infinite;
        }
        
        @keyframes shimmer {
            0% {
                transform: translateX(-100%);
            }
            100% {
                transform: translateX(100%);
            }
        }
        
        .export-progress-tips {
            background: #f8fafc;
            border-radius: 8px;
            padding: 16px;
            border-left: 4px solid #22c55e;
        }
        
        .tip-item {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
            font-size: 14px;
            color: #64748b;
        }
        
        .tip-item:last-child {
            margin-bottom: 0;
        }
        
        .tip-item i {
            color: #22c55e;
            font-size: 12px;
        }
        
        @media (max-width: 640px) {
            .export-format-grid {
                grid-template-columns: 1fr;
            }
            
            .export-modal-content {
                margin: 20px;
                max-width: none;
            }
            
            .export-modal-header,
            .export-modal-body {
                padding: 20px;
            }
            
            .export-progress-container {
                flex-direction: column;
                text-align: center;
                gap: 16px;
            }
            
            .export-progress-icon {
                width: 50px;
                height: 50px;
                font-size: 20px;
            }
        }
    </style>
</body>
</html>
