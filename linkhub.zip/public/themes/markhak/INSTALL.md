# MarkHak 主题安装指南

## 📦 安装步骤

### 1. 上传主题文件

将 `markhak` 文件夹上传到 LinkHub 的 `public/themes/` 目录下。

完整路径应该是：
```
your-linkhub-site/
├── public/
│   ├── themes/
│   │   ├── markhak/          ← 主题目录
│   │   │   ├── index.php     ← 主题模板
│   │   │   ├── style.css     ← 主题样式
│   │   │   ├── script.js     ← 主题脚本
│   │   │   ├── theme.json    ← 主题配置
│   │   │   └── ...
│   │   ├── default/
│   │   └── xinghe/
│   └── ...
└── ...
```

### 2. 检查文件权限

确保 Web 服务器对主题文件有读取权限：
```bash
# Linux/Unix 系统
chmod -R 644 public/themes/markhak/
chmod 755 public/themes/markhak/
```

### 3. 激活主题

1. 登录 LinkHub 管理后台
2. 进入 **主题设置** 页面
3. 在主题列表中找到 **MarkHak**
4. 点击 **启用** 按钮

### 4. 配置主题选项

激活主题后，可以在主题设置页面配置以下选项：

#### 显示选项
- ☑️ **显示搜索功能**: 启用/禁用首页搜索框
- ☑️ **显示页脚**: 启用/禁用页面底部信息
- ☑️ **启用动画效果**: 启用/禁用页面动画

#### 样式选项
- **卡片风格**: 
  - 🔹 悬浮卡片 (推荐)
  - 🔸 边框卡片
  - 🔹 填充卡片

- **布局密度**:
  - 🔹 舒适 (推荐)
  - 🔸 紧凑
  - 🔸 宽松

## 🔧 高级配置

### 自定义样式

如需自定义主题样式，建议创建额外的 CSS 文件而不是直接修改主题文件：

1. 在主题目录下创建 `custom.css`:
```css
/* 自定义样式 */
:root {
  --primary-color: #your-color;
}
```

2. 在 `index.php` 中引入自定义样式：
```php
<link rel="stylesheet" href="/themes/markhak/custom.css">
```

### JavaScript 配置

可以通过修改 `config.js` 文件来调整主题行为：

```javascript
// 示例：禁用动画
window.MarkHakConfig.userExperience.animations.pageLoad = false;
```

### Service Worker 配置

主题包含 Service Worker 用于离线缓存和性能优化。如需禁用：

```javascript
// 在 config.js 中设置
window.MarkHakConfig.performance.enableServiceWorker = false;
```

## 🌍 多语言支持

主题已包含中文界面，如需添加其他语言：

1. 复制并修改 `theme.json` 中的文本
2. 在 `index.php` 中添加语言判断逻辑
3. 创建对应的语言包文件

## 📱 移动端优化

主题已针对移动端进行优化，包括：

- ✅ 响应式布局
- ✅ 触摸友好的交互
- ✅ 移动端性能优化
- ✅ PWA 支持准备

## 🔍 SEO 优化

主题已包含 SEO 优化：

- ✅ 语义化 HTML 结构
- ✅ 完整的 meta 标签
- ✅ Open Graph 支持
- ✅ 结构化数据准备

## ⚡ 性能优化

主题已集成多项性能优化：

- ✅ CSS/JS 压缩
- ✅ 图片懒加载
- ✅ 关键资源预加载
- ✅ Service Worker 缓存
- ✅ 代码分割准备

## 🎨 自定义配色

### 方法一：CSS 变量覆盖

```css
:root {
  /* 主色调 */
  --primary-color: #1a73e8;
  --secondary-color: #34a853;
  --accent-color: #ea4335;
  
  /* 背景色 */
  --bg-primary: #ffffff;
  --bg-secondary: #f8f9fa;
  
  /* 文字色 */
  --text-primary: #202124;
  --text-secondary: #5f6368;
}

/* 暗色主题 */
[data-theme="dark"] {
  --primary-color: #8ab4f8;
  --bg-primary: #202124;
  --text-primary: #e8eaed;
}
```

### 方法二：配置文件修改

修改 `config.js` 中的颜色配置：

```javascript
window.MarkHakConfig.theming.customColors = {
  enabled: true,
  primary: '#your-primary-color',
  secondary: '#your-secondary-color',
  accent: '#your-accent-color'
};
```

## 🐛 故障排除

### 常见问题

#### 1. 主题列表中没有显示 MarkHak
- 检查文件上传是否完整
- 确认 `theme.json` 文件格式正确
- 检查文件权限设置

#### 2. 样式显示异常
- 清除浏览器缓存
- 检查 CSS 文件是否完整
- 确认没有 CSS 冲突

#### 3. JavaScript 功能不工作
- 检查浏览器控制台错误
- 确认 JavaScript 文件加载正常
- 检查是否有 JS 冲突

#### 4. 搜索功能异常
- 检查搜索引擎图标文件
- 确认 JavaScript 配置正确
- 检查网络连接

### 调试模式

启用调试模式来诊断问题：

```javascript
// 在浏览器控制台中执行
window.MarkHakConfig.developer.debug = true;
window.MarkHakConfig.developer.logging.enabled = true;
```

## 📞 技术支持

如遇到安装或使用问题：

1. 📖 查看 [README.md] 文档
2. 🔍 检查 [故障排除] 部分
3. 💬 联系技术支持
4. 🐛 提交 Issue 报告

## 🔄 更新说明

### 更新步骤
1. 备份当前主题文件
2. 下载新版本主题
3. 替换主题文件（保留自定义配置）
4. 清除缓存
5. 测试功能

### 版本兼容性
- LinkHub 1.0+: ✅ 完全支持
- PHP 7.4+: ✅ 完全支持
- 现代浏览器: ✅ 完全支持

## 📋 检查清单

安装完成后，请检查以下项目：

- [ ] 主题文件完整上传
- [ ] 文件权限设置正确
- [ ] 主题成功激活
- [ ] 首页显示正常
- [ ] 搜索功能工作
- [ ] 主题切换正常
- [ ] 移动端显示正常
- [ ] 链接跳转正常
- [ ] 过渡页面工作（如启用）

## 🎉 享受使用

安装完成！现在您可以享受 MarkHak 主题带来的优雅体验了。

---

**祝您使用愉快！** 🚀
