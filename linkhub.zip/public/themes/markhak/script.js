/**
 * MarkHak Theme JavaScript
 * Google-inspired interactions and enhancements
 */

class MarkHakTheme {
    constructor() {
        this.init();
    }

    init() {
        this.setupTheme();
        this.setupSearch();
        this.setupAnimations();
        this.setupKeyboardShortcuts();
        this.setupPerformanceOptimizations();
        this.setupAccessibility();
    }

    // Theme Management
    setupTheme() {
        const savedTheme = localStorage.getItem('markhak-theme') || 'light';
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const initialTheme = savedTheme === 'auto' ? (prefersDark ? 'dark' : 'light') : savedTheme;
        
        document.documentElement.setAttribute('data-theme', initialTheme);
        
        // Listen for system theme changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (localStorage.getItem('markhak-theme') === 'auto') {
                document.documentElement.setAttribute('data-theme', e.matches ? 'dark' : 'light');
            }
        });
    }

    // Search Enhancements
    setupSearch() {
        const searchInput = document.getElementById('search-input');
        const searchForm = document.querySelector('.search-form');
        
        if (!searchInput || !searchForm) return;

        // Search suggestions (basic implementation)
        let suggestionsTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(suggestionsTimeout);
            const query = e.target.value.trim();
            
            if (query.length > 2) {
                suggestionsTimeout = setTimeout(() => {
                    this.showSearchSuggestions(query);
                }, 300);
            } else {
                this.hideSearchSuggestions();
            }
        });

        // Handle search focus
        searchInput.addEventListener('focus', () => {
            document.querySelector('.search-container').classList.add('focused');
        });

        searchInput.addEventListener('blur', () => {
            setTimeout(() => {
                document.querySelector('.search-container').classList.remove('focused');
                this.hideSearchSuggestions();
            }, 150);
        });
    }

    // Animation System
    setupAnimations() {
        // Intersection Observer for scroll animations
        const animateElements = document.querySelectorAll('[class*="animate-"]');
        
        if (animateElements.length === 0) return;

        const observerOptions = {
            threshold: 0.1,
            rootMargin: '50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        animateElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            observer.observe(el);
        });

        // Parallax effect for hero section
        window.addEventListener('scroll', this.throttle(() => {
            const scrolled = window.pageYOffset;
            const heroSection = document.querySelector('.header-section');
            
            if (heroSection && scrolled > 0) {
                const rate = scrolled * -0.5;
                heroSection.style.transform = `translateY(${rate}px)`;
            }
        }, 16));
    }

    // Keyboard Shortcuts
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + K: Focus search
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                const searchInput = document.getElementById('search-input');
                if (searchInput) {
                    searchInput.focus();
                    searchInput.select();
                }
            }

            // Escape: Blur search, close suggestions
            if (e.key === 'Escape') {
                const searchInput = document.getElementById('search-input');
                if (searchInput && document.activeElement === searchInput) {
                    searchInput.blur();
                }
                this.hideSearchSuggestions();
            }

            // T: Toggle theme
            if (e.key.toLowerCase() === 't' && !e.ctrlKey && !e.metaKey && !this.isTyping()) {
                e.preventDefault();
                this.toggleTheme();
            }
        });
    }

    // Performance Optimizations
    setupPerformanceOptimizations() {
        // Lazy load images
        const images = document.querySelectorAll('img[loading="lazy"]');
        if ('loading' in HTMLImageElement.prototype) {
            // Native lazy loading supported
            images.forEach(img => {
                img.loading = 'lazy';
            });
        } else {
            // Fallback for browsers without native lazy loading
            this.setupLazyLoading(images);
        }

        // Preload critical resources
        this.preloadCriticalResources();

        // Service Worker registration (if available)
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/themes/markhak/sw.js')
                    .then(registration => {
                        console.log('SW registered: ', registration);
                    })
                    .catch(registrationError => {
                        console.log('SW registration failed: ', registrationError);
                    });
            });
        }
    }

    // Accessibility Enhancements
    setupAccessibility() {
        // Skip to content link
        this.createSkipLink();

        // Enhanced focus management
        this.setupFocusManagement();

        // ARIA live regions for dynamic content
        this.setupAriaLiveRegions();

        // Reduced motion support
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            document.documentElement.classList.add('reduce-motion');
        }
    }

    // Utility Methods
    toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const newTheme = current === 'light' ? 'dark' : 'light';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('markhak-theme', newTheme);
        
        // Announce theme change to screen readers
        this.announceToScreenReader(`Theme switched to ${newTheme} mode`);
    }

    showSearchSuggestions(query) {
        // Basic search suggestions (can be enhanced with API calls)
        const suggestions = [
            `${query} site:github.com`,
            `${query} filetype:pdf`,
            `"${query}"`,
            `${query} -site:pinterest.com`
        ].filter(suggestion => suggestion.toLowerCase().includes(query.toLowerCase()));

        this.renderSuggestions(suggestions);
    }

    hideSearchSuggestions() {
        const existingSuggestions = document.querySelector('.search-suggestions');
        if (existingSuggestions) {
            existingSuggestions.remove();
        }
    }

    renderSuggestions(suggestions) {
        this.hideSearchSuggestions();
        
        if (suggestions.length === 0) return;

        const suggestionsContainer = document.createElement('div');
        suggestionsContainer.className = 'search-suggestions';
        suggestionsContainer.innerHTML = suggestions.map(suggestion => 
            `<div class="suggestion-item" role="option">${this.escapeHtml(suggestion)}</div>`
        ).join('');

        const searchContainer = document.querySelector('.search-container');
        searchContainer.appendChild(suggestionsContainer);

        // Add click handlers
        suggestionsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('suggestion-item')) {
                document.getElementById('search-input').value = e.target.textContent;
                this.hideSearchSuggestions();
            }
        });
    }

    setupLazyLoading(images) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });

        images.forEach(img => imageObserver.observe(img));
    }

    preloadCriticalResources() {
        const criticalResources = [
            '/themes/markhak/style.css',
            '/transition_advanced.php'
        ];

        criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'prefetch';
            link.href = resource;
            document.head.appendChild(link);
        });
    }

    createSkipLink() {
        const skipLink = document.createElement('a');
        skipLink.href = '#main-content';
        skipLink.textContent = 'Skip to main content';
        skipLink.className = 'skip-link';
        skipLink.style.cssText = `
            position: absolute;
            top: -40px;
            left: 6px;
            background: var(--primary-color);
            color: white;
            padding: 8px;
            text-decoration: none;
            border-radius: 4px;
            z-index: 1000;
            transition: top 0.3s;
        `;
        
        skipLink.addEventListener('focus', () => {
            skipLink.style.top = '6px';
        });
        
        skipLink.addEventListener('blur', () => {
            skipLink.style.top = '-40px';
        });

        document.body.insertBefore(skipLink, document.body.firstChild);
    }

    setupFocusManagement() {
        // Enhanced focus styles
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                document.body.classList.add('using-keyboard');
            }
        });

        document.addEventListener('mousedown', () => {
            document.body.classList.remove('using-keyboard');
        });
    }

    setupAriaLiveRegions() {
        const liveRegion = document.createElement('div');
        liveRegion.setAttribute('aria-live', 'polite');
        liveRegion.setAttribute('aria-atomic', 'true');
        liveRegion.className = 'sr-only';
        liveRegion.id = 'live-region';
        document.body.appendChild(liveRegion);
    }

    announceToScreenReader(message) {
        const liveRegion = document.getElementById('live-region');
        if (liveRegion) {
            liveRegion.textContent = message;
            setTimeout(() => {
                liveRegion.textContent = '';
            }, 1000);
        }
    }

    isTyping() {
        const activeElement = document.activeElement;
        return activeElement && (
            activeElement.tagName === 'INPUT' ||
            activeElement.tagName === 'TEXTAREA' ||
            activeElement.contentEditable === 'true'
        );
    }

    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, (m) => map[m]);
    }
}

// Initialize theme when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new MarkHakTheme();
});

// Export for potential external use
window.MarkHakTheme = MarkHakTheme;
