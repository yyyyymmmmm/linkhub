# MarkHak 主题

一个受 Google Material Design 启发的简洁优雅主题，专为 LinkHub 导航系统设计。

## 🎨 主题特色

### 设计理念
- **Google 风格**: 采用 Material Design 设计语言
- **简洁优雅**: 减少视觉噪音，专注内容展示
- **用户体验**: 注重交互细节和使用感受
- **现代化**: 使用最新的 Web 技术和设计趋势

### 核心特性

#### 🎯 视觉设计
- **Material Design 色彩系统**: 科学的配色方案
- **Google Sans 字体**: 现代化的字体排版
- **卡片式布局**: 清晰的信息层次
- **优雅的阴影系统**: 5级阴影深度
- **流畅的动画**: 60fps 的流畅过渡效果

#### 🌓 主题系统
- **明暗双主题**: 自动适配系统主题偏好
- **一键切换**: 支持手动切换主题模式
- **持久化存储**: 记住用户的主题选择
- **平滑过渡**: 主题切换带有流畅动画

#### 🔍 搜索增强
- **双引擎支持**: Google 和百度搜索切换
- **智能建议**: 基础搜索建议功能
- **键盘快捷键**: Ctrl/Cmd + K 快速聚焦
- **优雅交互**: 悬浮、聚焦状态的视觉反馈

#### 📱 响应式设计
- **移动优先**: 专为移动设备优化的体验
- **弹性布局**: 适配各种屏幕尺寸
- **触摸友好**: 适合触摸操作的交互设计
- **性能优化**: 移动端的性能考虑

#### ♿ 无障碍支持
- **屏幕阅读器**: 完整的 ARIA 标签支持
- **键盘导航**: 完全的键盘操作支持
- **对比度**: 符合 WCAG 2.1 标准
- **减少动画**: 尊重用户的运动偏好设置

#### ⚡ 性能优化
- **Service Worker**: 离线缓存和快速加载
- **懒加载**: 图片和资源的按需加载
- **预加载**: 关键资源的智能预加载
- **代码分割**: 最小化首屏加载时间

## 🛠️ 技术实现

### 前端技术栈
- **CSS3**: 现代 CSS 特性，CSS Grid/Flexbox
- **JavaScript ES6+**: 原生 JavaScript，无依赖
- **Web APIs**: Service Worker, Intersection Observer 等
- **字体**: Google Fonts (Google Sans, Roboto)
- **图标**: Font Awesome 6.4.0

### 浏览器支持
- **Chrome**: 88+
- **Firefox**: 85+
- **Safari**: 14+
- **Edge**: 88+
- **移动端**: iOS Safari 14+, Chrome Android 88+

### 性能指标
- **First Contentful Paint**: < 1.5s
- **Largest Contentful Paint**: < 2.5s
- **Cumulative Layout Shift**: < 0.1
- **First Input Delay**: < 100ms

## 📋 配置选项

### 主题设置
主题支持在后台进行以下配置：

#### 显示选项
- `show_search`: 是否显示搜索功能 (默认: true)
- `show_footer`: 是否显示页脚 (默认: true)
- `animation_enabled`: 是否启用动画效果 (默认: true)

#### 样式选项
- `card_style`: 卡片风格
  - `elevated`: 悬浮卡片 (默认)
  - `outlined`: 边框卡片
  - `filled`: 填充卡片

- `layout_density`: 布局密度
  - `comfortable`: 舒适 (默认)
  - `compact`: 紧凑
  - `spacious`: 宽松

### 自定义配置
```json
{
  "show_search": true,
  "show_footer": true,
  "animation_enabled": true,
  "card_style": "elevated",
  "layout_density": "comfortable"
}
```

## 🎮 快捷键

### 全局快捷键
- `Ctrl/Cmd + K`: 聚焦搜索框
- `T`: 切换主题模式
- `Esc`: 关闭搜索建议

### 搜索快捷键
- `Enter`: 执行搜索
- `↑/↓`: 浏览搜索建议
- `Esc`: 关闭建议列表

## 🔧 自定义指南

### 颜色自定义
主题使用 CSS 变量系统，可以轻松自定义颜色：

```css
:root {
  --primary-color: #1a73e8;
  --secondary-color: #34a853;
  --accent-color: #ea4335;
}
```

### 字体自定义
更换字体系统：

```css
:root {
  --font-family: 'Your Font', 'Roboto', sans-serif;
}
```

### 布局自定义
调整布局密度：

```css
.comfortable-layout {
  --space-multiplier: 1;
}

.compact-layout {
  --space-multiplier: 0.75;
}

.spacious-layout {
  --space-multiplier: 1.25;
}
```

## 📱 移动端优化

### 触摸优化
- 最小触摸目标: 44x44px
- 适当的点击间距
- 避免误触的设计

### 性能优化
- 减少重绘和重排
- 优化动画性能
- 合理的图片压缩

### 体验优化
- 快速响应的交互
- 清晰的视觉反馈
- 符合移动端习惯的操作方式

## 🚀 最佳实践

### SEO 优化
- 语义化的 HTML 结构
- 合适的 meta 标签
- 结构化数据支持
- 快速的页面加载速度

### 性能监控
- Core Web Vitals 指标监控
- 资源加载时间分析
- 用户交互延迟监控

### 安全考虑
- XSS 防护
- CSRF 保护
- 内容安全策略 (CSP)
- 安全的资源引用

## 🎯 未来规划

### 功能增强
- [ ] PWA 支持
- [ ] 更多动画效果
- [ ] 手势操作支持
- [ ] 语音搜索集成

### 性能优化
- [ ] 更智能的缓存策略
- [ ] 资源包的进一步优化
- [ ] 关键渲染路径优化

### 用户体验
- [ ] 更多个性化选项
- [ ] 高级搜索功能
- [ ] 书签同步功能
- [ ] 分享功能集成

## 🤝 贡献指南

### 开发环境
1. 确保有完整的 LinkHub 开发环境
2. 主题文件位于 `/themes/markhak/`
3. 使用现代浏览器进行测试

### 代码规范
- 遵循 CSS BEM 命名规范
- JavaScript 使用 ES6+ 语法
- 注释清晰，代码可读性高
- 保持性能优先的开发理念

### 测试建议
- 多浏览器测试
- 移动端设备测试
- 无障碍功能测试
- 性能指标测试

## 📄 许可证

本主题遵循 MIT 许可证，可自由使用和修改。

## 💬 支持与反馈

如有问题或建议，请通过以下方式联系：
- GitHub Issues
- 邮件反馈
- 社区讨论

---

**MarkHak** - 让导航更优雅，让体验更美好 ✨
