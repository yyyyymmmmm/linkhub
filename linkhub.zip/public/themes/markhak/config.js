/**
 * MarkHak Theme Configuration
 * 主题高级配置选项
 */

window.MarkHakConfig = {
    // 主题信息
    theme: {
        name: 'MarkHak',
        version: '1.0.0',
        author: 'LinkHub Team',
        description: 'Google-inspired elegant navigation theme'
    },

    // 性能配置
    performance: {
        // 启用Service Worker
        enableServiceWorker: true,
        
        // 启用懒加载
        enableLazyLoading: true,
        
        // 启用预加载
        enablePreloading: true,
        
        // 动画性能模式
        animationPerformance: 'auto', // 'auto', 'high', 'low', 'disabled'
        
        // 图片质量设置
        imageQuality: 'auto', // 'auto', 'high', 'medium', 'low'
        
        // 缓存策略
        cacheStrategy: {
            static: 'cache-first',     // 静态资源
            dynamic: 'network-first',  // 动态内容
            images: 'cache-first'      // 图片资源
        }
    },

    // 用户体验配置
    userExperience: {
        // 动画偏好
        animations: {
            // 页面载入动画
            pageLoad: true,
            
            // 悬停效果
            hover: true,
            
            // 主题切换动画
            themeTransition: true,
            
            // 搜索动画
            search: true,
            
            // 滚动动画
            scroll: true,
            
            // 动画时长配置
            duration: {
                fast: 150,
                normal: 250,
                slow: 350
            },
            
            // 动画缓动函数
            easing: 'cubic-bezier(0.4, 0, 0.2, 1)'
        },

        // 交互反馈
        feedback: {
            // 触觉反馈 (支持的设备)
            haptic: true,
            
            // 音频反馈
            audio: false,
            
            // 视觉反馈
            visual: true,
            
            // 加载指示器
            loading: true
        },

        // 可访问性
        accessibility: {
            // 高对比度模式
            highContrast: false,
            
            // 大字体模式
            largeText: false,
            
            // 减少动画
            reduceMotion: 'auto', // 'auto', 'always', 'never'
            
            // 键盘导航增强
            enhancedKeyboard: true,
            
            // 屏幕阅读器优化
            screenReader: true
        }
    },

    // 搜索配置
    search: {
        // 默认搜索引擎
        defaultEngine: 'google', // 'google', 'baidu'
        
        // 搜索建议
        suggestions: {
            enabled: true,
            maxResults: 8,
            minQueryLength: 2,
            debounceDelay: 300
        },
        
        // 搜索快捷键
        shortcuts: {
            focus: ['ctrl+k', 'cmd+k'],
            submit: ['enter'],
            clear: ['escape']
        },
        
        // 搜索历史
        history: {
            enabled: true,
            maxItems: 20,
            storage: 'localStorage'
        }
    },

    // 主题配置
    theming: {
        // 自动主题切换
        autoTheme: {
            enabled: true,
            followSystem: true,
            timeBasedSwitching: false,
            lightTime: '06:00',
            darkTime: '18:00'
        },
        
        // 主题过渡
        transition: {
            enabled: true,
            duration: 300,
            easing: 'ease-in-out'
        },
        
        // 自定义颜色
        customColors: {
            enabled: false,
            primary: '#1a73e8',
            secondary: '#34a853',
            accent: '#ea4335'
        }
    },

    // 布局配置
    layout: {
        // 响应式断点
        breakpoints: {
            xs: 480,
            sm: 768,
            md: 1024,
            lg: 1200,
            xl: 1400
        },
        
        // 容器宽度
        containerWidth: {
            sm: '640px',
            md: '768px',
            lg: '1024px',
            xl: '1200px'
        },
        
        // 网格配置
        grid: {
            columns: 12,
            gutter: '1rem',
            margin: '1rem'
        }
    },

    // 开发者选项
    developer: {
        // 调试模式
        debug: false,
        
        // 性能监控
        performanceMonitoring: false,
        
        // 控制台日志
        logging: {
            enabled: false,
            level: 'info', // 'error', 'warn', 'info', 'debug'
            prefix: '[MarkHak]'
        },
        
        // 实验性功能
        experimental: {
            newAnimations: false,
            advancedCaching: false,
            webGL: false
        }
    },

    // 第三方集成
    integrations: {
        // 分析工具
        analytics: {
            enabled: false,
            provider: null, // 'google', 'baidu', 'custom'
            trackingId: null
        },
        
        // 社交分享
        social: {
            enabled: false,
            platforms: ['twitter', 'facebook', 'weibo']
        },
        
        // 评论系统
        comments: {
            enabled: false,
            provider: null // 'disqus', 'gitalk', 'custom'
        }
    }
};

// 配置验证和初始化
class MarkHakConfigManager {
    constructor(config = {}) {
        this.config = this.mergeConfig(window.MarkHakConfig, config);
        this.initializeConfig();
    }

    // 合并配置
    mergeConfig(defaultConfig, userConfig) {
        return this.deepMerge(defaultConfig, userConfig);
    }

    // 深度合并对象
    deepMerge(target, source) {
        const result = { ...target };
        
        for (const key in source) {
            if (source[key] !== null && typeof source[key] === 'object' && !Array.isArray(source[key])) {
                result[key] = this.deepMerge(target[key] || {}, source[key]);
            } else {
                result[key] = source[key];
            }
        }
        
        return result;
    }

    // 初始化配置
    initializeConfig() {
        // 应用性能配置
        this.applyPerformanceConfig();
        
        // 应用用户体验配置
        this.applyUXConfig();
        
        // 应用可访问性配置
        this.applyAccessibilityConfig();
        
        // 设置开发者选项
        this.setupDeveloperOptions();
    }

    // 应用性能配置
    applyPerformanceConfig() {
        const { performance } = this.config;
        
        // 设置动画性能模式
        if (performance.animationPerformance === 'low') {
            document.documentElement.style.setProperty('--animation-duration-multiplier', '0.5');
        } else if (performance.animationPerformance === 'disabled') {
            document.documentElement.classList.add('no-animations');
        }
        
        // 应用图片质量设置
        if (performance.imageQuality === 'low') {
            document.documentElement.classList.add('low-quality-images');
        }
    }

    // 应用用户体验配置
    applyUXConfig() {
        const { userExperience } = this.config;
        
        // 应用动画配置
        if (!userExperience.animations.pageLoad) {
            document.documentElement.classList.add('no-page-animations');
        }
        
        if (!userExperience.animations.hover) {
            document.documentElement.classList.add('no-hover-animations');
        }
    }

    // 应用可访问性配置
    applyAccessibilityConfig() {
        const { accessibility } = this.config.userExperience;
        
        if (accessibility.highContrast) {
            document.documentElement.classList.add('high-contrast');
        }
        
        if (accessibility.largeText) {
            document.documentElement.classList.add('large-text');
        }
        
        if (accessibility.reduceMotion === 'always') {
            document.documentElement.classList.add('reduce-motion');
        }
    }

    // 设置开发者选项
    setupDeveloperOptions() {
        const { developer } = this.config;
        
        if (developer.debug) {
            window.MarkHakDebug = true;
            console.log('[MarkHak] Debug mode enabled');
            console.log('[MarkHak] Config:', this.config);
        }
        
        if (developer.performanceMonitoring) {
            this.setupPerformanceMonitoring();
        }
    }

    // 性能监控
    setupPerformanceMonitoring() {
        if ('performance' in window) {
            window.addEventListener('load', () => {
                setTimeout(() => {
                    const perfData = performance.getEntriesByType('navigation')[0];
                    console.log('[MarkHak] Performance Data:', {
                        DOMContentLoaded: perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart,
                        LoadComplete: perfData.loadEventEnd - perfData.loadEventStart,
                        TotalLoadTime: perfData.loadEventEnd - perfData.fetchStart
                    });
                }, 0);
            });
        }
    }

    // 获取配置值
    get(path, defaultValue = null) {
        return path.split('.').reduce((obj, key) => {
            return obj && obj[key] !== undefined ? obj[key] : defaultValue;
        }, this.config);
    }

    // 设置配置值
    set(path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        const target = keys.reduce((obj, key) => {
            if (!obj[key]) obj[key] = {};
            return obj[key];
        }, this.config);
        
        target[lastKey] = value;
        
        // 保存到localStorage
        this.saveConfig();
    }

    // 保存配置
    saveConfig() {
        try {
            localStorage.setItem('markhak-config', JSON.stringify(this.config));
        } catch (error) {
            console.warn('[MarkHak] Failed to save config:', error);
        }
    }

    // 加载配置
    loadConfig() {
        try {
            const saved = localStorage.getItem('markhak-config');
            if (saved) {
                return JSON.parse(saved);
            }
        } catch (error) {
            console.warn('[MarkHak] Failed to load config:', error);
        }
        return {};
    }
}

// 导出配置管理器
window.MarkHakConfigManager = MarkHakConfigManager;

// 自动初始化（如果DOM已加载）
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.markHakConfig = new MarkHakConfigManager();
    });
} else {
    window.markHakConfig = new MarkHakConfigManager();
}
