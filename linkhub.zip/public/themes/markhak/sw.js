/**
 * MarkHak Theme Service Worker
 * 提供离线缓存和性能优化
 */

const CACHE_NAME = 'markhak-v1.0.0';
const STATIC_CACHE = 'markhak-static-v1';
const DYNAMIC_CACHE = 'markhak-dynamic-v1';

// 需要缓存的静态资源
const STATIC_ASSETS = [
    '/themes/markhak/style.css',
    '/themes/markhak/script.js',
    '/themes/markhak/icons/google.svg',
    '/themes/markhak/icons/baidu.svg',
    'https://fonts.googleapis.com/css2?family=Google+Sans:wght@300;400;500;700&family=Roboto:wght@300;400;500;700&display=swap',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
];

// 缓存策略配置
const CACHE_STRATEGIES = {
    // 静态资源：缓存优先
    static: {
        cacheName: STATIC_CACHE,
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7天
        maxEntries: 50
    },
    // 动态内容：网络优先，失败时使用缓存
    dynamic: {
        cacheName: DYNAMIC_CACHE,
        maxAge: 24 * 60 * 60 * 1000, // 1天
        maxEntries: 100
    }
};

// 安装事件
self.addEventListener('install', (event) => {
    console.log('[SW] Installing...');
    
    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then((cache) => {
                console.log('[SW] Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => {
                console.log('[SW] Install complete');
                return self.skipWaiting();
            })
            .catch((error) => {
                console.error('[SW] Install failed:', error);
            })
    );
});

// 激活事件
self.addEventListener('activate', (event) => {
    console.log('[SW] Activating...');
    
    event.waitUntil(
        Promise.all([
            // 清理旧缓存
            caches.keys().then((cacheNames) => {
                return Promise.all(
                    cacheNames
                        .filter((cacheName) => {
                            return cacheName !== STATIC_CACHE && 
                                   cacheName !== DYNAMIC_CACHE;
                        })
                        .map((cacheName) => {
                            console.log('[SW] Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        })
                );
            }),
            // 声明控制所有客户端
            self.clients.claim()
        ]).then(() => {
            console.log('[SW] Activation complete');
        })
    );
});

// 请求拦截
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);
    
    // 跳过非GET请求
    if (request.method !== 'GET') {
        return;
    }
    
    // 跳过chrome-extension和其他协议
    if (!url.protocol.startsWith('http')) {
        return;
    }
    
    // 处理不同类型的请求
    if (isStaticAsset(request.url)) {
        event.respondWith(cacheFirst(request));
    } else if (isAPIRequest(request.url)) {
        event.respondWith(networkFirst(request));
    } else {
        event.respondWith(staleWhileRevalidate(request));
    }
});

// 缓存优先策略（静态资源）
async function cacheFirst(request) {
    try {
        const cache = await caches.open(STATIC_CACHE);
        const cached = await cache.match(request);
        
        if (cached) {
            console.log('[SW] Serving from cache:', request.url);
            return cached;
        }
        
        console.log('[SW] Fetching and caching:', request.url);
        const response = await fetch(request);
        
        if (response.ok) {
            await cache.put(request, response.clone());
        }
        
        return response;
    } catch (error) {
        console.error('[SW] Cache first failed:', error);
        return new Response('Network error', { 
            status: 408,
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}

// 网络优先策略（API请求）
async function networkFirst(request) {
    try {
        const response = await fetch(request);
        
        if (response.ok) {
            const cache = await caches.open(DYNAMIC_CACHE);
            await cache.put(request, response.clone());
        }
        
        return response;
    } catch (error) {
        console.log('[SW] Network failed, trying cache:', request.url);
        
        const cache = await caches.open(DYNAMIC_CACHE);
        const cached = await cache.match(request);
        
        if (cached) {
            return cached;
        }
        
        return new Response('Offline', { 
            status: 503,
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}

// 陈旧同时重新验证策略（页面内容）
async function staleWhileRevalidate(request) {
    try {
        const cache = await caches.open(DYNAMIC_CACHE);
        const cached = await cache.match(request);
        
        // 后台更新缓存
        const updateCache = fetch(request).then((response) => {
            if (response.ok) {
                cache.put(request, response.clone());
            }
            return response;
        });
        
        // 返回缓存的响应（如果有）或等待网络响应
        return cached || await updateCache;
    } catch (error) {
        console.error('[SW] Stale while revalidate failed:', error);
        
        const cache = await caches.open(DYNAMIC_CACHE);
        const cached = await cache.match(request);
        
        return cached || new Response('Offline', { 
            status: 503,
            headers: { 'Content-Type': 'text/plain' }
        });
    }
}

// 工具函数
function isStaticAsset(url) {
    return /\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)(\?.*)?$/.test(url) ||
           url.includes('fonts.googleapis.com') ||
           url.includes('cdnjs.cloudflare.com');
}

function isAPIRequest(url) {
    return url.includes('/api/') || 
           url.includes('/admin/') ||
           url.includes('ajax');
}

// 消息处理
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
    
    if (event.data && event.data.type === 'GET_CACHE_INFO') {
        getCacheInfo().then((info) => {
            event.ports[0].postMessage(info);
        });
    }
});

// 获取缓存信息
async function getCacheInfo() {
    const cacheNames = await caches.keys();
    const info = {};
    
    for (const cacheName of cacheNames) {
        const cache = await caches.open(cacheName);
        const keys = await cache.keys();
        info[cacheName] = {
            count: keys.length,
            urls: keys.map(req => req.url)
        };
    }
    
    return info;
}

// 后台同步（如果支持）
if ('sync' in self.registration) {
    self.addEventListener('sync', (event) => {
        if (event.tag === 'background-sync') {
            event.waitUntil(doBackgroundSync());
        }
    });
}

async function doBackgroundSync() {
    console.log('[SW] Background sync triggered');
    // 这里可以添加后台同步逻辑，比如同步离线时的用户操作
}

console.log('[SW] Service Worker loaded');
