<?php
// MarkHak Theme - Google-inspired Design
// 获取主题配置
$themeConfig = $site['theme_config'] ?? [];
$animationEnabled = $themeConfig['animation_enabled'] ?? true;
$cardStyle = $themeConfig['card_style'] ?? 'elevated';
$layoutDensity = $themeConfig['layout_density'] ?? 'comfortable';

// 处理搜索
$searchEngine = $_GET["engine"] ?? 'google';
$searchQuery = $_POST["q"] ?? '';

if (!empty($searchQuery)) {
    if ($searchEngine === 'baidu') {
        echo '<script>window.location.href="https://www.baidu.com/s?ie=utf-8&word=' . htmlspecialchars($searchQuery) . '";</script>';
    } else {
        echo '<script>window.location.href="https://www.google.com/search?q=' . htmlspecialchars($searchQuery) . '";</script>';
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- SEO Meta Tags -->
    <title><?= htmlspecialchars($site['title']) ?> - <?= htmlspecialchars($site['subtitle']) ?></title>
    <meta name="description" content="<?= htmlspecialchars($site['description']) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($site['keywords']) ?>">
    <meta name="author" content="<?= htmlspecialchars($site['title']) ?>">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= htmlspecialchars($site['title']) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($site['description']) ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] ?>">
    
    <!-- Favicon & Icons -->
    <?php if (!empty($site['favicon'])): ?>
        <link rel="icon" href="<?= htmlspecialchars($site['favicon']) ?>" type="image/x-icon">
        <link rel="shortcut icon" href="<?= htmlspecialchars($site['favicon']) ?>" type="image/x-icon">
        <link rel="apple-touch-icon" href="<?= htmlspecialchars($site['favicon']) ?>">
    <?php else: ?>
        <link rel="icon" href="/site-icon" type="image/svg+xml">
        <link rel="shortcut icon" href="/site-icon" type="image/svg+xml">
        <link rel="apple-touch-icon" href="/site-icon">
    <?php endif; ?>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@300;400;500;700&family=Roboto:wght@300;400;500;700&family=Roboto+Mono:wght@400;500&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Theme Styles -->
    <link rel="stylesheet" href="/themes/markhak/style.css?v=<?= time() ?>">
    
    <!-- Theme Color -->
    <meta name="theme-color" content="#1a73e8">
    <meta name="msapplication-TileColor" content="#1a73e8">
    
    <!-- Performance Hints -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link rel="dns-prefetch" href="//cdnjs.cloudflare.com">
    <link rel="preload" href="/themes/markhak/style.css" as="style">
</head>

<body class="<?= $layoutDensity ?>-layout">
    <!-- Page Container -->
    <div class="page-container">
        <!-- Controls -->
        <div class="controls-section">
            <button class="control-button theme-toggle" onclick="toggleTheme()" aria-label="切换主题" title="切换主题">
                <span class="theme-toggle-icon"></span>
            </button>
            <a href="/admin/" class="control-button" aria-label="管理后台" title="管理后台">
                <i class="fas fa-cog"></i>
            </a>
        </div>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header Section -->
            <header class="header-section <?= $animationEnabled ? 'animate-fade-in-scale' : '' ?>">
                <div class="site-logo">
                    <?php if (!empty($site['logo'])): ?>
                        <img src="<?= htmlspecialchars($site['logo']) ?>" alt="<?= htmlspecialchars($site['title']) ?>">
                    <?php else: ?>
                        <img src="/site-icon" alt="<?= htmlspecialchars($site['title']) ?>">
                    <?php endif; ?>
                </div>
                <h1 class="site-title"><?= htmlspecialchars($site['title']) ?></h1>
                <p class="site-subtitle"><?= htmlspecialchars($site['subtitle']) ?></p>
            </header>

            <!-- Search Section -->
            <?php if ($themeConfig['show_search'] ?? true): ?>
            <section class="search-section <?= $animationEnabled ? 'animate-fade-in-up' : '' ?>">
                <div class="search-container">
                    <form class="search-form" method="post" action="">
                        <button type="button" class="search-engine-toggle" onclick="toggleSearchEngine()" title="切换搜索引擎">
                            <img src="/themes/markhak/icons/<?= $searchEngine === 'baidu' ? 'baidu' : 'google' ?>.svg" 
                                 alt="<?= $searchEngine === 'baidu' ? '百度' : 'Google' ?>" 
                                 width="20" height="20" id="search-engine-icon">
                        </button>
                        <input type="text" 
                               name="q" 
                               class="search-input" 
                               placeholder="搜索任何内容..." 
                               autocomplete="off"
                               spellcheck="false"
                               id="search-input">
                        <button type="submit" class="search-button" aria-label="搜索">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </section>
            <?php endif; ?>

            <!-- Categories & Links -->
            <section class="categories-container">
                <?php 
                $animationDelay = 0;
                foreach ($categories as $category): 
                    $links = $category['links'] ?? [];
                    if (empty($links)) continue;
                    
                    $animationDelay += 0.1;
                ?>
                <div class="category-section <?= $animationEnabled ? 'animate-fade-in-up' : '' ?>" 
                     style="<?= $animationEnabled ? 'animation-delay: ' . $animationDelay . 's; opacity: 0;' : '' ?>">
                    <!-- Category Header -->
                    <div class="category-header">
                        <div class="category-icon">
                            <?php if (!empty($category['icon_url'])): ?>
                                <img src="<?= htmlspecialchars($category['icon_url']) ?>" alt="<?= htmlspecialchars($category['name']) ?>">
                            <?php elseif (!empty($category['icon']) || !empty($category['font_icon'])): ?>
                                <?php 
                                $iconClass = $category['icon'] ?: $category['font_icon'];
                                if (strpos($iconClass, 'fa-') === 0) {
                                    $iconClass = 'fas ' . $iconClass;
                                }
                                ?>
                                <i class="<?= htmlspecialchars($iconClass) ?>" style="color: <?= htmlspecialchars($category['icon_color'] ?? '#1a73e8') ?>"></i>
                            <?php else: ?>
                                <div class="category-letter-avatar" style="background: <?= htmlspecialchars($category['icon_color'] ?? '#1a73e8') ?>">
                                    <?= htmlspecialchars(mb_substr($category['name'], 0, 1, 'UTF-8')) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <h2 class="category-title"><?= htmlspecialchars($category['name']) ?></h2>
                        <span class="category-count"><?= count($links) ?></span>
                    </div>

                    <!-- Links Grid -->
                    <div class="links-grid">
                        <?php foreach ($links as $link): ?>
                        <a href="<?= htmlspecialchars($link['url']) ?>" 
                           class="link-card <?= $cardStyle ?>" 
                           target="_blank"
                           onclick="return handleLinkClick(event, '<?= htmlspecialchars($link['url'], ENT_QUOTES) ?>', '<?= htmlspecialchars($link['title'], ENT_QUOTES) ?>')"
                           title="<?= htmlspecialchars($link['note'] ?? $link['title']) ?>">
                            
                            <div class="link-header">
                                <div class="link-icon">
                                    <?php if (!empty($link['icon_url'])): ?>
                                        <img src="<?= htmlspecialchars($link['icon_url']) ?>" 
                                             alt="<?= htmlspecialchars($link['title']) ?>"
                                             loading="lazy">
                                    <?php elseif (!empty($link['icon']) || !empty($link['font_icon'])): ?>
                                        <?php 
                                        $linkIconClass = $link['icon'] ?: $link['font_icon'];
                                        if (strpos($linkIconClass, 'fa-') === 0) {
                                            $linkIconClass = 'fas ' . $linkIconClass;
                                        }
                                        ?>
                                        <i class="<?= htmlspecialchars($linkIconClass) ?>" 
                                           style="color: <?= htmlspecialchars($link['icon_color'] ?? '#1a73e8') ?>"></i>
                                    <?php else: ?>
                                        <div class="link-letter-avatar" 
                                             style="background: <?= htmlspecialchars($link['icon_color'] ?? '#1a73e8') ?>">
                                            <?= htmlspecialchars(mb_substr($link['title'], 0, 1, 'UTF-8')) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <h3 class="link-title"><?= htmlspecialchars($link['title']) ?></h3>
                            </div>

                            <?php if (!empty($link['note'])): ?>
                            <p class="link-description"><?= htmlspecialchars($link['note']) ?></p>
                            <?php endif; ?>

                            <div class="link-footer">
                                <span class="link-url"><?= htmlspecialchars(parse_url($link['url'], PHP_URL_HOST)) ?></span>
                                <span class="link-status"></span>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </section>
        </main>

        <!-- Footer -->
        <?php if ($themeConfig['show_footer'] ?? true): ?>
        <footer class="site-footer">
            <div class="footer-content">
                <?php if (!empty($site['custom_footer'])): ?>
                    <?= $site['custom_footer'] ?>
                <?php else: ?>
                    <div class="footer-links">
                        <a href="/admin/" target="_blank">管理后台</a>
                        <a href="https://github.com/linkhub/linkhub" target="_blank" rel="noopener">GitHub</a>
                    </div>
                    <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($site['title']) ?> | Powered by LinkHub | Theme: MarkHak
                    <?php if (!empty($site['icp'])): ?>
                        <br><a href="https://beian.miit.gov.cn/" target="_blank" rel="noopener"><?= htmlspecialchars($site['icp']) ?></a>
                    <?php endif; ?>
                    </p>
                <?php endif; ?>
            </div>
        </footer>
        <?php endif; ?>
    </div>

    <!-- Scripts -->
    <script>
        // Theme Management
        const themeToggle = document.querySelector('.theme-toggle');
        const html = document.documentElement;
        
        // Initialize theme
        const savedTheme = localStorage.getItem('markhak-theme') || 'light';
        html.setAttribute('data-theme', savedTheme);
        
        function toggleTheme() {
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('markhak-theme', newTheme);
            
            // Add smooth transition
            document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
            setTimeout(() => {
                document.body.style.transition = '';
            }, 300);
        }
        
        // Search Engine Toggle
        let currentSearchEngine = '<?= $searchEngine ?>';
        
        function toggleSearchEngine() {
            currentSearchEngine = currentSearchEngine === 'google' ? 'baidu' : 'google';
            const icon = document.getElementById('search-engine-icon');
            const input = document.getElementById('search-input');
            
            if (currentSearchEngine === 'baidu') {
                icon.src = '/themes/markhak/icons/baidu.svg';
                icon.alt = '百度';
                input.placeholder = '百度一下，你就知道';
            } else {
                icon.src = '/themes/markhak/icons/google.svg';
                icon.alt = 'Google';
                input.placeholder = 'Search anything...';
            }
            
            // Update URL parameter
            const url = new URL(window.location);
            url.searchParams.set('engine', currentSearchEngine);
            window.history.replaceState({}, '', url);
        }
        
        // Link Click Handler (Transition Page Support)
        function handleLinkClick(event, url, title) {
            const enableTransition = <?= json_encode($site['enable_transition_page'] ?? '0') ?>;
            
            if (enableTransition == '1' || enableTransition === 1) {
                event.preventDefault();
                const transitionUrl = '/transition_advanced.php?url=' + encodeURIComponent(url) + '&site=' + encodeURIComponent(title);
                window.location.href = transitionUrl;
                return false;
            }
            return true;
        }
        
        // Search Enhancement
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('search-input');
            const searchForm = document.querySelector('.search-form');
            
            // Focus on search input with keyboard shortcut
            document.addEventListener('keydown', function(e) {
                if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                    e.preventDefault();
                    searchInput.focus();
                }
                
                if (e.key === 'Escape') {
                    searchInput.blur();
                }
            });
            
            // Update form action based on search engine
            searchForm.addEventListener('submit', function(e) {
                const query = searchInput.value.trim();
                if (!query) {
                    e.preventDefault();
                    return;
                }
                
                e.preventDefault();
                
                if (currentSearchEngine === 'baidu') {
                    window.open('https://www.baidu.com/s?ie=utf-8&word=' + encodeURIComponent(query), '_blank');
                } else {
                    window.open('https://www.google.com/search?q=' + encodeURIComponent(query), '_blank');
                }
            });
            
            // Animation delays for better UX
            <?php if ($animationEnabled): ?>
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '50px'
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                    }
                });
            }, observerOptions);
            
            document.querySelectorAll('.animate-fade-in-up').forEach(el => {
                observer.observe(el);
            });
            <?php endif; ?>
        });
        
        // Performance: Preload critical resources
        const linkPreloader = document.createElement('link');
        linkPreloader.rel = 'prefetch';
        linkPreloader.href = '/transition_advanced.php';
        document.head.appendChild(linkPreloader);
        
        // Analytics (if needed)
        <?= $site['statistics'] ?? '' ?>
    </script>
</body>
</html>
