<?php
// 星河主题 - 前台主页
// 基于原版xinghe主题优化

// 获取主题配置
$themeConfig = $site['theme_config'] ?? [];
$t = $_GET["t"] ?? 'baidu';
$q = $_POST["q"] ?? '';

// 处理搜索
if (!empty($q)) {
    if ($t == "google") {
        echo '<script>window.location.href="https://gsearch.g.shellten.top/search?q=' . htmlspecialchars($q) . '";</script>';
    } else {
        echo '<script>window.location.href="//www.baidu.com/s?ie=utf-8&word=' . htmlspecialchars($q) . '";</script>';
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta name="referrer" content="no-referrer">
    <meta name="theme-color" content="#ffffff">
    
    <!-- 图标设置 - 智能网站图标 -->
    <?php if (!empty($site['favicon'])): ?>
        <link rel="icon" href="<?= htmlspecialchars($site['favicon']) ?>" type="image/x-icon">
        <link rel="apple-touch-icon-precomposed" href="<?= htmlspecialchars($site['favicon']) ?>">
        <link rel="shortcut icon" href="<?= htmlspecialchars($site['favicon']) ?>" type="image/x-icon">
        <meta name="msapplication-TileImage" content="<?= htmlspecialchars($site['favicon']) ?>">
    <?php else: ?>
        <link rel="icon" href="/site-icon" type="image/svg+xml">
        <link rel="apple-touch-icon-precomposed" href="/site-icon">
        <link rel="shortcut icon" href="/site-icon" type="image/svg+xml">
        <meta name="msapplication-TileImage" content="/site-icon">
    <?php endif; ?>
    
    <!-- 网站图标预加载 -->
    <link rel="prefetch" href="/site-icon" as="image" type="image/svg+xml">
    
    <!-- Meta信息 -->
    <title><?= htmlspecialchars($site['title']) ?> - <?= htmlspecialchars($site['subtitle']) ?></title>
    <meta name="keywords" content="<?= htmlspecialchars($site['keywords']) ?>">
    <meta name="description" content="<?= htmlspecialchars($site['description']) ?>">
    
    <!-- 样式文件 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="/themes/xinghe/style.css?v=<?= time() ?>">
    
    <!-- 图标加载器 -->
    
    <!-- JavaScript文件 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="/themes/xinghe/script.js?v=<?= time() ?>"></script>
    
    <!-- 图标初始化脚本 -->
    <script>
        // 简化的图标错误处理
        document.addEventListener('DOMContentLoaded', function() {
            // 为所有图标图片添加错误处理
            const iconImages = document.querySelectorAll('.link-icon-image');
            iconImages.forEach(img => {
                if (!img.onerror) {
                    img.onerror = function() {
                        this.style.display = 'none';
                        const avatar = this.nextElementSibling;
                        if (avatar && avatar.classList.contains('link-letter-avatar')) {
                            avatar.style.display = 'flex';
                        }
                    };
                }
            });
        });

        function renderAllXingheIcons() {
            const iconElements = document.querySelectorAll('[data-link-id]');
            iconElements.forEach(element => {
                const linkId = element.getAttribute('data-link-id');
                const title = element.getAttribute('data-title');
                const iconUrl = element.getAttribute('data-icon-url');
                const icon = element.getAttribute('data-icon');
                const iconColor = element.getAttribute('data-icon-color');

                if (window.iconLoader && typeof window.iconLoader.renderIcon === 'function') {
                    try {
                        // 渲染新图标
                        const renderedIcon = window.iconLoader.renderIcon(linkId, title, iconUrl, icon, iconColor);
                        element.innerHTML = renderedIcon;
                        
                        // 添加成功标记，避免显示备用图标
                        element.classList.add('icon-loaded');
                    } catch (error) {
                        console.error('渲染图标失败:', error);
                        // 保持备用显示
                    }
                }
            });
        }
    </script>
    
    <!-- 自定义头部代码 -->
    <?= $site['custom_header'] ?? '' ?>
    
    <style>
        /* 动态主题样式 */
        :root {
            --primary-color: <?= $themeConfig['primary_color'] ?? '#6b7280' ?>;
            --accent-color: <?= $themeConfig['accent_color'] ?? '#9ca3af' ?>;
            --bg-primary: <?= $themeConfig['bg_color'] ?? 'linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%)' ?>;
        }
        
        [data-theme="dark"] {
            --primary-color: <?= $themeConfig['dark_primary_color'] ?? '#6b7280' ?>;
            --bg-primary: <?= $themeConfig['dark_bg_color'] ?? 'linear-gradient(135deg, #111827 0%, #1f2937 100%)' ?>;
        }
        
        /* 自定义CSS */
        <?= $themeConfig['custom_css'] ?? '' ?>
    </style>
</head>

<body>
    <!-- 预加载动画 -->
    <div class="preloader">
        <div class="spinner"></div>
    </div>
    
    <!-- 快捷键提示 -->
    <div class="shortcuts-hint" id="shortcutsHint">
        <kbd>Ctrl</kbd> + <kbd>K</kbd> 快速搜索 · 
        <kbd>Ctrl</kbd> + <kbd>/</kbd> 切换菜单 · 
        <kbd>Esc</kbd> 关闭
    </div>
    
    <!-- 汉堡菜单按钮 -->
    <div id="menu" aria-label="菜单" role="button" tabindex="0">
        <i></i>
    </div>
    
    <!-- 右上角功能区 -->
    <div class="theme-toggle" id="themeToggle" aria-label="主题切换" role="button" tabindex="0">
        <i class="fas fa-moon" aria-hidden="true"></i>
        <span>深色模式</span>
    </div>
    
    <a href="<?= $site['user_center_url'] ?? '/login.php' ?>" class="user-center" aria-label="个人中心">
        <i class="fas fa-user" aria-hidden="true"></i>
        <span>个人中心</span>
    </a>

    <!-- 侧边栏导航 -->
    <div class="list closed">
        <!-- 侧边栏搜索框 -->
        <div class="search">
            <input type="text" placeholder="搜索导航..." aria-label="搜索导航" id="sidebarSearch">
            <i class="fas fa-search" aria-hidden="true"></i>
        </div>
        
        <!-- 每日一言 -->
        <div class="daily-quote" id="dailyQuote">
            <div class="quote-content">点击汉堡菜单，发现更多精彩</div>
        </div>
        
        <ul>
            <!-- 遍历分类目录 -->
            <?php foreach ($categories as $category): ?>
                <?php $links = $category['links'] ?? []; ?>
                <?php if (!empty($links)): ?>
                
                <li class="title" data-category-id="<?= $category['id'] ?>">
                    <?php
                    $categoryIcon = $category['icon'] ?? $category['font_icon'] ?? 'fas fa-folder';
                    // 如果图标类名不包含前缀，自动添加 fas 前缀
                    if (strpos($categoryIcon, 'fa-') === 0) {
                        $categoryIcon = 'fas ' . $categoryIcon;
                    }
                    ?>
                    <i class="<?= htmlspecialchars($categoryIcon) ?>"
                       style="color: <?= htmlspecialchars($category['icon_color'] ?? '#6366f1') ?>;"></i> 
                    <?= htmlspecialchars($category['name']) ?>
                </li>
                
                <!-- 遍历链接 -->
                <?php foreach ($links as $link): ?>
                    <?php
                    // 链接地址处理
                    if (($site['link_model'] ?? 'direct') === 'direct') {
                        $url = $link['url'];
                    } else {
                        $url = '/click/' . $link['id'];
                    }
                    ?>
                    <li class="link">
                        <a title="<?= htmlspecialchars($link['note'] ?? $link['title']) ?>" 
                           href="<?= htmlspecialchars($url) ?>" 
                           target="_blank"
                           onclick="return handleLinkClick(event, '<?= htmlspecialchars($link['url'], ENT_QUOTES) ?>', '<?= htmlspecialchars($link['title'], ENT_QUOTES) ?>')">
                            <!-- 智能链接图标 -->
                            <div class="smart-link-icon">
                                <?php
                                // 简单逻辑：有图标设置就显示图标，没有就显示首字母
                                $iconColor = $link['icon_color'] ?? '#6b7280';
                                $hasIcon = false;
                                
                                // 1. 检查图片URL图标
                                if (!empty($link['icon_url'])) {
                                    $hasIcon = true;
                                    echo '<img src="' . htmlspecialchars($link['icon_url']) . '" 
                                             alt="' . htmlspecialchars($link['title']) . '" 
                                             class="link-icon-image">';
                                }
                                // 2. 检查字体图标
                                elseif (!empty($link['icon']) || !empty($link['font_icon'])) {
                                    $iconClass = $link['icon'] ?: $link['font_icon'];
                                    if (!empty($iconClass)) {
                                        $hasIcon = true;
                                        // 自动添加 fas 前缀
                                        if (strpos($iconClass, 'fa-') === 0) {
                                            $iconClass = 'fas ' . $iconClass;
                                        }
                                        echo '<i class="' . htmlspecialchars($iconClass) . '" 
                                                style="color: ' . htmlspecialchars($iconColor) . ';"></i>';
                                    }
                                }
                                
                                // 3. 没有图标设置，显示首字母
                                if (!$hasIcon) {
                                    $firstChar = mb_substr($link['title'], 0, 1, 'UTF-8');
                                    echo '<div class="link-letter-avatar" 
                                                style="background: linear-gradient(135deg, ' . $iconColor . ' 0%, ' . $iconColor . 'dd 100%);" 
                                                title="' . htmlspecialchars($link['title']) . '">
                                            ' . htmlspecialchars($firstChar) . '
                                          </div>';
                                }
                                ?>
                            </div>
                            
                            <span class="site-title" title="<?= htmlspecialchars($link['title']) ?>">
                                <?= htmlspecialchars($link['title']) ?>
                            </span>
                        </a>
                    </li>
                <?php endforeach; ?>
                
                <?php endif; ?>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- 主内容区域 -->
    <div id="content">
        <div class="con">
            <!-- LOGO -->
            <?php
            if (!empty($site['logo'])) {
                $logo_url = $site['logo'];
            } else {
                $logo_url = '/site-icon';
            }
            ?>
            <a href="/" aria-label="网站首页">
                <div class="shlogo" style="background: url(<?= htmlspecialchars($logo_url) ?>) no-repeat center/cover;" 
                     role="img" aria-label="网站标志"></div>
            </a>
            
            <!-- 搜索区域 -->
            <?php if (($themeConfig['show_search'] ?? true)): ?>
            <div class="sou">
                <form action="" method="post" target="_self" role="search">
                    <?php
                    $t = $_GET['t'] ?? 'baidu';
                    if ($t == "google") {
                        $search_logo = '/themes/xinghe/icons/g.svg';
                        echo "<div class='lg' style='background: url($search_logo) no-repeat center/cover;' onclick='change_search(\"baidu\");' role='button' tabindex='0' aria-label='切换到百度搜索' title='当前：Google搜索，点击切换到百度'></div>";
                    } else {
                        $search_logo = '/themes/xinghe/icons/baidu.svg';
                        echo "<div class='lg' style='background: url($search_logo) no-repeat center/cover;' onclick='change_search(\"google\");' role='button' tabindex='0' aria-label='切换到Google搜索' title='当前：百度搜索，点击切换到Google'></div>";
                    }
                    ?>
                    
                    <input class="wd" 
                           type="text" 
                           placeholder="请输入搜索内容" 
                           name="q" 
                           autocomplete="off"
                           aria-label="搜索输入框"
                           spellcheck="false"
                           id="searchInput">
                    
                    <button type="submit" aria-label="搜索" title="搜索">
                        <i class="fas fa-search" aria-hidden="true"></i>
                    </button>
                </form>
                
                <!-- 搜索建议下拉框 -->
                <div id="word" role="listbox" aria-label="搜索建议"></div>
            </div>
            <?php endif; ?>
        </div>
        
    <!-- 页脚 -->
    <?php if ($themeConfig['show_footer'] ?? true): ?>
    <footer class="site-footer">
        <?php if (empty($site['custom_footer'])): ?>
            <p>© <?= date('Y') ?> <?= htmlspecialchars($site['title']) ?> | Powered by <a target="_blank" href="https://github.com/linkhub/linkhub" rel="nofollow">LinkHub</a>
            <?php if (!empty($site['icp'])): ?>
             | 备案号：<a href="https://beian.miit.gov.cn/" target="_blank"><?= htmlspecialchars($site['icp']) ?></a>
            <?php endif; ?>
            </p>
        <?php else: ?>
            <?= $site['custom_footer'] ?>
        <?php endif; ?>
    </footer>
    <?php endif; ?>
    </div>

    <!-- 统计代码 -->
    <?= $site['statistics'] ?? '' ?>
    
    <!-- 主题功能脚本 -->
    <script>
        // 搜索引擎切换
        function change_search(engine) {
            const currentUrl = new URL(window.location);
            currentUrl.searchParams.set('t', engine);
            window.location.href = currentUrl.toString();
        }
        
        // 页面加载完成后初始化
        document.addEventListener('DOMContentLoaded', function() {
            // 侧边栏搜索功能
            const sidebarSearch = document.getElementById('sidebarSearch');
            if (sidebarSearch) {
                sidebarSearch.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    const links = document.querySelectorAll('.list .link');
                    
                    links.forEach(link => {
                        const title = link.querySelector('.site-title').textContent.toLowerCase();
                        if (title.includes(searchTerm)) {
                            link.style.display = 'block';
                        } else {
                            link.style.display = 'none';
                        }
                    });
                });
            }
            
            // 焦点在搜索框时的快捷键
            document.addEventListener('keydown', function(e) {
                if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                    e.preventDefault();
                    const searchInput = document.getElementById('searchInput');
                    if (searchInput) {
                        searchInput.focus();
                    }
                }
                
                if ((e.ctrlKey || e.metaKey) && e.key === '/') {
                    e.preventDefault();
                    const menu = document.getElementById('menu');
                    if (menu) {
                        menu.click();
                    }
                }
            });
        });
        
        // 过渡页面处理函数
        function handleLinkClick(event, url, title) {
            const enableTransition = <?= json_encode($site['enable_transition_page'] ?? '0') ?>;
            
            // 简化逻辑：只检查是否启用过渡页面（兼容数字和字符串）
            if (enableTransition == '1' || enableTransition === 1) {
                event.preventDefault();
                const transitionUrl = '/transition_advanced.php?url=' + encodeURIComponent(url) + '&site=' + encodeURIComponent(title);
                window.location.href = transitionUrl;
                return false;
            }
            return true;
        }
        
        // 自定义JavaScript
        <?= $themeConfig['custom_js'] ?? '' ?>
    </script>
</body>
</html>