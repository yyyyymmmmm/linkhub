/*
作者:D.Young
主页：https://yyv.me/
github：https://github.com/5iux/sou
日期：2020/11/18
版权所有，请勿删除
美化增强版本
*/

// 使用现代化的 easing functions
jQuery.easing['easeOutQuart'] = function (x, t, b, c, d) {
    return -c * ((t=t/d-1)*t*t*t - 1) + b;
};

jQuery.easing['easeOutCubic'] = function (x, t, b, c, d) {
    return c*((t=t/d-1)*t*t + 1) + b;
};

$(document).ready(function() {
    console.log('SouApp: 初始化开始');
    
    // 强制显示按钮
    $('.theme-toggle, .user-center').each(function() {
        $(this).show().css({
            'display': 'flex',
            'opacity': '1',
            'visibility': 'visible',
            'position': 'fixed',
            'z-index': '99999'
        });
    });
    
    console.log('按钮数量:', $('.theme-toggle').length, $('.user-center').length);
    
    // 初始化预加载器
    initPreloader();
    
    // 页面加载动画优化
    initPageAnimation();
    
    // 初始化主题系统
    initThemeSystem();
    
    // 初始化搜索功能  
    initSearchSystem();
    
    // 初始化菜单系统
    initMenuSystem();
    
    // 初始化快捷键支持
    initKeyboardShortcuts();
    
    // 初始化快捷键提示
    initShortcutsHint();
    
    // 初始化性能优化
    initPerformanceOptimization();
    
    // 初始化增强功能
    initEnhancements();
    
    // 每日一言已移除

    // 分类折叠功能已集成到侧边栏增强中
    
    console.log('SouApp: 初始化完成');
});

// 分类折叠功能已移至侧边栏增强中

// ========================================
// 页面加载动画
// ========================================
function initPageAnimation() {
    // 预加载动画
    $("body").css({ opacity: 0 });
    
    // 确保按钮立即可见
    $(".theme-toggle, .user-center").css({
        display: 'flex',
        opacity: 1,
        visibility: 'visible'
    });
    
    // 分阶段显示元素
    setTimeout(function() {
        $("body").animate({ opacity: 1 }, 600, 'easeOutCubic');
        $("#content").css({ transform: 'translateY(30px)', opacity: 0 })
                     .animate({ opacity: 1 }, 800, 'easeOutQuart')
                     .css({ transform: 'translateY(0)' });
    }, 100);
    
    // 延迟显示其他元素
    setTimeout(function() {
        $("#menu").css({ 
            transform: 'translateY(-20px)', 
            opacity: 0 
        }).animate({ opacity: 1 }, 400, 'easeOutCubic')
          .css({ transform: 'translateY(0)' });
        
        // 确保按钮保持可见
        $(".theme-toggle, .user-center").css({
            opacity: 1,
            transform: 'translateY(0)'
        });
    }, 300);
    
    // 自动聚焦搜索框（桌面端）
    var wid = $("body").width();
    if (wid >= 768) {
        setTimeout(function() {
            $("#content .wd").focus();
        }, 800);
    }
}

// ========================================
// 主题系统
// ========================================
function initThemeSystem() {
    // 获取系统主题偏好
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = localStorage.getItem('theme');
    
    // 设置初始主题
    const currentTheme = savedTheme || (prefersDark ? 'dark' : 'light');
    
    // 确保按钮正确初始化
    setTimeout(() => {
        applyTheme(currentTheme);
    }, 100);
    
    // 主题切换按钮事件
    $(document).on('click', '.theme-toggle', function(e) {
        e.stopPropagation();
        console.log('主题切换按钮被点击');
        
        // 添加点击动画
        $(this).css('transform', 'scale(0.95)');
        setTimeout(() => {
            $(this).css('transform', 'scale(1)');
        }, 150);
        
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        console.log('切换主题从', currentTheme, '到', newTheme);
        
        // 平滑过渡效果
        $("body").css('transition', 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)');
        applyTheme(newTheme);
        
        // 保存主题偏好
        localStorage.setItem('theme', newTheme);
    });
    
    // 监听系统主题变化
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!localStorage.getItem('theme')) {
            applyTheme(e.matches ? 'dark' : 'light');
        }
    });
    
    // 个人中心按钮作为普通链接，无需JavaScript处理
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    
    // 更新主题切换按钮图标和文本
    const icon = theme === 'dark' ? 'fa-sun-o' : 'fa-moon-o';
    const text = theme === 'dark' ? '浅色模式' : '深色模式';
    
    $(".theme-toggle i").removeClass('fa-moon-o fa-sun-o').addClass(icon);
    $(".theme-toggle span").text(text);
}

// ========================================
// 搜索系统增强
// ========================================
function initSearchSystem() {
    let searchTimeout;
    let currentSuggestionIndex = -1;
    let suggestions = [];
    
    // 搜索输入事件
    $("#content .wd").on('input', function() {
        const query = $(this).val().trim();
        
        clearTimeout(searchTimeout);
        
        if (query.length === 0) {
            hideSuggestions();
            return;
        }
        
        // 防抖处理
        searchTimeout = setTimeout(() => {
            fetchSuggestions(query);
        }, 300);
    });
    
    // 键盘导航支持
    $("#content .wd").on('keydown', function(e) {
        const $suggestions = $("#word li");
        
        switch(e.keyCode) {
            case 38: // 上箭头
                e.preventDefault();
                currentSuggestionIndex = Math.max(0, currentSuggestionIndex - 1);
                updateSuggestionSelection($suggestions);
                break;
            case 40: // 下箭头
                e.preventDefault();
                currentSuggestionIndex = Math.min($suggestions.length - 1, currentSuggestionIndex + 1);
                updateSuggestionSelection($suggestions);
                break;
            case 13: // 回车
                if (currentSuggestionIndex >= 0) {
                    e.preventDefault();
                    $suggestions.eq(currentSuggestionIndex).click();
                }
                break;
            case 27: // ESC
                hideSuggestions();
                break;
        }
    });
    
    // 失焦隐藏建议
    $("#content .wd").on('blur', function() {
        setTimeout(() => {
            hideSuggestions();
        }, 200);
    });
    
    // 搜索引擎切换动画
    $(".lg").on('click', function() {
        $(this).css('transform', 'scale(0.9)');
        setTimeout(() => {
            $(this).css('transform', 'scale(1)');
        }, 150);
    });
    
    // 搜索按钮动画
    $(".sou button").on('mousedown', function() {
        $(this).css('transform', 'scale(0.95)');
    }).on('mouseup mouseleave', function() {
        $(this).css('transform', 'scale(1)');
    });
}

// 获取搜索建议
function fetchSuggestions(query) {
    // 这里可以集成真实的搜索建议API
    // 暂时使用模拟数据
    const mockSuggestions = [
        query + ' 教程',
        query + ' 是什么',
        query + ' 怎么用',
        query + ' 下载',
        query + ' 官网'
    ];
    
    showSuggestions(mockSuggestions);
}

// 显示搜索建议
function showSuggestions(suggestionList) {
    suggestions = suggestionList;
    currentSuggestionIndex = -1;
    
    const $word = $("#word");
    $word.empty();
    
    suggestionList.forEach((suggestion, index) => {
        const $li = $('<li></li>')
            .text(suggestion)
            .on('click', function() {
                $("#content .wd").val(suggestion);
                hideSuggestions();
                // 可以在这里触发搜索
            })
            .on('mouseenter', function() {
                currentSuggestionIndex = index;
                updateSuggestionSelection($("#word li"));
            });
        
        $word.append($li);
    });
    
    $word.slideDown(200, 'easeOutCubic');
}

// 隐藏搜索建议
function hideSuggestions() {
    $("#word").slideUp(200, 'easeOutCubic');
    currentSuggestionIndex = -1;
}

// 更新建议选择状态
function updateSuggestionSelection($suggestions) {
    $suggestions.removeClass('active');
    if (currentSuggestionIndex >= 0) {
        $suggestions.eq(currentSuggestionIndex).addClass('active');
    }
}

// ========================================
// 菜单系统增强
// ========================================
// 全局变量，解决作用域问题
let isMenuOpen = false;

function initMenuSystem() {
    // 重置菜单状态
    isMenuOpen = false;
    
    // 检测移动设备
    const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    // 优化的菜单切换事件 - 简化逻辑，提升性能
    $("#menu").off('click touchstart').on('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        
        // 防止重复点击
        if ($(this).hasClass('animating')) {
            return false;
        }
        
        $(this).addClass('animating');
        
        isMenuOpen = !isMenuOpen;
        $(this).toggleClass('on');
        $(".list").toggleClass('closed');
        
        // 简化的菜单动画
        if (isMenuOpen) {
            fastOpenMenu();
        } else {
            fastCloseMenu();
        }
        
        // 快速恢复可点击状态
        setTimeout(() => {
            $(this).removeClass('animating');
        }, 300);
    });
    
    // 点击内容区域关闭菜单
    $("#content").on('click', function(event) {
        event.stopPropagation();
        if (isMenuOpen) {
            $("#menu").removeClass('on');
            $(".list").addClass('closed');
            isMenuOpen = false;
            fastCloseMenu();
        }
    });
    
    // ESC键关闭菜单
    $(document).on('keydown', function(e) {
        if (e.keyCode === 27 && isMenuOpen) {
            $("#menu").removeClass('on');
            $(".list").addClass('closed');
            isMenuOpen = false;
            fastCloseMenu();
        }
    });
    
    // 侧边栏搜索功能
    $(".list .search input").on('input', function() {
        const query = $(this).val().toLowerCase();
        filterMenuItems(query);
    });
    
    // 链接点击处理 - 修复移动端不跳转问题
    $(".list ul li.link a").on('click', function(e) {
        const $link = $(this);
        const href = $link.attr('href');
        
        // 检测是否为移动设备
        const isMobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        
        if (isMobileDevice) {
            // 移动端：不阻止默认行为，直接跳转，只添加简单的视觉反馈
            $link.css({
                'transform': 'translateX(4px)',
                'opacity': '0.8'
            });
            
            // 立即跳转，不延迟
            setTimeout(() => {
                $link.css({
                    'transform': 'translateX(0)',
                    'opacity': '1'
                });
            }, 50);
            
            // 不阻止默认行为，让浏览器处理链接跳转
            return true;
        } else {
            // 桌面端：保持原有动画效果
            e.preventDefault();
            
            $link.css('transform', 'translateX(8px)');
            
            setTimeout(() => {
                $link.css('transform', 'translateX(0)');
                window.open(href, '_blank');
            }, 150);
        }
    });
    
    // 移动端额外的触摸事件处理 - 双重保险
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        $(".list ul li.link a").on('touchend', function(e) {
            const href = $(this).attr('href');
            if (href && href !== '#' && href !== 'javascript:void(0)') {
                // 确保在触摸结束时能够跳转
                setTimeout(() => {
                    window.open(href, '_blank');
                }, 10);
            }
        });
    }
}

// 优化版本的菜单动画 - 更快更流畅
function fastOpenMenu() {
    console.log('打开侧边栏');
    // 简化的内容区域动画
    $('#content').css({
        'transform': 'translateX(320px)',
        'opacity': '0.8',
        'transition': 'all 0.3s cubic-bezier(0.25, 0.1, 0.25, 1)'
    });
}

function fastCloseMenu() {
    console.log('关闭侧边栏');
    $("#menu").removeClass('on');
    $(".list").addClass('closed');
    
    // 快速恢复内容区域
    $('#content').css({
        'transform': 'translateX(0)',
        'opacity': '1',
        'transition': 'all 0.3s cubic-bezier(0.25, 0.1, 0.25, 1)'
    });
    
    // 更新菜单状态
    isMenuOpen = false;
}

// 保留原有复杂动画函数作为备用
function openMenu() {
    // 菜单打开动画
    $('#content').animate({
        left: '384px',
        opacity: 0.7
    }, 400, 'easeOutQuart');
    
    // 为菜单项添加延迟动画
    setTimeout(() => {
        $(".list ul li.link").each(function(index) {
            $(this).css({
                opacity: 0,
                transform: 'translateX(-20px)'
            }).delay(index * 50).animate({
                opacity: 1
            }, 300, 'easeOutCubic').css({
                transform: 'translateX(0)'
            });
        });
    }, 200);
}

function closeMenu() {
            $("#menu").removeClass('on');
            $(".list").addClass('closed');
            
    // 菜单关闭动画
            $('#content').animate({
                left: '0',
                opacity: 1
    }, 400, 'easeOutQuart');
    
    // 更新菜单状态
    isMenuOpen = false;
    
    // 重新启用菜单点击
    $("#menu").css('pointer-events', 'auto');
}

// 菜单项过滤
function filterMenuItems(query) {
    $(".list ul li.link").each(function() {
        const text = $(this).text().toLowerCase();
        if (text.includes(query)) {
            $(this).slideDown(200);
        } else {
            $(this).slideUp(200);
        }
    });
}

// ========================================
// 快捷键支持
// ========================================
function initKeyboardShortcuts() {
    $(document).on('keydown', function(e) {
        // Ctrl/Cmd + K 聚焦搜索框
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 75) {
            e.preventDefault();
            $("#content .wd").focus().select();
        }
        
        // Ctrl/Cmd + / 切换菜单
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 191) {
            e.preventDefault();
            $("#menu").click();
        }
        
        // Ctrl/Cmd + Shift + T 切换主题
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.keyCode === 84) {
            e.preventDefault();
            $(".theme-toggle").click();
        }
    });
}

// ========================================
// 性能优化
// ========================================
function initPerformanceOptimization() {
    // 防抖函数
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // 节流函数
    function throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }
    
    // 窗口大小变化处理
    const handleResize = debounce(function() {
        const wid = $(window).width();
        
        // 移动端自动关闭菜单
        if (wid < 768 && !$(".list").hasClass('closed')) {
            closeMenu();
        }
        
        // 响应式搜索框焦点
        if (wid >= 768) {
            $("#content .wd").attr('placeholder', '请输入搜索内容');
        } else {
            $("#content .wd").attr('placeholder', '搜索...');
        }
    }, 300);
    
    $(window).on('resize', handleResize);
    
    // 初始化时调用一次
    handleResize();
    
    // 滚动优化
    const handleScroll = throttle(function() {
        const scrollTop = $(window).scrollTop();
        
        // 根据滚动位置调整元素透明度
        if (scrollTop > 50) {
            $(".foot").css('opacity', 0.6);
        } else {
            $(".foot").css('opacity', 0.8);
        }
    }, 100);
    
    $(window).on('scroll', handleScroll);
}

// ========================================
// 搜索引擎切换功能
// ========================================
function change_search(type) {
    const currentUrl = new URL(window.location);
    currentUrl.searchParams.set('t', type);
    
    // 平滑切换动画
    $(".lg").css('transform', 'scale(0.8)').animate({
        opacity: 0.5
    }, 150, function() {
        // 更新图标
        window.location.href = currentUrl.toString();
    });
}

// ========================================
// 工具函数
// ========================================

// 延迟执行函数
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// 检测移动设备
function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// 检测触摸设备
function isTouchDevice() {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
}

// 平滑滚动到元素
function smoothScrollTo(element, duration = 500) {
    const target = $(element);
    if (target.length) {
        $('html, body').animate({
            scrollTop: target.offset().top
        }, duration, 'easeOutQuart');
    }
}

// 复制到剪贴板
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showNotification('已复制到剪贴板');
    } catch (err) {
        console.error('复制失败:', err);
    }
}

// 显示通知
function showNotification(message, duration = 3000) {
    const $notification = $('<div class="notification"></div>')
        .text(message)
        .css({
            position: 'fixed',
            top: '20px',
            right: '20px',
            background: 'var(--primary-color)',
            color: 'white',
            padding: '12px 20px',
            borderRadius: 'var(--radius-medium)',
            boxShadow: 'var(--shadow-medium)',
            zIndex: 10000,
            opacity: 0,
            transform: 'translateX(100%)'
        });
    
    $('body').append($notification);
    
    $notification.animate({
        opacity: 1,
        transform: 'translateX(0)'
    }, 300, 'easeOutCubic');
    
    setTimeout(() => {
        $notification.animate({
            opacity: 0,
            transform: 'translateX(100%)'
        }, 300, 'easeOutCubic', function() {
            $(this).remove();
        });
    }, duration);
}

// ========================================
// 页面可见性API - 性能优化
// ========================================
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // 页面不可见时暂停动画
        $('*').css('animation-play-state', 'paused');
    } else {
        // 页面可见时恢复动画
        $('*').css('animation-play-state', 'running');
    }
});

// ========================================
// 错误处理
// ========================================
window.addEventListener('error', function(e) {
    console.error('JavaScript错误:', e.error);
    // 可以在这里添加错误上报逻辑
});

// Promise错误处理
window.addEventListener('unhandledrejection', function(e) {
    console.error('未处理的Promise错误:', e.reason);
    e.preventDefault();
});

// ========================================
// 预加载器
// ========================================
function initPreloader() {
    // 页面加载完成后隐藏预加载器
    $(window).on('load', function() {
        setTimeout(() => {
            $('.preloader').addClass('hidden');
            
            // 预加载器隐藏后移除元素
            setTimeout(() => {
                $('.preloader').remove();
            }, 500);
        }, 300);
    });
    
    // 如果页面加载时间过长，强制隐藏预加载器
    setTimeout(() => {
        if ($('.preloader').length) {
            $('.preloader').addClass('hidden');
        }
    }, 5000);
}

// ========================================
// 快捷键提示
// ========================================
function initShortcutsHint() {
    // 在移动设备上不显示快捷键提示
    if (isMobile() || isTouchDevice()) {
        // 确保移除快捷键提示元素
        $('#shortcutsHint').remove();
        return;
    }
    
    let hintTimeout;
    let hasShownOnce = false;
    
    // 延迟首次显示提示
    setTimeout(() => {
        if (!hasShownOnce) {
            $('#shortcutsHint').addClass('show');
            hasShownOnce = true;
            
            setTimeout(() => {
                $('#shortcutsHint').removeClass('show');
            }, 4000);
        }
    }, 2000);
    
    // 鼠标移动时显示提示
    $(document).on('mousemove', function() {
        clearTimeout(hintTimeout);
        
        if (!$('#shortcutsHint').hasClass('show')) {
            $('#shortcutsHint').addClass('show');
        }
        
        // 3秒后隐藏提示
        hintTimeout = setTimeout(() => {
            $('#shortcutsHint').removeClass('show');
        }, 3000);
    });
    
    // 使用快捷键后隐藏提示
    $(document).on('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && (e.keyCode === 75 || e.keyCode === 191 || (e.shiftKey && e.keyCode === 84))) {
            $('#shortcutsHint').removeClass('show');
        }
    });
}

// ========================================
// 增强功能
// ========================================
function initEnhancements() {
    // 移除搜索引擎切换按钮的可能导致紫色高亮的类名
    $('.lg').removeClass('interactive-element micro-animation focus-ring');
    
    // 为交互元素添加类名 (排除.lg避免紫色高亮)
    $('.theme-toggle, .user-center, #menu, .sou button').addClass('interactive-element micro-animation');
    
    // 为表单元素添加焦点环 (排除搜索引擎切换按钮)
    $('input, button:not(.lg), [tabindex]:not(.lg)').addClass('focus-ring');
    
    // 搜索框验证
    $('.wd').on('blur', function() {
        const value = $(this).val().trim();
        
        if (value.length > 0 && value.length < 2) {
            $(this).addClass('error-state');
            setTimeout(() => {
                $(this).removeClass('error-state');
            }, 1000);
        } else if (value.length >= 2) {
            $(this).addClass('success-state');
            setTimeout(() => {
                $(this).removeClass('success-state');
            }, 1000);
        }
    });
    
    // 键盘导航增强
    $(document).on('keydown', function(e) {
        // Tab键导航时显示焦点环
        if (e.keyCode === 9) {
            $('body').addClass('keyboard-navigation');
        }
    });
    
    // 鼠标点击时隐藏焦点环
    $(document).on('mousedown', function() {
        $('body').removeClass('keyboard-navigation');
    });
    
    // 长按搜索引擎切换按钮显示更多选项
    let longPressTimer;
    $('.lg').on('mousedown touchstart', function() {
        longPressTimer = setTimeout(() => {
            showSearchEngineMenu();
        }, 1000);
    }).on('mouseup mouseleave touchend', function() {
        clearTimeout(longPressTimer);
    });
    
    // 双击logo显示关于信息
    $('.shlogo').on('dblclick', function() {
        showAboutDialog();
    });
    
    // 滚动到顶部功能
    initScrollToTop();
    
    // 处理网站图标
    initIconFallbacks();
}

// 简化的图标处理函数
function initIconFallbacks() {
    // 不需要复杂的处理，使用本地图标
}

// ========================================
// 搜索引擎菜单
// ========================================
function showSearchEngineMenu() {
    const engines = [
        { name: '百度', value: 'baidu', icon: 'templates/sousuo/icon/baidu.svg' },
        { name: 'Google', value: 'google', icon: 'templates/sousuo/icon/g.svg' },
        { name: '必应', value: 'bing', icon: 'https://www.bing.com/favicon.ico' },
        { name: '搜狗', value: 'sogou', icon: 'https://www.sogou.com/favicon.ico' }
    ];
    
    const menu = $('<div class="search-engine-menu"></div>').css({
        position: 'absolute',
        background: 'var(--bg-secondary)',
        backdropFilter: 'blur(20px)',
        border: '1px solid var(--border-color)',
        borderRadius: 'var(--radius-medium)',
        padding: '8px',
        zIndex: 1000,
        boxShadow: 'var(--shadow-large)'
    });
    
    engines.forEach(engine => {
        const item = $(`<div class="engine-item">${engine.name}</div>`).css({
            padding: '8px 12px',
            cursor: 'pointer',
            borderRadius: 'var(--radius-small)',
            fontSize: '14px',
            transition: 'all 0.2s ease'
        }).on('click', function() {
            change_search(engine.value);
            menu.remove();
        }).on('mouseenter', function() {
            $(this).css('background', 'var(--primary-light)');
        }).on('mouseleave', function() {
            $(this).css('background', 'transparent');
        });
        
        menu.append(item);
    });
    
    $('body').append(menu);
    
    const lgPos = $('.lg').offset();
    menu.css({
        top: lgPos.top + $('.lg').outerHeight() + 8,
        left: lgPos.left
    });
    
    // 点击外部关闭菜单
    setTimeout(() => {
        $(document).one('click', function() {
            menu.remove();
        });
    }, 100);
}

// ========================================
// 关于对话框
// ========================================
function showAboutDialog() {
    const dialog = $(`
        <div class="about-dialog">
            <div class="dialog-content">
                <h3>关于本站</h3>
                <p>这是一个美观、现代化的导航网站</p>
                <p>支持多种搜索引擎，提供便捷的网站导航服务</p>
                <div class="dialog-actions">
                    <button class="btn-close">关闭</button>
                </div>
            </div>
        </div>
    `).css({
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        background: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10000,
        opacity: 0
    });
    
    dialog.find('.dialog-content').css({
        background: 'var(--bg-secondary)',
        backdropFilter: 'blur(20px)',
        border: '1px solid var(--border-color)',
        borderRadius: 'var(--radius-large)',
        padding: '24px',
        maxWidth: '400px',
        textAlign: 'center',
        transform: 'scale(0.9)'
    });
    
    $('body').append(dialog);
    
    dialog.animate({ opacity: 1 }, 200);
    dialog.find('.dialog-content').animate({
        transform: 'scale(1)'
    }, 300, 'easeOutCubic');
    
    dialog.find('.btn-close').on('click', function() {
        dialog.animate({ opacity: 0 }, 200, function() {
            dialog.remove();
        });
    });
    
    dialog.on('click', function(e) {
        if (e.target === dialog[0]) {
            dialog.find('.btn-close').click();
        }
    });
}

// ========================================
// 滚动到顶部
// ========================================
function initScrollToTop() {
    const scrollBtn = $('<div class="scroll-to-top">↑</div>').css({
        position: 'fixed',
        bottom: '80px',
        right: '20px',
        width: '48px',
        height: '48px',
        background: 'var(--bg-card)',
        color: 'var(--text-primary)',
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
        fontSize: '20px',
        fontWeight: 'bold',
        boxShadow: 'var(--shadow-medium)',
        opacity: 0,
        transform: 'translateY(20px)',
        transition: 'all 0.3s ease',
        zIndex: 1000,
        border: '1px solid var(--border-color)',
        WebkitTapHighlightColor: 'transparent',
        WebkitUserSelect: 'none',
        userSelect: 'none'
    });
    
    $('body').append(scrollBtn);
    
    $(window).on('scroll', function() {
        if ($(window).scrollTop() > 300) {
            scrollBtn.css({
                opacity: 1,
                transform: 'translateY(0)'
            });
        } else {
            scrollBtn.css({
                opacity: 0,
                transform: 'translateY(20px)'
            });
        }
    });
    
    scrollBtn.on('click', function() {
        $('html, body').animate({ scrollTop: 0 }, 500, 'easeOutQuart');
    });
    
    // 添加悬停效果（非紫色）
    scrollBtn.on('mouseenter', function() {
        $(this).css({
            'background': 'var(--bg-secondary)',
            'transform': 'translateY(-2px) scale(1.05)',
            'box-shadow': '0 8px 25px rgba(0, 0, 0, 0.15)'
        });
    }).on('mouseleave', function() {
        $(this).css({
            'background': 'var(--bg-card)',
            'transform': 'translateY(0) scale(1)',
            'box-shadow': 'var(--shadow-medium)'
        });
    });
}

// 每日一言功能已移除

// ========================================
// 搜索引擎切换功能
// ========================================
function change_search(engine) {
    console.log('切换搜索引擎到:', engine);
    
    // 获取当前页面URL并添加搜索引擎参数
    const currentUrl = new URL(window.location.href);
    currentUrl.searchParams.set('t', engine);
    
    // 重新加载页面
    window.location.href = currentUrl.toString();
}

// 处理搜索表单提交
function initSearchSystem() {
    const $searchForm = $('.con .sou form');
    const $searchInput = $('.con .sou .wd');
    
    if ($searchForm.length > 0) {
        $searchForm.on('submit', function(e) {
            e.preventDefault();
            
            const query = $searchInput.val().trim();
            if (!query) return;
            
            // 获取当前搜索引擎类型
            const urlParams = new URLSearchParams(window.location.search);
            const searchEngine = urlParams.get('t') || 'baidu';
            
            // 定义搜索引擎URLs
            const searchEngines = {
                'baidu': 'https://www.baidu.com/s?ie=utf-8&word=',
                'google': 'https://www.google.com/search?q=',
                'bing': 'https://cn.bing.com/search?FORM=BESBTB&q='
            };
            
            const searchUrl = searchEngines[searchEngine] || searchEngines['baidu'];
            const fullUrl = searchUrl + encodeURIComponent(query);
            
            // 在新标签页中打开搜索结果
            window.open(fullUrl, '_blank');
        });
        
        // 搜索建议功能
        $searchInput.on('input', debounce(function() {
            const query = $(this).val().trim();
            if (query.length > 1) {
                showSearchSuggestions(query);
            } else {
                hideSearchSuggestions();
            }
        }, 300));
    }
}

// 显示搜索建议
function showSearchSuggestions(query) {
    // 这里可以添加搜索建议的API调用
    // 暂时隐藏搜索建议功能
    hideSearchSuggestions();
}

// 隐藏搜索建议
function hideSearchSuggestions() {
    $('#word').hide();
}

// ========================================
// 现代化侧边栏交互增强
// ========================================

// 添加现代化交互效果
function initSidebarEnhancements() {
    console.log("初始化侧边栏交互效果");
    
    // 搜索框焦点效果
    $('.list .search input').on('focus', function() {
        $(this).closest('.search').addClass('focused');
    }).on('blur', function() {
        $(this).closest('.search').removeClass('focused');
    });
    
    // 分类折叠功能 - 优化版本
    $('.list ul li.title').off('click').on('click', function(e) {
        e.preventDefault();
        console.log('分类标题被点击');
        
        const $title = $(this);
        const $links = $title.nextUntil('.title', '.link');
        
        console.log('找到链接数量:', $links.length);
        
        $title.toggleClass('collapsed');
        
        if ($title.hasClass('collapsed')) {
            console.log('收缩分类');
            $links.slideUp(300);
        } else {
            console.log('展开分类');
            $links.slideDown(300);
        }
        
        // 添加点击反馈
        $title.css('transform', 'scale(0.98)');
        setTimeout(() => {
            $title.css('transform', 'scale(1)');
        }, 150);
    });
    
    // 链接悬停效果增强
    $('.list ul li.link a').on('mouseenter', function() {
        const $link = $(this);
        $link.addClass('link-hover-active');
        
        // 图标动画
        $link.find('.icon-container').addClass('icon-hover');
    }).on('mouseleave', function() {
        const $link = $(this);
        $link.removeClass('link-hover-active');
        $link.find('.icon-container').removeClass('icon-hover');
    });
    
    // 搜索功能
    $('.list .search input').on('input', debounce(function() {
        const query = $(this).val().toLowerCase().trim();
        filterSidebarLinks(query);
    }, 300));
    
    // 移动端优化
    if (isMobile()) {
        initMobileSidebarOptimizations();
    }
}

// 侧边栏链接过滤
function filterSidebarLinks(query) {
    const $links = $('.list ul li.link');
    const $titles = $('.list ul li.title');
    
    if (!query) {
        $links.show().removeClass('search-match');
        $titles.show();
        return;
    }
    
    let matchCount = 0;
    
    $links.each(function() {
        const $link = $(this);
        const title = $link.find('.site-title').text().toLowerCase();
        
        if (title.includes(query)) {
            $link.show().addClass('search-match');
            matchCount++;
        } else {
            $link.hide().removeClass('search-match');
        }
    });
    
    // 显示/隐藏分类标题
    $titles.each(function() {
        const $title = $(this);
        const $relatedLinks = $title.nextUntil('.title', '.link');
        const visibleLinks = $relatedLinks.filter(':visible').length;
        
        if (visibleLinks > 0) {
            $title.show();
        } else {
            $title.hide();
        }
    });
    
    console.log(`搜索 "${query}" 找到 ${matchCount} 个匹配项`);
}

// 移动端侧边栏优化
function initMobileSidebarOptimizations() {
    // 触摸反馈
    $('.list ul li.link a, .list ul li.title').on('touchstart', function() {
        $(this).addClass('touch-feedback');
    }).on('touchend touchcancel', function() {
        const $this = $(this);
        setTimeout(() => $this.removeClass('touch-feedback'), 150);
    });
    
    // 搜索框移动端优化
    $('.list .search input').on('focus', function() {
        // 防止移动端键盘遮挡
        setTimeout(() => {
            $(this)[0].scrollIntoView({ 
                behavior: 'smooth', 
                block: 'center' 
            });
        }, 300);
    });
}

// 防抖函数
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func.apply(this, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 确保侧边栏增强功能在页面完全加载后初始化
$(document).ready(function() {
    // 延迟执行以确保DOM完全准备好
    setTimeout(() => {
        initSidebarEnhancements();
        console.log('侧边栏增强功能初始化完成');
    }, 500);
});

// 导出函数供外部使用
window.SouApp = {
    showNotification,
    copyToClipboard,
    smoothScrollTo,
    applyTheme,
    isMobile,
    isTouchDevice,
    showSearchEngineMenu,
    showAboutDialog,
    initSidebarEnhancements,
    filterSidebarLinks,
    change_search
};

// 将change_search函数设为全局函数，供HTML内联调用
window.change_search = change_search;