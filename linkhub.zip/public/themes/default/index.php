<?php
// 默认主题 - 前台主页
// 现代化导航页面设计

// 获取主题配置
$themeConfig = $site['theme_config'] ?? [];
$q = $_POST["q"] ?? '';

// 处理搜索
if (!empty($q)) {
    $searchUrl = "https://www.baidu.com/s?ie=utf-8&word=" . urlencode($q);
    echo '<script>window.location.href="' . htmlspecialchars($searchUrl) . '";</script>';
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta name="referrer" content="no-referrer">
    <meta name="theme-color" content="#4285f4">
    
    <!-- 图标设置 - 智能网站图标 -->
    <?php if (!empty($site['favicon'])): ?>
        <link rel="icon" href="<?= htmlspecialchars($site['favicon']) ?>" type="image/x-icon">
        <link rel="shortcut icon" href="<?= htmlspecialchars($site['favicon']) ?>" type="image/x-icon">
        <link rel="apple-touch-icon" href="<?= htmlspecialchars($site['favicon']) ?>">
    <?php else: ?>
        <link rel="icon" href="/site-icon" type="image/svg+xml">
        <link rel="shortcut icon" href="/site-icon" type="image/svg+xml">
        <link rel="apple-touch-icon" href="/site-icon">
    <?php endif; ?>
    
    <!-- 预连接优化 -->
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    <link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
    
    <!-- 网站图标预加载 -->
    <link rel="prefetch" href="/site-icon" as="image" type="image/svg+xml">
    
    <!-- 资源预加载 -->
    <link rel="preload" href="/themes/default/style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>" as="style">
    
    <!-- Meta信息 -->
    <title><?= htmlspecialchars($site['title']) ?> - <?= htmlspecialchars($site['subtitle']) ?></title>
    <meta name="keywords" content="<?= htmlspecialchars($site['keywords']) ?>">
    <meta name="description" content="<?= htmlspecialchars($site['description']) ?>">
    
    <!-- 样式文件 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="/themes/default/style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>" media="all">
    
    <!-- 图标加载器 -->
    
    <!-- 自定义头部代码 -->
    <?= $site['custom_header'] ?? '' ?>
</head>

<body>
    <div class="app-container">
        <!-- 左侧边栏 -->
        <aside class="sidebar">
            <!-- 网站标题 -->
            <div class="site-header">
                <div class="site-logo">
                    <?php if (!empty($site['logo'])): ?>
                        <img src="<?= htmlspecialchars($site['logo']) ?>" alt="<?= htmlspecialchars($site['title']) ?>" class="site-logo-img">
                    <?php else: ?>
                        <img src="/site-icon" alt="<?= htmlspecialchars($site['title']) ?>" class="site-logo-img">
                    <?php endif; ?>
                </div>
                <div class="site-info">
                    <h1 class="site-title"><?= htmlspecialchars($site['title'] ?? 'LinkHub') ?></h1>
                    <p class="site-subtitle"><?= htmlspecialchars($site['subtitle'] ?? '开源书签管理器') ?></p>
                </div>
            </div>

            <!-- 分类导航 -->
            <nav class="category-nav">
                <?php if (!empty($categories)): ?>
                    <?php foreach ($categories as $category): ?>
                        <?php
                        // 处理分类图标前缀
                        $categoryIcon = $category['icon'] ?? 'fas fa-folder';
                        if (strpos($categoryIcon, 'fa-') === 0) {
                            // 品牌图标列表 (需要 fab 前缀)
                            $brandIcons = [
                                'fa-github', 'fa-youtube', 'fa-docker', 'fa-google', 'fa-facebook',
                                'fa-twitter', 'fa-linkedin', 'fa-instagram', 'fa-microsoft', 'fa-apple',
                                'fa-amazon', 'fa-netflix', 'fa-spotify', 'fa-discord', 'fa-telegram',
                                'fa-whatsapp', 'fa-chrome', 'fa-firefox', 'fa-edge', 'fa-safari',
                                'fa-stack-overflow', 'fa-codepen', 'fa-npm', 'fa-node-js', 'fa-react',
                                'fa-vue', 'fa-angular', 'fa-laravel', 'fa-wordpress', 'fa-drupal',
                                'fa-bootstrap', 'fa-css3', 'fa-html5', 'fa-js', 'fa-python',
                                'fa-java', 'fa-php', 'fa-android', 'fa-ubuntu', 'fa-windows',
                                'fa-linux', 'fa-git', 'fa-gitlab', 'fa-bitbucket'
                            ];
                            
                            if (in_array($categoryIcon, $brandIcons)) {
                                $categoryIcon = 'fab ' . $categoryIcon;
                            } else {
                                $categoryIcon = 'fas ' . $categoryIcon;
                            }
                        }
                        ?>
                        <a href="#category-<?= $category['id'] ?>" class="category-item" data-category="<?= $category['id'] ?>">
                            <i class="<?= htmlspecialchars($categoryIcon) ?>" 
                               style="color: <?= htmlspecialchars($category['icon_color'] ?? '#6b7280') ?>"></i>
                            <span><?= htmlspecialchars($category['name']) ?></span>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </nav>

            <!-- 添加分类按钮 -->
            <div class="sidebar-footer">
                <a href="<?= $site['admin_url'] ?? '/admin/categories.php' ?>" class="add-category-btn">
                    <i class="fas fa-plus"></i>
                    <span>新建分类</span>
                </a>
            </div>
        </aside>

        <!-- 主内容区域 -->
        <main class="main-content">
            <!-- 顶部搜索栏 -->
            <header class="search-header">
                <div class="search-container">
                    <form method="POST" class="search-form">
                        <div class="search-engine-select">
                            <select name="engine" id="searchEngine">
                                <option value="baidu">百度</option>
                                <option value="google">Google</option>
                                <option value="bing">Bing</option>
                            </select>
                        </div>
                        <div class="search-input-wrapper">
                            <input type="text" name="q" class="search-input" placeholder="请输入关键词" autocomplete="off">
                            <button type="submit" class="search-btn">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- 管理后台链接 -->
                <div class="header-actions">
                    <a href="<?= $site['user_center_url'] ?? '/login.php' ?>" class="admin-link">
                        <i class="fas fa-cog"></i>
                    </a>
                </div>
            </header>

            <!-- 链接内容区域 -->
            <div class="content-area">
                <?php if (!empty($categories)): ?>
                    <?php foreach ($categories as $category): ?>
                        <section class="category-section" id="category-<?= $category['id'] ?>">
                            <div class="category-header">
                                <h2 class="category-title">
                                    <?php
                                    // 处理分类图标前缀
                                    $categoryTitleIcon = $category['icon'] ?? 'fas fa-folder';
                                    if (strpos($categoryTitleIcon, 'fa-') === 0) {
                                        // 品牌图标列表 (需要 fab 前缀)
                                        $brandIcons = [
                                            'fa-github', 'fa-youtube', 'fa-docker', 'fa-google', 'fa-facebook',
                                            'fa-twitter', 'fa-linkedin', 'fa-instagram', 'fa-microsoft', 'fa-apple',
                                            'fa-amazon', 'fa-netflix', 'fa-spotify', 'fa-discord', 'fa-telegram',
                                            'fa-whatsapp', 'fa-chrome', 'fa-firefox', 'fa-edge', 'fa-safari',
                                            'fa-stack-overflow', 'fa-codepen', 'fa-npm', 'fa-node-js', 'fa-react',
                                            'fa-vue', 'fa-angular', 'fa-laravel', 'fa-wordpress', 'fa-drupal',
                                            'fa-bootstrap', 'fa-css3', 'fa-html5', 'fa-js', 'fa-python',
                                            'fa-java', 'fa-php', 'fa-android', 'fa-ubuntu', 'fa-windows',
                                            'fa-linux', 'fa-git', 'fa-gitlab', 'fa-bitbucket'
                                        ];
                                        
                                        if (in_array($categoryTitleIcon, $brandIcons)) {
                                            $categoryTitleIcon = 'fab ' . $categoryTitleIcon;
                                        } else {
                                            $categoryTitleIcon = 'fas ' . $categoryTitleIcon;
                                        }
                                    }
                                    ?>
                                    <i class="<?= htmlspecialchars($categoryTitleIcon) ?>" 
                                       style="color: <?= htmlspecialchars($category['icon_color'] ?? '#6b7280') ?>"></i>
                                    <?= htmlspecialchars($category['name']) ?>
                                </h2>
                                <button class="category-edit-btn" onclick="editCategory(<?= $category['id'] ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>

                            <?php 
                            // 获取分类下的链接
                            $categoryLinks = $category['links'] ?? [];
                            ?>

                            <?php if (!empty($categoryLinks)): ?>
                                <div class="links-grid">
                                    <?php foreach ($categoryLinks as $link): ?>
                                        <?php
                                        // 根据链接模式生成URL
                                        if ($site['link_model'] === 'direct') {
                                            $url = htmlspecialchars($link['url']);
                                        } else {
                                            $url = "/click/" . $link['id'];
                                        }
                                        ?>
                                        <a href="<?= $url ?>" 
                                           target="_blank" 
                                           class="link-card"
                                           title="<?= htmlspecialchars($link['note'] ?? '') ?>"
                                           onclick="return handleLinkClick(event, '<?= htmlspecialchars($link['url'], ENT_QUOTES) ?>', '<?= htmlspecialchars($link['title'], ENT_QUOTES) ?>')"
                                        >
                                            <!-- 智能链接图标 -->
                                            <div class="smart-link-icon" id="icon-link-<?= $link['id'] ?>" 
                                                 data-link-id="<?= $link['id'] ?>"
                                                 data-title="<?= htmlspecialchars($link['title']) ?>"
                                                 data-icon-url="<?= !empty($link['icon_url']) ? htmlspecialchars($link['icon_url']) : '' ?>"
                                                 data-icon="<?= !empty($link['icon']) ? htmlspecialchars($link['icon']) : '' ?>"
                                                 data-icon-color="<?= htmlspecialchars($link['icon_color'] ?? '#6b7280') ?>">
                                                <!-- 简化逻辑：两种情况 -->
                                                <?php
                                                // 简单逻辑：有图标设置就显示图标，没有就显示首字母
                                                $iconColor = $link['icon_color'] ?? '#6b7280';
                                                $hasIcon = false;
                                                
                                                // 1. 检查图片URL图标
                                                if (!empty($link['icon_url'])) {
                                                    $hasIcon = true;
                                                    echo '<img src="' . htmlspecialchars($link['icon_url']) . '" 
                                                             alt="' . htmlspecialchars($link['title']) . '" 
                                                             class="link-icon-image">';
                                                }
                                                // 2. 检查字体图标
                                                elseif (!empty($link['icon']) || !empty($link['font_icon'])) {
                                                    $iconClass = $link['icon'] ?: $link['font_icon'];
                                                    if (!empty($iconClass)) {
                                                        $hasIcon = true;
                                                        // 智能添加图标前缀
                                                        if (strpos($iconClass, 'fa-') === 0) {
                                                            // 品牌图标列表 (需要 fab 前缀)
                                                            $brandIcons = [
                                                                'fa-github', 'fa-youtube', 'fa-docker', 'fa-google', 'fa-facebook',
                                                                'fa-twitter', 'fa-linkedin', 'fa-instagram', 'fa-microsoft', 'fa-apple',
                                                                'fa-amazon', 'fa-netflix', 'fa-spotify', 'fa-discord', 'fa-telegram',
                                                                'fa-whatsapp', 'fa-chrome', 'fa-firefox', 'fa-edge', 'fa-safari',
                                                                'fa-stack-overflow', 'fa-codepen', 'fa-npm', 'fa-node-js', 'fa-react',
                                                                'fa-vue', 'fa-angular', 'fa-laravel', 'fa-wordpress', 'fa-drupal',
                                                                'fa-bootstrap', 'fa-css3', 'fa-html5', 'fa-js', 'fa-python',
                                                                'fa-java', 'fa-php', 'fa-android', 'fa-ubuntu', 'fa-windows',
                                                                'fa-linux', 'fa-git', 'fa-gitlab', 'fa-bitbucket'
                                                            ];
                                                            
                                                            if (in_array($iconClass, $brandIcons)) {
                                                                $iconClass = 'fab ' . $iconClass;
                                                            } else {
                                                                $iconClass = 'fas ' . $iconClass;
                                                            }
                                                        }
                                                        echo '<i class="' . htmlspecialchars($iconClass) . '" 
                                                                style="color: ' . htmlspecialchars($iconColor) . ';"></i>';
                                                    }
                                                }
                                                
                                                // 3. 没有图标设置，显示首字母
                                                if (!$hasIcon) {
                                                    $firstChar = mb_substr($link['title'], 0, 1, 'UTF-8');
                                                    echo '<div class="link-letter-avatar" 
                                                                style="background: linear-gradient(135deg, ' . $iconColor . ' 0%, ' . $iconColor . 'dd 100%);" 
                                                                title="' . htmlspecialchars($link['title']) . '">
                                                            ' . htmlspecialchars($firstChar) . '
                                                          </div>';
                                                }
                                                ?>
                                            </div>
                                            <div class="link-info">
                                                <h3 class="link-title"><?= htmlspecialchars($link['title']) ?></h3>
                                                <p class="link-description"><?= htmlspecialchars($link['note'] ?? '') ?></p>
                                            </div>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="empty-category">
                                    <i class="fas fa-inbox"></i>
                                    <p>暂无链接</p>
                                </div>
                            <?php endif; ?>
                        </section>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-compass"></i>
                        <h3>欢迎使用 LinkHub</h3>
                        <p>开始添加您的第一个分类和链接吧</p>
                    </div>
                <?php endif; ?>
            </div>

        </main>
    </div>
    
    <!-- 全宽页脚区域 - 独立于侧边栏布局 -->
    <footer class="site-footer">
        <div class="footer-content">
            <?php if (empty($site['custom_footer'])): ?>
                <p>© <?= date('Y') ?> <?= htmlspecialchars($site['title']) ?> | Powered by <a href="https://github.com/linkhub/linkhub" target="_blank">LinkHub</a>
                <?php if (!empty($site['icp'])): ?>
                 | 备案号：<a href="https://beian.miit.gov.cn/" target="_blank"><?= htmlspecialchars($site['icp']) ?></a>
                <?php endif; ?>
                </p>
            <?php else: ?>
                <?= $site['custom_footer'] ?>
            <?php endif; ?>
        </div>
    </footer>
    
    <!-- 底部操作栏 -->
    <div class="bottom-actions">
        <button class="action-btn" onclick="scrollToTop()" title="返回顶部">
            <i class="fas fa-arrow-up"></i>
        </button>
    </div>

    <!-- JavaScript -->
    <script>
        // 简化的图标错误处理
        document.addEventListener('DOMContentLoaded', function() {
            // 为所有图标图片添加错误处理
            const iconImages = document.querySelectorAll('.link-icon-image');
            iconImages.forEach(img => {
                if (!img.onerror) {
                    img.onerror = function() {
                        this.style.display = 'none';
                        const avatar = this.nextElementSibling;
                        if (avatar && avatar.classList.contains('link-letter-avatar')) {
                            avatar.style.display = 'flex';
                        }
                    };
                }
            });
        });

        // 渲染所有图标的函数
        function renderAllIcons() {
            const iconElements = document.querySelectorAll('[data-link-id]');
            iconElements.forEach(element => {
                const linkId = element.getAttribute('data-link-id');
                const title = element.getAttribute('data-title');
                const iconUrl = element.getAttribute('data-icon-url');
                const icon = element.getAttribute('data-icon');
                const iconColor = element.getAttribute('data-icon-color');

                if (window.iconLoader && typeof window.iconLoader.renderIcon === 'function') {
                    try {
                        element.innerHTML = window.iconLoader.renderIcon(linkId, title, iconUrl, icon, iconColor);
                    } catch (error) {
                        console.error('渲染图标失败，使用备用显示', error);
                        // 保持备用显示不变
                    }
                }
                // 如果iconLoader不可用，保持备用的HTML显示
            });
        }
        
        // 过渡页面处理函数
        function handleLinkClick(event, url, title) {
            const enableTransition = <?= json_encode($site['enable_transition_page'] ?? '0') ?>;
            
            // 简化逻辑：只检查是否启用过渡页面（兼容数字和字符串）
            if (enableTransition == '1' || enableTransition === 1) {
                event.preventDefault();
                const transitionUrl = '/transition_advanced.php?url=' + encodeURIComponent(url) + '&site=' + encodeURIComponent(title);
                window.location.href = transitionUrl;
                return false;
            }
            return true;
        }

        // 搜索引擎切换
        document.getElementById('searchEngine').addEventListener('change', function() {
            const engine = this.value;
            const form = document.querySelector('.search-form');
            
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                const query = document.querySelector('.search-input').value;
                if (!query.trim()) return;
                
                let searchUrl = '';
                switch(engine) {
                    case 'google':
                        searchUrl = 'https://www.google.com/search?q=' + encodeURIComponent(query);
                        break;
                    case 'bing':
                        searchUrl = 'https://www.bing.com/search?q=' + encodeURIComponent(query);
                        break;
                    default:
                        searchUrl = 'https://www.baidu.com/s?ie=utf-8&word=' + encodeURIComponent(query);
                }
                
                window.open(searchUrl, '_blank');
            });
        });

        // 分类导航高亮
        function updateActiveCategory() {
            const sections = document.querySelectorAll('.category-section');
            const navItems = document.querySelectorAll('.category-item');
            
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                if (window.pageYOffset >= sectionTop - 100) {
                    current = section.getAttribute('id');
                }
            });

            navItems.forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('href') === '#' + current) {
                    item.classList.add('active');
                }
            });
        }

        // 滚动监听
        window.addEventListener('scroll', updateActiveCategory);

        // 平滑滚动到顶部
        function scrollToTop() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // 分类导航点击处理
        document.querySelectorAll('.category-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });

        // 搜索框自动聚焦
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.querySelector('.search-input');
            if (searchInput) {
                searchInput.focus();
            }
        });

        // 占位函数（后续可以添加实际功能）
        function showAddCategoryModal() { console.log('添加分类'); }
        function showAddLinkModal() { console.log('添加链接'); }
        function editCategory(id) { console.log('编辑分类', id); }
        function toggleView() { console.log('切换视图'); }
        function showImportModal() { console.log('导入书签'); }
        function showSettingsModal() { console.log('设置'); }
    </script>
</body>
</html>