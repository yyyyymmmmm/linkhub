/**
 * LinkHub - Modern Admin JavaScript
 * 现代化后台管理系统交互脚本
 */

(function() {
    'use strict';

    // 全局配置
    const Config = {
        sidebarKey: 'linkhub_sidebar_collapsed',
        animationDuration: 300,
        debounceDelay: 300
    };

    // 工具函数
    const Utils = {
        // 防抖函数
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        // 本地存储
        storage: {
            get: function(key, defaultValue = null) {
                try {
                    const item = localStorage.getItem(key);
                    return item ? JSON.parse(item) : defaultValue;
                } catch (e) {
                    return defaultValue;
                }
            },
            set: function(key, value) {
                try {
                    localStorage.setItem(key, JSON.stringify(value));
                    return true;
                } catch (e) {
                    return false;
                }
            }
        },

        // 查询选择器
        $: function(selector, context = document) {
            return context.querySelector(selector);
        },

        $$: function(selector, context = document) {
            return Array.from(context.querySelectorAll(selector));
        }
    };

    // 侧边栏管理
    const Sidebar = {
        elements: {
            sidebar: null,
            toggle: null,
            overlay: null,
            mobileToggle: null
        },

        init: function() {
            this.elements.sidebar = Utils.$('.admin-sidebar');
            this.elements.toggle = Utils.$('.sidebar-toggle');
            this.elements.overlay = Utils.$('.sidebar-overlay');
            this.elements.mobileToggle = Utils.$('.mobile-sidebar-toggle');

            if (!this.elements.sidebar) return;

            this.bindEvents();
            this.restoreState();
        },

        bindEvents: function() {
            if (this.elements.toggle) {
                this.elements.toggle.addEventListener('click', () => {
                    this.toggle();
                });
            }

            if (this.elements.mobileToggle) {
                this.elements.mobileToggle.addEventListener('click', () => {
                    this.open();
                });
            }

            if (this.elements.overlay) {
                this.elements.overlay.addEventListener('click', () => {
                    this.close();
                });
            }

            // ESC键关闭
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    this.close();
                }
            });

            // 窗口大小变化处理
            window.addEventListener('resize', () => {
                this.handleResize();
            });
        },

        toggle: function() {
            if (!this.elements.sidebar) return;
            const isCollapsed = this.elements.sidebar.classList.toggle('collapsed');
            Utils.storage.set(Config.sidebarKey, isCollapsed);
        },

        open: function() {
            if (!this.elements.sidebar) return;
            this.elements.sidebar.classList.add('active');
            if (this.elements.overlay) {
                this.elements.overlay.classList.add('active');
            }
            document.body.style.overflow = 'hidden';
        },

        close: function() {
            if (!this.elements.sidebar) return;
            this.elements.sidebar.classList.remove('active');
            if (this.elements.overlay) {
                this.elements.overlay.classList.remove('active');
            }
            document.body.style.overflow = '';
        },

        restoreState: function() {
            const isCollapsed = Utils.storage.get(Config.sidebarKey, false);
            if (isCollapsed && window.innerWidth > 768) {
                this.elements.sidebar.classList.add('collapsed');
            }
        },

        handleResize: function() {
            if (window.innerWidth > 768) {
                this.close();
                this.restoreState();
            }
        }
    };

    // 标签页管理
    const Tabs = {
        init: function() {
            const tabBtns = Utils.$$('.tab-btn');
            const tabContents = Utils.$$('.tab-content');

            if (tabBtns.length === 0) return;

            tabBtns.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const tabId = btn.dataset.tab;
                    this.switchTab(tabId, tabBtns, tabContents);
                });
            });
        },

        switchTab: function(tabId, tabBtns, tabContents) {
            // 移除所有活动状态
            tabBtns.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // 激活当前标签
            const activeBtn = Utils.$(`[data-tab="${tabId}"]`);
            const activeContent = Utils.$(`#${tabId}`);

            if (activeBtn && activeContent) {
                activeBtn.classList.add('active');
                activeContent.classList.add('active');
            }
        }
    };

    // 表格管理
    const Table = {
        init: function() {
            this.initSelectAll();
            this.initBatchActions();
            this.initDeleteConfirm();
        },

        initSelectAll: function() {
            const selectAll = Utils.$('.select-all');
            if (!selectAll) return;

            selectAll.addEventListener('change', () => {
                const selectItems = Utils.$$('.select-item');
                selectItems.forEach(item => {
                    item.checked = selectAll.checked;
                });
                this.updateBatchActions();
            });
        },

        initBatchActions: function() {
            const selectItems = Utils.$$('.select-item');
            selectItems.forEach(item => {
                item.addEventListener('change', () => {
                    this.updateBatchActions();
                });
            });
        },

        updateBatchActions: function() {
            const selectedItems = Utils.$$('.select-item:checked');
            const batchActions = Utils.$('#batchActions, .batch-actions');
            const selectedCount = Utils.$('.selected-count');
        
        if (batchActions) {
            if (selectedItems.length > 0) {
                batchActions.style.display = 'block';
                    if (selectedCount) {
                        selectedCount.textContent = selectedItems.length;
                    }
            } else {
                batchActions.style.display = 'none';
            }
        }

            // 更新全选状态
            const selectAll = Utils.$('.select-all');
            const totalItems = Utils.$$('.select-item');
            if (selectAll && totalItems.length > 0) {
                selectAll.checked = selectedItems.length === totalItems.length;
            }
        },

        initDeleteConfirm: function() {
            const deleteButtons = Utils.$$('.delete-btn, [data-action="delete"]');
            deleteButtons.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const message = btn.dataset.message || '确定要删除这个项目吗？';
                    if (confirm(message)) {
                        if (btn.href) {
                            window.location.href = btn.href;
                        } else if (btn.dataset.url) {
                            window.location.href = btn.dataset.url;
                        }
                    }
                });
            });
        }
    };

    // 全局函数
    window.toggleSidebar = function() {
        Sidebar.toggle();
    };

    window.openSidebar = function() {
        Sidebar.open();
    };

    window.closeSidebar = function() {
        Sidebar.close();
    };

    window.updateBatchActions = function() {
        Table.updateBatchActions();
    };

    window.batchUpdateProperty = function(property) {
        const selectedItems = Utils.$$('.select-item:checked');
        if (selectedItems.length === 0) {
            alert('请选择要操作的项目');
            return;
        }

        const ids = selectedItems.map(item => item.value);
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const actionInput = document.createElement('input');
        actionInput.name = 'action';
        actionInput.value = 'update_property';
        form.appendChild(actionInput);

        const propertyInput = document.createElement('input');
        propertyInput.name = 'property';
        propertyInput.value = property;
        form.appendChild(propertyInput);

        ids.forEach(id => {
            const idInput = document.createElement('input');
            idInput.name = 'ids[]';
            idInput.value = id;
            form.appendChild(idInput);
        });

        document.body.appendChild(form);
        form.submit();
    };

    window.batchDelete = function() {
        const selectedItems = Utils.$$('.select-item:checked');
        if (selectedItems.length === 0) {
            alert('请选择要删除的项目');
            return;
        }

        if (!confirm(`确定要删除选中的 ${selectedItems.length} 个项目吗？此操作无法撤销。`)) {
            return;
        }
        
        const ids = selectedItems.map(item => item.value);
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';

        const actionInput = document.createElement('input');
        actionInput.name = 'action';
        actionInput.value = 'batch_delete';
        form.appendChild(actionInput);

        ids.forEach(id => {
            const idInput = document.createElement('input');
            idInput.name = 'ids[]';
            idInput.value = id;
            form.appendChild(idInput);
        });

        document.body.appendChild(form);
        form.submit();
    };

    // 侧边栏导航高亮
    const Navigation = {
        init: function() {
            this.setActiveNavigation();
        },

        setActiveNavigation: function() {
            const currentPath = window.location.pathname;
            const currentSearch = window.location.search;
            const currentUrl = currentPath + currentSearch;
            
            // 移除所有active类
            const navLinks = Utils.$$('.sidebar-nav a');
            navLinks.forEach(link => link.classList.remove('active'));
            
            // 定义页面匹配规则
            const pageRules = [
                { pattern: /\/admin\/$/, selector: 'a[href="/admin/"]' },
                { pattern: /\/admin\/index\.php/, selector: 'a[href="/admin/"]' },
                { pattern: /\/admin\/categories\.php\?action=add/, selector: 'a[href="/admin/categories.php?action=add"]' },
                { pattern: /\/admin\/categories\.php/, selector: 'a[href="/admin/categories.php"]' },
                { pattern: /\/admin\/links\.php\?action=add/, selector: 'a[href="/admin/links.php?action=add"]' },
                { pattern: /\/admin\/links\.php/, selector: 'a[href="/admin/links.php"]' },
                { pattern: /\/admin\/users\.php/, selector: 'a[href="/admin/users.php"]' },
                { pattern: /\/admin\/settings\.php/, selector: 'a[href="/admin/settings.php"]' },
                { pattern: /\/admin\/themes\.php/, selector: 'a[href="/admin/themes.php"]' },
                { pattern: /\/admin\/backup\.php/, selector: 'a[href="/admin/backup.php"]' },
                { pattern: /\/admin\/import\.php/, selector: 'a[href="/admin/import.php"]' },
                { pattern: /\/admin\/demo\.php/, selector: 'a[href="/admin/demo.php"]' }
            ];
            
            // 查找匹配的规则
            for (const rule of pageRules) {
                if (rule.pattern.test(currentUrl)) {
                    const activeLink = Utils.$(rule.selector);
                    if (activeLink) {
                        activeLink.classList.add('active');
                        break;
                    }
                }
            }
        }
    };

    // 初始化
    document.addEventListener('DOMContentLoaded', function() {
        Sidebar.init();
        Navigation.init();
        Tabs.init();
        Table.init();

        // 页面加载完成效果
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 0.3s ease';
        
        requestAnimationFrame(() => {
            document.body.style.opacity = '1';
        });
    });

})();