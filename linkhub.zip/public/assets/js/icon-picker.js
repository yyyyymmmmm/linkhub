/**
 * LinkHub - Icon Picker Component
 * 图标选择器组件
 */

(function() {
    'use strict';

    // 图标库 - 200+ FontAwesome 图标
    const ICON_LIBRARY = {
        // 常用图标
        'common': [
            'fa-home', 'fa-star', 'fa-heart', 'fa-user', 'fa-users', 'fa-cog', 'fa-search', 'fa-plus',
            'fa-minus', 'fa-times', 'fa-check', 'fa-arrow-right', 'fa-arrow-left', 'fa-arrow-up', 'fa-arrow-down',
            'fa-edit', 'fa-trash', 'fa-save', 'fa-download', 'fa-upload', 'fa-share', 'fa-print', 'fa-copy',
            'fa-cut', 'fa-paste', 'fa-undo', 'fa-redo', 'fa-refresh', 'fa-sync', 'fa-lock', 'fa-unlock'
        ],
        
        // 网站和应用
        'websites': [
            'fa-globe', 'fa-link', 'fa-external-link-alt', 'fa-bookmark', 'fa-bookmarks', 'fa-sitemap',
            'fa-rss', 'fa-wifi', 'fa-signal', 'fa-broadcast-tower', 'fa-satellite', 'fa-server',
            'fa-database', 'fa-cloud', 'fa-cloud-download-alt', 'fa-cloud-upload-alt', 'fa-network-wired'
        ],

        // 社交媒体
        'social': [
            'fa-facebook', 'fa-twitter', 'fa-instagram', 'fa-linkedin', 'fa-youtube', 'fa-tiktok',
            'fa-wechat', 'fa-weibo', 'fa-qq', 'fa-telegram', 'fa-whatsapp', 'fa-discord',
            'fa-skype', 'fa-snapchat', 'fa-pinterest', 'fa-reddit', 'fa-tumblr', 'fa-flickr'
        ],

        // 科技和开发
        'tech': [
            'fa-code', 'fa-terminal', 'fa-laptop', 'fa-desktop', 'fa-mobile-alt', 'fa-tablet-alt',
            'fa-keyboard', 'fa-mouse', 'fa-microchip', 'fa-memory', 'fa-hdd', 'fa-usb',
            'fa-github', 'fa-gitlab', 'fa-bitbucket', 'fa-stack-overflow', 'fa-codepen', 'fa-jsfiddle'
        ],

        // 商业和金融
        'business': [
            'fa-briefcase', 'fa-building', 'fa-industry', 'fa-store', 'fa-shopping-cart', 'fa-credit-card',
            'fa-money-bill', 'fa-coins', 'fa-chart-line', 'fa-chart-bar', 'fa-chart-pie', 'fa-analytics',
            'fa-calculator', 'fa-receipt', 'fa-file-invoice', 'fa-handshake', 'fa-balance-scale'
        ],

        // 教育和学习
        'education': [
            'fa-book', 'fa-book-open', 'fa-graduation-cap', 'fa-school', 'fa-university', 'fa-chalkboard',
            'fa-chalkboard-teacher', 'fa-pencil-alt', 'fa-pen', 'fa-highlighter', 'fa-eraser',
            'fa-ruler', 'fa-compass', 'fa-microscope', 'fa-flask', 'fa-atom', 'fa-dna'
        ],

        // 娱乐和媒体
        'entertainment': [
            'fa-film', 'fa-video', 'fa-camera', 'fa-photo-video', 'fa-music', 'fa-headphones',
            'fa-microphone', 'fa-guitar', 'fa-drum', 'fa-gamepad', 'fa-dice', 'fa-chess',
            'fa-puzzle-piece', 'fa-theater-masks', 'fa-ticket-alt', 'fa-popcorn'
        ],

        // 交通和旅行
        'travel': [
            'fa-car', 'fa-bus', 'fa-train', 'fa-plane', 'fa-ship', 'fa-bicycle', 'fa-motorcycle',
            'fa-taxi', 'fa-truck', 'fa-helicopter', 'fa-rocket', 'fa-subway', 'fa-tram',
            'fa-map', 'fa-map-marked-alt', 'fa-compass', 'fa-route', 'fa-road', 'fa-gas-pump'
        ],

        // 健康和医疗
        'health': [
            'fa-heartbeat', 'fa-user-md', 'fa-hospital', 'fa-ambulance', 'fa-first-aid',
            'fa-pills', 'fa-syringe', 'fa-thermometer', 'fa-stethoscope', 'fa-x-ray',
            'fa-dumbbell', 'fa-running', 'fa-walking', 'fa-biking', 'fa-swimming-pool'
        ],

        // 食物和饮品
        'food': [
            'fa-utensils', 'fa-coffee', 'fa-wine-glass', 'fa-beer', 'fa-cocktail', 'fa-ice-cream',
            'fa-pizza-slice', 'fa-hamburger', 'fa-hotdog', 'fa-cookie', 'fa-birthday-cake',
            'fa-apple-alt', 'fa-carrot', 'fa-pepper-hot', 'fa-fish', 'fa-egg'
        ],

        // 天气和自然
        'weather': [
            'fa-sun', 'fa-moon', 'fa-cloud', 'fa-cloud-rain', 'fa-cloud-snow', 'fa-bolt',
            'fa-rainbow', 'fa-wind', 'fa-temperature-high', 'fa-temperature-low', 'fa-snowflake',
            'fa-tree', 'fa-leaf', 'fa-seedling', 'fa-mountain', 'fa-water', 'fa-fire'
        ],

        // 工具和实用
        'tools': [
            'fa-wrench', 'fa-screwdriver', 'fa-hammer', 'fa-toolbox', 'fa-cogs', 'fa-bolt',
            'fa-plug', 'fa-battery-full', 'fa-lightbulb', 'fa-key', 'fa-scissors', 'fa-paperclip',
            'fa-thumbtack', 'fa-magnet', 'fa-anchor', 'fa-shield-alt', 'fa-lock', 'fa-unlock'
        ],

        // 办公用品
        'office': [
            'fa-folder', 'fa-folder-open', 'fa-file', 'fa-file-alt', 'fa-file-pdf', 'fa-file-word',
            'fa-file-excel', 'fa-file-powerpoint', 'fa-file-image', 'fa-file-archive', 'fa-envelope',
            'fa-inbox', 'fa-calendar', 'fa-clock', 'fa-stopwatch', 'fa-hourglass', 'fa-bell'
        ]
    };

    // 预定义颜色
    const COLOR_PALETTE = [
        '#6366f1', '#8b5cf6', '#ec4899', '#ef4444', '#f97316', '#f59e0b', '#eab308', '#84cc16',
        '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9', '#3b82f6', '#6366f1', '#8b5cf6',
        '#a855f7', '#d946ef', '#ec4899', '#f43f5e', '#ef4444', '#f97316', '#f59e0b', '#eab308',
        '#84cc16', '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9', '#3b82f6', '#1e40af',
        '#1e3a8a', '#312e81', '#581c87', '#86198f', '#be185d', '#be123c', '#dc2626', '#ea580c',
        '#d97706', '#ca8a04', '#65a30d', '#16a34a', '#059669', '#0d9488', '#0891b2', '#0284c7',
        '#2563eb', '#4f46e5', '#7c3aed', '#9333ea', '#c026d3', '#db2777', '#e11d48', '#dc2626'
    ];

    // 图标选择器类
    class IconPicker {
        constructor(options = {}) {
            this.options = {
                target: options.target || null,
                value: options.value || '',
                color: options.color || '#6366f1',
                showColorPicker: options.showColorPicker !== false,
                showUpload: options.showUpload !== false,
                onSelect: options.onSelect || function() {},
                onColorChange: options.onColorChange || function() {},
                onUpload: options.onUpload || function() {}
            };

            this.selectedIcon = this.options.value;
            this.selectedColor = this.options.color;
            this.modal = null;
            this.searchTerm = '';
            this.activeCategory = 'common';

            this.init();
        }

        init() {
            if (this.options.target) {
                this.bindTrigger();
            }
        }

        bindTrigger() {
            const trigger = document.querySelector(this.options.target);
            if (trigger) {
                trigger.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.show();
                });
            }
        }

        show() {
            this.createModal();
            this.modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            
            // 使用requestAnimationFrame确保平滑显示
            requestAnimationFrame(() => {
                this.modal.classList.add('show');
                
                // 聚焦搜索框
                const searchInput = this.modal.querySelector('.icon-search');
                if (searchInput) {
                    setTimeout(() => searchInput.focus(), 100);
                }
            });
        }

        hide() {
            if (this.modal) {
                this.modal.classList.remove('show');
                
                // 等待动画完成后隐藏
                setTimeout(() => {
                    if (this.modal) {
                        this.modal.style.display = 'none';
                        document.body.style.overflow = '';
                    }
                }, 200);
            }
        }

        createModal() {
            if (this.modal) {
                this.modal.remove();
            }

            this.modal = document.createElement('div');
            this.modal.className = 'icon-picker-modal';
            this.modal.innerHTML = this.getModalHTML();

            document.body.appendChild(this.modal);
            this.bindModalEvents();
            this.renderIcons();
        }

        getModalHTML() {
            return `
                <div class="icon-picker-overlay"></div>
                <div class="icon-picker-content">
                    <div class="icon-picker-header">
                        <h3>选择图标</h3>
                        <button class="icon-picker-close">&times;</button>
                    </div>
                    
                    <div class="icon-picker-body">
                        <!-- 搜索栏 -->
                        <div class="icon-search-bar">
                            <input type="text" class="icon-search" placeholder="搜索图标...">
                            <i class="fas fa-search"></i>
                        </div>

                        <!-- 上传区域 -->
                        ${this.options.showUpload ? `
                        <div class="icon-upload-section">
                            <div class="icon-upload-area">
                                <input type="file" id="iconUpload" accept="image/*" style="display: none;">
                                <label for="iconUpload" class="icon-upload-label">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <span>上传自定义图标</span>
                                </label>
                            </div>
                        </div>
                        ` : ''}

                        <!-- 分类标签 -->
                        <div class="icon-categories">
                            ${Object.keys(ICON_LIBRARY).map(category => `
                                <button class="icon-category-btn ${category === this.activeCategory ? 'active' : ''}" 
                                        data-category="${category}">
                                    ${this.getCategoryName(category)}
                                </button>
                            `).join('')}
                        </div>

                        <!-- 图标网格 -->
                        <div class="icon-grid-container">
                            <div class="icon-grid"></div>
                        </div>

                        <!-- 颜色选择器 -->
                        ${this.options.showColorPicker ? `
                        <div class="color-picker-section">
                            <h4>选择颜色</h4>
                            <div class="color-palette">
                                ${COLOR_PALETTE.map(color => `
                                    <button class="color-btn ${color === this.selectedColor ? 'active' : ''}" 
                                            style="background-color: ${color}" 
                                            data-color="${color}"></button>
                                `).join('')}
                            </div>
                            <div class="custom-color-input">
                                <label>自定义颜色：</label>
                                <input type="color" class="custom-color" value="${this.selectedColor}">
                            </div>
                        </div>
                        ` : ''}
                    </div>

                    <div class="icon-picker-footer">
                        <div class="icon-preview">
                            <i class="fas ${this.selectedIcon}" style="color: ${this.selectedColor}"></i>
                            <span>${this.selectedIcon || '未选择'}</span>
                        </div>
                        <div class="icon-picker-actions">
                            <button class="btn btn-secondary icon-picker-cancel">取消</button>
                            <button class="btn btn-primary icon-picker-confirm">确认选择</button>
                        </div>
                    </div>
                </div>
            `;
        }

        getCategoryName(category) {
            const names = {
                'common': '常用',
                'websites': '网站',
                'social': '社交',
                'tech': '科技',
                'business': '商业',
                'education': '教育',
                'entertainment': '娱乐',
                'travel': '旅行',
                'health': '健康',
                'food': '食物',
                'weather': '天气',
                'tools': '工具',
                'office': '办公'
            };
            return names[category] || category;
        }

        bindModalEvents() {
            // 关闭按钮
            this.modal.querySelector('.icon-picker-close').addEventListener('click', () => {
                this.hide();
            });

            this.modal.querySelector('.icon-picker-cancel').addEventListener('click', () => {
                this.hide();
            });

            // 遮罩层点击关闭
            this.modal.querySelector('.icon-picker-overlay').addEventListener('click', () => {
                this.hide();
            });

            // 确认按钮
            this.modal.querySelector('.icon-picker-confirm').addEventListener('click', () => {
                this.selectIcon();
            });

            // 搜索
            const searchInput = this.modal.querySelector('.icon-search');
            searchInput.addEventListener('input', (e) => {
                this.searchTerm = e.target.value.toLowerCase();
                this.renderIcons();
            });

            // 分类切换
            this.modal.querySelectorAll('.icon-category-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    this.activeCategory = btn.dataset.category;
                    this.modal.querySelectorAll('.icon-category-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    this.renderIcons();
                });
            });

            // 颜色选择
            if (this.options.showColorPicker) {
                this.modal.querySelectorAll('.color-btn').forEach(btn => {
                    btn.addEventListener('click', () => {
                        this.selectedColor = btn.dataset.color;
                        this.updateColorSelection();
                        this.updatePreview();
                    });
                });

                const customColorInput = this.modal.querySelector('.custom-color');
                customColorInput.addEventListener('change', (e) => {
                    this.selectedColor = e.target.value;
                    this.updateColorSelection();
                    this.updatePreview();
                });
            }

            // 文件上传
            if (this.options.showUpload) {
                const fileInput = this.modal.querySelector('#iconUpload');
                fileInput.addEventListener('change', (e) => {
                    this.handleFileUpload(e.target.files[0]);
                });
            }

            // ESC键关闭
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.modal && this.modal.style.display === 'flex') {
                    this.hide();
                }
            });
        }

        renderIcons() {
            const grid = this.modal.querySelector('.icon-grid');
            let icons = [];

            if (this.searchTerm) {
                // 搜索模式
                Object.values(ICON_LIBRARY).forEach(categoryIcons => {
                    icons = icons.concat(categoryIcons.filter(icon => 
                        icon.toLowerCase().includes(this.searchTerm)
                    ));
                });
            } else {
                // 分类模式
                icons = ICON_LIBRARY[this.activeCategory] || [];
            }

            grid.innerHTML = icons.map(icon => `
                <button class="icon-item ${icon === this.selectedIcon ? 'selected' : ''}" 
                        data-icon="${icon}" title="${icon}">
                    <i class="fas ${icon}" style="color: ${this.selectedColor}"></i>
                </button>
            `).join('');

            // 绑定图标点击事件
            grid.querySelectorAll('.icon-item').forEach(item => {
                item.addEventListener('click', () => {
                    this.selectedIcon = item.dataset.icon;
                    this.updateIconSelection();
                    this.updatePreview();
                });
            });
        }

        updateIconSelection() {
            this.modal.querySelectorAll('.icon-item').forEach(item => {
                item.classList.toggle('selected', item.dataset.icon === this.selectedIcon);
            });
        }

        updateColorSelection() {
            if (this.options.showColorPicker) {
                this.modal.querySelectorAll('.color-btn').forEach(btn => {
                    btn.classList.toggle('active', btn.dataset.color === this.selectedColor);
                });

                // 更新所有图标的颜色
                this.modal.querySelectorAll('.icon-item i').forEach(icon => {
                    icon.style.color = this.selectedColor;
                });
            }
        }

        updatePreview() {
            const preview = this.modal.querySelector('.icon-preview');
            const iconElement = preview.querySelector('i');
            const textElement = preview.querySelector('span');

            iconElement.className = `fas ${this.selectedIcon}`;
            iconElement.style.color = this.selectedColor;
            textElement.textContent = this.selectedIcon || '未选择';
        }

        handleFileUpload(file) {
            if (!file || !file.type.startsWith('image/')) {
                alert('请选择图片文件');
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                // 创建自定义图标项
                const customIcon = `custom-${Date.now()}`;
                this.selectedIcon = e.target.result; // 使用base64作为图标
                this.updatePreview();
                this.options.onUpload(file, e.target.result);
            };
            reader.readAsDataURL(file);
        }

        selectIcon() {
            this.options.onSelect(this.selectedIcon, this.selectedColor);
            if (this.options.showColorPicker) {
                this.options.onColorChange(this.selectedColor);
            }
            this.hide();
        }

        // 公共方法
        setValue(icon, color = null) {
            this.selectedIcon = icon;
            if (color) {
                this.selectedColor = color;
            }
        }

        getValue() {
            return {
                icon: this.selectedIcon,
                color: this.selectedColor
            };
        }
    }

    // 全局暴露
    window.IconPicker = IconPicker;

})();
