/**
 * LinkHub图标加载器
 * 用于高效加载和管理网站图标，提高前端性能
 */
class IconLoader {
    constructor() {
        this.iconMap = null;
        this.iconCache = {};
        this.loadingPromise = null;
        this.initialized = false;
    }

    /**
     * 初始化图标加载器
     */
    async init() {
        if (this.initialized) return;
        
        try {
            // 加载图标映射文件
            await this.loadIconMap();
            this.initialized = true;
            console.log('IconLoader: 初始化完成，已加载图标映射');
        } catch (error) {
            console.error('IconLoader: 初始化失败', error);
            // 初始化失败时设置为空映射，避免重复尝试加载
            this.iconMap = {};
            this.initialized = true;
        }
    }

    /**
     * 加载图标映射文件
     */
    async loadIconMap() {
        if (this.loadingPromise) {
            return this.loadingPromise;
        }

        this.loadingPromise = new Promise(async (resolve, reject) => {
            try {
                // 添加时间戳防止缓存
                const timestamp = new Date().getTime();
                const response = await fetch(`/cache/icon_map.json?_=${timestamp}`);
                
                if (!response.ok) {
                    throw new Error(`加载图标映射失败: ${response.status}`);
                }
                
                this.iconMap = await response.json();
                resolve(this.iconMap);
            } catch (error) {
                console.error('加载图标映射文件失败', error);
                this.iconMap = {};
                reject(error);
            }
        });

        return this.loadingPromise;
    }

    /**
     * 获取链接图标
     * @param {number} linkId 链接ID
     * @param {string} title 链接标题
     * @param {string} iconUrl 图标URL
     * @param {string} icon Font Awesome图标
     * @param {string} iconColor 图标颜色
     * @returns {Object} 图标信息
     */
    getIcon(linkId, title, iconUrl, icon, iconColor) {
        // 确保已初始化
        if (!this.initialized) {
            this.init();
        }

        const cacheKey = `link_${linkId}`;
        const defaultColor = iconColor || '#6b7280';
        const firstChar = title ? title.charAt(0) : '?';

        // 默认返回文字图标
        const defaultIcon = {
            type: 'text',
            value: firstChar,
            color: defaultColor
        };

        // 如果映射未加载，返回基于传入参数的图标
        if (!this.iconMap) {
            if (iconUrl) {
                return { type: 'url', value: iconUrl, color: defaultColor };
            } else if (icon && icon !== 'fas fa-link') {
                return { type: 'fa', value: icon, color: defaultColor };
            }
            return defaultIcon;
        }

        // 从缓存映射中获取图标
        const cachedIcon = this.iconMap[cacheKey];
        if (cachedIcon) {
            // 优先使用缓存的图标URL
            if (cachedIcon.type === 'url' && cachedIcon.cache_url) {
                return {
                    type: 'url',
                    value: cachedIcon.cache_url,
                    color: cachedIcon.color || defaultColor
                };
            } 
            // 其次使用Font Awesome图标
            else if (cachedIcon.type === 'fa') {
                return {
                    type: 'fa',
                    value: cachedIcon.value,
                    color: cachedIcon.color || defaultColor
                };
            }
        }

        // 如果没有缓存，使用传入的参数
        if (iconUrl) {
            return { type: 'url', value: iconUrl, color: defaultColor };
        } else if (icon && icon !== 'fas fa-link') {
            return { type: 'fa', value: icon, color: defaultColor };
        }

        // 最后返回文字图标
        return defaultIcon;
    }

    /**
     * 渲染图标HTML
     * @param {number} linkId 链接ID
     * @param {string} title 链接标题
     * @param {string} iconUrl 图标URL
     * @param {string} icon Font Awesome图标
     * @param {string} iconColor 图标颜色
     * @returns {string} 图标HTML
     */
    renderIcon(linkId, title, iconUrl, icon, iconColor) {
        const iconInfo = this.getIcon(linkId, title, iconUrl, icon, iconColor);
        
        if (iconInfo.type === 'url') {
            return `<img src="${iconInfo.value}" alt="${title}" class="icon-image">`;
        } else if (iconInfo.type === 'fa') {
            return `<i class="${iconInfo.value}" style="color: ${iconInfo.color};"></i>`;
        } else {
            // 生成随机背景色
            const bgColor = this.getColorFromString(title);
            return `<div class="icon-text" style="background-color: ${bgColor}; color: white;">${iconInfo.value}</div>`;
        }
    }

    /**
     * 从字符串生成颜色
     * @param {string} str 输入字符串
     * @returns {string} 颜色值
     */
    getColorFromString(str) {
        if (!str) return '#6b7280';
        
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        
        let color = '#';
        for (let i = 0; i < 3; i++) {
            const value = (hash >> (i * 8)) & 0xFF;
            color += ('00' + value.toString(16)).substr(-2);
        }
        
        return color;
    }

    /**
     * 预加载所有图标
     * 用于提前缓存所有图标，提高用户体验
     */
    async preloadAllIcons() {
        if (!this.iconMap) {
            await this.loadIconMap();
        }

        // 预加载所有URL类型的图标
        const urlIcons = Object.values(this.iconMap)
            .filter(icon => icon.type === 'url' && icon.cache_url)
            .map(icon => icon.cache_url);

        // 批量加载图片
        const preloadBatch = (urls, batchSize = 10) => {
            let processed = 0;
            
            const loadNext = () => {
                if (processed >= urls.length) return;
                
                const batch = urls.slice(processed, processed + batchSize);
                processed += batchSize;
                
                batch.forEach(url => {
                    const img = new Image();
                    img.src = url;
                });
                
                // 延迟加载下一批
                setTimeout(loadNext, 200);
            };
            
            loadNext();
        };

        preloadBatch(urlIcons);
    }
}

// 创建全局图标加载器实例
window.iconLoader = new window.iconLoader || new IconLoader();

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    window.iconLoader.init();
});
