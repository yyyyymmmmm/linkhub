/**
 * LinkHub - 侧边栏控制修复
 * 专门用于修复侧边栏展开收回问题
 */

(function() {
    'use strict';

    // 侧边栏控制器
    const SidebarController = {
        sidebar: null,
        toggleBtn: null,
        mobileToggleBtn: null,
        overlay: null,
        initialized: false,

        init: function() {
            if (this.initialized) return;

            // 获取DOM元素
            this.sidebar = document.querySelector('.admin-sidebar');
            this.toggleBtn = document.querySelector('.sidebar-toggle, #sidebarToggle');
            this.mobileToggleBtn = document.querySelector('.mobile-sidebar-toggle, #mobileSidebarToggle');
            this.overlay = document.querySelector('.sidebar-overlay');

            if (!this.sidebar) {
                console.warn('Sidebar element not found');
                return;
            }

            // 防止admin.js的侧边栏冲突
            this.preventConflicts();
            
            this.bindEvents();
            this.restoreState();
            this.initialized = true;
        },
        
        preventConflicts: function() {
            // 移除现有事件监听器
            if (this.toggleBtn) {
                const newToggleBtn = this.toggleBtn.cloneNode(true);
                this.toggleBtn.parentNode.replaceChild(newToggleBtn, this.toggleBtn);
                this.toggleBtn = newToggleBtn;
            }
            
            if (this.mobileToggleBtn) {
                const newMobileBtn = this.mobileToggleBtn.cloneNode(true);
                this.mobileToggleBtn.parentNode.replaceChild(newMobileBtn, this.mobileToggleBtn);
                this.mobileToggleBtn = newMobileBtn;
            }
            
            // 标记为已由SidebarController管理
            this.sidebar.setAttribute('data-sidebar-controller', 'true');
        },

        bindEvents: function() {
            // 桌面端切换按钮
            if (this.toggleBtn) {
                this.toggleBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.toggleCollapse();
                });
            }

            // 移动端切换按钮
            if (this.mobileToggleBtn) {
                this.mobileToggleBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    this.toggleMobile();
                });
            }

            // 遮罩层点击关闭
            if (this.overlay) {
                this.overlay.addEventListener('click', () => {
                    this.closeMobile();
                });
            }

            // ESC键关闭移动端侧边栏
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.isMobileView()) {
                    this.closeMobile();
                }
            });

            // 窗口大小变化处理
            window.addEventListener('resize', () => {
                this.handleResize();
            });
        },

        toggleCollapse: function() {
            if (!this.sidebar) return;

            const wasCollapsed = this.sidebar.classList.contains('collapsed');
            const isCollapsed = !wasCollapsed;
            
            // 切换class
            if (isCollapsed) {
                this.sidebar.classList.add('collapsed');
            } else {
                this.sidebar.classList.remove('collapsed');
            }
            
            // 保存状态（使用与admin.js相同的键名）
            try {
                localStorage.setItem('linkhub_sidebar_collapsed', JSON.stringify(isCollapsed));
            } catch (e) {
                console.warn('Failed to save sidebar state:', e);
            }

            // 更新切换按钮图标
            this.updateToggleIcon(isCollapsed);
        },

        updateToggleIcon: function(isCollapsed) {
            if (this.toggleBtn) {
                const icon = this.toggleBtn.querySelector('i');
                if (icon) {
                    icon.style.transform = isCollapsed ? 'rotate(180deg)' : 'rotate(0deg)';
                    icon.style.transition = 'transform 0.3s ease';
                }
            }
        },

        toggleMobile: function() {
            if (!this.sidebar) return;

            const isActive = this.sidebar.classList.toggle('active');
            
            if (this.overlay) {
                this.overlay.classList.toggle('active', isActive);
            }

            // 防止背景滚动
            document.body.style.overflow = isActive ? 'hidden' : '';
        },

        closeMobile: function() {
            if (!this.sidebar) return;

            this.sidebar.classList.remove('active');
            
            if (this.overlay) {
                this.overlay.classList.remove('active');
            }

            document.body.style.overflow = '';
        },

        restoreState: function() {
            if (!this.sidebar) return;

            try {
                // 默认状态：展开（不收缩）
                const savedData = localStorage.getItem('linkhub_sidebar_collapsed');
                const savedCollapsed = savedData ? JSON.parse(savedData) : false;
                const shouldCollapse = savedCollapsed && !this.isMobileView();
                
                if (shouldCollapse) {
                    this.sidebar.classList.add('collapsed');
                } else {
                    this.sidebar.classList.remove('collapsed');
                }
                
                // 更新切换按钮图标
                this.updateToggleIcon(shouldCollapse);
            } catch (e) {
                console.warn('Failed to restore sidebar state:', e);
                // 出错时确保默认展开
                this.sidebar.classList.remove('collapsed');
                this.updateToggleIcon(false);
            }
        },

        handleResize: function() {
            if (!this.sidebar) return;

            if (this.isMobileView()) {
                // 移动端：移除collapsed类，使用active类控制
                this.sidebar.classList.remove('collapsed');
                this.closeMobile();
            } else {
                // 桌面端：恢复collapsed状态
                this.restoreState();
            }
        },

        isMobileView: function() {
            return window.innerWidth <= 768;
        },

        // 公共API
        collapse: function() {
            if (this.sidebar && !this.sidebar.classList.contains('collapsed')) {
                this.toggleCollapse();
            }
        },

        expand: function() {
            if (this.sidebar && this.sidebar.classList.contains('collapsed')) {
                this.toggleCollapse();
            }
        },

        isCollapsed: function() {
            return this.sidebar ? this.sidebar.classList.contains('collapsed') : false;
        }
    };

    // 当DOM加载完成时初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            SidebarController.init();
        });
    } else {
        SidebarController.init();
    }

    // 全局暴露
    window.SidebarController = SidebarController;

    // 兼容旧的全局函数
    window.toggleSidebar = function() {
        SidebarController.toggleCollapse();
    };

    window.openSidebar = function() {
        if (SidebarController.isMobileView()) {
            SidebarController.toggleMobile();
        } else {
            SidebarController.expand();
        }
    };

    window.closeSidebar = function() {
        if (SidebarController.isMobileView()) {
            SidebarController.closeMobile();
        } else {
            SidebarController.collapse();
        }
    };

})();
