/**
 * 图标选择器
 * 提供Font Awesome图标选择功能
 */
class IconSelector {
    constructor(options = {}) {
        this.options = Object.assign({
            inputSelector: '#iconInput',          // 图标输入框选择器
            previewSelector: '#iconPreview',      // 图标预览元素选择器
            colorInputSelector: '#iconColor',     // 颜色输入框选择器
            modalId: 'iconSelectorModal',         // 模态框ID
            onSelect: null                        // 选择图标后的回调函数
        }, options);
        
        // 从图片中提取的图标
        this.allIcons = [
            // 第一页 - 文件和文档类
            'fa-folder', 'fa-file', 'fa-link', 'fa-globe', 'fa-home', 'fa-search',
            'fa-user', 'fa-users', 'fa-cog', 'fa-wrench', 'fa-star', 'fa-heart',
            'fa-bookmark', 'fa-file-alt', 'fa-code', 'fa-file-code', 'fa-file-pdf',
            'fa-file-word', 'fa-file-excel', 'fa-file-image', 'fa-file-video', 'fa-file-audio',
            'fa-file-archive', 'fa-file-signature', 'fa-file-invoice', 'fa-file-medical',
            'fa-file-csv', 'fa-file-download', 'fa-file-upload', 'fa-file-export',
            'fa-file-import', 'fa-file-contract', 'fa-file-prescription', 'fa-file-medical-alt',
            'fa-file-invoice-dollar', 'fa-file-powerpoint', 'fa-file-certificate', 'fa-paste',
            'fa-copy', 'fa-save', 'fa-folder-open', 'fa-folder-plus', 'fa-folder-minus',
            'fa-archive', 'fa-box', 'fa-boxes', 'fa-box-open', 'fa-box-archive',
            
            // 第二页 - 界面元素
            'fa-bars', 'fa-th', 'fa-th-large', 'fa-th-list', 'fa-list', 'fa-list-alt',
            'fa-list-ul', 'fa-list-ol', 'fa-table', 'fa-columns', 'fa-grip-horizontal',
            'fa-grip-vertical', 'fa-grip-lines', 'fa-grip-lines-vertical', 'fa-sliders-h',
            'fa-sliders-v', 'fa-tasks', 'fa-check-square', 'fa-check-circle', 'fa-check',
            'fa-times', 'fa-times-circle', 'fa-exclamation-circle', 'fa-exclamation-triangle',
            'fa-info-circle', 'fa-question-circle', 'fa-bell', 'fa-calendar', 'fa-calendar-alt',
            'fa-calendar-check', 'fa-calendar-plus', 'fa-calendar-minus', 'fa-calendar-times',
            'fa-clock', 'fa-stopwatch', 'fa-hourglass', 'fa-hourglass-start', 'fa-hourglass-half',
            'fa-hourglass-end', 'fa-sync', 'fa-sync-alt', 'fa-spinner', 'fa-circle-notch',
            'fa-compass', 'fa-map', 'fa-map-marker', 'fa-map-marker-alt', 'fa-map-pin',
            
            // 第三页 - 方向和箭头
            'fa-arrow-up', 'fa-arrow-down', 'fa-arrow-left', 'fa-arrow-right',
            'fa-arrow-circle-up', 'fa-arrow-circle-down', 'fa-arrow-circle-left',
            'fa-arrow-circle-right', 'fa-chevron-up', 'fa-chevron-down', 'fa-chevron-left',
            'fa-chevron-right', 'fa-chevron-circle-up', 'fa-chevron-circle-down',
            'fa-chevron-circle-left', 'fa-chevron-circle-right', 'fa-angle-up', 'fa-angle-down',
            'fa-angle-left', 'fa-angle-right', 'fa-angle-double-up', 'fa-angle-double-down',
            'fa-angle-double-left', 'fa-angle-double-right', 'fa-caret-up', 'fa-caret-down',
            'fa-caret-left', 'fa-caret-right', 'fa-sort', 'fa-sort-up', 'fa-sort-down',
            'fa-sort-alpha-up', 'fa-sort-alpha-down', 'fa-sort-numeric-up', 'fa-sort-numeric-down',
            'fa-sort-amount-up', 'fa-sort-amount-down', 'fa-long-arrow-up', 'fa-long-arrow-down',
            'fa-long-arrow-left', 'fa-long-arrow-right', 'fa-exchange', 'fa-exchange-alt',
            'fa-random', 'fa-redo', 'fa-undo', 'fa-reply', 'fa-share', 'fa-external-link-alt',
            
            // 第四页 - 媒体控制
            'fa-play', 'fa-pause', 'fa-stop', 'fa-backward', 'fa-forward',
            'fa-step-backward', 'fa-step-forward', 'fa-fast-backward', 'fa-fast-forward',
            'fa-play-circle', 'fa-pause-circle', 'fa-stop-circle', 'fa-volume-up',
            'fa-volume-down', 'fa-volume-off', 'fa-volume-mute', 'fa-music', 'fa-headphones',
            'fa-microphone', 'fa-microphone-slash', 'fa-podcast', 'fa-broadcast-tower',
            'fa-rss', 'fa-rss-square', 'fa-image', 'fa-images', 'fa-camera', 'fa-camera-retro',
            'fa-video', 'fa-film', 'fa-photo-video', 'fa-ticket-alt', 'fa-theater-masks',
            'fa-tv', 'fa-projector', 'fa-laptop-code', 'fa-gamepad', 'fa-puzzle-piece',
            'fa-dice', 'fa-chess', 'fa-chess-king', 'fa-chess-queen', 'fa-chess-bishop',
            'fa-chess-knight', 'fa-chess-rook', 'fa-chess-pawn', 'fa-dice-one', 'fa-dice-two',
            'fa-dice-three', 'fa-dice-four', 'fa-dice-five', 'fa-dice-six',
            
            // 第五页 - 通信和社交
            'fa-envelope', 'fa-envelope-open', 'fa-envelope-square', 'fa-paper-plane',
            'fa-comment', 'fa-comment-alt', 'fa-comment-dots', 'fa-comment-slash',
            'fa-comments', 'fa-sms', 'fa-inbox', 'fa-phone', 'fa-phone-alt', 'fa-phone-slash',
            'fa-phone-square', 'fa-phone-volume', 'fa-fax', 'fa-mobile', 'fa-mobile-alt',
            'fa-address-book', 'fa-address-card', 'fa-id-badge', 'fa-id-card', 'fa-id-card-alt',
            'fa-user-circle', 'fa-user-plus', 'fa-user-minus', 'fa-user-times', 'fa-user-edit',
            'fa-user-cog', 'fa-user-shield', 'fa-user-check', 'fa-user-clock', 'fa-user-friends',
            'fa-user-graduate', 'fa-user-injured', 'fa-user-lock', 'fa-user-md', 'fa-user-nurse',
            'fa-user-secret', 'fa-user-tag', 'fa-user-tie', 'fa-users-cog', 'fa-users-slash',
            'fa-share-alt', 'fa-share-alt-square', 'fa-share-square', 'fa-thumbs-up',
            'fa-thumbs-down', 'fa-hands-helping', 'fa-handshake', 'fa-heart-broken',
            
            // 第六页 - 设备和硬件
            'fa-desktop', 'fa-laptop', 'fa-tablet', 'fa-tablet-alt', 'fa-mobile', 'fa-mobile-alt',
            'fa-server', 'fa-database', 'fa-hdd', 'fa-sd-card', 'fa-memory', 'fa-microchip',
            'fa-sim-card', 'fa-ethernet', 'fa-wifi', 'fa-broadcast-tower', 'fa-router',
            'fa-satellite-dish', 'fa-satellite', 'fa-network-wired', 'fa-plug', 'fa-power-off',
            'fa-battery-full', 'fa-battery-three-quarters', 'fa-battery-half',
            'fa-battery-quarter', 'fa-battery-empty', 'fa-solar-panel', 'fa-charging-station',
            'fa-print', 'fa-scanner', 'fa-fax', 'fa-calculator', 'fa-cash-register',
            'fa-keyboard', 'fa-mouse', 'fa-mouse-pointer', 'fa-webcam', 'fa-camera',
            'fa-camera-retro', 'fa-video', 'fa-headphones', 'fa-headset', 'fa-microphone',
            'fa-microphone-alt', 'fa-microphone-slash', 'fa-speaker', 'fa-volume-up',
            'fa-volume-down', 'fa-volume-mute', 'fa-volume-off',
            
            // 第七页 - 编程和开发
            'fa-code', 'fa-code-branch', 'fa-terminal', 'fa-console', 'fa-laptop-code',
            'fa-bug', 'fa-shield-alt', 'fa-shield-virus', 'fa-virus', 'fa-virus-slash',
            'fa-spider', 'fa-microchip', 'fa-sitemap', 'fa-project-diagram', 'fa-digital-tachograph',
            'fa-network-wired', 'fa-server', 'fa-database', 'fa-hdd', 'fa-memory',
            'fa-cloud', 'fa-cloud-download-alt', 'fa-cloud-upload-alt', 'fa-cloud-meatball',
            'fa-cloud-moon', 'fa-cloud-moon-rain', 'fa-cloud-rain', 'fa-cloud-showers-heavy',
            'fa-cloud-sun', 'fa-cloud-sun-rain', 'fa-folder', 'fa-folder-open', 'fa-folder-plus',
            'fa-folder-minus', 'fa-file-code', 'fa-file-archive', 'fa-file-download',
            'fa-file-export', 'fa-file-import', 'fa-file-upload', 'fa-keyboard', 'fa-mouse',
            'fa-desktop', 'fa-laptop', 'fa-mobile', 'fa-mobile-alt', 'fa-tablet', 'fa-tablet-alt',
            'fa-qrcode', 'fa-barcode', 'fa-wifi', 'fa-rss',
            
            // 第八页 - 商业和金融
            'fa-chart-bar', 'fa-chart-line', 'fa-chart-pie', 'fa-chart-area',
            'fa-dollar-sign', 'fa-euro-sign', 'fa-pound-sign', 'fa-yen-sign', 'fa-ruble-sign',
            'fa-rupee-sign', 'fa-won-sign', 'fa-bitcoin', 'fa-ethereum', 'fa-btc', 'fa-usd',
            'fa-eur', 'fa-gbp', 'fa-yen', 'fa-rub', 'fa-krw', 'fa-inr', 'fa-money-bill',
            'fa-money-bill-alt', 'fa-money-bill-wave', 'fa-money-bill-wave-alt',
            'fa-money-check', 'fa-money-check-alt', 'fa-credit-card', 'fa-cc-visa',
            'fa-cc-mastercard', 'fa-cc-amex', 'fa-cc-discover', 'fa-cc-paypal', 'fa-cc-stripe',
            'fa-cc-apple-pay', 'fa-cc-amazon-pay', 'fa-wallet', 'fa-cash-register',
            'fa-coins', 'fa-piggy-bank', 'fa-percentage', 'fa-funnel-dollar', 'fa-donate',
            'fa-gift', 'fa-gifts', 'fa-store', 'fa-store-alt', 'fa-shopping-bag',
            'fa-shopping-basket', 'fa-shopping-cart', 'fa-cart-plus', 'fa-cart-arrow-down',
            'fa-cash-register', 'fa-receipt', 'fa-tag', 'fa-tags',
            
            // 第九页 - 交通和旅行
            'fa-car', 'fa-car-alt', 'fa-car-side', 'fa-car-crash', 'fa-car-battery',
            'fa-truck', 'fa-truck-moving', 'fa-truck-loading', 'fa-truck-monster',
            'fa-truck-pickup', 'fa-bus', 'fa-bus-alt', 'fa-taxi', 'fa-shuttle-van',
            'fa-bicycle', 'fa-biking', 'fa-motorcycle', 'fa-walking', 'fa-running',
            'fa-skating', 'fa-skiing', 'fa-skiing-nordic', 'fa-snowboarding', 'fa-plane',
            'fa-plane-arrival', 'fa-plane-departure', 'fa-helicopter', 'fa-fighter-jet',
            'fa-space-shuttle', 'fa-rocket', 'fa-train', 'fa-subway', 'fa-tram',
            'fa-ship', 'fa-sailboat', 'fa-anchor', 'fa-gas-pump', 'fa-charging-station',
            'fa-route', 'fa-road', 'fa-map-signs', 'fa-traffic-light', 'fa-compass',
            'fa-map', 'fa-map-marked', 'fa-map-marked-alt', 'fa-map-marker', 'fa-map-marker-alt',
            'fa-map-pin', 'fa-directions', 'fa-location-arrow', 'fa-globe', 'fa-globe-africa',
            'fa-globe-americas', 'fa-globe-asia', 'fa-globe-europe',
            
            // 第十页 - 天气和自然
            'fa-sun', 'fa-moon', 'fa-cloud', 'fa-cloud-sun', 'fa-cloud-moon',
            'fa-cloud-rain', 'fa-cloud-showers-heavy', 'fa-cloud-sun-rain', 'fa-cloud-moon-rain',
            'fa-poo-storm', 'fa-thunderstorm', 'fa-smog', 'fa-snowflake', 'fa-wind',
            'fa-tornado', 'fa-temperature-high', 'fa-temperature-low', 'fa-bolt', 'fa-umbrella',
            'fa-umbrella-beach', 'fa-rainbow', 'fa-fire', 'fa-fire-alt', 'fa-meteor',
            'fa-volcano', 'fa-water', 'fa-mountain', 'fa-tree', 'fa-seedling',
            'fa-leaf', 'fa-flower', 'fa-spa', 'fa-cannabis', 'fa-fan', 'fa-icicles',
            'fa-snowman', 'fa-eclipse', 'fa-stars', 'fa-star-and-crescent', 'fa-sunrise',
            'fa-sunset', 'fa-smog', 'fa-fog', 'fa-hurricane', 'fa-rainbow', 'fa-sun-dust',
            'fa-sun-haze', 'fa-pollen', 'fa-sprout', 'fa-plant', 'fa-flower-daffodil',
            'fa-flower-tulip', 'fa-frog', 'fa-bug', 'fa-spider', 'fa-mosquito',
            
            // 第十一页 - 食物和饮料
            'fa-coffee', 'fa-mug-hot', 'fa-tea', 'fa-beer', 'fa-glass-martini',
            'fa-glass-whiskey', 'fa-wine-glass', 'fa-wine-bottle', 'fa-flask', 'fa-cocktail',
            'fa-wine-glass-alt', 'fa-glass-cheers', 'fa-utensils', 'fa-utensil-spoon',
            'fa-hamburger', 'fa-pizza-slice', 'fa-hotdog', 'fa-sandwich', 'fa-taco',
            'fa-burrito', 'fa-salad', 'fa-soup', 'fa-drumstick-bite', 'fa-cheese',
            'fa-egg', 'fa-bacon', 'fa-fish', 'fa-bread-slice', 'fa-cookie', 'fa-apple-alt',
            'fa-lemon', 'fa-carrot', 'fa-pepper-hot', 'fa-ice-cream', 'fa-candy-cane',
            'fa-birthday-cake', 'fa-cookie-bite', 'fa-pepper-hot', 'fa-stroopwafel',
            'fa-wheat', 'fa-bone', 'fa-meat', 'fa-popcorn', 'fa-french-fries',
            'fa-apple-crate', 'fa-sushi', 'fa-sushi-roll', 'fa-pizza', 'fa-croissant',
            'fa-pie', 'fa-cupcake', 'fa-salt-shaker', 'fa-pepper-shaker',
            
            // 第十二页 - 品牌图标
            'fa-android', 'fa-apple', 'fa-windows', 'fa-linux', 'fa-ubuntu', 'fa-chrome',
            'fa-firefox', 'fa-edge', 'fa-safari', 'fa-opera', 'fa-internet-explorer',
            'fa-facebook', 'fa-facebook-f', 'fa-facebook-square', 'fa-twitter',
            'fa-twitter-square', 'fa-instagram', 'fa-instagram-square', 'fa-linkedin',
            'fa-linkedin-in', 'fa-github', 'fa-github-alt', 'fa-github-square',
            'fa-gitlab', 'fa-bitbucket', 'fa-youtube', 'fa-youtube-square', 'fa-vimeo',
            'fa-vimeo-square', 'fa-vimeo-v', 'fa-twitch', 'fa-reddit', 'fa-reddit-alien',
            'fa-reddit-square', 'fa-whatsapp', 'fa-whatsapp-square', 'fa-telegram',
            'fa-telegram-plane', 'fa-slack', 'fa-slack-hash', 'fa-discord', 'fa-tiktok',
            'fa-snapchat', 'fa-snapchat-ghost', 'fa-snapchat-square', 'fa-pinterest',
            'fa-pinterest-p', 'fa-pinterest-square', 'fa-dribbble', 'fa-dribbble-square',
            'fa-behance', 'fa-behance-square', 'fa-google', 'fa-google-plus',
            'fa-google-plus-g', 'fa-google-plus-square', 'fa-google-drive'
        ];
        
        // 初始化时只加载第一页的图标
        this.currentPage = 1;
        this.totalPages = Math.ceil(this.allIcons.length / 30); // 每页30个图标
        this.icons = this.getIconsForCurrentPage();
        
        this.colors = [
            '#6366f1', '#3b82f6', '#06b6d4', '#10b981', '#84cc16',
            '#eab308', '#f97316', '#ef4444', '#ec4899', '#8b5cf6',
            '#a855f7', '#d946ef', '#6b7280', '#000000', '#ffffff'
        ];
        
        this.init();
    }
    
    init() {
        this.createModal();
        this.bindEvents();
    }
    
    // 获取当前页的图标
    getIconsForCurrentPage() {
        const startIndex = (this.currentPage - 1) * 30;
        const endIndex = startIndex + 30;
        return this.allIcons.slice(startIndex, endIndex);
    }
    
    // 更新分页信息
    updatePagination() {
        const modal = document.getElementById(this.options.modalId);
        if (!modal) return;
        
        const iconCount = modal.querySelector('.icon-count');
        const prevButton = modal.querySelector('.pagination-prev');
        const nextButton = modal.querySelector('.pagination-next');
        
        if (iconCount) {
            iconCount.textContent = `${this.currentPage}/${this.totalPages} (${this.allIcons.length})`;
        }
        
        if (prevButton) {
            prevButton.disabled = this.currentPage <= 1;
        }
        
        if (nextButton) {
            nextButton.disabled = this.currentPage >= this.totalPages;
        }
    }
    
    // 加载指定页的图标
    loadPage(pageNumber) {
        if (pageNumber < 1 || pageNumber > this.totalPages) return;
        
        this.currentPage = pageNumber;
        this.icons = this.getIconsForCurrentPage();
        
        const modal = document.getElementById(this.options.modalId);
        if (!modal) return;
        
        const iconGrid = modal.querySelector('.icon-selector-grid');
        if (!iconGrid) return;
        
        // 清空当前图标
        iconGrid.innerHTML = '';
        
        // 添加新页的图标
        this.icons.forEach(icon => {
            const iconItem = document.createElement('div');
            iconItem.className = 'icon-item';
            iconItem.setAttribute('data-icon', icon);
            
            const iconElement = document.createElement('i');
            iconElement.className = `fas ${icon}`;
            
            iconItem.appendChild(iconElement);
            iconGrid.appendChild(iconItem);
            
            // 绑定点击事件
            iconItem.addEventListener('click', () => {
                this.selectIcon(icon);
                
                // 移除其他图标的active类
                modal.querySelectorAll('.icon-item').forEach(i => i.classList.remove('active'));
                // 为当前图标添加active类
                iconItem.classList.add('active');
            });
        });
        
        // 更新分页信息
        this.updatePagination();
    }
    
    createModal() {
        // 如果已存在模态框，则不重复创建
        if (document.getElementById(this.options.modalId)) {
            return;
        }
        
        // 创建模态框结构
        const modal = document.createElement('div');
        modal.id = this.options.modalId;
        modal.className = 'icon-selector-modal';
        modal.style.display = 'none';
        
        // 创建模态框内容
        let modalHTML = `
            <div class="icon-selector-overlay"></div>
            <div class="icon-selector-content">
                <div class="icon-selector-header">
                    <h3>选择图标</h3>
                    <button type="button" class="icon-selector-close">&times;</button>
                </div>
                <div class="icon-selector-search">
                    <input type="text" class="icon-search-input" placeholder="搜索图标...">
                </div>
                <div class="icon-selector-body">
                    <div class="icon-selector-colors">
                        <div class="color-title">选择颜色</div>
                        <div class="color-list">`;
        
        // 添加颜色选择器
        this.colors.forEach(color => {
            modalHTML += `<div class="color-item" data-color="${color}" style="background-color: ${color}"></div>`;
        });
        
        modalHTML += `</div>
                    </div>
                    <div class="icon-selector-grid">`;
        
        // 添加图标选择器
        this.icons.forEach(icon => {
            modalHTML += `<div class="icon-item" data-icon="${icon}">
                            <i class="fas ${icon}"></i>
                          </div>`;
        });
        
        modalHTML += `</div>
                    <div class="icon-selector-pagination">
                        <span class="icon-count">1/27 (${this.icons.length})</span>
                        <div class="pagination-controls">
                            <button class="pagination-prev" disabled>&lt;</button>
                            <button class="pagination-next">&gt;</button>
                        </div>
                    </div>
                    <div class="icon-selector-actions">
                        <button type="button" class="icon-save-btn">
                            <i class="fas fa-save"></i> 保存图标
                        </button>
                        <button type="button" class="icon-cancel-btn">
                            <i class="fas fa-times"></i> 取消
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        modal.innerHTML = modalHTML;
        document.body.appendChild(modal);
        
        // 添加CSS样式
        if (!document.getElementById('icon-selector-styles')) {
            const style = document.createElement('style');
            style.id = 'icon-selector-styles';
            style.textContent = `
                .icon-selector-modal {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    z-index: 9999;
                    display: none;
                }
                
                .icon-selector-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.5);
                }
                
                .icon-selector-content {
                    position: relative;
                    width: 80%;
                    max-width: 800px;
                    max-height: 80vh;
                    margin: 50px auto;
                    background-color: #fff;
                    border-radius: 8px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                    overflow: hidden;
                    display: flex;
                    flex-direction: column;
                }
                
                .icon-selector-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 15px 20px;
                    border-bottom: 1px solid #e5e7eb;
                }
                
                .icon-selector-header h3 {
                    margin: 0;
                    font-size: 18px;
                    font-weight: 600;
                }
                
                .icon-selector-close {
                    background: none;
                    border: none;
                    font-size: 24px;
                    cursor: pointer;
                    color: #6b7280;
                }
                
                .icon-selector-search {
                    padding: 15px 20px;
                    border-bottom: 1px solid #e5e7eb;
                }
                
                .icon-search-input {
                    width: 100%;
                    padding: 10px 15px;
                    border: 1px solid #d1d5db;
                    border-radius: 6px;
                    font-size: 14px;
                }
                
                .icon-selector-body {
                    flex: 1;
                    overflow-y: auto;
                    padding: 20px;
                }
                
                .icon-selector-colors {
                    margin-bottom: 20px;
                }
                
                .color-title {
                    font-size: 14px;
                    font-weight: 600;
                    margin-bottom: 10px;
                }
                
                .color-list {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                }
                
                .color-item {
                    width: 30px;
                    height: 30px;
                    border-radius: 50%;
                    cursor: pointer;
                    border: 2px solid transparent;
                    transition: transform 0.2s;
                }
                
                .color-item:hover {
                    transform: scale(1.1);
                }
                
                .color-item.active {
                    border-color: #000;
                    transform: scale(1.1);
                }
                
                .icon-selector-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
                    gap: 10px;
                }
                
                .icon-item {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    padding: 10px;
                    border-radius: 6px;
                    cursor: pointer;
                    transition: background-color 0.2s;
                }
                
                .icon-item:hover {
                    background-color: #f3f4f6;
                }
                
                .icon-item.active {
                    background-color: #e5e7eb;
                }
                
                .icon-item i {
                    font-size: 24px;
                    margin-bottom: 5px;
                }
                
                .icon-selector-pagination {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 15px 20px;
                    border-top: 1px solid #e5e7eb;
                }
                
                .icon-count {
                    font-size: 12px;
                    color: #6b7280;
                }
                
                .pagination-controls {
                    display: flex;
                    gap: 10px;
                }
                
                .pagination-controls button {
                    width: 30px;
                    height: 30px;
                    border-radius: 6px;
                    border: 1px solid #d1d5db;
                    background-color: #fff;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                
                .pagination-controls button:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }
                
                .icon-selector-actions {
                    display: flex;
                    justify-content: space-between;
                    padding: 15px 20px;
                    border-top: 1px solid #e5e7eb;
                }
                
                .icon-save-btn, .icon-cancel-btn {
                    padding: 8px 16px;
                    border-radius: 6px;
                    border: none;
                    cursor: pointer;
                    font-size: 14px;
                    display: flex;
                    align-items: center;
                    gap: 5px;
                }
                
                .icon-save-btn {
                    background-color: #3b82f6;
                    color: white;
                }
                
                .icon-save-btn:hover {
                    background-color: #2563eb;
                }
                
                .icon-cancel-btn {
                    background-color: #e5e7eb;
                    color: #4b5563;
                }
                
                .icon-cancel-btn:hover {
                    background-color: #d1d5db;
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    bindEvents() {
        // 获取元素
        const input = document.querySelector(this.options.inputSelector);
        const preview = document.querySelector(this.options.previewSelector);
        
        if (!input || !preview) {
            console.error('Icon selector: Input or preview element not found');
            return;
        }
        
        // 点击输入框或预览图标时打开选择器
        input.addEventListener('click', () => this.open());
        preview.addEventListener('click', () => this.open());
        
        // 绑定模态框内的事件
        const modal = document.getElementById(this.options.modalId);
        
        // 关闭模态框
        modal.querySelector('.icon-selector-close').addEventListener('click', () => this.close());
        modal.querySelector('.icon-selector-overlay').addEventListener('click', () => this.close());
        
        // 搜索图标
        modal.querySelector('.icon-search-input').addEventListener('input', (e) => this.searchIcons(e.target.value));
        
        // 分页控制
        const prevButton = modal.querySelector('.pagination-prev');
        const nextButton = modal.querySelector('.pagination-next');
        
        prevButton.addEventListener('click', () => {
            if (this.currentPage > 1) {
                this.loadPage(this.currentPage - 1);
            }
        });
        
        nextButton.addEventListener('click', () => {
            if (this.currentPage < this.totalPages) {
                this.loadPage(this.currentPage + 1);
            }
        });
        
        // 保存按钮事件
        const saveButton = modal.querySelector('.icon-save-btn');
        saveButton.addEventListener('click', () => {
            // 获取当前选中的图标和颜色
            const iconInput = document.querySelector(this.options.inputSelector);
            const colorInput = document.querySelector(this.options.colorInputSelector);
            
            // 关闭选择器
            this.close();
            
            // 如果有选择的图标和颜色，则保存它们
            if (iconInput && colorInput) {
                const preview = document.querySelector(this.options.previewSelector);
                if (preview) {
                    // 更新预览
                    preview.className = '';
                    const iconClasses = iconInput.value.split(' ');
                    iconClasses.forEach(cls => {
                        if (cls) preview.classList.add(cls);
                    });
                    preview.style.color = colorInput.value;
                }
                
                // 如果用户点击了保存图标按钮，我们只需要关闭模态框，不提交表单
                // 用户可以使用表单上的其他按钮来保存整个分类
                
                // 显示保存成功提示
                this.showNotification('图标设置已保存', 'success');
            }
        });
        
        // 取消按钮事件
        const cancelButton = modal.querySelector('.icon-cancel-btn');
        cancelButton.addEventListener('click', () => {
            this.close();
        });
        
        // 初始化分页信息
        this.updatePagination();
        
        // 选择图标 - 由于现在使用动态加载，这部分在loadPage方法中处理
        
        // 选择颜色
        const colorItems = modal.querySelectorAll('.color-item');
        colorItems.forEach(item => {
            item.addEventListener('click', () => {
                const color = item.getAttribute('data-color');
                this.selectColor(color);
                
                // 移除其他颜色的active类
                colorItems.forEach(i => i.classList.remove('active'));
                // 为当前颜色添加active类
                item.classList.add('active');
            });
        });
    }
    
    open() {
        const modal = document.getElementById(this.options.modalId);
        if (modal) {
            modal.style.display = 'block';
            
            // 重置为第一页并加载图标
            this.currentPage = 1;
            this.loadPage(1);
            
            // 高亮当前选中的图标和颜色
            const input = document.querySelector(this.options.inputSelector);
            const colorInput = document.querySelector(this.options.colorInputSelector);
            
            const currentIcon = input.value;
            const currentColor = colorInput.value;
            
            // 查找当前图标所在的页面
            if (currentIcon) {
                const iconIndex = this.allIcons.indexOf(currentIcon);
                if (iconIndex !== -1) {
                    const page = Math.floor(iconIndex / 30) + 1;
                    this.loadPage(page);
                    
                    // 等待页面加载后高亮图标
                    setTimeout(() => {
                        const iconItem = modal.querySelector(`.icon-item[data-icon="${currentIcon}"]`);
                        if (iconItem) {
                            iconItem.classList.add('active');
                            iconItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }
                    }, 100);
                }
            }
            
            if (currentColor) {
                const colorItem = modal.querySelector(`.color-item[data-color="${currentColor}"]`);
                if (colorItem) {
                    colorItem.classList.add('active');
                }
            }
            
            // 聚焦搜索框
            setTimeout(() => {
                modal.querySelector('.icon-search-input').focus();
            }, 100);
        }
    }
    
    close() {
        const modal = document.getElementById(this.options.modalId);
        if (modal) {
            modal.style.display = 'none';
        }
    }
    
    // 显示通知消息
    showNotification(message, type = 'info') {
        // 创建通知元素
        const notification = document.createElement('div');
        notification.className = `icon-selector-notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        // 添加到页面
        document.body.appendChild(notification);
        
        // 添加样式
        if (!document.getElementById('icon-notification-styles')) {
            const style = document.createElement('style');
            style.id = 'icon-notification-styles';
            style.textContent = `
                .icon-selector-notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 12px 20px;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                    z-index: 10000;
                    animation: notification-slide-in 0.3s ease-out forwards;
                }
                
                @keyframes notification-slide-in {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                
                .icon-selector-notification.success {
                    background-color: #d1fae5;
                    color: #065f46;
                    border-left: 4px solid #10b981;
                }
                
                .icon-selector-notification.info {
                    background-color: #e0f2fe;
                    color: #0369a1;
                    border-left: 4px solid #0ea5e9;
                }
                
                .icon-selector-notification.error {
                    background-color: #fee2e2;
                    color: #b91c1c;
                    border-left: 4px solid #ef4444;
                }
                
                .notification-content {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                
                .notification-content i {
                    font-size: 18px;
                }
            `;
            document.head.appendChild(style);
        }
        
        // 3秒后自动移除
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            notification.style.transition = 'all 0.3s ease-out';
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
    
    searchIcons(query) {
        query = query.toLowerCase();
        const modal = document.getElementById(this.options.modalId);
        
        if (!query) {
            // 如果搜索框为空，恢复正常分页显示
            this.loadPage(this.currentPage);
            return;
        }
        
        // 在所有图标中搜索
        const matchingIcons = this.allIcons.filter(icon => 
            icon.toLowerCase().includes(query)
        );
        
        const iconGrid = modal.querySelector('.icon-selector-grid');
        if (!iconGrid) return;
        
        // 清空当前图标
        iconGrid.innerHTML = '';
        
        // 显示搜索结果
        matchingIcons.forEach(icon => {
            const iconItem = document.createElement('div');
            iconItem.className = 'icon-item';
            iconItem.setAttribute('data-icon', icon);
            
            const iconElement = document.createElement('i');
            iconElement.className = `fas ${icon}`;
            
            iconItem.appendChild(iconElement);
            iconGrid.appendChild(iconItem);
            
            // 绑定点击事件
            iconItem.addEventListener('click', () => {
                this.selectIcon(icon);
                
                // 移除其他图标的active类
                modal.querySelectorAll('.icon-item').forEach(i => i.classList.remove('active'));
                // 为当前图标添加active类
                iconItem.classList.add('active');
            });
        });
        
        // 更新计数
        const iconCount = modal.querySelector('.icon-count');
        if (iconCount) {
            iconCount.textContent = `搜索结果: ${matchingIcons.length}`;
        }
        
        // 禁用分页按钮
        const prevButton = modal.querySelector('.pagination-prev');
        const nextButton = modal.querySelector('.pagination-next');
        
        if (prevButton) prevButton.disabled = true;
        if (nextButton) nextButton.disabled = true;
    }
    
    selectIcon(icon) {
        const input = document.querySelector(this.options.inputSelector);
        const preview = document.querySelector(this.options.previewSelector);
        
        if (input && preview) {
            // 确保图标格式正确 - 如果没有前缀，添加"fas"前缀
            if (!icon.includes(' ')) {
                icon = 'fas ' + icon;
            }
            
            input.value = icon;
            
            // 更新预览图标
            preview.className = '';
            
            // 正确设置图标类名
            const iconClasses = icon.split(' ');
            iconClasses.forEach(cls => {
                if (cls) preview.classList.add(cls);
            });
            
            // 应用颜色
            const colorInput = document.querySelector(this.options.colorInputSelector);
            if (colorInput) {
                preview.style.color = colorInput.value;
            }
            
            // 如果有回调函数，则调用
            if (typeof this.options.onSelect === 'function') {
                this.options.onSelect(icon);
            }
        }
    }
    
    selectColor(color) {
        const colorInput = document.querySelector(this.options.colorInputSelector);
        const preview = document.querySelector(this.options.previewSelector);
        
        if (colorInput && preview) {
            colorInput.value = color;
            preview.style.color = color;
        }
    }
}

// 导出图标选择器
window.IconSelector = IconSelector;
