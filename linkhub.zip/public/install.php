<?php

// 简易安装页面
// 这个文件是一个临时解决方案，用于在没有完整框架的情况下进行安装

// 启用会话支持
session_start();

// 定义基础路径
$basePath = dirname(__DIR__);

// 检查是否已安装
$envFile = $basePath . '/.env';
$installFile = $basePath . '/storage/installed';

// 获取当前步骤，允许显示安装完成页面
$currentStep = isset($_GET['step']) ? (int)$_GET['step'] : 1;

// 允许重新安装：如果强制重新安装，删除安装标记
if (isset($_POST['force_reinstall']) || isset($_GET['force_reinstall'])) {
    if (file_exists($installFile)) {
        unlink($installFile);
    }
    if (file_exists($envFile)) {
        unlink($envFile);
    }
    // 清除session重新开始
    session_destroy();
    session_start();
}

// 检查是否已安装，显示重新安装选项
$alreadyInstalled = file_exists($installFile);

// 只有在已安装且不是强制重新安装时才显示已安装页面
if ($alreadyInstalled && !isset($_GET['force_reinstall']) && $currentStep !== 4) {
    // 显示已安装页面
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>LinkHub - 已安装</title>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
            .container { max-width: 600px; margin: 50px auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
            h1 { color: #2c3e50; margin-bottom: 20px; }
            .success { color: #27ae60; font-size: 48px; margin-bottom: 20px; }
            .btn { display: inline-block; padding: 12px 24px; margin: 10px; background: #3498db; color: white; text-decoration: none; border-radius: 5px; border: none; cursor: pointer; font-size: 16px; }
            .btn:hover { background: #2980b9; }
            .btn-danger { background: #e74c3c; }
            .btn-danger:hover { background: #c0392b; }
            .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #ffeaa7; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="success">✅</div>
            <h1>LinkHub 已经安装完成</h1>
            <p>系统检测到 LinkHub 已经安装完成。</p>
            
            <div class="warning">
                <strong>重新安装说明：</strong><br>
                重新安装会清空所有数据，包括用户账户、分类和链接等。<br>
                系统会自动创建新的管理员账户和示例数据。
            </div>
            
            <a href="/" class="btn">进入网站</a>
            <a href="?force_reinstall=1" class="btn btn-danger" onclick="return confirm('确定要重新安装吗？这将清空所有现有数据！')">重新安装</a>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// 处理测试数据库连接请求
if (isset($_POST['test_connection'])) {
    header('Content-Type: application/json');
    
    $dbHost = $_POST['db_host'] ?? 'localhost';
    $dbPort = $_POST['db_port'] ?? '3306';
    $dbName = $_POST['db_name'] ?? '';
    $dbUser = $_POST['db_user'] ?? 'root';
    $dbPass = $_POST['db_pass'] ?? '';
    
    try {
        // 先测试连接到MySQL服务器
        $dsn = "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 5
        ]);
        
        // 测试数据库是否存在
        if (!empty($dbName)) {
            try {
                $pdo->exec("USE `{$dbName}`");
                $dbStatus = "数据库 '{$dbName}' 存在";
            } catch (PDOException $e) {
                $dbStatus = "数据库 '{$dbName}' 不存在，安装时将自动创建";
            }
        } else {
            $dbStatus = "请填写数据库名称";
        }
        
        echo json_encode([
            'success' => true, 
            'message' => '✅ 连接成功！',
            'details' => [
                'server' => "MySQL服务器连接正常",
                'database' => $dbStatus,
                'version' => $pdo->getAttribute(PDO::ATTR_SERVER_VERSION)
            ]
        ]);
        
    } catch (PDOException $e) {
        $errorMessage = $e->getMessage();
        
        if (strpos($errorMessage, '1045') !== false) {
            $suggestion = "用户名或密码错误。phpStudy默认密码通常是 'root' 或留空。";
        } elseif (strpos($errorMessage, '2002') !== false) {
            $suggestion = "无法连接MySQL服务器。请检查phpStudy中MySQL服务是否启动。";
        } else {
            $suggestion = "请检查连接参数或查看phpStudy日志。";
        }
        
        echo json_encode([
            'success' => false, 
            'message' => '❌ 连接失败',
            'error' => $errorMessage,
            'suggestion' => $suggestion
        ]);
    }
    exit;
}

// 处理删除安装文件请求
if (isset($_POST['delete_install']) && $_POST['delete_install'] === 'confirm') {
    if (unlink(__FILE__)) {
        echo json_encode(['success' => true, 'message' => '安装文件已删除']);
    } else {
        echo json_encode(['success' => false, 'message' => '删除失败，请手动删除']);
    }
    exit;
}

// 处理安装步骤
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($step) {
        // 数据库配置
        case 2:
            $dbType = trim($_POST['db_type'] ?? 'sqlite');
            $dbHost = trim($_POST['db_host'] ?? 'localhost');
            $dbPort = (int)($_POST['db_port'] ?? 3306);
            $dbName = trim($_POST['db_name'] ?? 'onenav');
            $dbUser = trim($_POST['db_user'] ?? 'root');
            $dbPass = trim($_POST['db_pass'] ?? '');
            $dbPrefix = trim($_POST['db_prefix'] ?? 'on_');
            
            // 验证数据库类型
            if (!in_array($dbType, ['mysql', 'sqlite'])) {
                $dbType = 'sqlite';
            }
            
            // 验证表前缀格式 - 用户友好的处理
            if (empty($dbPrefix)) {
                $dbPrefix = 'on';
            }
            // 清理特殊字符，只保留字母、数字、下划线
            $dbPrefix = preg_replace('/[^a-zA-Z0-9_]/', '', $dbPrefix);
            if (empty($dbPrefix)) {
                $dbPrefix = 'on';
            }
            // 自动添加下划线分隔符，让表名更清晰 (如: linkhub -> linkhub_settings)
            if (!empty($dbPrefix) && substr($dbPrefix, -1) !== '_') {
                $dbPrefix .= '_';
            }
            
            try {
                // 初始化表计数器
                $successCount = 0;
                
                if ($dbType === 'mysql') {
                    // 测试MySQL连接
                    $dsn = "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4";
                    $pdo = new PDO($dsn, $dbUser, $dbPass, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
                    ]);
                    
                    // 创建数据库
                    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                    $pdo->exec("USE `{$dbName}`");
                    
                    // 使用经过验证的直接SQL创建方式 (MySQL)
                    $createTableSQL = [
                        // 设置表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}settings` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `key` varchar(50) NOT NULL COMMENT '键名',
                            `value` text NOT NULL COMMENT '键值',
                            `description` varchar(255) DEFAULT NULL COMMENT '描述',
                            `group_name` varchar(50) DEFAULT 'site' COMMENT '分组',
                            PRIMARY KEY (`id`),
                            UNIQUE KEY `key` (`key`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设置表'",
                        
                        // 用户表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}users` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `username` varchar(50) NOT NULL COMMENT '用户名',
                            `password` varchar(255) NOT NULL COMMENT '密码',
                            `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
                            `token` varchar(255) DEFAULT NULL COMMENT 'API Token',
                            `token_expire` int(11) DEFAULT NULL COMMENT 'Token过期时间',
                            `role` tinyint(4) NOT NULL DEFAULT '1' COMMENT '角色:1管理员,2普通用户',
                            `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态:1正常,0禁用',
                            `add_time` int(11) DEFAULT NULL COMMENT '创建时间',
                            `last_login_at` int(11) DEFAULT NULL COMMENT '最后登录时间',
                            `last_login` int(11) DEFAULT NULL COMMENT '最后登录时间(兼容字段)',
                            `last_login_ip` varchar(45) DEFAULT NULL COMMENT '最后登录IP',
                            PRIMARY KEY (`id`),
                            UNIQUE KEY `username` (`username`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表'",
                        
                        // 分类表 - 使用与admin代码兼容的字段名
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}categorys` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `name` varchar(50) NOT NULL COMMENT '分类名称',
                            `fid` int(11) NOT NULL DEFAULT '0' COMMENT '父分类ID',
                            `property` tinyint(4) NOT NULL DEFAULT '0' COMMENT '属性:0公开,1私有',
                            `weight` int(11) NOT NULL DEFAULT '0' COMMENT '权重(排序)',
                            `description` varchar(255) DEFAULT NULL COMMENT '描述',
                            `font_icon` varchar(255) DEFAULT NULL COMMENT '图标',
                            `icon_color` varchar(7) DEFAULT '#6366f1' COMMENT '图标颜色',
                            `add_time` int(11) NOT NULL COMMENT '添加时间',
                            `up_time` int(11) DEFAULT NULL COMMENT '更新时间',
                            PRIMARY KEY (`id`),
                            KEY `fid` (`fid`),
                            KEY `property` (`property`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分类表'",
                        
                        // 链接表 - 使用与admin代码兼容的字段名
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}links` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `fid` int(11) NOT NULL COMMENT '分类ID',
                            `title` varchar(100) NOT NULL COMMENT '链接标题',
                            `url` varchar(1000) NOT NULL COMMENT 'URL地址',
                            `url_standby` varchar(1000) DEFAULT NULL COMMENT '备用URL',
                            `note` varchar(500) DEFAULT NULL COMMENT '备注',
                            `font_icon` varchar(255) DEFAULT NULL COMMENT '图标',
                            `icon` varchar(255) DEFAULT NULL COMMENT '图标样式',
                            `icon_url` varchar(500) DEFAULT NULL COMMENT '图标URL',
                            `icon_color` varchar(20) DEFAULT '#6b7280' COMMENT '图标颜色',
                            `icon_type` varchar(20) DEFAULT 'fa' COMMENT '图标类型',
                            `property` tinyint(4) NOT NULL DEFAULT '0' COMMENT '属性:0公开,1私有',
                            `weight` int(11) NOT NULL DEFAULT '0' COMMENT '权重(排序)',
                            `click` int(11) NOT NULL DEFAULT '0' COMMENT '点击次数',
                            `add_time` int(11) NOT NULL COMMENT '添加时间',
                            `up_time` int(11) DEFAULT NULL COMMENT '更新时间',
                            PRIMARY KEY (`id`),
                            KEY `fid` (`fid`),
                            KEY `property` (`property`),
                            KEY `weight` (`weight`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='链接表'",
                        
                        // 点击统计表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}clicks` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `link_id` int(11) NOT NULL COMMENT '链接ID',
                            `ip` varchar(45) DEFAULT NULL COMMENT '访问者IP',
                            `user_agent` varchar(255) DEFAULT NULL COMMENT '用户代理',
                            `referer` varchar(255) DEFAULT NULL COMMENT '来源页面',
                            `click_time` int(11) NOT NULL COMMENT '点击时间',
                            PRIMARY KEY (`id`),
                            KEY `link_id` (`link_id`),
                            KEY `click_time` (`click_time`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='点击统计表'",
                        
                        // 分享表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}shares` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `sid` varchar(32) NOT NULL COMMENT '分享ID',
                            `user_id` int(11) NOT NULL COMMENT '用户ID',
                            `title` varchar(100) NOT NULL COMMENT '分享标题',
                            `description` varchar(255) DEFAULT NULL COMMENT '分享描述',
                            `views` int(11) NOT NULL DEFAULT '0' COMMENT '浏览次数',
                            `expire_time` int(11) DEFAULT NULL COMMENT '过期时间',
                            `add_time` int(11) NOT NULL COMMENT '添加时间',
                            `up_time` int(11) DEFAULT NULL COMMENT '更新时间',
                            PRIMARY KEY (`id`),
                            UNIQUE KEY `sid` (`sid`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分享表'",
                        
                        // 分享链接关联表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}share_links` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `share_id` int(11) NOT NULL COMMENT '分享ID',
                            `link_id` int(11) NOT NULL COMMENT '链接ID',
                            PRIMARY KEY (`id`),
                            KEY `share_id` (`share_id`),
                            KEY `link_id` (`link_id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分享链接关联表'",
                        
                        // 标签表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}tags` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `name` varchar(50) NOT NULL COMMENT '标签名称',
                            `color` varchar(20) DEFAULT NULL COMMENT '标签颜色',
                            `user_id` int(11) NOT NULL COMMENT '用户ID',
                            `add_time` int(11) NOT NULL COMMENT '添加时间',
                            PRIMARY KEY (`id`),
                            KEY `user_id` (`user_id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标签表'",
                        
                        // 链接标签关联表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}link_tags` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `link_id` int(11) NOT NULL COMMENT '链接ID',
                            `tag_id` int(11) NOT NULL COMMENT '标签ID',
                            PRIMARY KEY (`id`),
                            KEY `link_id` (`link_id`),
                            KEY `tag_id` (`tag_id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='链接标签关联表'",
                        
                        // 备份表
                        "CREATE TABLE IF NOT EXISTS `{$dbPrefix}backups` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `filename` varchar(255) NOT NULL COMMENT '文件名',
                            `size` int(11) NOT NULL COMMENT '文件大小',
                            `description` varchar(255) DEFAULT NULL COMMENT '描述',
                            `add_time` int(11) NOT NULL COMMENT '添加时间',
                            PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='备份表'"
                    ];
                    
                    $tableNames = ['设置表', '用户表', '分类表', '链接表', '点击统计表', '分享表', '分享链接关联表', '标签表', '链接标签关联表', '备份表'];
                    
                    foreach ($createTableSQL as $index => $statement) {
                        try {
                            $pdo->exec($statement);
                            $successCount++;
                            // 验证表确实创建成功
                            $tableName = $dbPrefix . ['settings', 'users', 'categorys', 'links', 'clicks', 'shares', 'share_links', 'tags', 'link_tags', 'backups'][$index];
                            $checkStmt = $pdo->query("SHOW TABLES LIKE '$tableName'");
                            if ($checkStmt->rowCount() == 0) {
                                throw new Exception("表 $tableName 创建后无法找到");
                            }
                        } catch (PDOException $e) {
                            $tableName = $tableNames[$index] ?? "表" . ($index + 1);
                            throw new Exception("创建 {$tableName} 失败: " . $e->getMessage() . "\n\n可能原因:\n1. 数据库权限不足\n2. 表前缀冲突 (当前前缀: {$dbPrefix})\n3. MySQL版本兼容性问题\n\n建议:\n1. 检查数据库用户是否有CREATE权限\n2. 尝试不同的表前缀\n3. 检查MySQL错误日志");
                        }
                    }
                } else {
                    // SQLite
                    $dbFile = $basePath . '/storage/database/database.sqlite';
                    
                    // 确保目录存在
                    if (!is_dir(dirname($dbFile))) {
                        mkdir(dirname($dbFile), 0755, true);
                    }
                    
                    // 创建数据库连接
                    $pdo = new PDO("sqlite:{$dbFile}");
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    
                    // 使用经过验证的直接SQL创建方式 (SQLite)
                    $createTableSQL = [
                        // 设置表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}settings\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"key\" TEXT NOT NULL UNIQUE,
                            \"value\" TEXT,
                            \"description\" TEXT,
                            \"group_name\" TEXT DEFAULT 'site'
                        )",
                        
                        // 用户表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}users\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"username\" TEXT NOT NULL,
                            \"password\" TEXT NOT NULL,
                            \"email\" TEXT,
                            \"token\" TEXT,
                            \"token_expire\" INTEGER,
                            \"role\" INTEGER DEFAULT 1,
                            \"status\" INTEGER DEFAULT 1,
                            \"add_time\" INTEGER,
                            \"last_login_at\" INTEGER,
                            \"last_login\" INTEGER DEFAULT 0,
                            \"last_login_ip\" TEXT,
                            UNIQUE(\"username\")
                        )",
                        
                        // 分类表 - 使用与admin代码兼容的字段名
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}categorys\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"name\" TEXT NOT NULL,
                            \"fid\" INTEGER DEFAULT 0,
                            \"property\" INTEGER DEFAULT 0,
                            \"weight\" INTEGER DEFAULT 0,
                            \"description\" TEXT,
                            \"font_icon\" TEXT,
                            \"icon_color\" TEXT DEFAULT '#6366f1',
                            \"add_time\" INTEGER DEFAULT 0,
                            \"up_time\" INTEGER DEFAULT 0
                        )",
                        
                        // 链接表 - 使用与admin代码兼容的字段名
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}links\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"fid\" INTEGER DEFAULT 0,
                            \"title\" TEXT NOT NULL,
                            \"url\" TEXT NOT NULL,
                            \"url_standby\" TEXT,
                            \"note\" TEXT,
                            \"font_icon\" TEXT,
                            \"icon\" TEXT,
                            \"icon_url\" TEXT,
                            \"icon_color\" TEXT DEFAULT '#6b7280',
                            \"icon_type\" TEXT DEFAULT 'fa',
                            \"property\" INTEGER DEFAULT 0,
                            \"weight\" INTEGER DEFAULT 0,
                            \"add_time\" INTEGER DEFAULT 0,
                            \"up_time\" INTEGER DEFAULT 0,
                            \"click\" INTEGER DEFAULT 0
                        )",
                        
                        // 点击统计表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}clicks\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"link_id\" INTEGER NOT NULL,
                            \"ip\" TEXT,
                            \"user_agent\" TEXT,
                            \"referer\" TEXT,
                            \"click_time\" INTEGER NOT NULL
                        )",
                        
                        // 分享表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}shares\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"sid\" TEXT NOT NULL UNIQUE,
                            \"user_id\" INTEGER NOT NULL,
                            \"title\" TEXT NOT NULL,
                            \"description\" TEXT,
                            \"views\" INTEGER DEFAULT 0,
                            \"expire_time\" INTEGER,
                            \"add_time\" INTEGER NOT NULL,
                            \"up_time\" INTEGER
                        )",
                        
                        // 分享链接关联表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}share_links\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"share_id\" INTEGER NOT NULL,
                            \"link_id\" INTEGER NOT NULL
                        )",
                        
                        // 标签表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}tags\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"name\" TEXT NOT NULL,
                            \"color\" TEXT,
                            \"user_id\" INTEGER NOT NULL,
                            \"add_time\" INTEGER NOT NULL
                        )",
                        
                        // 链接标签关联表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}link_tags\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"link_id\" INTEGER NOT NULL,
                            \"tag_id\" INTEGER NOT NULL
                        )",
                        
                        // 备份表
                        "CREATE TABLE IF NOT EXISTS \"{$dbPrefix}backups\" (
                            \"id\" INTEGER PRIMARY KEY AUTOINCREMENT,
                            \"filename\" TEXT NOT NULL,
                            \"size\" INTEGER NOT NULL,
                            \"description\" TEXT,
                            \"add_time\" INTEGER NOT NULL
                        )"
                    ];
                    
                    $tableNames = ['设置表', '用户表', '分类表', '链接表', '点击统计表', '分享表', '分享链接关联表', '标签表', '链接标签关联表', '备份表'];
                    
                    foreach ($createTableSQL as $index => $statement) {
                        try {
                            $pdo->exec($statement);
                            $successCount++;
                            // 验证表确实创建成功
                            $tableName = $dbPrefix . ['settings', 'users', 'categorys', 'links', 'clicks', 'shares', 'share_links', 'tags', 'link_tags', 'backups'][$index];
                            $checkStmt = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='$tableName'");
                            if (!$checkStmt->fetch()) {
                                throw new Exception("表 $tableName 创建后无法找到");
                            }
                        } catch (PDOException $e) {
                            $tableName = $tableNames[$index] ?? "表" . ($index + 1);
                            throw new Exception("创建 {$tableName} 失败: " . $e->getMessage() . "\n\n可能原因:\n1. SQLite文件权限问题\n2. 磁盘空间不足\n3. SQLite版本兼容性\n\n建议:\n1. 检查storage/database目录权限\n2. 确认磁盘空间充足\n3. 尝试删除现有的database.sqlite文件");
                        }
                    }
                }
                
                // 生成.env文件 - 确保变量值正确
                $envContent = "APP_NAME=LinkHub\n";
                $envContent .= "APP_ENV=production\n";
                $envContent .= "APP_DEBUG=false\n";
                $envContent .= "APP_URL=http://{$_SERVER['HTTP_HOST']}\n\n";
                
                // 确保数据库类型值正确
                $dbType = trim($dbType);
                $envContent .= "DB_CONNECTION={$dbType}\n";
                
                if ($dbType === 'mysql') {
                    $envContent .= "DB_HOST=" . trim($dbHost) . "\n";
                    $envContent .= "DB_PORT=" . trim($dbPort) . "\n";
                    $envContent .= "DB_DATABASE=" . trim($dbName) . "\n";
                    $envContent .= "DB_USERNAME=" . trim($dbUser) . "\n";
                    $envContent .= "DB_PASSWORD=" . trim($dbPass) . "\n";
                } else {
                    $envContent .= "DB_DATABASE=storage/database/database.sqlite\n";
                }
                
                $envContent .= "DB_PREFIX=" . trim($dbPrefix) . "\n\n";
                
                $envContent .= "CACHE_DRIVER=file\n";
                $envContent .= "SESSION_DRIVER=file\n";
                $envContent .= "SESSION_LIFETIME=120\n\n";
                
                $envContent .= "LOG_CHANNEL=daily\n";
                $envContent .= "LOG_LEVEL=warning\n\n";
                
                $envContent .= "THEME_DEFAULT=default\n";
                $envContent .= "THEME_ADMIN=admin\n";
                $envContent .= "THEME_MOBILE=default\n\n";
                
                $envContent .= "INSTALLED=false\n";
                
                // 保存.env文件
                file_put_contents($envFile, $envContent);
                
                // 保存表创建数量到SESSION供后续步骤使用
                $_SESSION['install_tables_count'] = $successCount;
                
                // 进入下一步
                $step = 3;
                            } catch (PDOException $e) {
                    $errorCode = $e->getCode();
                    $errorMessage = $e->getMessage();
                    
                    // 根据错误类型提供具体解决方案
                    if (strpos($errorMessage, '1045') !== false) {
                        $error = '<strong>❌ MySQL访问被拒绝</strong><br><br>';
                        $error .= '<strong>错误详情:</strong> ' . $errorMessage . '<br><br>';
                        $error .= '<strong>🔧 解决方案：</strong><br>';
                        $error .= '1. <strong>检查密码：</strong>phpStudy默认密码通常是 <code>root</code> 或为空<br>';
                        $error .= '2. <strong>重置MySQL：</strong>在phpStudy中停止MySQL → 版本切换 → 重装<br>';
                        $error .= '3. <strong>使用phpMyAdmin：</strong>通过phpStudy打开phpMyAdmin查看连接信息<br>';
                        $error .= '4. <strong>检查MySQL服务：</strong>确保MySQL在phpStudy中正常运行<br>';
                    } elseif (strpos($errorMessage, '2002') !== false || strpos($errorMessage, 'Connection refused') !== false) {
                        $error = '<strong>❌ 无法连接MySQL服务器</strong><br><br>';
                        $error .= '<strong>错误详情:</strong> ' . $errorMessage . '<br><br>';
                        $error .= '<strong>🔧 解决方案：</strong><br>';
                        $error .= '1. <strong>启动MySQL：</strong>在phpStudy中启动MySQL服务<br>';
                        $error .= '2. <strong>检查端口：</strong>确认MySQL端口是3306<br>';
                        $error .= '3. <strong>重启服务：</strong>在phpStudy中重启MySQL<br>';
                    } elseif (strpos($errorMessage, '1049') !== false) {
                        $error = '<strong>❌ 数据库不存在</strong><br><br>';
                        $error .= '<strong>错误详情:</strong> ' . $errorMessage . '<br><br>';
                        $error .= '<strong>🔧 解决方案：</strong><br>';
                        $error .= '1. <strong>创建数据库：</strong>在phpMyAdmin中创建数据库<br>';
                        $error .= '2. <strong>使用现有数据库：</strong>检查数据库名称是否正确<br>';
                    } else {
                        $error = '<strong>❌ 数据库连接失败</strong><br><br>';
                        $error .= '<strong>错误详情:</strong> ' . $errorMessage . '<br><br>';
                        $error .= '<strong>🔧 建议：</strong><br>';
                        $error .= '1. 检查数据库服务是否运行<br>';
                        $error .= '2. 验证连接信息是否正确<br>';
                        $error .= '3. 查看phpStudy日志获取更多信息<br>';
                    }
                    
                    $step = 2;
                } catch (Exception $e) {
                    $error = '<strong>❌ 安装错误</strong><br><br>';
                    $error .= '<strong>错误详情:</strong> ' . $e->getMessage() . '<br><br>';
                    $error .= '<strong>🔧 建议：</strong> 请检查服务器配置和权限设置';
                    $step = 2;
                }
            break;
            
        // 管理员设置
        case 3:
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            $email = $_POST['email'] ?? '';
            
            // 从SESSION获取数据库表创建数量
            $successCount = $_SESSION['install_tables_count'] ?? 0;
            
            // 验证输入
            if (empty($username)) {
                $error = '用户名不能为空';
            } elseif (strlen($username) < 3 || strlen($username) > 20) {
                $error = '用户名长度必须在3-20个字符之间';
            } elseif (empty($password)) {
                $error = '密码不能为空';
            } elseif (strlen($password) < 6) {
                $error = '密码长度不能少于6个字符';
            } elseif ($password !== $confirmPassword) {
                $error = '两次输入的密码不一致';
            } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = '邮箱格式不正确';
            }
            
            if (empty($error)) {
                try {
                    // 读取.env文件
                    $envContent = file_get_contents($envFile);
                    $dbType = preg_match('/DB_CONNECTION=([^\n]+)/', $envContent, $matches) ? $matches[1] : 'sqlite';
                    
                    if ($dbType === 'mysql') {
                        preg_match('/DB_HOST=([^\n]+)/', $envContent, $matches);
                        $dbHost = $matches[1] ?? 'localhost';
                        
                        preg_match('/DB_PORT=([^\n]+)/', $envContent, $matches);
                        $dbPort = $matches[1] ?? '3306';
                        
                        preg_match('/DB_DATABASE=([^\n]+)/', $envContent, $matches);
                        $dbName = $matches[1] ?? 'linkhub';
                        
                        preg_match('/DB_USERNAME=([^\n]+)/', $envContent, $matches);
                        $dbUser = $matches[1] ?? 'root';
                        
                        preg_match('/DB_PASSWORD=([^\n]+)/', $envContent, $matches);
                        $dbPass = $matches[1] ?? '';
                        
                        preg_match('/DB_PREFIX=([^\n]+)/', $envContent, $matches);
                        $dbPrefix = $matches[1] ?? 'on_';
                        
                        // 连接数据库
                        $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
                        $pdo = new PDO($dsn, $dbUser, $dbPass, [
                            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
                        ]);
                    } else {
                        // SQLite
                        $dbFile = $basePath . '/storage/database/database.sqlite';
                        $pdo = new PDO("sqlite:{$dbFile}");
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        
                        preg_match('/DB_PREFIX=([^\n]+)/', $envContent, $matches);
                        $dbPrefix = $matches[1] ?? 'on_';
                    }
                    
                    // 创建管理员账户
                    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                    $currentTime = time();
                    
                    // 创建管理员账户（覆盖安装模式：删除已存在的管理员）
                    $userTable = $dbPrefix . 'users';
                    
                    // 删除已存在的管理员用户（避免重复安装）
                    $pdo->exec("DELETE FROM " . $userTable . " WHERE role = 1");
                    
                    $stmt = $pdo->prepare("INSERT INTO " . $userTable . " (username, password, email, role, status, add_time) VALUES (?, ?, ?, 1, 1, ?)");
                    $stmt->execute([$username, $passwordHash, $email, $currentTime]);
                    
                    // 验证用户是否成功创建
                    $verifyStmt = $pdo->prepare("SELECT id FROM " . $userTable . " WHERE username = ?");
                    $verifyStmt->execute([$username]);
                    if (!$verifyStmt->fetch()) {
                        throw new Exception("管理员账户创建失败，请检查数据库状态。");
                    }
                    
                    // 插入默认系统设置
                    $settingsTable = $dbPrefix . 'settings';
                    $defaultSettings = [
                        // 站点基本信息
                        ['site_name', 'LinkHub', '网站名称', 'site'],
                        ['site_subtitle', '简洁高效的网址导航系统', '网站副标题', 'site'],
                        ['site_description', '简洁高效的网址导航系统', '网站描述', 'site'],
                        ['site_keywords', 'LinkHub,导航,网址,书签', '网站关键词', 'site'],
                        ['site_url', "http://{$_SERVER['HTTP_HOST']}", '网站地址', 'site'],
                        ['site_icp', '', 'ICP备案号', 'site'],
                        ['site_copyright', 'LinkHub', '版权信息', 'site'],
                        ['site_logo', '', '网站Logo', 'site'],
                        ['site_favicon', '', '网站图标', 'site'],
                        ['custom_header', '', '自定义头部代码', 'site'],
                        ['custom_footer', '', '自定义底部代码', 'site'],
                        ['custom_css', '', '自定义CSS代码', 'site'],
                        ['custom_js', '', '自定义JavaScript代码', 'site'],
                        ['analytics_code', '', '统计代码', 'site'],
                        
                        // 显示选项
                        ['theme', 'default', '默认主题', 'display'],
                        ['enable_register', '0', '开启用户注册', 'display'],
                        ['enable_public_links', '1', '开启公开链接', 'display'],
                        ['enable_click_stats', '1', '开启点击统计', 'display'],
                        ['enable_seo_friendly', '1', '开启SEO友好链接', 'display'],
                        ['link_model', 'click', '链接模式', 'display'],
                        
                        // 过渡页配置
                        ['enable_transition_page', '0', '启用过渡页', 'transition'],
                        ['transition_time', '3', '过渡时间（秒）', 'transition'],
                        ['transition_theme_color', '#6366f1', '过渡页主题色', 'transition'],
                        ['transition_title', '正在跳转中...', '过渡页标题', 'transition'],
                        ['transition_message', '即将为您跳转到目标网站，请稍候...', '过渡页消息', 'transition'],
                        ['transition_ad_code', '', '过渡页广告代码', 'transition'],
                        ['transition_show_progress', '1', '显示进度条', 'transition'],
                        ['transition_allow_skip', '1', '允许跳过', 'transition'],
                        
                        // 安全设置
                        ['login_attempts', '5', '登录尝试次数', 'security'],
                        ['login_timeout', '300', '登录超时时间', 'security'],
                        ['session_lifetime', '7200', '会话生存时间', 'security'],
                        
                        // 系统设置
                        ['cache_enable', '1', '启用缓存', 'system'],
                        ['debug_mode', '0', '调试模式', 'system'],
                        ['log_level', 'warning', '日志级别', 'system'],
                        ['backup_auto', '0', '自动备份', 'system'],
                        
                        // 邮件设置
                        ['mail_driver', 'smtp', '邮件驱动', 'mail'],
                        ['mail_host', '', 'SMTP主机', 'mail'],
                        ['mail_port', '587', 'SMTP端口', 'mail'],
                        ['mail_username', '', 'SMTP用户名', 'mail'],
                        ['mail_password', '', 'SMTP密码', 'mail'],
                        ['mail_encryption', 'tls', '加密方式', 'mail'],
                        ['mail_from_address', '', '发件人地址', 'mail'],
                        ['mail_from_name', 'LinkHub', '发件人名称', 'mail'],
                    ];
                    
                    foreach ($defaultSettings as $setting) {
                        list($key, $value, $description, $group) = $setting;
                        if ($dbType === 'sqlite') {
                            $stmt = $pdo->prepare("INSERT OR IGNORE INTO " . $settingsTable . " (`key`, `value`, `description`, `group_name`) VALUES (?, ?, ?, ?)");
                        } else {
                            $stmt = $pdo->prepare("INSERT IGNORE INTO " . $settingsTable . " (`key`, `value`, `description`, `group_name`) VALUES (?, ?, ?, ?)");
                        }
                        $stmt->execute([$key, $value, $description, $group]);
                    }
                    
                    // 创建默认分类（覆盖安装模式：清空后重新插入）
                    $categoryTable = $dbPrefix . 'categorys';
                    $linkTable = $dbPrefix . 'links';
                    
                    // 清空已存在的数据（避免重复安装）
                    $pdo->exec("DELETE FROM " . $linkTable);  // 先删除链接（有外键约束）
                    $pdo->exec("DELETE FROM " . $categoryTable);  // 再删除分类
                    
                    $defaultCategories = [
                        ['常用网站', 'fa-star', '#3498db', '日常使用的常用网站'],
                        ['开发工具', 'fa-code', '#9b59b6', '开发相关的工具和资源'],
                        ['学习资源', 'fa-book', '#2ecc71', '学习和教育相关网站'],
                        ['娱乐休闲', 'fa-gamepad', '#f39c12', '娱乐和休闲网站'],
                    ];
                    
                    $categoryIds = [];
                    foreach ($defaultCategories as $index => $category) {
                        list($name, $icon, $icon_color, $description) = $category;
                        $stmt = $pdo->prepare("INSERT INTO " . $categoryTable . " (name, font_icon, icon_color, description, weight, property, add_time) VALUES (?, ?, ?, ?, ?, 0, ?)");
                        $stmt->execute([$name, $icon, $icon_color, $description, (100 - $index * 10), $currentTime]);
                        $categoryIds[] = $pdo->lastInsertId();
                    }
                    
                    // 创建示例链接（上面已经清空了链接表）
                    if (count($categoryIds) >= 4) {
                        $defaultLinks = [
                            ['Google', 'https://www.google.com', 'fa-search', '#4285f4', '全球最大的搜索引擎', $categoryIds[0]],
                            ['GitHub', 'https://github.com', 'fa-github', '#333333', '全球最大的代码托管平台', $categoryIds[0]],
                            ['YouTube', 'https://www.youtube.com', 'fa-youtube', '#ff0000', '全球最大的视频分享平台', $categoryIds[0]],
                            ['Visual Studio Code', 'https://code.visualstudio.com', 'fa-code', '#007acc', '微软开发的免费代码编辑器', $categoryIds[1]],
                            ['Docker', 'https://www.docker.com', 'fa-docker', '#2496ed', '容器化平台', $categoryIds[1]],
                            ['MDN Web Docs', 'https://developer.mozilla.org', 'fa-book', '#4d4e53', 'Web开发者文档', $categoryIds[2]],
                            ['Stack Overflow', 'https://stackoverflow.com', 'fa-stack-overflow', '#f48024', '程序员问答社区', $categoryIds[2]],
                        ];
                        
                        foreach ($defaultLinks as $index => $link) {
                            list($title, $url, $icon, $icon_color, $note, $fid) = $link;
                            $stmt = $pdo->prepare("INSERT INTO " . $linkTable . " (fid, title, url, note, font_icon, icon_color, weight, property, add_time) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)");
                            $stmt->execute([$fid, $title, $url, $note, $icon, $icon_color, (100 - $index * 10), $currentTime]);
                        }
                    }
                    
                    // 标记安装完成
                    $envContent = str_replace("INSTALLED=false", "INSTALLED=true", $envContent);
                    file_put_contents($envFile, $envContent);
                    
                    // 创建installed文件
                    $installData = [
                        'install_time' => date('Y-m-d H:i:s'),
                        'version' => '2.0.0',
                        'admin_user' => $username,
                        'database_type' => $dbType,
                        'php_version' => PHP_VERSION,
                        'server_info' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
                    ];
                    file_put_contents($installFile, json_encode($installData, JSON_PRETTY_PRINT));
                    
                    // 保存安装信息供第4步显示
                    $_SESSION['install_admin_username'] = $username;
                    $_SESSION['install_admin_email'] = $email;
                    $_SESSION['install_success'] = true;
                    $_SESSION['install_db_type'] = $dbType;
                    $_SESSION['install_db_prefix'] = $dbPrefix;
                    $_SESSION['install_tables_count'] = $successCount;
                    
                    // 进入下一步
                    $step = 4;
                } catch (PDOException $e) {
                    $error = '创建管理员失败: ' . $e->getMessage() . '<br><br>请检查：<br>1. 数据库连接是否正常<br>2. 用户名是否已存在<br>3. 数据库表是否正确创建';
                    $step = 3;
                } catch (Exception $e) {
                    $error = '安装错误: ' . $e->getMessage() . '<br><br>如果问题持续，请检查：<br>1. 服务器权限设置<br>2. PHP错误日志<br>3. 数据库连接状态';
                    $step = 3;
                }
            } else {
                $step = 3;
            }
            break;
    }
}

// 检查环境要求
function checkRequirements() {
    $requirements = [
        'php' => [
            'version' => PHP_VERSION,
            'required' => '7.4.0',
            'status' => version_compare(PHP_VERSION, '7.4.0', '>='),
        ],
        'extensions' => [
            'pdo' => extension_loaded('pdo'),
            'pdo_mysql' => extension_loaded('pdo_mysql'),
            'pdo_sqlite' => extension_loaded('pdo_sqlite'),
            'json' => extension_loaded('json'),
            'mbstring' => extension_loaded('mbstring'),
        ],
        'directories' => [
            'storage' => is_writable(dirname(__DIR__) . '/storage'),
            'storage/database' => is_writable(dirname(__DIR__) . '/storage/database'),
            'storage/cache' => is_writable(dirname(__DIR__) . '/storage/cache'),
            'storage/logs' => is_writable(dirname(__DIR__) . '/storage/logs'),
            'storage/uploads' => is_writable(dirname(__DIR__) . '/storage/uploads'),
        ],
    ];
    
    $success = true;
    
    if (version_compare(PHP_VERSION, '7.4.0', '<')) {
        $success = false;
    }
    
    foreach ($requirements['extensions'] as $extension => $loaded) {
        if (!$loaded) {
            $success = false;
            break;
        }
    }
    
    foreach ($requirements['directories'] as $directory => $writable) {
        if (!$writable) {
            $success = false;
            break;
        }
    }
    
    $requirements['success'] = $success;
    
    return $requirements;
}

$requirements = checkRequirements();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkHub 安装向导</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #1f2937;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 40px 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/><circle cx="10" cy="60" r="0.5" fill="white" opacity="0.1"/><circle cx="90" cy="40" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            pointer-events: none;
        }
        
        .header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
            position: relative;
            z-index: 1;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 16px;
            font-weight: 400;
            position: relative;
            z-index: 1;
        }
        
        .content {
            padding: 40px;
        }
        
        .footer {
            background: #f8fafc;
            padding: 20px 40px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .steps {
            display: flex;
            margin-bottom: 40px;
            padding: 0 20px;
            position: relative;
        }
        
        .steps::before {
            content: '';
            position: absolute;
            top: 22px;
            left: 20px;
            right: 20px;
            height: 2px;
            background: #e2e8f0;
            z-index: 0;
        }
        
        .step {
            flex: 1;
            text-align: center;
            position: relative;
            z-index: 1;
        }
        
        .step-number {
            width: 44px;
            height: 44px;
            background: #fff;
            border: 3px solid #e2e8f0;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            font-weight: 600;
            font-size: 16px;
            color: #64748b;
            transition: all 0.3s ease;
        }
        
        .step-name {
            font-size: 14px;
            font-weight: 500;
            color: #64748b;
            transition: color 0.3s ease;
        }
        
        .step.active .step-number {
            background: #667eea;
            border-color: #667eea;
            color: #fff;
            transform: scale(1.1);
        }
        
        .step.active .step-name {
            color: #667eea;
            font-weight: 600;
        }
        
        .step.completed .step-number {
            background: #10b981;
            border-color: #10b981;
            color: #fff;
        }
        
        .step.completed .step-name {
            color: #10b981;
            font-weight: 600;
        }
        
        .form-group {
            margin-bottom: 28px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #374151;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 16px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            background: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-1px);
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 16px 32px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 14px 0 rgba(102, 126, 234, 0.39);
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px 0 rgba(102, 126, 234, 0.45);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-secondary {
            background: #64748b;
            color: #fff;
            box-shadow: 0 4px 14px 0 rgba(100, 116, 139, 0.39);
        }
        
        .btn-secondary:hover {
            background: #475569;
            box-shadow: 0 8px 25px 0 rgba(100, 116, 139, 0.45);
        }
        
        .btn:disabled {
            background: #94a3b8;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .alert {
            padding: 20px;
            margin-bottom: 24px;
            border-radius: 16px;
            border: none;
            font-weight: 500;
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
            color: #166534;
            border-left: 4px solid #22c55e;
        }
        
        .alert-info {
            background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
            color: #1e40af;
            border-left: 4px solid #3b82f6;
        }
        
        .requirement-item {
            background: #f8fafc;
            padding: 16px;
            margin: 8px 0;
            border-radius: 12px;
            border-left: 4px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        
        .requirement-item:hover {
            transform: translateX(4px);
        }
        
        .requirement-item.success {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            color: #166534;
            border-left-color: #22c55e;
        }
        
        .requirement-item.danger {
            background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
            color: #991b1b;
            border-left-color: #ef4444;
        }
        
        .success-icon {
            font-size: 64px;
            margin: 20px 0;
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 20%, 53%, 80%, 100% {
                animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
                transform: translate3d(0, 0, 0);
            }
            40%, 43% {
                animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                transform: translate3d(0, -8px, 0);
            }
            70% {
                animation-timing-function: cubic-bezier(0.755, 0.05, 0.855, 0.06);
                transform: translate3d(0, -4px, 0);
            }
            90% {
                transform: translate3d(0, -1px, 0);
            }
        }
        
        .db-type-selector {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .db-type-selector .btn {
            padding: 20px;
            border: 2px solid #e5e7eb;
            background: #fff;
            border-radius: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            font-size: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            text-align: center;
            margin-bottom: 0;
        }
        
        .db-type-selector .btn:hover {
            border-color: #667eea;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px -8px rgba(102, 126, 234, 0.3);
        }
        
        .db-type-selector .btn.active {
            border-color: #667eea;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px -8px rgba(102, 126, 234, 0.4);
        }
        
        .form-help {
            font-size: 13px;
            color: #64748b;
            margin-top: 6px;
            line-height: 1.5;
        }
        
        small {
            display: block;
            color: #64748b;
            margin-top: 8px;
            font-size: 13px;
            line-height: 1.5;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 10px;
                border-radius: 16px;
            }
            
            .content {
                padding: 24px;
            }
            
            .footer {
                padding: 16px 24px;
                flex-direction: column;
                gap: 12px;
            }
            
            .steps {
                padding: 0 10px;
            }
            
            .step-number {
                width: 36px;
                height: 36px;
                font-size: 14px;
            }
            
            .step-name {
                font-size: 12px;
            }
            
            .db-type-selector {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 LinkHub 安装向导</h1>
            <p>简单几步，快速搭建您的专属导航站点</p>
            <?php if (isset($_GET['force_reinstall'])): ?>
            <div style="background: #fff3cd; color: #856404; padding: 12px; border-radius: 8px; margin-top: 15px; border: 1px solid #ffeaa7; text-align: center;">
                <strong>⚠️ 重新安装模式</strong> - 将清空所有现有数据并重新初始化系统
            </div>
            <?php endif; ?>
        </div>
        
        <div class="content">
            <div class="steps">
                <div class="step <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 1 ? '✓' : '1'; ?></div>
                    <div class="step-name">环境检查</div>
                </div>
                <div class="step <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 2 ? '✓' : '2'; ?></div>
                    <div class="step-name">数据库配置</div>
                </div>
                <div class="step <?php echo $step >= 3 ? 'active' : ''; ?> <?php echo $step > 3 ? 'completed' : ''; ?>">
                    <div class="step-number"><?php echo $step > 3 ? '✓' : '3'; ?></div>
                    <div class="step-name">管理员设置</div>
                </div>
                <div class="step <?php echo $step >= 4 ? 'active' : ''; ?>">
                    <div class="step-number"><?php echo $step > 4 ? '✓' : '4'; ?></div>
                    <div class="step-name">安装完成</div>
                </div>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($step === 1): ?>
                <!-- 环境检查 -->
                <h3>环境检查</h3>
                <p>LinkHub 需要以下环境支持：</p>
                
                <div class="requirement-section">
                    <h5>PHP版本</h5>
                    <div class="requirement-item <?php echo $requirements['php']['status'] ? 'success' : 'danger'; ?>">
                        <div style="display: flex; justify-content: space-between;">
                            <span>PHP版本 >= 7.4.0</span>
                            <span>
                                当前版本: <?php echo $requirements['php']['version']; ?>
                                <?php if ($requirements['php']['status']): ?>
                                    ✓
                                <?php else: ?>
                                    ✗
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    
                    <h5>必要扩展</h5>
                    <?php foreach ($requirements['extensions'] as $name => $installed): ?>
                        <div class="requirement-item <?php echo $installed ? 'success' : 'danger'; ?>">
                            <div style="display: flex; justify-content: space-between;">
                                <span><?php echo $name; ?></span>
                                <span>
                                    <?php if ($installed): ?>
                                        ✓
                                    <?php else: ?>
                                        ✗
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <h5>目录权限</h5>
                    <?php foreach ($requirements['directories'] as $name => $writable): ?>
                        <div class="requirement-item <?php echo $writable ? 'success' : 'danger'; ?>">
                            <div style="display: flex; justify-content: space-between;">
                                <span><?php echo $name; ?></span>
                                <span>
                                    <?php if ($writable): ?>
                                        ✓
                                    <?php else: ?>
                                        ✗
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($step === 2): ?>
                <!-- 数据库配置 -->
                <h3>数据库配置</h3>
                <form action="?step=2" method="post">
                    <div style="margin-bottom: 32px;">
                        <label style="display: block; margin-bottom: 16px; font-weight: 600; color: #374151; font-size: 16px;">选择数据库类型</label>
                        <div class="db-type-selector">
                            <button type="button" class="btn active" id="sqlite-btn" data-type="sqlite">
                                <span style="font-size: 20px;">🗄️</span>
                                <div>
                                    <div style="font-weight: 600;">SQLite</div>
                                    <div style="font-size: 12px; opacity: 0.8;">快速便捷 • 推荐</div>
                                </div>
                            </button>
                            <button type="button" class="btn" id="mysql-btn" data-type="mysql">
                                <span style="font-size: 20px;">🐬</span>
                                <div>
                                    <div style="font-weight: 600;">MySQL / MariaDB</div>
                                    <div style="font-size: 12px; opacity: 0.8;">高性能数据库</div>
                                </div>
                            </button>
                        </div>
                    </div>
                    
                    <input type="hidden" name="db_type" id="db_type" value="sqlite">
                    
                    <div id="sqlite-config">
                        <div class="alert alert-success">
                            SQLite数据库将存储在 <code>storage/database/database.sqlite</code> 文件中，无需额外配置。
                        </div>
                    </div>
                    
                    <div id="mysql-config" style="display: none;">
                        <div class="form-group">
                            <label for="db_host">数据库主机</label>
                            <input type="text" class="form-control" id="db_host" name="db_host" value="localhost">
                            <small>通常为localhost或127.0.0.1</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_port">端口</label>
                            <input type="number" class="form-control" id="db_port" name="db_port" value="3306">
                            <small>MySQL默认端口为3306</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_name">数据库名称</label>
                            <input type="text" class="form-control" id="db_name" name="db_name" value="linkhub">
                            <small>如果数据库不存在，将尝试创建</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="db_user">用户名</label>
                            <input type="text" class="form-control" id="db_user" name="db_user" value="root">
                        </div>
                        
                        <div class="form-group">
                            <label for="db_pass">密码</label>
                            <input type="password" class="form-control" id="db_pass" name="db_pass" value="">
                            <small style="color: #667eea;">💡 phpStudy默认密码通常是 <code>root</code> 或留空</small>
                        </div>
                        
                        <div style="margin-top: 20px;">
                            <button type="button" class="btn btn-secondary" onclick="testConnection()" id="test-btn">
                                🔍 测试连接
                            </button>
                            <div id="test-result" style="margin-top: 12px;"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_prefix">表前缀</label>
                        <input type="text" class="form-control" id="db_prefix" name="db_prefix" value="on" placeholder="推荐: on, lh, hub">
                        <small class="form-help" style="color: #666; font-size: 12px; margin-top: 5px; display: block;">
                            <strong>建议使用短前缀：</strong>输入 "on" 将创建 "on_links"、"on_users" 等表<br>
                            <strong>避免过长前缀：</strong>过长会导致表名冗余，如 "linkhub_" 会创建 "linkhub_categorys"
                        </small>
                        <small style="color: #28a745;">💡 首次安装推荐使用默认值 "on"</small>
                    </div>
                    
                    <div class="footer">
                        <a href="?step=1" class="btn btn-secondary">← 上一步</a>
                        <button type="submit" class="btn">下一步 →</button>
                    </div>
                </form>
            <?php elseif ($step === 3): ?>
                <!-- 管理员设置 -->
                <h3>管理员账户设置</h3>
                <form action="?step=3" method="post">
                    <div class="form-group">
                        <label for="username">用户名</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo $_POST['username'] ?? ''; ?>" required>
                        <small>用户名长度为3-20个字符</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">密码</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <small>密码长度不能少于6个字符</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">确认密码</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">电子邮箱 (可选)</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $_POST['email'] ?? ''; ?>">
                        <small>用于接收系统通知和找回密码</small>
                    </div>
                    
                    <div class="footer">
                        <a href="?step=2" class="btn btn-secondary">← 上一步</a>
                        <button type="submit" class="btn">🚀 完成安装</button>
                    </div>
                </form>
            <?php elseif ($step === 4): ?>
                <!-- 安装完成 -->
                <div style="text-align: center;">
                    <div style="text-align: center; margin: 40px 0;">
                        <div class="success-icon" style="font-size: 64px; color: #10b981;">🎉</div>
                        <h2 style="color: #10b981; margin: 20px 0; font-weight: 700; font-size: 28px;">恭喜！LinkHub 安装成功</h2>
                        <p style="font-size: 18px; color: #64748b; margin: 20px 0;">您的专属导航站点已准备就绪</p>
                        <?php if (isset($_GET['force_reinstall'])): ?>
                        <div class="alert alert-info" style="max-width: 500px; margin: 20px auto; text-align: left;">
                            <i class="fa fa-refresh"></i>
                            <strong>覆盖安装完成</strong> - 所有旧数据已被清空并重新初始化，系统恢复为全新状态
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (isset($_SESSION['install_success']) && $_SESSION['install_success']): ?>
                    <div class="alert alert-success" style="text-align: left; max-width: 500px; margin: 20px auto;">
                        <h4>✅ 安装信息</h4>
                        <p><strong>管理员用户名:</strong> <code style="background: #e9ecef; padding: 2px 6px; border-radius: 3px; color: #495057;"><?php echo htmlspecialchars($_SESSION['install_admin_username'] ?? ''); ?></code></p>
                        <p><strong>管理员邮箱:</strong> <?php echo htmlspecialchars($_SESSION['install_admin_email'] ?? '无'); ?></p>
                        <p><strong>数据库类型:</strong> <?php echo strtoupper($_SESSION['install_db_type'] ?? 'Unknown'); ?></p>
                        <p><strong>表前缀:</strong> <code style="background: #e9ecef; padding: 2px 6px; border-radius: 3px; color: #495057;"><?php echo htmlspecialchars($_SESSION['install_db_prefix'] ?? ''); ?></code></p>
                        <p><strong>创建表数:</strong> <?php echo $_SESSION['install_tables_count'] ?? 0; ?> 个数据表</p>
                        <p><strong>安装时间:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
                    </div>
                    
                    <div class="alert alert-info" style="text-align: left; max-width: 600px; margin: 20px auto;">
                        <h4>🔐 登录信息</h4>
                        <p><strong>用户名:</strong> <code style="background: #e3f2fd; color: #1565c0; padding: 4px 8px; border-radius: 4px;"><?php echo htmlspecialchars($_SESSION['install_admin_username'] ?? ''); ?></code></p>
                        <p><strong>密码:</strong> 您刚才设置的密码</p>
                        <p><strong>登录地址:</strong> <code>/login.php</code> 或 <code>/admin/</code></p>
                        <div style="background: #fff3cd; padding: 12px; border-radius: 8px; margin-top: 16px; border-left: 4px solid #ffc107;">
                            <strong>💡 现在就去登录：</strong>
                            <p style="margin: 8px 0 0 0;">点击下方的"🔐 立即登录"按钮，使用上述用户名和密码登录管理后台。</p>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 40px; display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                        <a href="/" class="btn" style="background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); text-decoration: none;">
                            🏠 进入首页
                        </a>
                        <a href="login.php" class="btn" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); text-decoration: none;">
                            🔐 立即登录
                        </a>
                        <button onclick="deleteInstallFile()" class="btn" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); text-decoration: none;">
                            🗑️ 删除安装文件
                        </button>
                    </div>
                    
                    <div style="margin-top: 40px; padding: 32px; background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border-radius: 20px; max-width: 700px; margin-left: auto; margin-right: auto; border: 1px solid #e2e8f0;">
                        <h4 style="color: #1f2937; margin-bottom: 24px; font-weight: 600; font-size: 18px;">📋 下一步操作建议</h4>
                        <ol style="text-align: left; line-height: 2; color: #374151; padding-left: 20px;">
                            <li style="margin-bottom: 8px;"><strong style="color: #ef4444;">🔒 立即删除安装文件</strong> - 删除 <code style="background: #fee2e2; color: #991b1b; padding: 3px 8px; border-radius: 6px; font-size: 13px;">install.php</code> 确保安全</li>
                            <li style="margin-bottom: 8px;">⚙️ 访问管理后台，完善网站基本信息</li>
                            <li style="margin-bottom: 8px;">📁 创建分类，添加您的常用网站链接</li>
                            <li style="margin-bottom: 8px;">🎨 选择并配置您喜欢的主题</li>
                            <li style="margin-bottom: 8px;">🖼️ 设置网站Logo和图标</li>
                            <li style="margin-bottom: 8px;">💾 配置其他系统设置并定期备份</li>
                        </ol>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if ($step === 1): ?>
        <div class="footer">
            <div></div>
            <?php if ($requirements['success']): ?>
                <a href="?step=2" class="btn">开始安装 →</a>
            <?php else: ?>
                <button class="btn" disabled>请先解决环境问题</button>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
        // 数据库类型切换
        document.addEventListener('DOMContentLoaded', function() {
            const sqliteBtn = document.getElementById('sqlite-btn');
            const mysqlBtn = document.getElementById('mysql-btn');
            const dbTypeInput = document.getElementById('db_type');
            const sqliteConfig = document.getElementById('sqlite-config');
            const mysqlConfig = document.getElementById('mysql-config');
            
            if (sqliteBtn && mysqlBtn) {
                sqliteBtn.addEventListener('click', function() {
                    dbTypeInput.value = 'sqlite';
                    sqliteConfig.style.display = 'block';
                    mysqlConfig.style.display = 'none';
                    sqliteBtn.classList.add('active');
                    mysqlBtn.classList.remove('active');
                });
                
                mysqlBtn.addEventListener('click', function() {
                    dbTypeInput.value = 'mysql';
                    sqliteConfig.style.display = 'none';
                    mysqlConfig.style.display = 'block';
                    sqliteBtn.classList.remove('active');
                    mysqlBtn.classList.add('active');
                });
            }
        });
        
        // 测试数据库连接功能
        function testConnection() {
            const testBtn = document.getElementById('test-btn');
            const testResult = document.getElementById('test-result');
            const dbType = document.getElementById('db_type').value;
            
            if (dbType !== 'mysql') {
                testResult.innerHTML = '<div class="alert alert-info">SQLite无需测试连接，将自动创建数据库文件。</div>';
                return;
            }
            
            // 获取表单数据
            const formData = new FormData();
            formData.append('test_connection', '1');
            formData.append('db_host', document.getElementById('db_host').value);
            formData.append('db_port', document.getElementById('db_port').value);
            formData.append('db_name', document.getElementById('db_name').value);
            formData.append('db_user', document.getElementById('db_user').value);
            formData.append('db_pass', document.getElementById('db_pass').value);
            
            // 显示加载状态
            testBtn.disabled = true;
            testBtn.innerHTML = '⏳ 连接中...';
            testResult.innerHTML = '<div style="color: #667eea;">正在测试连接...</div>';
            
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                testBtn.disabled = false;
                testBtn.innerHTML = '🔍 测试连接';
                
                if (data.success) {
                    let resultHtml = '<div class="alert alert-success">';
                    resultHtml += '<strong>' + data.message + '</strong><br>';
                    if (data.details) {
                        resultHtml += '<small>';
                        if (data.details.server) resultHtml += '🔗 ' + data.details.server + '<br>';
                        if (data.details.database) resultHtml += '💾 ' + data.details.database + '<br>';
                        if (data.details.version) resultHtml += '📋 MySQL版本: ' + data.details.version;
                        resultHtml += '</small>';
                    }
                    resultHtml += '</div>';
                    testResult.innerHTML = resultHtml;
                } else {
                    let resultHtml = '<div class="alert alert-danger">';
                    resultHtml += '<strong>' + data.message + '</strong><br>';
                    if (data.error) resultHtml += '<small>错误: ' + data.error + '</small><br>';
                    if (data.suggestion) resultHtml += '<strong>💡 建议: </strong>' + data.suggestion;
                    resultHtml += '</div>';
                    testResult.innerHTML = resultHtml;
                }
            })
            .catch(error => {
                testBtn.disabled = false;
                testBtn.innerHTML = '🔍 测试连接';
                testResult.innerHTML = '<div class="alert alert-danger">❌ 测试失败: ' + error.message + '</div>';
            });
        }
        
        // 删除安装文件功能
        function deleteInstallFile() {
            if (confirm('确认删除安装文件吗？此操作不可逆。\n\n删除后将无法再次访问安装页面。')) {
                const formData = new FormData();
                formData.append('delete_install', 'confirm');
                
                fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ ' + data.message + '\n\n现在可以安全使用您的LinkHub了！');
                        window.location.href = '/';
                    } else {
                        alert('❌ ' + data.message + '\n\n请手动删除 install.php 文件。');
                    }
                })
                .catch(error => {
                    alert('❌ 删除过程中发生错误：' + error.message + '\n\n请手动删除 install.php 文件。');
                });
            }
        }
    </script>
</body>
</html>
