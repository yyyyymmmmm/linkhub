<?php

// 生产环境建议关闭错误显示

// 检查是否已安装
$envFile = dirname(__DIR__) . '/.env';
$installFile = dirname(__DIR__) . '/storage/installed';
$isInstalled = file_exists($envFile) || file_exists($installFile);

// 如果未安装，重定向到安装页面
if (!$isInstalled) {
    header('Location: /install.php');
    exit;
}

// 加载助手函数
$helpersPath = dirname(__DIR__) . '/src/helpers.php';
if (file_exists($helpersPath)) {
    require $helpersPath;
}

// 加载自动加载器
$autoloadPath = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require $autoloadPath;
} else {
    // 如果没有Composer自动加载器，使用简单的自动加载器
    spl_autoload_register(function ($class) {
        // LinkHub命名空间映射到src目录
        if (strpos($class, 'LinkHub\\') === 0) {
            $path = dirname(__DIR__) . '/src/' . str_replace('\\', '/', substr($class, 7)) . '.php';
            if (file_exists($path)) {
                require $path;
                return true;
            }
        }
        
        return false;
    });
}

// 使用主题系统渲染前台
try {
    // 手动加载必要的类
    $basePath = dirname(__DIR__);
    
    // 加载核心类
    require_once $basePath . '/src/Core/Http/Request.php';
    require_once $basePath . '/src/Core/Http/Response.php';
    require_once $basePath . '/src/Core/Controller/BaseController.php';
    require_once $basePath . '/src/Controllers/HomeController.php';
    
    $homeController = new LinkHub\Controllers\HomeController();
    
    // 创建请求对象
    $request = new LinkHub\Core\Http\Request(
        $_GET,
        $_POST, 
        $_SERVER,
        $_FILES
    );
    
    // 🚀 万能路由解析 - 开箱即用，无需服务器配置
    $requestUri = $_SERVER['REQUEST_URI'] ?? '';
    $path = parse_url($requestUri, PHP_URL_PATH);
    
    // 移除开头的斜杠和index.php相关
    $originalPath = $path;
    $path = ltrim($path, '/');
    $path = str_replace('index.php/', '', $path);
    $path = str_replace('index.php', '', $path);
    $path = trim($path, '/');
    
    // 解析路由
    $controller = $_GET['c'] ?? null;
    $id = $_GET['id'] ?? null;
    
    // 🎯 核心路由解析逻辑 - 处理所有URL格式
    if (!empty($path)) {
        $segments = explode('/', $path);
        
        // 处理 /click/数字 格式（最重要）
        if (count($segments) >= 2 && $segments[0] === 'click' && is_numeric($segments[1])) {
            $controller = 'click';
            $id = (int)$segments[1];
            $_GET['c'] = $controller;
            $_GET['id'] = $id;
        }
        // 处理 /favicon 格式  
        elseif (count($segments) >= 1 && $segments[0] === 'favicon') {
            $controller = 'favicon';
            $_GET['c'] = $controller;
        }
        // 处理 /site-icon 格式
        elseif (count($segments) >= 1 && $segments[0] === 'site-icon') {
            $controller = 'site-icon';
            $_GET['c'] = $controller;
        }
        // 处理其他路由格式
        elseif (count($segments) >= 2) {
            $controller = $segments[0];
            $id = is_numeric($segments[1]) ? (int)$segments[1] : $segments[1];
            $_GET['c'] = $controller;
            $_GET['id'] = $id;
        } elseif (count($segments) == 1 && !empty($segments[0])) {
            // 检查是否是已知的控制器
            if (in_array($segments[0], ['click', 'favicon', 'site-icon'])) {
                $controller = $segments[0];
                $_GET['c'] = $controller;
            }
        }
    }
    
    // 使用解析后的参数或默认值
    $controller = $_GET['c'] ?? 'index';
    $id = $_GET['id'] ?? null;
    
    // 重新创建请求对象以包含更新的GET参数
    $request = new LinkHub\Core\Http\Request(
        $_GET,
        $_POST, 
        $_SERVER,
        $_FILES
    );
    
    // 根据控制器分发请求
    switch ($controller) {
        case 'click':
            $response = $homeController->click($request);
            break;
        case 'favicon':
            $response = $homeController->favicon($request);
            break;
            
        case 'site-icon':
            $response = $homeController->siteIcon($request);
            break;
        default:
            $response = $homeController->index($request);
            break;
    }
    
    // 发送响应
    $response->send();
} catch (Exception $e) {
    // 记录错误日志
    error_log("Router error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    error_log("Request URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A'));
    error_log("Parsed path: " . ($path ?? 'N/A'));
    error_log("Controller: " . ($controller ?? 'N/A'));
    error_log("ID: " . ($id ?? 'N/A'));
    error_log("GET params: " . json_encode($_GET));
    error_log("Has rewrite params: " . (isset($hasRewriteParams) ? ($hasRewriteParams ? 'Yes' : 'No') : 'N/A'));
    
    // 出错时显示简单错误页面
    echo "<!DOCTYPE html>
    <html>
    <head>
        <title>错误 - LinkHub</title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
            .error { background: #f8f8f8; padding: 30px; border-radius: 8px; margin: 50px auto; max-width: 600px; }
            h1 { color: #e74c3c; }
            a { color: #3498db; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class='error'>
            <h1>系统错误</h1>
            <p>" . htmlspecialchars($e->getMessage()) . "</p>
            <p><a href='/login.php'>返回管理后台</a> | <a href='/init_database.php'>重新初始化数据库</a></p>
        </div>
    </body>
    </html>";
}