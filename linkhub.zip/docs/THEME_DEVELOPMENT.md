# 🎨 LinkHub 主题开发指南

<div align="center">

![Theme Development](https://img.shields.io/badge/Theme-Development-purple?style=for-the-badge&logo=palette&logoColor=white)

**为LinkHub创建精美主题的完整开发指南**

[![PHP](https://img.shields.io/badge/PHP-7.4+-777BB4?style=flat-square&logo=php&logoColor=white)](https://php.net)
[![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=flat-square&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=flat-square&logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat-square&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)

[快速开始](#快速开始) · [API参考](#api参考) · [示例代码](#示例代码) · [最佳实践](#最佳实践)

</div>

---

## 📖 目录

- [📖 目录](#-目录)
- [🚀 快速开始](#-快速开始)
- [📁 主题结构](#-主题结构)
- [⚙️ 配置文件 (theme.json)](#️-配置文件-themejson)
- [🔧 核心文件详解](#-核心文件详解)
- [📊 可用数据变量](#-可用数据变量)
- [🎨 CSS 框架和约定](#-css-框架和约定)
- [🔌 JavaScript API](#-javascript-api)
- [🎯 图标系统](#-图标系统)
- [📱 响应式设计](#-响应式设计)
- [⚡ 性能优化](#-性能优化)
- [🛠️ 开发工具](#️-开发工具)
- [🧪 调试和测试](#-调试和测试)
- [📦 主题发布](#-主题发布)
- [🌟 最佳实践](#-最佳实践)
- [❓ 常见问题](#-常见问题)

---

## 🚀 快速开始

### 创建新主题

1. **创建主题目录**
```bash
mkdir public/themes/your-theme-name
cd public/themes/your-theme-name
```

2. **创建基础文件**
```bash
touch index.php          # 主模板文件
touch style.css          # 主样式文件
touch script.js          # 主脚本文件
touch theme.json         # 主题配置文件
touch screenshot.jpg     # 主题预览图
```

3. **复制模板结构**
```bash
# 复制默认主题作为起点
cp -r ../default/* ./
```

4. **修改主题信息**
编辑 `theme.json` 文件，设置您的主题信息。

---

## 📁 主题结构

```
your-theme/
├── index.php              # 🔴 必需：主模板文件
├── style.css              # 🔴 必需：主样式文件
├── theme.json             # 🔴 必需：主题配置文件
├── screenshot.jpg         # 🔴 必需：主题预览图 (1200x800px)
├── script.js              # 🟡 可选：主脚本文件
├── README.md              # 🟡 可选：主题说明文档
├── LICENSE                # 🟡 可选：许可证文件
├── assets/                # 🟡 可选：静态资源目录
│   ├── images/           #      图片资源
│   ├── fonts/            #      字体文件
│   └── icons/            #      图标文件
├── components/            # 🟡 可选：组件目录
│   ├── header.php        #      页头组件
│   ├── footer.php        #      页脚组件
│   └── sidebar.php       #      侧边栏组件
└── js/                    # 🟡 可选：额外脚本目录
    ├── main.js           #      主脚本
    └── utils.js          #      工具函数
```

### 文件命名规范

- **必需文件**：文件名固定，不可更改
- **可选文件**：可以根据需要添加
- **目录结构**：建议保持清晰的目录层次
- **文件编码**：统一使用 UTF-8 编码

---

## ⚙️ 配置文件 (theme.json)

`theme.json` 是主题的核心配置文件，定义了主题的基本信息和功能特性。

### 基础配置结构

```json
{
    "name": "主题名称",
    "version": "1.0.0",
    "description": "主题描述",
    "author": "作者名称",
    "author_url": "https://author-website.com",
    "theme_url": "https://theme-homepage.com",
    "screenshot": "screenshot.jpg",
    "demo": "https://demo-url.com",
    "tags": ["modern", "responsive", "dark-mode"],
    "require": {
        "min": "2.0.0",
        "max": ""
    },
    "config": {
        "favicon": "online",
        "shortcut_icon": "",
        "show_search": true,
        "show_sidebar": true,
        "show_footer": true,
        "custom_css": "",
        "custom_js": ""
    },
    "settings": {
        "color_scheme": {
            "type": "select",
            "label": "颜色方案",
            "options": {
                "light": "浅色模式",
                "dark": "深色模式",
                "auto": "跟随系统"
            },
            "default": "light"
        },
        "layout_width": {
            "type": "range",
            "label": "布局宽度",
            "min": 1200,
            "max": 1920,
            "step": 100,
            "default": 1400,
            "unit": "px"
        },
        "enable_animations": {
            "type": "switch",
            "label": "启用动画效果",
            "default": true
        },
        "primary_color": {
            "type": "color",
            "label": "主色调",
            "default": "#4f46e5"
        },
        "custom_header": {
            "type": "textarea",
            "label": "自定义头部代码",
            "placeholder": "在此输入自定义HTML/CSS/JS代码",
            "default": ""
        }
    },
    "features": [
        "响应式设计",
        "深色模式",
        "快速搜索",
        "平滑动画"
    ],
    "color": "#4f46e5"
}
```

### 配置字段详解

#### 基本信息字段

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `name` | string | ✅ | 主题显示名称 |
| `version` | string | ✅ | 主题版本号 (语义化版本) |
| `description` | string | ✅ | 主题简短描述 |
| `author` | string | ✅ | 作者名称 |
| `author_url` | string | ❌ | 作者网站 |
| `theme_url` | string | ❌ | 主题主页 |
| `screenshot` | string | ✅ | 预览图文件名 |
| `demo` | string | ❌ | 在线演示地址 |
| `tags` | array | ❌ | 主题标签 |

#### 兼容性字段

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `require.min` | string | ✅ | 最小兼容版本 |
| `require.max` | string | ❌ | 最大兼容版本 |

#### 设置字段类型

| 类型 | 说明 | 属性 |
|------|------|------|
| `switch` | 开关选择器 | `default: boolean` |
| `select` | 下拉选择器 | `options: object, default: string` |
| `range` | 范围滑块 | `min: number, max: number, step: number, default: number, unit: string` |
| `color` | 颜色选择器 | `default: string` |
| `text` | 文本输入框 | `placeholder: string, default: string` |
| `textarea` | 多行文本框 | `placeholder: string, default: string, rows: number` |
| `number` | 数字输入框 | `min: number, max: number, step: number, default: number` |

---

## 🔧 核心文件详解

### index.php - 主模板文件

这是主题的核心文件，负责渲染整个页面结构。

```php
<?php
// 主题开发模板

// 获取主题配置
$themeConfig = $site['theme_config'] ?? [];
$settings = $themeConfig['settings'] ?? [];

// 处理搜索请求
if (!empty($_POST['q'])) {
    $searchUrl = "https://www.baidu.com/s?ie=utf-8&word=" . urlencode($_POST['q']);
    header("Location: " . $searchUrl);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="<?= $settings['primary_color'] ?? '#4f46e5' ?>">
    
    <!-- SEO Meta -->
    <title><?= htmlspecialchars($site['title']) ?> - <?= htmlspecialchars($site['subtitle']) ?></title>
    <meta name="keywords" content="<?= htmlspecialchars($site['keywords']) ?>">
    <meta name="description" content="<?= htmlspecialchars($site['description']) ?>">
    
    <!-- 样式文件 -->
    <link rel="stylesheet" href="/themes/<?= basename(__DIR__) ?>/style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- 自定义头部代码 -->
    <?php if (!empty($settings['custom_header'])): ?>
        <?= $settings['custom_header'] ?>
    <?php endif; ?>
</head>
<body class="theme-<?= basename(__DIR__) ?> color-scheme-<?= $settings['color_scheme'] ?? 'light' ?>">
    <!-- 主要内容区域 -->
    <div id="app">
        <!-- 头部区域 -->
        <header class="site-header">
            <div class="container">
                <div class="site-branding">
                    <h1 class="site-title"><?= htmlspecialchars($site['title']) ?></h1>
                    <p class="site-description"><?= htmlspecialchars($site['subtitle']) ?></p>
                </div>
                
                <!-- 搜索框 -->
                <?php if ($settings['show_search'] ?? true): ?>
                <div class="search-form">
                    <form method="POST" action="">
                        <input type="text" name="q" placeholder="搜索..." autocomplete="off">
                        <button type="submit"><i class="fas fa-search"></i></button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </header>
        
        <!-- 主内容区域 -->
        <main class="site-main">
            <div class="container">
                <!-- 分类导航 -->
                <?php if ($settings['show_sidebar'] ?? true): ?>
                <aside class="categories-sidebar">
                    <?php if (!empty($categories)): ?>
                        <nav class="categories-nav">
                            <?php foreach ($categories as $category): ?>
                                <a href="#category-<?= $category['id'] ?>" class="category-item" data-category="<?= $category['id'] ?>">
                                    <?php
                                    // 处理图标前缀
                                    $iconClass = $category['icon'] ?? 'fas fa-folder';
                                    if (strpos($iconClass, 'fa-') === 0) {
                                        $brandIcons = ['fa-github', 'fa-youtube', 'fa-docker', 'fa-google'];
                                        if (in_array($iconClass, $brandIcons)) {
                                            $iconClass = 'fab ' . $iconClass;
                                        } else {
                                            $iconClass = 'fas ' . $iconClass;
                                        }
                                    }
                                    ?>
                                    <i class="<?= htmlspecialchars($iconClass) ?>" 
                                       style="color: <?= htmlspecialchars($category['icon_color'] ?? '#6b7280') ?>"></i>
                                    <span><?= htmlspecialchars($category['name']) ?></span>
                                </a>
                            <?php endforeach; ?>
                        </nav>
                    <?php endif; ?>
                </aside>
                <?php endif; ?>
                
                <!-- 链接内容区域 -->
                <div class="links-content">
                    <?php if (!empty($categories)): ?>
                        <?php foreach ($categories as $category): ?>
                            <section class="category-section" id="category-<?= $category['id'] ?>">
                                <h2 class="category-title">
                                    <?php
                                    $iconClass = $category['icon'] ?? 'fas fa-folder';
                                    if (strpos($iconClass, 'fa-') === 0) {
                                        $brandIcons = ['fa-github', 'fa-youtube', 'fa-docker', 'fa-google'];
                                        if (in_array($iconClass, $brandIcons)) {
                                            $iconClass = 'fab ' . $iconClass;
                                        } else {
                                            $iconClass = 'fas ' . $iconClass;
                                        }
                                    }
                                    ?>
                                    <i class="<?= htmlspecialchars($iconClass) ?>" 
                                       style="color: <?= htmlspecialchars($category['icon_color'] ?? '#6b7280') ?>"></i>
                                    <?= htmlspecialchars($category['name']) ?>
                                </h2>
                                
                                <?php if (!empty($category['links'])): ?>
                                    <div class="links-grid">
                                        <?php foreach ($category['links'] as $link): ?>
                                            <div class="link-item">
                                                <a href="/click?id=<?= $link['id'] ?>&url=<?= urlencode($link['url']) ?>" 
                                                   target="_blank" rel="noopener noreferrer"
                                                   class="link-card">
                                                    <div class="link-icon">
                                                        <?php
                                                        $linkIcon = $link['icon'] ?? 'fas fa-link';
                                                        if (strpos($linkIcon, 'fa-') === 0) {
                                                            $brandIcons = ['fa-github', 'fa-youtube', 'fa-docker', 'fa-google'];
                                                            if (in_array($linkIcon, $brandIcons)) {
                                                                $linkIcon = 'fab ' . $linkIcon;
                                                            } else {
                                                                $linkIcon = 'fas ' . $linkIcon;
                                                            }
                                                        }
                                                        ?>
                                                        <i class="<?= htmlspecialchars($linkIcon) ?>" 
                                                           style="color: <?= htmlspecialchars($link['icon_color'] ?? '#6b7280') ?>"></i>
                                                    </div>
                                                    <div class="link-content">
                                                        <h3 class="link-title"><?= htmlspecialchars($link['title']) ?></h3>
                                                        <p class="link-description"><?= htmlspecialchars($link['note'] ?? '') ?></p>
                                                        <span class="link-url"><?= htmlspecialchars(parse_url($link['url'], PHP_URL_HOST)) ?></span>
                                                    </div>
                                                </a>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="empty-category">
                                        <i class="fas fa-inbox"></i>
                                        <p>暂无链接</p>
                                    </div>
                                <?php endif; ?>
                            </section>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-compass"></i>
                            <h3>欢迎使用 LinkHub</h3>
                            <p>开始添加您的第一个分类和链接吧</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
        
        <!-- 页脚区域 -->
        <?php if ($settings['show_footer'] ?? true): ?>
        <footer class="site-footer">
            <div class="container">
                <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($site['title']) ?>. Powered by LinkHub.</p>
            </div>
        </footer>
        <?php endif; ?>
    </div>
    
    <!-- JavaScript -->
    <script src="/themes/<?= basename(__DIR__) ?>/script.js?v=<?= filemtime(__DIR__ . '/script.js') ?>"></script>
    
    <!-- 自定义脚本 -->
    <?php if (!empty($settings['custom_js'])): ?>
        <script><?= $settings['custom_js'] ?></script>
    <?php endif; ?>
</body>
</html>
```

### style.css - 样式文件结构

```css
/* ================================
   主题样式文件结构
   ================================ */

/* 1. CSS 变量定义 */
:root {
    /* 颜色变量 */
    --primary-color: #4f46e5;
    --secondary-color: #6b7280;
    --background-color: #ffffff;
    --text-color: #1f2937;
    --border-color: #e5e7eb;
    
    /* 尺寸变量 */
    --container-width: 1400px;
    --border-radius: 8px;
    --shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    
    /* 动画变量 */
    --transition: all 0.3s ease;
}

/* 2. 深色模式变量 */
.color-scheme-dark {
    --background-color: #1f2937;
    --text-color: #f9fafb;
    --border-color: #374151;
}

/* 3. 基础重置样式 */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: var(--text-color);
    background-color: var(--background-color);
    transition: var(--transition);
}

/* 4. 布局组件 */
.container {
    max-width: var(--container-width);
    margin: 0 auto;
    padding: 0 20px;
}

/* 5. 头部样式 */
.site-header {
    padding: 2rem 0;
    border-bottom: 1px solid var(--border-color);
}

/* 6. 主内容样式 */
.site-main {
    padding: 2rem 0;
}

/* 7. 分类样式 */
.categories-sidebar {
    /* 侧边栏样式 */
}

.category-item {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    text-decoration: none;
    color: var(--text-color);
    border-radius: var(--border-radius);
    transition: var(--transition);
}

.category-item:hover {
    background-color: var(--primary-color);
    color: white;
}

/* 8. 链接卡片样式 */
.links-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
    margin-top: 1rem;
}

.link-card {
    display: block;
    padding: 1.5rem;
    background: white;
    border-radius: var(--border-radius);
    box-shadow: var(--shadow);
    text-decoration: none;
    color: inherit;
    transition: var(--transition);
}

.link-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* 9. 响应式设计 */
@media (max-width: 768px) {
    .container {
        padding: 0 15px;
    }
    
    .links-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}

/* 10. 动画效果 */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.link-item {
    animation: fadeIn 0.5s ease-out;
}

/* 11. 工具类 */
.text-center { text-align: center; }
.hidden { display: none; }
.sr-only { 
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
}
```

### script.js - 脚本文件结构

```javascript
/**
 * 主题脚本文件
 */

(function() {
    'use strict';
    
    // 主题配置
    const THEME_CONFIG = {
        name: 'your-theme',
        version: '1.0.0',
        animations: true,
        debug: false
    };
    
    // DOM 元素
    const elements = {
        app: document.getElementById('app'),
        categories: document.querySelectorAll('.category-item'),
        links: document.querySelectorAll('.link-item'),
        searchForm: document.querySelector('.search-form form'),
        searchInput: document.querySelector('.search-form input[name="q"]')
    };
    
    /**
     * 初始化主题
     */
    function initTheme() {
        console.log(`🎨 ${THEME_CONFIG.name} v${THEME_CONFIG.version} 已加载`);
        
        // 初始化各个模块
        initCategoryNavigation();
        initLinkCards();
        initSearch();
        initAnimations();
        initThemeSettings();
        
        // 触发主题就绪事件
        document.dispatchEvent(new CustomEvent('themeReady', {
            detail: THEME_CONFIG
        }));
    }
    
    /**
     * 分类导航功能
     */
    function initCategoryNavigation() {
        elements.categories.forEach(category => {
            category.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    // 平滑滚动到目标分类
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    
                    // 更新活动状态
                    updateActiveCategory(this);
                }
            });
        });
    }
    
    /**
     * 更新活动分类
     */
    function updateActiveCategory(activeCategory) {
        elements.categories.forEach(cat => cat.classList.remove('active'));
        activeCategory.classList.add('active');
    }
    
    /**
     * 链接卡片功能
     */
    function initLinkCards() {
        elements.links.forEach(link => {
            const card = link.querySelector('.link-card');
            
            if (card) {
                // 添加点击统计
                card.addEventListener('click', function() {
                    // 这里可以添加统计代码
                    if (THEME_CONFIG.debug) {
                        console.log('链接点击:', this.href);
                    }
                });
                
                // 添加卡片动画
                if (THEME_CONFIG.animations) {
                    addCardAnimation(card);
                }
            }
        });
    }
    
    /**
     * 卡片动画效果
     */
    function addCardAnimation(card) {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-4px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    }
    
    /**
     * 搜索功能
     */
    function initSearch() {
        if (elements.searchInput) {
            // 搜索自动补全
            elements.searchInput.addEventListener('input', debounce(function() {
                const query = this.value.trim();
                if (query.length > 1) {
                    performSearch(query);
                }
            }, 300));
            
            // 快捷键支持
            document.addEventListener('keydown', function(e) {
                // Ctrl/Cmd + K 打开搜索
                if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                    e.preventDefault();
                    elements.searchInput.focus();
                }
                
                // ESC 清空搜索
                if (e.key === 'Escape' && document.activeElement === elements.searchInput) {
                    elements.searchInput.value = '';
                    elements.searchInput.blur();
                }
            });
        }
    }
    
    /**
     * 执行搜索
     */
    function performSearch(query) {
        // 这里可以实现本地搜索或发送到服务器
        console.log('搜索:', query);
    }
    
    /**
     * 初始化动画
     */
    function initAnimations() {
        if (!THEME_CONFIG.animations) return;
        
        // 页面加载动画
        elements.app.classList.add('loaded');
        
        // 滚动动画
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '50px'
        });
        
        elements.links.forEach(link => {
            observer.observe(link);
        });
    }
    
    /**
     * 主题设置
     */
    function initThemeSettings() {
        // 检测系统主题
        if (window.matchMedia) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            
            // 初始检测
            handleThemeChange(mediaQuery);
            
            // 监听变化
            mediaQuery.addEventListener('change', handleThemeChange);
        }
    }
    
    /**
     * 处理主题变化
     */
    function handleThemeChange(e) {
        const body = document.body;
        const currentScheme = body.classList.contains('color-scheme-dark') ? 'dark' : 'light';
        const preferredScheme = e.matches ? 'dark' : 'light';
        
        // 如果设置为跟随系统
        if (getCurrentThemeSetting() === 'auto') {
            body.classList.remove('color-scheme-light', 'color-scheme-dark');
            body.classList.add(`color-scheme-${preferredScheme}`);
        }
    }
    
    /**
     * 获取当前主题设置
     */
    function getCurrentThemeSetting() {
        return localStorage.getItem('theme-color-scheme') || 'auto';
    }
    
    /**
     * 防抖函数
     */
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func.apply(this, args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    /**
     * 工具函数
     */
    const utils = {
        // 获取元素
        $: (selector) => document.querySelector(selector),
        $$: (selector) => document.querySelectorAll(selector),
        
        // 添加类
        addClass: (element, className) => element.classList.add(className),
        
        // 移除类
        removeClass: (element, className) => element.classList.remove(className),
        
        // 切换类
        toggleClass: (element, className) => element.classList.toggle(className),
        
        // 显示元素
        show: (element) => element.style.display = 'block',
        
        // 隐藏元素
        hide: (element) => element.style.display = 'none',
        
        // 获取CSS变量
        getCSSVar: (name) => getComputedStyle(document.documentElement).getPropertyValue(name),
        
        // 设置CSS变量
        setCSSVar: (name, value) => document.documentElement.style.setProperty(name, value)
    };
    
    // 暴露工具函数到全局
    window.ThemeUtils = utils;
    
    // DOM 加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTheme);
    } else {
        initTheme();
    }
    
})();
```

---

## 📊 可用数据变量

在主题模板中，您可以使用以下预定义的变量：

### 网站配置 ($site)

```php
$site = [
    'title' => '网站标题',
    'subtitle' => '网站副标题',
    'keywords' => '网站关键词',
    'description' => '网站描述',
    'logo' => '网站Logo路径',
    'favicon' => '网站图标路径',
    'theme_config' => [], // 主题配置
    // ... 更多配置
];
```

### 分类数据 ($categories)

```php
$categories = [
    [
        'id' => 1,
        'name' => '分类名称',
        'icon' => 'fa-folder',
        'icon_color' => '#4f46e5',
        'description' => '分类描述',
        'weight' => 100,
        'links' => [
            // 链接数据...
        ]
    ],
    // ... 更多分类
];
```

### 链接数据 (在分类中的links数组)

```php
$link = [
    'id' => 1,
    'title' => '链接标题',
    'url' => 'https://example.com',
    'note' => '链接描述',
    'icon' => 'fa-link',
    'icon_color' => '#6b7280',
    'click' => 100, // 点击次数
    'category_id' => 1,
    'weight' => 100,
    // ... 更多属性
];
```

### 主题配置 ($themeConfig)

```php
$themeConfig = [
    'settings' => [
        'color_scheme' => 'light',
        'layout_width' => 1400,
        'enable_animations' => true,
        'primary_color' => '#4f46e5',
        // ... 用户自定义设置
    ]
];
```

---

## 🎨 CSS 框架和约定

### CSS 类命名规范

我们采用 **BEM (Block Element Modifier)** 命名规范：

```css
/* Block */
.site-header { }

/* Element */
.site-header__logo { }
.site-header__nav { }

/* Modifier */
.site-header--dark { }
.site-header__nav--mobile { }
```

### 预定义CSS类

```css
/* 布局类 */
.container              /* 容器 */
.grid                   /* 网格布局 */
.flex                   /* 弹性布局 */

/* 间距类 */
.m-{size}              /* margin */
.p-{size}              /* padding */
.mt-{size}             /* margin-top */
.pt-{size}             /* padding-top */
/* size: 0, 1, 2, 3, 4, 5 */

/* 文本类 */
.text-left             /* 左对齐 */
.text-center           /* 居中对齐 */
.text-right            /* 右对齐 */
.text-truncate         /* 文本截断 */

/* 颜色类 */
.text-primary          /* 主色文本 */
.text-secondary        /* 次色文本 */
.bg-primary            /* 主色背景 */
.bg-secondary          /* 次色背景 */

/* 状态类 */
.active                /* 活动状态 */
.disabled              /* 禁用状态 */
.hidden                /* 隐藏 */
.visible               /* 显示 */

/* 响应式显示 */
.d-none                /* 隐藏 */
.d-block               /* 块级显示 */
.d-md-none             /* 中等屏幕隐藏 */
.d-lg-block            /* 大屏幕块级显示 */
```

### CSS 变量系统

```css
:root {
    /* 颜色系统 */
    --color-primary: #4f46e5;
    --color-secondary: #6b7280;
    --color-success: #10b981;
    --color-warning: #f59e0b;
    --color-error: #ef4444;
    
    /* 文本颜色 */
    --text-primary: #1f2937;
    --text-secondary: #6b7280;
    --text-muted: #9ca3af;
    
    /* 背景颜色 */
    --bg-primary: #ffffff;
    --bg-secondary: #f9fafb;
    --bg-tertiary: #f3f4f6;
    
    /* 边框颜色 */
    --border-color: #e5e7eb;
    --border-color-light: #f3f4f6;
    
    /* 阴影 */
    --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
    --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
    
    /* 圆角 */
    --border-radius-sm: 4px;
    --border-radius-md: 8px;
    --border-radius-lg: 12px;
    
    /* 间距 */
    --spacing-xs: 0.25rem;
    --spacing-sm: 0.5rem;
    --spacing-md: 1rem;
    --spacing-lg: 1.5rem;
    --spacing-xl: 2rem;
    
    /* 字体 */
    --font-family-sans: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-family-mono: 'SF Mono', Monaco, 'Cascadia Code', monospace;
    
    /* 字体大小 */
    --font-size-xs: 0.75rem;
    --font-size-sm: 0.875rem;
    --font-size-md: 1rem;
    --font-size-lg: 1.125rem;
    --font-size-xl: 1.25rem;
    
    /* 过渡动画 */
    --transition-fast: 0.15s ease;
    --transition-normal: 0.3s ease;
    --transition-slow: 0.5s ease;
}
```

---

## 🔌 JavaScript API

### 主题事件系统

```javascript
// 监听主题就绪事件
document.addEventListener('themeReady', function(e) {
    console.log('主题已加载:', e.detail);
});

// 监听主题设置变化
document.addEventListener('themeSettingChanged', function(e) {
    console.log('设置已更改:', e.detail);
});

// 触发自定义事件
document.dispatchEvent(new CustomEvent('customEvent', {
    detail: { data: 'value' }
}));
```

### 主题API方法

```javascript
// 获取主题工具
const utils = window.ThemeUtils;

// DOM 操作
const element = utils.$('#myElement');
const elements = utils.$$('.myClass');

// 样式操作
utils.addClass(element, 'active');
utils.removeClass(element, 'hidden');
utils.toggleClass(element, 'expanded');

// 显示/隐藏
utils.show(element);
utils.hide(element);

// CSS 变量操作
const primaryColor = utils.getCSSVar('--color-primary');
utils.setCSSVar('--color-primary', '#ff0000');
```

### 主题设置API

```javascript
// 主题设置管理器
const ThemeSettings = {
    // 获取设置值
    get(key) {
        return localStorage.getItem(`theme-${key}`);
    },
    
    // 设置值
    set(key, value) {
        localStorage.setItem(`theme-${key}`, value);
        this.apply(key, value);
    },
    
    // 应用设置
    apply(key, value) {
        switch(key) {
            case 'color-scheme':
                document.body.className = document.body.className
                    .replace(/color-scheme-\w+/, `color-scheme-${value}`);
                break;
            case 'layout-width':
                document.documentElement.style
                    .setProperty('--container-width', value + 'px');
                break;
        }
        
        // 触发设置变化事件
        document.dispatchEvent(new CustomEvent('themeSettingChanged', {
            detail: { key, value }
        }));
    }
};
```

---

## 🎯 图标系统

### Font Awesome 图标

LinkHub 内置了 Font Awesome 6.0，您可以使用所有可用的图标：

```html
<!-- 实心图标 (fas) -->
<i class="fas fa-home"></i>
<i class="fas fa-user"></i>
<i class="fas fa-search"></i>

<!-- 品牌图标 (fab) -->
<i class="fab fa-github"></i>
<i class="fab fa-twitter"></i>
<i class="fab fa-google"></i>

<!-- 线条图标 (far) -->
<i class="far fa-heart"></i>
<i class="far fa-bookmark"></i>
```

### 图标处理逻辑

主题会自动处理图标前缀：

```php
<?php
// 自动添加正确的图标前缀
function processIcon($iconClass) {
    if (strpos($iconClass, 'fa-') === 0) {
        $brandIcons = [
            'fa-github', 'fa-youtube', 'fa-docker', 'fa-google',
            'fa-facebook', 'fa-twitter', 'fa-linkedin', 'fa-instagram'
        ];
        
        if (in_array($iconClass, $brandIcons)) {
            return 'fab ' . $iconClass;
        } else {
            return 'fas ' . $iconClass;
        }
    }
    return $iconClass;
}
?>
```

### 自定义图标

您也可以使用自定义图标：

```css
/* 自定义图标字体 */
@font-face {
    font-family: 'CustomIcons';
    src: url('assets/fonts/custom-icons.woff2') format('woff2');
}

.custom-icon {
    font-family: 'CustomIcons';
}

.custom-icon-home::before { content: '\e001'; }
.custom-icon-user::before { content: '\e002'; }
```

---

## 📱 响应式设计

### 断点系统

```css
/* 断点定义 */
:root {
    --breakpoint-xs: 0;
    --breakpoint-sm: 576px;
    --breakpoint-md: 768px;
    --breakpoint-lg: 992px;
    --breakpoint-xl: 1200px;
    --breakpoint-xxl: 1400px;
}

/* 媒体查询 */
@media (max-width: 575.98px) { /* xs */ }
@media (min-width: 576px) { /* sm */ }
@media (min-width: 768px) { /* md */ }
@media (min-width: 992px) { /* lg */ }
@media (min-width: 1200px) { /* xl */ }
@media (min-width: 1400px) { /* xxl */ }
```

### 响应式网格

```css
/* 响应式网格系统 */
.links-grid {
    display: grid;
    gap: 1.5rem;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
}

/* 响应式调整 */
@media (max-width: 768px) {
    .links-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}

@media (min-width: 1200px) {
    .links-grid {
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    }
}
```

### 移动端优化

```css
/* 移动端优化 */
@media (max-width: 768px) {
    /* 增大触摸目标 */
    .link-card {
        padding: 1rem;
        min-height: 44px;
    }
    
    /* 简化导航 */
    .categories-sidebar {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: white;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        z-index: 1000;
    }
    
    /* 滚动优化 */
    .links-content {
        -webkit-overflow-scrolling: touch;
    }
}
```

---

## ⚡ 性能优化

### CSS 优化

```css
/* 使用 CSS 自定义属性减少重复 */
:root {
    --card-padding: 1.5rem;
    --card-radius: 8px;
    --card-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* 使用 transform 而不是改变 layout 属性 */
.link-card {
    transform: translateZ(0); /* 开启硬件加速 */
    transition: transform 0.3s ease;
}

.link-card:hover {
    transform: translateY(-2px); /* 使用 transform */
}

/* 优化字体加载 */
@font-face {
    font-family: 'CustomFont';
    src: url('fonts/custom.woff2') format('woff2');
    font-display: swap; /* 字体交换策略 */
}

/* 优化图片 */
img {
    max-width: 100%;
    height: auto;
    loading: lazy; /* 懒加载 */
}
```

### JavaScript 优化

```javascript
// 使用节流和防抖
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// 优化滚动事件
window.addEventListener('scroll', throttle(function() {
    // 滚动处理逻辑
}, 100));

// 使用 requestAnimationFrame 优化动画
function animateElement(element) {
    let start = null;
    
    function step(timestamp) {
        if (!start) start = timestamp;
        const progress = timestamp - start;
        
        // 动画逻辑
        element.style.transform = `translateX(${progress / 10}px)`;
        
        if (progress < 1000) {
            requestAnimationFrame(step);
        }
    }
    
    requestAnimationFrame(step);
}
```

### 资源优化

```html
<!-- 预加载关键资源 -->
<link rel="preload" href="/themes/your-theme/style.css" as="style">
<link rel="preload" href="/themes/your-theme/script.js" as="script">

<!-- DNS 预解析 -->
<link rel="dns-prefetch" href="//cdnjs.cloudflare.com">

<!-- 预连接 -->
<link rel="preconnect" href="https://fonts.googleapis.com">

<!-- 延迟加载非关键资源 -->
<link rel="stylesheet" href="/themes/your-theme/style.css" media="print" onload="this.media='all'">
```

---

## 🛠️ 开发工具

### 开发环境设置

```bash
# 创建开发环境
mkdir theme-dev
cd theme-dev

# 初始化Git
git init

# 创建基本文件
touch index.php style.css script.js theme.json

# 设置监听文件变化（可选）
npm install -g browser-sync
browser-sync start --proxy "localhost/your-site" --files "**/*.php,**/*.css,**/*.js"
```

### 调试工具

在主题中添加调试功能：

```php
<?php
// 调试模式检测
$debugMode = defined('THEME_DEBUG') && THEME_DEBUG;

if ($debugMode) {
    // 显示调试信息
    echo '<div id="theme-debug" style="position: fixed; top: 0; right: 0; background: #000; color: #fff; padding: 10px; z-index: 9999;">';
    echo '<h4>主题调试信息</h4>';
    echo '<p>主题: ' . basename(__DIR__) . '</p>';
    echo '<p>可用变量:</p>';
    echo '<pre>' . print_r(['site' => array_keys($site), 'categories' => count($categories)], true) . '</pre>';
    echo '</div>';
}
?>
```

### 代码格式化

```bash
# PHP 代码格式化
composer global require friendsofphp/php-cs-fixer
php-cs-fixer fix --rules=@PSR12 ./

# CSS 代码格式化
npm install -g prettier
prettier --write "**/*.css"

# JavaScript 代码格式化  
prettier --write "**/*.js"
```

---

## 🧪 调试和测试

### 调试技巧

1. **PHP 调试**
```php
// 输出变量内容
var_dump($categories);

// 检查变量是否存在
if (isset($site['title'])) {
    echo $site['title'];
}

// 安全输出
echo htmlspecialchars($site['title'] ?? '默认标题');
```

2. **CSS 调试**
```css
/* 显示所有元素边框 */
* {
    outline: 1px solid red !important;
}

/* 调试网格布局 */
.debug-grid {
    background-image: 
        linear-gradient(rgba(255,0,0,0.1) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,0,0,0.1) 1px, transparent 1px);
    background-size: 20px 20px;
}
```

3. **JavaScript 调试**
```javascript
// 调试信息
console.group('主题调试');
console.log('主题配置:', THEME_CONFIG);
console.log('可用元素:', elements);
console.groupEnd();

// 性能测试
console.time('主题初始化');
initTheme();
console.timeEnd('主题初始化');
```

### 测试清单

- [ ] **兼容性测试**
  - [ ] Chrome/Edge (最新版本)
  - [ ] Firefox (最新版本)
  - [ ] Safari (最新版本)
  - [ ] 移动端浏览器

- [ ] **响应式测试**
  - [ ] 手机端 (320px-768px)
  - [ ] 平板端 (768px-1024px)
  - [ ] 桌面端 (1024px+)

- [ ] **功能测试**
  - [ ] 分类导航正常工作
  - [ ] 链接点击正常跳转
  - [ ] 搜索功能正常
  - [ ] 主题设置正常

- [ ] **性能测试**
  - [ ] 页面加载时间 < 3秒
  - [ ] 图片优化完成
  - [ ] CSS/JS 压缩完成

---

## 📦 主题发布

### 发布前准备

1. **代码清理**
```bash
# 删除调试代码
grep -r "console.log\|var_dump\|print_r" ./

# 压缩CSS/JS（可选）
# 建议保留未压缩版本便于调试
```

2. **文件检查**
```bash
# 检查必需文件
ls -la index.php style.css theme.json screenshot.jpg

# 检查文件权限
chmod 644 *.php *.css *.js *.json
chmod 755 assets/
```

3. **创建文档**
```markdown
# 主题说明文档
- 安装方法
- 配置选项
- 自定义说明
- 更新日志
```

### 打包主题

```bash
# 创建主题包
zip -r your-theme-v1.0.0.zip \
    index.php \
    style.css \
    script.js \
    theme.json \
    screenshot.jpg \
    README.md \
    assets/ \
    -x "*.git*" "*.DS_Store" "node_modules/*"
```

### 发布渠道

1. **GitHub Release**
   - 创建仓库
   - 添加标签
   - 上传主题包

2. **主题市场**
   - 提交到官方主题商店
   - 填写主题信息
   - 等待审核

3. **个人网站**
   - 创建下载页面
   - 提供安装说明
   - 收集用户反馈

---

## 🌟 最佳实践

### 代码规范

1. **PHP 规范**
```php
// 使用短标签
<?= $variable ?>

// 安全输出
<?= htmlspecialchars($user_input) ?>

// 条件检查
<?php if (!empty($categories)): ?>
    <!-- 内容 -->
<?php endif; ?>
```

2. **CSS 规范**
```css
/* 使用 BEM 命名 */
.block__element--modifier { }

/* 移动端优先 */
.component {
    /* 移动端样式 */
}

@media (min-width: 768px) {
    .component {
        /* 桌面端样式 */
    }
}
```

3. **JavaScript 规范**
```javascript
// 使用严格模式
'use strict';

// 避免全局变量
(function() {
    // 代码逻辑
})();

// 使用有意义的变量名
const categoryNavigationElements = document.querySelectorAll('.category-item');
```

### 性能优化

1. **减少HTTP请求**
   - 合并CSS/JS文件
   - 使用CSS精灵图
   - 优化图片格式

2. **优化渲染性能**
   - 避免强制重排
   - 使用CSS transform
   - 减少DOM操作

3. **代码优化**
   - 移除未使用的CSS
   - 压缩资源文件
   - 使用CDN加速

### 用户体验

1. **可访问性**
```html
<!-- 添加适当的ARIA标签 -->
<nav aria-label="分类导航">
    <a href="#category-1" aria-describedby="category-1-desc">
        分类名称
    </a>
</nav>

<!-- 提供键盘导航支持 -->
<button tabindex="0" role="button">按钮</button>
```

2. **加载优化**
```html
<!-- 懒加载图片 -->
<img src="placeholder.jpg" data-src="actual-image.jpg" loading="lazy" alt="描述">

<!-- 预加载关键资源 -->
<link rel="preload" href="critical.css" as="style">
```

3. **错误处理**
```javascript
// 优雅降级
try {
    // 新功能代码
} catch (error) {
    // 兼容性处理
    console.warn('功能不支持，使用备用方案');
}
```

---

## ❓ 常见问题

### 开发问题

**Q: 主题不显示怎么办？**
A: 检查以下几点：
1. 确保 `theme.json` 格式正确
2. 检查 `index.php` 语法错误
3. 确认文件权限正确
4. 查看服务器错误日志

**Q: 样式不生效？**
A: 可能的原因：
1. CSS语法错误
2. 浏览器缓存问题
3. CSS优先级问题
4. 文件路径错误

**Q: JavaScript功能异常？**
A: 调试步骤：
1. 打开浏览器开发者工具
2. 查看控制台错误信息
3. 检查JavaScript语法
4. 确认DOM元素存在

### 兼容性问题

**Q: 在旧版本LinkHub上不兼容？**
A: 在 `theme.json` 中设置正确的版本要求：
```json
{
    "require": {
        "min": "2.0.0",
        "max": ""
    }
}
```

**Q: 移动端显示异常？**
A: 检查响应式设计：
1. 添加viewport meta标签
2. 使用相对单位 (rem, em, %)
3. 测试不同屏幕尺寸
4. 优化触摸交互

### 性能问题

**Q: 页面加载缓慢？**
A: 优化建议：
1. 压缩CSS/JS文件
2. 优化图片大小和格式
3. 减少HTTP请求数量
4. 使用浏览器缓存

**Q: 动画卡顿？**
A: 性能优化：
1. 使用CSS transform代替position
2. 添加will-change属性
3. 减少同时运行的动画
4. 使用requestAnimationFrame

---

<div align="center">

## 🎉 祝您开发愉快！

如果您在开发过程中遇到问题，欢迎：

- 📧 发送邮件：[dev@linkhub.com](mailto:dev@linkhub.com)
- 💬 加入社区：[LinkHub开发者社区](https://community.linkhub.com)
- 🐛 提交Issue：[GitHub Issues](https://github.com/yourusername/linkhub/issues)

---

**[⬆ 回到顶部](#-linkhub-主题开发指南)**

<sub>由 ❤️ 用心编写 | Copyright © 2024 LinkHub Team</sub>

</div>
