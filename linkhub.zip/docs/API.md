# 🔌 LinkHub API 文档

<div align="center">

![API Version](https://img.shields.io/badge/API-v1-blue?style=for-the-badge)

**强大、简洁、RESTful 的 API 接口**

[快速开始](#快速开始) · [认证授权](#认证授权) · [API 参考](#api-参考) · [错误处理](#错误处理)

</div>

---

## 📖 概述

LinkHub API 提供了完整的 RESTful 接口，支持分类管理、链接管理、搜索和统计功能。所有接口都返回 JSON 格式的响应。

### 基础信息

- **Base URL**: `https://yourdomain.com/api`
- **API Version**: v1
- **Content-Type**: `application/json`
- **字符编码**: UTF-8

## 🚀 快速开始

### 1. 测试 API 连接

```bash
curl -X GET "https://yourdomain.com/api"
```

**响应示例：**
```json
{
    "success": true,
    "message": "LinkHub API v1",
    "version": "v1",
    "endpoints": {
        "categories": "/api/categories",
        "links": "/api/links", 
        "search": "/api/search",
        "stats": "/api/stats"
    },
    "timestamp": 1642751234
}
```

### 2. 获取所有分类

```bash
curl -X GET "https://yourdomain.com/api/categories"
```

### 3. 创建新链接

```bash
curl -X POST "https://yourdomain.com/api/links" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "GitHub",
    "url": "https://github.com", 
    "category_id": 1,
    "note": "全球最大的代码托管平台"
  }'
```

---

## 🔐 认证授权

当前版本的 API 为开放接口，未来版本将支持以下认证方式：

- **API Key** - 基于密钥的认证
- **JWT Token** - JSON Web Token 认证
- **OAuth 2.0** - 第三方应用授权

---

## 📡 响应格式

### 成功响应

```json
{
    "success": true,
    "code": 200,
    "message": "操作成功",
    "data": { ... },
    "timestamp": 1642751234
}
```

### 分页响应

```json
{
    "success": true,
    "message": "获取成功",
    "data": [...],
    "pagination": {
        "total": 100,
        "per_page": 20,
        "current_page": 1,
        "total_pages": 5,
        "has_more": true
    },
    "timestamp": 1642751234
}
```

### 错误响应

```json
{
    "success": false,
    "code": 400,
    "message": "请求参数错误",
    "errors": {
        "title": ["标题字段是必需的"]
    },
    "timestamp": 1642751234
}
```

---

## 📋 API 参考

### 🗂️ 分类管理

#### 获取分类列表

`GET /api/categories`

**查询参数：**

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `page` | integer | 页码 (默认:1) | `?page=2` |
| `per_page` | integer | 每页数量 (默认:20) | `?per_page=10` |
| `search` | string | 搜索关键词 | `?search=工具` |
| `sort_by` | string | 排序字段 | `?sort_by=weight` |
| `sort_order` | string | 排序方向 (ASC/DESC) | `?sort_order=DESC` |

**响应示例：**
```json
{
    "success": true,
    "message": "获取成功",
    "data": [
        {
            "id": 1,
            "name": "常用网站",
            "icon": "fa-star",
            "icon_color": "#3498db",
            "description": "日常使用的常用网站",
            "weight": 100,
            "links_count": 5,
            "add_time": "2024-01-15 10:30:00"
        }
    ],
    "pagination": { ... }
}
```

#### 获取分类详情

`GET /api/categories/{id}`

**查询参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `include_links` | boolean | 是否包含链接列表 |

**响应示例：**
```json
{
    "success": true,
    "data": {
        "id": 1,
        "name": "常用网站",
        "icon": "fa-star",
        "icon_color": "#3498db",
        "description": "日常使用的常用网站",
        "weight": 100,
        "links_count": 5,
        "add_time": "2024-01-15 10:30:00",
        "links": [...]  // 当 include_links=true 时返回
    }
}
```

#### 创建分类

`POST /api/categories`

**请求体：**
```json
{
    "name": "开发工具",
    "description": "开发相关的工具和资源", 
    "icon": "fa-code",
    "icon_color": "#9b59b6",
    "weight": 90
}
```

**字段说明：**

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `name` | string | ✅ | 分类名称 (1-50字符) |
| `description` | string | ❌ | 分类描述 (最多200字符) |
| `icon` | string | ❌ | 图标类名 (默认: fa-folder) |
| `icon_color` | string | ❌ | 图标颜色 (默认: #6366f1) |
| `weight` | integer | ❌ | 排序权重 (默认: 100) |

#### 更新分类

`PUT /api/categories/{id}`

请求体格式同创建分类。

#### 删除分类

`DELETE /api/categories/{id}`

**注意：** 只有当分类下没有链接时才能删除。

### 🔗 链接管理

#### 获取链接列表

`GET /api/links`

**查询参数：**

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `page` | integer | 页码 | `?page=2` |
| `per_page` | integer | 每页数量 | `?per_page=10` |
| `category_id` | integer | 分类筛选 | `?category_id=1` |
| `search` | string | 搜索关键词 | `?search=github` |
| `sort_by` | string | 排序字段 | `?sort_by=click` |
| `sort_order` | string | 排序方向 | `?sort_order=DESC` |

**响应示例：**
```json
{
    "success": true,
    "data": [
        {
            "id": 1,
            "title": "GitHub",
            "url": "https://github.com",
            "note": "全球最大的代码托管平台",
            "icon": "fa-github", 
            "icon_color": "#333333",
            "click": 150,
            "weight": 100,
            "category_id": 1,
            "category_name": "开发工具",
            "domain": "github.com",
            "favicon_url": "/favicon?url=https%3A//github.com",
            "add_time": "2024-01-15 10:30:00"
        }
    ],
    "pagination": { ... }
}
```

#### 获取链接详情

`GET /api/links/{id}`

**查询参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `include_stats` | boolean | 是否包含点击统计 |

#### 创建链接

`POST /api/links`

**请求体：**
```json
{
    "title": "Visual Studio Code",
    "url": "https://code.visualstudio.com",
    "category_id": 1,
    "note": "微软开发的免费代码编辑器",
    "icon": "fa-code",
    "icon_color": "#007acc",
    "weight": 95
}
```

**字段说明：**

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `title` | string | ✅ | 链接标题 (1-100字符) |
| `url` | string | ✅ | 链接URL (有效URL格式) |
| `category_id` | integer | ✅ | 所属分类ID |
| `note` | string | ❌ | 链接描述 (最多300字符) |
| `icon` | string | ❌ | 图标类名 |
| `icon_color` | string | ❌ | 图标颜色 |
| `weight` | integer | ❌ | 排序权重 |

#### 更新链接

`PUT /api/links/{id}`

请求体格式同创建链接。

#### 删除链接

`DELETE /api/links/{id}`

#### 点击统计

`POST /api/links/{id}/click`

记录链接点击，用于统计分析。

#### 批量操作

`POST /api/links/batch`

**请求体：**
```json
{
    "action": "delete",  // delete | move
    "ids": [1, 2, 3],
    "category_id": 2     // move操作时需要
}
```

### 🔍 搜索功能

#### 全站搜索

`GET /api/search`

**查询参数：**

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `q` | string | 搜索关键词 (必需) | `?q=github` |
| `type` | string | 搜索类型 | `?type=links` |
| `page` | integer | 页码 | `?page=2` |
| `per_page` | integer | 每页数量 | `?per_page=10` |

**搜索类型：**
- `all` - 全部 (默认)
- `links` - 仅搜索链接
- `categories` - 仅搜索分类

**响应示例：**
```json
{
    "success": true,
    "message": "找到 15 个结果", 
    "data": [
        {
            "type": "link",
            "id": 1,
            "title": "GitHub",
            "url": "https://github.com",
            "note": "代码托管平台",
            "icon": "fa-github",
            "icon_color": "#333333",
            "click": 150,
            "category_name": "开发工具",
            "category_id": 1,
            "domain": "github.com",
            "highlight": ["<mark>GitHub</mark>", "代码托管平台"],
            "add_time": "2024-01-15 10:30:00"
        }
    ],
    "pagination": { ... }
}
```

#### 搜索建议

`GET /api/search/suggestions`

**查询参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `q` | string | 关键词前缀 (最少2个字符) |
| `limit` | integer | 返回数量 (5-10，默认8) |

**响应示例：**
```json
{
    "success": true,
    "data": [
        {
            "text": "GitHub",
            "popularity": 150
        },
        {
            "text": "GitLab", 
            "popularity": 89
        }
    ]
}
```

#### 热门搜索

`GET /api/search/hot`

**查询参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `limit` | integer | 返回数量 (5-20，默认10) |

### 📊 统计分析

#### 总体统计

`GET /api/stats`

**响应示例：**
```json
{
    "success": true,
    "data": {
        "categories_count": 8,
        "links_count": 45,
        "total_clicks": 2350,
        "today_clicks": 127,
        "week_clicks": 856,
        "month_clicks": 2350
    }
}
```

#### 点击趋势

`GET /api/stats/clicks`

**查询参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `period` | string | 时间周期 (7d/30d/90d，默认7d) |

**响应示例：**
```json
{
    "success": true,
    "data": [
        {
            "date": "2024-01-15",
            "clicks": 127
        },
        {
            "date": "2024-01-16", 
            "clicks": 143
        }
    ]
}
```

#### 热门链接排行

`GET /api/stats/popular`

**查询参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `limit` | integer | 返回数量 (5-50，默认10) |

#### 分类统计

`GET /api/stats/categories`

**响应示例：**
```json
{
    "success": true,
    "data": [
        {
            "id": 1,
            "name": "开发工具",
            "icon": "fa-code",
            "icon_color": "#9b59b6",
            "links_count": 15,
            "total_clicks": 850
        }
    ]
}
```

---

## ⚠️ 错误处理

### 常见错误码

| 状态码 | 说明 | 处理建议 |
|--------|------|----------|
| `200` | 成功 | - |
| `201` | 创建成功 | - |
| `400` | 请求参数错误 | 检查请求参数格式 |
| `404` | 资源不存在 | 确认资源ID是否正确 |
| `405` | 请求方法不允许 | 使用正确的HTTP方法 |
| `422` | 参数验证失败 | 根据errors字段修正参数 |
| `500` | 服务器内部错误 | 联系技术支持 |
| `503` | 服务不可用 | 系统可能未安装或维护中 |

### 错误响应格式

```json
{
    "success": false,
    "code": 422,
    "message": "参数验证失败",
    "errors": {
        "title": ["标题字段是必需的"],
        "url": ["URL格式不正确"]
    },
    "timestamp": 1642751234
}
```

---

## 📝 使用示例

### JavaScript (Fetch API)

```javascript
// 获取分类列表
async function getCategories() {
    try {
        const response = await fetch('/api/categories');
        const data = await response.json();
        
        if (data.success) {
            console.log('分类列表:', data.data);
            return data.data;
        } else {
            console.error('获取失败:', data.message);
        }
    } catch (error) {
        console.error('请求错误:', error);
    }
}

// 创建新链接
async function createLink(linkData) {
    try {
        const response = await fetch('/api/links', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(linkData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            console.log('创建成功:', data.data);
            return data.data;
        } else {
            console.error('创建失败:', data.message, data.errors);
        }
    } catch (error) {
        console.error('请求错误:', error);
    }
}

// 搜索链接
async function searchLinks(query) {
    try {
        const url = `/api/search?q=${encodeURIComponent(query)}&type=links`;
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            console.log('搜索结果:', data.data);
            return data.data;
        }
    } catch (error) {
        console.error('搜索错误:', error);
    }
}
```

### PHP (cURL)

```php
<?php
// 获取分类列表
function getCategories() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://yourdomain.com/api/categories');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

// 创建链接
function createLink($data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://yourdomain.com/api/links');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

// 使用示例
$result = createLink([
    'title' => 'GitHub',
    'url' => 'https://github.com',
    'category_id' => 1,
    'note' => '全球最大的代码托管平台'
]);

if ($result['success']) {
    echo '链接创建成功，ID: ' . $result['data']['id'];
} else {
    echo '创建失败: ' . $result['message'];
}
?>
```

### Python (requests)

```python
import requests
import json

# API基础配置
BASE_URL = 'https://yourdomain.com/api'
HEADERS = {
    'Content-Type': 'application/json'
}

# 获取分类列表
def get_categories():
    response = requests.get(f'{BASE_URL}/categories', headers=HEADERS)
    return response.json()

# 创建链接
def create_link(link_data):
    response = requests.post(
        f'{BASE_URL}/links', 
        headers=HEADERS,
        json=link_data
    )
    return response.json()

# 搜索
def search(query, search_type='all'):
    params = {
        'q': query,
        'type': search_type
    }
    response = requests.get(f'{BASE_URL}/search', params=params, headers=HEADERS)
    return response.json()

# 使用示例
if __name__ == '__main__':
    # 创建新链接
    new_link = {
        'title': 'GitHub',
        'url': 'https://github.com',
        'category_id': 1,
        'note': '全球最大的代码托管平台'
    }
    
    result = create_link(new_link)
    if result['success']:
        print(f'链接创建成功，ID: {result["data"]["id"]}')
    else:
        print(f'创建失败: {result["message"]}')
```

---

## 🛡️ 安全建议

1. **HTTPS**: 生产环境务必使用HTTPS
2. **输入验证**: 客户端和服务端都要进行输入验证
3. **频率限制**: 实施API调用频率限制
4. **日志记录**: 记录重要的API调用日志
5. **错误处理**: 不要在错误信息中泄露敏感信息

---

## 🔄 版本更新

### v1.0.0 (当前版本)
- ✅ 分类管理完整CRUD操作
- ✅ 链接管理完整CRUD操作  
- ✅ 搜索功能和搜索建议
- ✅ 统计分析和数据报告
- ✅ 批量操作支持

### 未来版本计划
- 🔜 API认证和授权
- 🔜 Webhook支持
- 🔜 数据导入导出
- 🔜 高级筛选和排序
- 🔜 缓存优化

---

<div align="center">

**[⬆ 回到顶部](#-linkhub-api-文档)**

---

如有疑问，请联系：[api@linkhub.com](mailto:api@linkhub.com)

<sub>Copyright © 2024 LinkHub Team</sub>

</div>
