# ❓ LinkHub 常见问题

<div align="center">

![FAQ](https://img.shields.io/badge/FAQ-常见问题-orange?style=for-the-badge&logo=question&logoColor=white)

**解答您使用 LinkHub 过程中的常见疑问**

[安装问题](#安装问题) · [配置问题](#配置问题) · [功能问题](#功能问题) · [性能问题](#性能问题) · [开发问题](#开发问题)

</div>

---

## 🚀 安装问题

<details>
<summary><strong>Q: 安装时提示"数据库连接失败"怎么办？</strong></summary>

**A:** 这通常是数据库配置问题，请按以下步骤排查：

1. **检查数据库服务**
```bash
# MySQL
sudo service mysql status
sudo service mysql start

# 检查端口
netstat -tlnp | grep :3306
```

2. **验证连接信息**
```bash
mysql -h localhost -u your_username -p
```

3. **常见错误码解决方案**
- **1045 - Access denied**: 用户名或密码错误
- **2002 - Connection refused**: 数据库服务未启动
- **1049 - Unknown database**: 数据库不存在

4. **创建数据库和用户**
```sql
CREATE DATABASE linkhub CHARACTER SET utf8mb4;
CREATE USER 'linkhub'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON linkhub.* TO 'linkhub'@'localhost';
FLUSH PRIVILEGES;
```
</details>

<details>
<summary><strong>Q: 安装后无法访问，显示404错误？</strong></summary>

**A:** URL重写配置问题，请检查：

1. **Apache用户** - 确保`.htaccess`文件存在：
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]
```

2. **Nginx用户** - 添加重写规则：
```nginx
location / {
    try_files $uri $uri/ /index.php?$query_string;
}
```

3. **检查mod_rewrite模块**：
```bash
# Apache
sudo a2enmod rewrite
sudo service apache2 restart

# 检查是否启用
apache2ctl -M | grep rewrite
```
</details>

<details>
<summary><strong>Q: 安装完成后页面空白或出现PHP错误？</strong></summary>

**A:** 权限或PHP配置问题：

1. **设置正确的文件权限**
```bash
chmod -R 755 storage/
chmod -R 755 public/cache/
chown -R www-data:www-data /path/to/linkhub
```

2. **检查PHP错误日志**
```bash
tail -f /var/log/apache2/error.log
tail -f /var/log/nginx/error.log
```

3. **PHP版本兼容性**
```bash
php -v  # 确保 PHP >= 7.4
php -m  # 检查必需扩展
```

4. **启用错误显示（仅开发环境）**
```php
// 在index.php顶部临时添加
ini_set('display_errors', 1);
error_reporting(E_ALL);
```
</details>

<details>
<summary><strong>Q: 安装时卡在某个步骤无法继续？</strong></summary>

**A:** 分步骤排查：

1. **检查浏览器控制台** - 查看JavaScript错误
2. **清除浏览器缓存** - 强制刷新 (Ctrl+F5)
3. **检查服务器日志** - 查看PHP和Web服务器错误
4. **手动删除安装锁**
```bash
rm -f storage/installed
```
5. **重新开始安装** - 访问 `/install.php`
</details>

---

## ⚙️ 配置问题

<details>
<summary><strong>Q: 如何修改默认的表前缀？</strong></summary>

**A:** 表前缀只能在安装时设置，安装后不建议修改：

1. **安装时设置**：在安装向导中设置表前缀（如：`lh_`）

2. **如果必须修改**（⚠️ 风险操作）：
```sql
-- 备份数据库
mysqldump -u user -p database_name > backup.sql

-- 重命名表（示例：从on_改为lh_）
RENAME TABLE on_categorys TO lh_categorys;
RENAME TABLE on_links TO lh_links;
-- ... 重命名所有表

-- 修改.env文件中的DB_PREFIX
DB_PREFIX=lh_
```
</details>

<details>
<summary><strong>Q: 如何启用HTTPS？</strong></summary>

**A:** HTTPS配置步骤：

1. **获取SSL证书**
```bash
# 使用Let's Encrypt
sudo certbot --apache -d yourdomain.com
# 或使用Nginx
sudo certbot --nginx -d yourdomain.com
```

2. **修改Apache配置**
```apache
<VirtualHost *:443>
    ServerName yourdomain.com
    DocumentRoot /var/www/linkhub/public
    
    SSLEngine on
    SSLCertificateFile /path/to/cert.pem
    SSLCertificateKeyFile /path/to/private.key
    
    # 重定向HTTP到HTTPS
    Redirect permanent / https://yourdomain.com/
</VirtualHost>
```

3. **更新.env文件**
```env
APP_URL=https://yourdomain.com
```
</details>

<details>
<summary><strong>Q: 如何配置邮件发送？</strong></summary>

**A:** 邮件配置（如果项目支持）：

1. **SMTP配置**
```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=your-email@gmail.com
MAIL_FROM_NAME="LinkHub"
```

2. **测试邮件发送**
```php
// 在后台创建测试页面
$to = 'test@example.com';
$subject = 'LinkHub 邮件测试';
$message = '这是一封测试邮件';
$headers = 'From: noreply@yourdomain.com';

if (mail($to, $subject, $message, $headers)) {
    echo '邮件发送成功';
} else {
    echo '邮件发送失败';
}
```
</details>

<details>
<summary><strong>Q: 如何备份和恢复数据？</strong></summary>

**A:** 数据备份方案：

1. **数据库备份**
```bash
# 备份
mysqldump -u username -p database_name > linkhub_backup.sql

# 恢复
mysql -u username -p database_name < linkhub_backup.sql
```

2. **完整备份**
```bash
# 备份整个项目
tar -czf linkhub_backup_$(date +%Y%m%d).tar.gz /path/to/linkhub

# 恢复
tar -xzf linkhub_backup_20240115.tar.gz -C /path/to/restore/
```

3. **自动备份脚本**
```bash
#!/bin/bash
# backup.sh
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/path/to/backups"
DB_NAME="linkhub"
DB_USER="username"

# 创建备份目录
mkdir -p $BACKUP_DIR

# 备份数据库
mysqldump -u $DB_USER -p $DB_NAME > $BACKUP_DIR/db_$DATE.sql

# 备份文件
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /path/to/linkhub/storage/uploads

# 清理7天前的备份
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
```
</details>

---

## 🔧 功能问题

<details>
<summary><strong>Q: 为什么图标显示为方框？</strong></summary>

**A:** Font Awesome加载问题：

1. **检查CDN连接**
```html
<!-- 确保CDN可访问 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
```

2. **使用国内CDN**
```html
<!-- 替换为国内CDN -->
<link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.0.0/css/all.min.css">
```

3. **本地化部署**
```bash
# 下载Font Awesome
wget https://use.fontawesome.com/releases/v6.0.0/fontawesome-free-6.0.0-web.zip
unzip fontawesome-free-6.0.0-web.zip -d public/assets/
```

4. **检查图标类名**
- 品牌图标使用 `fab` 前缀：`fab fa-github`
- 普通图标使用 `fas` 前缀：`fas fa-home`
</details>

<details>
<summary><strong>Q: 如何批量导入书签？</strong></summary>

**A:** 支持多种导入方式：

1. **从浏览器导出书签**
   - Chrome: 设置 → 书签 → 书签管理器 → 导出书签
   - Firefox: 书签 → 显示所有书签 → 导入和备份 → 导出书签至HTML

2. **使用后台导入功能**
   - 登录管理后台
   - 进入"导入"功能
   - 选择HTML文件上传
   - 选择目标分类
   - 确认导入

3. **JSON格式导入**
```json
[
    {
        "title": "GitHub",
        "url": "https://github.com",
        "category": "开发工具",
        "description": "代码托管平台"
    }
]
```

4. **CSV格式导入**
```csv
标题,URL,分类,描述
GitHub,https://github.com,开发工具,代码托管平台
Google,https://google.com,搜索引擎,搜索引擎
```
</details>

<details>
<summary><strong>Q: 搜索功能不准确怎么办？</strong></summary>

**A:** 搜索优化建议：

1. **重建搜索索引**
```sql
-- 为搜索字段添加全文索引
ALTER TABLE on_links ADD FULLTEXT(title, note);
ALTER TABLE on_categorys ADD FULLTEXT(name, description);
```

2. **优化搜索查询**
```php
// 使用MATCH AGAINST全文搜索
$sql = "SELECT * FROM on_links 
        WHERE MATCH(title, note) AGAINST(? IN NATURAL LANGUAGE MODE)
        OR title LIKE ? OR note LIKE ?";
```

3. **配置搜索权重**
- 标题匹配：权重最高
- 描述匹配：权重中等  
- URL匹配：权重最低

4. **启用智能提示**
```javascript
// 实现搜索建议
$('#search-input').on('input', debounce(function() {
    const query = $(this).val();
    if (query.length > 1) {
        $.get('/api/search/suggestions?q=' + query, function(data) {
            // 显示搜索建议
        });
    }
}, 300));
```
</details>

<details>
<summary><strong>Q: 如何自定义主题？</strong></summary>

**A:** 主题开发步骤：

1. **创建主题目录**
```bash
mkdir public/themes/mytheme
cd public/themes/mytheme
```

2. **创建必需文件**
```bash
# 主要文件
touch index.php      # 主模板
touch style.css      # 样式文件
touch theme.json     # 主题配置
touch screenshot.jpg # 预览图
```

3. **编辑theme.json**
```json
{
    "name": "我的主题",
    "version": "1.0.0",
    "description": "自定义主题",
    "author": "Your Name",
    "config": {
        "show_search": true,
        "show_sidebar": true
    }
}
```

4. **参考现有主题**
复制 `default` 主题作为起点，然后修改样式和布局。

详细教程请参考：[主题开发指南](THEME_DEVELOPMENT.md)
</details>

---

## ⚡ 性能问题

<details>
<summary><strong>Q: 网站打开速度慢怎么优化？</strong></summary>

**A:** 性能优化方案：

1. **启用PHP OPcache**
```ini
; php.ini
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=4000
opcache.revalidate_freq=60
```

2. **数据库优化**
```sql
-- 添加索引
CREATE INDEX idx_links_category ON on_links(fid);
CREATE INDEX idx_links_click ON on_links(click);
CREATE INDEX idx_category_weight ON on_categorys(weight);

-- 分析和优化表
ANALYZE TABLE on_links;
OPTIMIZE TABLE on_links;
```

3. **启用压缩**
```apache
# Apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/javascript
</IfModule>
```

4. **缓存配置**
```apache
# 静态文件缓存
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
</IfModule>
```

5. **使用CDN**
```html
<!-- 使用CDN加速静态资源 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/yourusername/linkhub@main/public/assets/css/app.css">
```
</details>

<details>
<summary><strong>Q: 数据量大时如何优化？</strong></summary>

**A:** 大数据量优化：

1. **分页优化**
```php
// 使用LIMIT和OFFSET
$sql = "SELECT * FROM on_links ORDER BY id DESC LIMIT ?, ?";
$stmt->execute([$offset, $limit]);
```

2. **索引优化**
```sql
-- 复合索引
CREATE INDEX idx_links_category_weight ON on_links(fid, weight);
CREATE INDEX idx_links_status_time ON on_links(property, add_time);
```

3. **查询缓存**
```php
// 简单的查询缓存
function getCachedResult($key, $query, $ttl = 300) {
    $cacheFile = "cache/{$key}.json";
    
    if (file_exists($cacheFile) && time() - filemtime($cacheFile) < $ttl) {
        return json_decode(file_get_contents($cacheFile), true);
    }
    
    $result = executeQuery($query);
    file_put_contents($cacheFile, json_encode($result));
    
    return $result;
}
```

4. **数据归档**
```sql
-- 定期清理老数据
DELETE FROM on_clicks WHERE click_time < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 YEAR));
```
</details>

<details>
<summary><strong>Q: 并发访问量大时如何处理？</strong></summary>

**A:** 高并发优化：

1. **连接池配置**
```ini
; PHP-FPM配置
pm.max_children = 50
pm.start_servers = 5
pm.min_spare_servers = 5
pm.max_spare_servers = 35
```

2. **MySQL优化**
```ini
# my.cnf
max_connections = 200
innodb_buffer_pool_size = 1G
innodb_log_file_size = 256M
query_cache_size = 128M
```

3. **负载均衡**
```nginx
upstream linkhub {
    server 127.0.0.1:8001;
    server 127.0.0.1:8002;
    server 127.0.0.1:8003;
}

server {
    location / {
        proxy_pass http://linkhub;
    }
}
```

4. **Redis缓存**
```php
// 使用Redis缓存热点数据
$redis = new Redis();
$redis->connect('127.0.0.1', 6379);

function getHotLinks() {
    global $redis;
    
    $cacheKey = 'hot_links';
    $result = $redis->get($cacheKey);
    
    if (!$result) {
        // 从数据库查询
        $result = queryDatabase();
        $redis->setex($cacheKey, 300, serialize($result));
    } else {
        $result = unserialize($result);
    }
    
    return $result;
}
```
</details>

---

## 💻 开发问题

<details>
<summary><strong>Q: 如何开发自定义插件？</strong></summary>

**A:** 插件开发指南：

1. **创建插件目录**
```bash
mkdir plugins/myplugin
cd plugins/myplugin
```

2. **创建插件主文件**
```php
<?php
// plugins/myplugin/plugin.php
class MyPlugin {
    public function __construct() {
        add_action('init', [$this, 'init']);
    }
    
    public function init() {
        // 插件初始化代码
    }
    
    public function activate() {
        // 插件激活时执行
    }
    
    public function deactivate() {
        // 插件停用时执行
    }
}

new MyPlugin();
```

3. **插件配置文件**
```json
{
    "name": "My Plugin",
    "version": "1.0.0",
    "description": "插件描述",
    "author": "Your Name",
    "requires": "2.0.0",
    "main": "plugin.php"
}
```

4. **钩子系统**
```php
// 添加钩子
add_action('link_created', function($linkId) {
    // 链接创建后的处理
});

add_filter('search_results', function($results, $query) {
    // 修改搜索结果
    return $results;
});
```
</details>

<details>
<summary><strong>Q: 如何调试API接口？</strong></summary>

**A:** API调试方法：

1. **启用调试模式**
```env
APP_DEBUG=true
APP_ENV=local
```

2. **使用Postman测试**
```json
// POST /api/links
{
    "title": "测试链接",
    "url": "https://example.com",
    "category_id": 1
}
```

3. **查看日志**
```bash
tail -f storage/logs/api.log
```

4. **使用curl测试**
```bash
# 获取分类列表
curl -X GET "http://localhost/api/categories" -H "Content-Type: application/json"

# 创建链接
curl -X POST "http://localhost/api/links" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test","url":"https://test.com","category_id":1}'
```

5. **错误处理**
```php
try {
    // API逻辑
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    return json_response(['error' => $e->getMessage()], 500);
}
```
</details>

<details>
<summary><strong>Q: 如何贡献代码？</strong></summary>

**A:** 代码贡献流程：

1. **Fork项目**
   - 访问GitHub项目页面
   - 点击"Fork"按钮

2. **克隆到本地**
```bash
git clone https://github.com/yourusername/linkhub.git
cd linkhub
git remote add upstream https://github.com/original/linkhub.git
```

3. **创建功能分支**
```bash
git checkout -b feature/my-new-feature
```

4. **开发和测试**
```bash
# 编写代码
# 运行测试
composer test

# 代码规范检查
composer cs-check
```

5. **提交代码**
```bash
git add .
git commit -m "feat: add new feature"
git push origin feature/my-new-feature
```

6. **创建Pull Request**
   - 在GitHub上创建PR
   - 填写详细的描述
   - 等待代码审查

详细指南请参考：[贡献指南](CONTRIBUTING.md)
</details>

<details>
<summary><strong>Q: 如何进行单元测试？</strong></summary>

**A:** 测试开发指南：

1. **安装PHPUnit**
```bash
composer require --dev phpunit/phpunit
```

2. **编写测试**
```php
<?php
// tests/Unit/CategoryTest.php
use PHPUnit\Framework\TestCase;

class CategoryTest extends TestCase {
    public function testCreateCategory() {
        $category = new Category();
        $category->name = 'Test Category';
        
        $this->assertEquals('Test Category', $category->name);
    }
    
    public function testCategoryValidation() {
        $category = new Category();
        
        $this->expectException(ValidationException::class);
        $category->save(); // 缺少必需字段
    }
}
```

3. **运行测试**
```bash
./vendor/bin/phpunit tests/
```

4. **测试覆盖率**
```bash
./vendor/bin/phpunit --coverage-html coverage/
```
</details>

---

## 🔒 安全问题

<details>
<summary><strong>Q: 如何加强系统安全？</strong></summary>

**A:** 安全防护措施：

1. **文件权限设置**
```bash
# 设置适当的文件权限
find /path/to/linkhub -type f -exec chmod 644 {} \;
find /path/to/linkhub -type d -exec chmod 755 {} \;
chmod 600 .env
```

2. **隐藏敏感文件**
```apache
# .htaccess
<Files ".env">
    Require all denied
</Files>

<Files "composer.json">
    Require all denied
</Files>
```

3. **SQL注入防护**
```php
// 使用预处理语句
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
```

4. **XSS防护**
```php
// 输出时转义
echo htmlspecialchars($userInput, ENT_QUOTES, 'UTF-8');
```

5. **CSRF防护**
```php
// 生成CSRF Token
session_start();
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 验证Token
if ($_SESSION['csrf_token'] !== $_POST['csrf_token']) {
    die('CSRF Token验证失败');
}
```
</details>

---

## 📞 获取更多帮助

如果以上内容没有解决您的问题，您可以：

### 🔍 搜索资源
- 📚 [完整文档](https://docs.linkhub.com)
- 🎥 [视频教程](https://www.youtube.com/playlist?list=xxx)
- 💡 [使用技巧](https://tips.linkhub.com)

### 💬 社区支持
- 🗣️ [社区论坛](https://community.linkhub.com)
- 💬 [QQ群](123456789)
- 📱 [微信群](扫码加入)

### 🐛 反馈问题
- 🐛 [GitHub Issues](https://github.com/yourusername/linkhub/issues)
- 📧 [邮件支持](mailto:support@linkhub.com)

### 🏢 商业支持
- 💼 [企业服务](https://enterprise.linkhub.com)
- 📞 [技术咨询](400-xxx-xxxx)

---

<div align="center">

**[⬆ 回到顶部](#-linkhub-常见问题)**

---

<sub>最后更新：2025年9月5日 | 如有遗漏或错误，欢迎反馈</sub>

</div>
