# 📋 LinkHub 项目概览

<div align="center">

![LinkHub Banner](https://img.shields.io/badge/LinkHub-项目概览-blue?style=for-the-badge&logo=bookmark&logoColor=white)

**现代化网址导航系统 - 技术架构与功能详解**

[![Version](https://img.shields.io/badge/Version-2.0.0-blue?style=flat-square)](https://github.com/yourusername/linkhub)
[![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)
[![PHP](https://img.shields.io/badge/PHP-7.4+-777BB4?style=flat-square)](https://php.net)
[![MySQL](https://img.shields.io/badge/MySQL-5.7+-4479A1?style=flat-square)](https://mysql.com)

[项目特性](#项目特性) · [技术架构](#技术架构) · [系统要求](#系统要求) · [常见问题](#常见问题)

</div>

---

## 🚀 项目简介

LinkHub 是一款**现代化的网址导航和书签管理系统**，专为个人和团队打造。采用 PHP 开发，具有简洁的界面、丰富的功能和优秀的性能表现。

### 设计理念

- **🎯 用户至上** - 简洁直观的用户体验
- **⚡ 性能优先** - 快速响应，轻量级设计
- **🛠️ 易于部署** - 一键安装，开箱即用
- **🔧 高度可定制** - 丰富的主题和配置选项
- **📱 响应式设计** - 完美适配各种设备

---

## ✨ 项目特性

### 🎨 现代化界面
- **精美主题系统** - 内置多款专业设计的主题
- **响应式布局** - 完美适配桌面端、平板和手机
- **Material Design** - 遵循现代设计规范
- **深色模式** - 支持明暗主题切换
- **动画效果** - 平滑的交互动画

### 🗂️ 强大的管理功能
- **分类管理** - 无限层级分类，拖拽排序
- **链接管理** - 批量操作，智能识别
- **图标系统** - 自动获取网站图标，支持自定义
- **批量导入** - 支持从浏览器书签批量导入
- **数据备份** - 自动备份和数据导出

### 🔍 智能搜索
- **全文搜索** - 搜索标题、描述、URL
- **搜索建议** - 实时搜索建议和自动补全
- **热门排行** - 基于点击量的智能推荐
- **快捷键** - 支持键盘快捷操作

### 📊 数据统计
- **访问统计** - 详细的点击统计和分析
- **趋势分析** - 图表展示访问趋势
- **热门排行** - 最受欢迎的链接和分类
- **数据导出** - 支持导出统计报告

### 🔌 API接口
- **RESTful API** - 完整的API接口
- **标准化响应** - 统一的JSON响应格式
- **丰富的端点** - 分类、链接、搜索、统计
- **开发友好** - 详细的API文档

### 🎯 高级特性
- **多用户支持** - 用户权限管理
- **主题开发** - 完整的主题开发框架
- **插件系统** - 可扩展的插件架构
- **SEO优化** - 搜索引擎友好
- **缓存机制** - 多级缓存提升性能

---

## 🏗️ 技术架构

### 整体架构

```
┌─────────────────────────────────────────────┐
│                   前端层                     │
│  ┌─────────────┐ ┌─────────────┐ ┌────────┐  │
│  │   主题系统   │ │   静态资源   │ │  API   │  │
│  │ (PHP/HTML)  │ │ (CSS/JS)   │ │(RESTful)│  │
│  └─────────────┘ └─────────────┘ └────────┘  │
└─────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────┐
│                   应用层                     │
│  ┌─────────────┐ ┌─────────────┐ ┌────────┐  │
│  │   控制器     │ │   服务层     │ │  模型   │  │
│  │(Controller) │ │ (Service)   │ │(Model) │  │
│  └─────────────┘ └─────────────┘ └────────┘  │
└─────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────┐
│                   数据层                     │
│  ┌─────────────┐ ┌─────────────┐ ┌────────┐  │
│  │    MySQL    │ │   文件系统   │ │  缓存   │  │
│  │  (主数据)   │ │  (上传文件)  │ │(Cache) │  │
│  └─────────────┘ └─────────────┘ └────────┘  │
└─────────────────────────────────────────────┘
```

### 核心组件

#### 🔧 后端架构
```php
src/
├── Controllers/        # 控制器层
│   ├── Api/           # API控制器
│   ├── Admin/         # 后台控制器
│   └── Auth/          # 认证控制器
├── Models/            # 数据模型层
│   ├── Category.php   # 分类模型
│   ├── Link.php       # 链接模型
│   └── User.php       # 用户模型
├── Services/          # 业务逻辑层
│   ├── CategoryService.php
│   ├── LinkService.php
│   └── AuthService.php
├── Core/              # 核心组件
│   ├── Http/         # HTTP处理
│   ├── Routing/      # 路由系统
│   └── Container/    # 依赖注入
└── Repositories/      # 数据访问层
    ├── CategoryRepository.php
    └── LinkRepository.php
```

#### 🎨 前端架构
```
public/
├── themes/            # 主题系统
│   ├── default/      # 默认主题
│   ├── markhak/      # MarkHak主题
│   └── xinghe/       # 星河主题
├── assets/           # 静态资源
│   ├── css/         # 样式文件
│   ├── js/          # 脚本文件
│   └── images/      # 图片资源
└── admin/           # 后台管理
    ├── index.php    # 管理首页
    ├── categories.php
    └── links.php
```

### 数据库设计

#### 核心表结构

```sql
-- 分类表
CREATE TABLE `on_categorys` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(50) NOT NULL COMMENT '分类名称',
    `font_icon` varchar(50) DEFAULT 'fa-folder' COMMENT '图标',
    `icon_color` varchar(10) DEFAULT '#6366f1' COMMENT '图标颜色',
    `description` varchar(200) DEFAULT '' COMMENT '描述',
    `weight` int(11) DEFAULT 100 COMMENT '排序权重',
    `property` tinyint(1) DEFAULT 0 COMMENT '状态(0正常1删除)',
    `add_time` int(11) NOT NULL COMMENT '添加时间',
    PRIMARY KEY (`id`),
    KEY `idx_weight` (`weight`),
    KEY `idx_property` (`property`)
);

-- 链接表
CREATE TABLE `on_links` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `fid` int(11) NOT NULL COMMENT '分类ID',
    `title` varchar(100) NOT NULL COMMENT '链接标题',
    `url` varchar(500) NOT NULL COMMENT '链接地址',
    `note` varchar(300) DEFAULT '' COMMENT '描述',
    `font_icon` varchar(50) DEFAULT 'fa-link' COMMENT '图标',
    `icon_color` varchar(10) DEFAULT '#6b7280' COMMENT '图标颜色',
    `click` int(11) DEFAULT 0 COMMENT '点击次数',
    `weight` int(11) DEFAULT 100 COMMENT '排序权重',
    `property` tinyint(1) DEFAULT 0 COMMENT '状态',
    `add_time` int(11) NOT NULL COMMENT '添加时间',
    PRIMARY KEY (`id`),
    KEY `idx_fid` (`fid`),
    KEY `idx_click` (`click`),
    KEY `idx_weight` (`weight`),
    KEY `idx_property` (`property`)
);

-- 点击统计表
CREATE TABLE `on_clicks` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `link_id` int(11) NOT NULL COMMENT '链接ID',
    `ip` varchar(45) DEFAULT '' COMMENT 'IP地址',
    `user_agent` varchar(500) DEFAULT '' COMMENT '用户代理',
    `referer` varchar(500) DEFAULT '' COMMENT '来源页面',
    `click_time` int(11) NOT NULL COMMENT '点击时间',
    PRIMARY KEY (`id`),
    KEY `idx_link_id` (`link_id`),
    KEY `idx_click_time` (`click_time`)
);
```

### 性能优化

#### 🚀 前端优化
- **资源压缩** - CSS/JS文件压缩
- **图片优化** - WebP格式，懒加载
- **缓存策略** - 浏览器缓存，CDN加速
- **代码分割** - 按需加载脚本

#### ⚡ 后端优化
- **数据库索引** - 关键字段建立索引
- **查询优化** - SQL语句优化
- **缓存机制** - 数据缓存，查询缓存
- **连接池** - 数据库连接池

#### 📊 监控指标
- **响应时间** - API响应时间监控
- **数据库性能** - 慢查询日志
- **服务器负载** - CPU、内存监控
- **错误跟踪** - 异常日志收集

---

## 💻 系统要求

### 最低要求

| 组件 | 版本要求 | 说明 |
|------|----------|------|
| **PHP** | 7.4+ | 推荐 PHP 8.0+ |
| **MySQL** | 5.7+ | 或 MariaDB 10.3+ |
| **Web服务器** | Apache 2.4+ / Nginx 1.18+ | 支持URL重写 |
| **内存** | 128MB+ | 推荐 256MB+ |
| **磁盘空间** | 50MB+ | 不包含用户数据 |

### 推荐配置

| 组件 | 推荐配置 | 说明 |
|------|----------|------|
| **操作系统** | Linux (Ubuntu 20.04+) | 生产环境推荐 |
| **PHP** | 8.1+ | 最佳性能 |
| **MySQL** | 8.0+ | 支持更多特性 |
| **内存** | 512MB+ | 支持更多并发 |
| **SSD存储** | 建议 | 提升读写性能 |

### PHP扩展要求

```bash
# 必需扩展
php-pdo          # 数据库连接
php-pdo-mysql    # MySQL支持
php-json         # JSON处理
php-mbstring     # 多字节字符串
php-curl         # HTTP请求
php-openssl      # 加密支持
php-gd           # 图片处理
php-zip          # 压缩支持

# 可选扩展
php-redis        # Redis缓存
php-memcached    # Memcached缓存
php-opcache      # 操作码缓存
```

### 环境配置示例

#### Apache配置
```apache
<VirtualHost *:80>
    ServerName linkhub.example.com
    DocumentRoot /var/www/linkhub/public
    
    <Directory /var/www/linkhub/public>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
        
        # URL重写规则
        RewriteEngine On
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule ^(.*)$ index.php [QSA,L]
    </Directory>
    
    # 安全配置
    <Files ".env">
        Require all denied
    </Files>
</VirtualHost>
```

#### Nginx配置
```nginx
server {
    listen 80;
    server_name linkhub.example.com;
    root /var/www/linkhub/public;
    index index.php index.html;
    
    # URL重写
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    # PHP处理
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
    
    # 安全配置
    location ~ /\.env {
        deny all;
    }
    
    location ~ /storage {
        deny all;
    }
    
    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

---

## 🔧 安装部署

### 自动安装（推荐）

1. **下载源码**
```bash
wget https://github.com/yourusername/linkhub/releases/latest/download/linkhub.zip
unzip linkhub.zip -d /var/www/html/
cd /var/www/html/linkhub
```

2. **设置权限**
```bash
chmod -R 755 storage/
chmod -R 755 public/cache/
chown -R www-data:www-data .
```

3. **访问安装程序**
浏览器访问：`http://yourdomain.com/install.php`

### 手动安装

1. **创建数据库**
```sql
CREATE DATABASE linkhub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'linkhub'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON linkhub.* TO 'linkhub'@'localhost';
```

2. **配置环境**
```bash
cp .env.example .env
# 编辑.env文件设置数据库连接
```

3. **导入数据结构**
```bash
mysql -u linkhub -p linkhub < database/mysql.sql
```

### Docker部署

```dockerfile
# Dockerfile
FROM php:8.1-apache

# 安装PHP扩展
RUN docker-php-ext-install pdo pdo_mysql mysqli gd

# 复制源码
COPY . /var/www/html/
RUN chown -R www-data:www-data /var/www/html/

# Apache配置
RUN a2enmod rewrite
EXPOSE 80
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "8080:80"
    volumes:
      - ./storage:/var/www/html/storage
    environment:
      - DB_HOST=mysql
      - DB_DATABASE=linkhub
      - DB_USERNAME=linkhub
      - DB_PASSWORD=password
    depends_on:
      - mysql
  
  mysql:
    image: mysql:8.0
    environment:
      - MYSQL_DATABASE=linkhub
      - MYSQL_USER=linkhub
      - MYSQL_PASSWORD=password
      - MYSQL_ROOT_PASSWORD=rootpassword
    volumes:
      - mysql_data:/var/lib/mysql

volumes:
  mysql_data:
```

---

## 🛠️ 开发指南

### 本地开发环境

1. **克隆项目**
```bash
git clone https://github.com/yourusername/linkhub.git
cd linkhub
```

2. **安装依赖**
```bash
composer install --dev
npm install  # 如果需要前端构建
```

3. **环境配置**
```bash
cp .env.example .env
# 编辑.env设置本地数据库配置
```

4. **启动开发服务器**
```bash
php -S localhost:8000 -t public
```

### 代码规范

- **PSR-12** - PHP代码规范
- **语义化版本** - 遵循SemVer规范
- **Git Flow** - 分支管理策略
- **单元测试** - 核心功能测试覆盖

### 目录结构说明

```
linkhub/
├── config/              # 配置文件
├── database/           # 数据库文件
├── docs/               # 文档目录
├── public/             # Web根目录
├── resources/          # 资源文件
├── src/                # 核心代码
├── storage/            # 存储目录
├── tests/              # 测试文件
└── vendor/             # Composer依赖
```

---

## 🤝 参与贡献

我们欢迎各种形式的贡献！

### 贡献方式

1. **问题反馈** - 报告Bug和提出建议
2. **代码贡献** - 提交Pull Request
3. **文档完善** - 改进项目文档
4. **主题开发** - 创建新主题
5. **插件开发** - 扩展功能插件

### 开发流程

1. Fork项目到个人账户
2. 创建功能分支
3. 提交代码改动
4. 创建Pull Request
5. 代码审查和合并

---

## 📞 技术支持

### 获取帮助

- 📧 **邮件支持**: support@linkhub.com
- 💬 **社区论坛**: https://community.linkhub.com
- 🐛 **问题反馈**: https://github.com/yourusername/linkhub/issues
- 📚 **完整文档**: https://docs.linkhub.com

### 商业支持

- 🏢 **企业定制**: 提供定制开发服务
- 🎓 **技术培训**: 团队培训和技术指导
- 🛡️ **安全审计**: 安全评估和加固服务
- 📈 **性能优化**: 性能调优和架构优化

---

<div align="center">

**[⬆ 回到顶部](#-linkhub-项目概览)**

---

<sub>Copyright © 2025 LinkHub Team | 用心构建每一行代码</sub>

</div>
