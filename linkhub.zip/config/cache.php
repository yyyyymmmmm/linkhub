<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 缓存配置
    |--------------------------------------------------------------------------
    */
    
    'default' => env('CACHE_DRIVER', 'file'),
    
    'stores' => [
        'array' => [
            'driver' => 'array',
        ],
        
        'file' => [
            'driver' => 'file',
            'path' => storage_path('cache/data'),
        ],
        
        'apc' => [
            'driver' => 'apc',
        ],
        
        'memcached' => [
            'driver' => 'memcached',
            'servers' => [
                [
                    'host' => env('MEMCACHED_HOST', '127.0.0.1'),
                    'port' => env('MEMCACHED_PORT', 11211),
                    'weight' => 100,
                ],
            ],
        ],
        
        'redis' => [
            'driver' => 'redis',
            'connection' => 'cache',
        ],
    ],
    
    'prefix' => env('CACHE_PREFIX', 'onenav_'),
    
    'ttl' => env('CACHE_TTL', 3600),
    
    'serialize' => false,
    
    'tags_enabled' => true,
];


