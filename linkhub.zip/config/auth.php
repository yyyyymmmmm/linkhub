<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 认证配置
    |--------------------------------------------------------------------------
    */
    
    'defaults' => [
        'guard' => 'web',
    ],
    
    'guards' => [
        'web' => [
            'driver' => 'session',
            'provider' => 'users',
        ],
        
        'api' => [
            'driver' => 'token',
            'provider' => 'users',
            'hash' => false,
        ],
    ],
    
    'providers' => [
        'users' => [
            'driver' => 'database',
            'table' => 'on_users',
        ],
    ],
    
    'passwords' => [
        'users' => [
            'provider' => 'users',
            'table' => 'on_password_resets',
            'expire' => 60, // minutes
            'throttle' => 60, // seconds
        ],
    ],
    
    'security' => [
        'password_hash_algo' => PASSWORD_ARGON2ID,
        'password_hash_options' => [
            'memory_cost' => 65536, // 64 MB
            'time_cost' => 4,       // 4 iterations
            'threads' => 3,         // 3 threads
        ],
        'session_lifetime' => env('SESSION_LIFETIME', 120),
        'max_login_attempts' => env('MAX_LOGIN_ATTEMPTS', 5),
        'lockout_time' => env('LOCKOUT_TIME', 900), // 15 minutes
    ],
    
    'jwt' => [
        'secret' => env('JWT_SECRET', ''),
        'ttl' => env('JWT_TTL', 60), // minutes
        'refresh_ttl' => env('JWT_REFRESH_TTL', 20160), // minutes
        'algo' => 'HS256',
        'blacklist_enabled' => true,
        'blacklist_grace_period' => 30, // seconds
    ],
];


