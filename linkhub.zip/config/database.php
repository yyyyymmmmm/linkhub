<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 默认数据库连接
    |--------------------------------------------------------------------------
    */
    
    'default' => env('DB_CONNECTION', 'mysql'),
    
    /*
    |--------------------------------------------------------------------------
    | 数据库连接配置
    |--------------------------------------------------------------------------
    */
    
    'connections' => [
        'sqlite' => [
            'driver' => 'sqlite',
            'url' => env('DATABASE_URL'),
            'database' => env('DB_SQLITE_PATH', base_path('storage/database/onenav.sqlite')),
            'prefix' => '',
            'foreign_key_constraints' => env('DB_FOREIGN_KEYS', true),
        ],
        
        'mysql' => [
            'driver' => 'mysql',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => env('DB_DATABASE', 'onenav'),
            'username' => env('DB_USERNAME', 'root'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => env('DB_PREFIX', 'on_'),
            'prefix_indexes' => true,
            'strict' => true,
            'engine' => null,
            'options' => extension_loaded('pdo_mysql') ? array_filter([
                PDO::MYSQL_ATTR_SSL_CA => env('MYSQL_ATTR_SSL_CA'),
            ]) : [],
        ],
        
        'pgsql' => [
            'driver' => 'pgsql',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '5432'),
            'database' => env('DB_DATABASE', 'onenav'),
            'username' => env('DB_USERNAME', 'postgres'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8',
            'prefix' => env('DB_PREFIX', 'on_'),
            'prefix_indexes' => true,
            'schema' => 'public',
            'sslmode' => 'prefer',
        ],
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 读写分离配置
    |--------------------------------------------------------------------------
    */
    
    'read_write_split' => [
        'mysql_cluster' => [
            'driver' => 'mysql',
            'read' => [
                'host' => env('DB_READ_HOST', env('DB_HOST', '127.0.0.1')),
                'port' => env('DB_READ_PORT', env('DB_PORT', '3306')),
                'database' => env('DB_DATABASE', 'onenav'),
                'username' => env('DB_READ_USERNAME', env('DB_USERNAME', 'root')),
                'password' => env('DB_READ_PASSWORD', env('DB_PASSWORD', '')),
            ],
            'write' => [
                'host' => env('DB_WRITE_HOST', env('DB_HOST', '127.0.0.1')),
                'port' => env('DB_WRITE_PORT', env('DB_PORT', '3306')),
                'database' => env('DB_DATABASE', 'onenav'),
                'username' => env('DB_WRITE_USERNAME', env('DB_USERNAME', 'root')),
                'password' => env('DB_WRITE_PASSWORD', env('DB_PASSWORD', '')),
            ],
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => env('DB_PREFIX', 'on_'),
            'sticky' => true,
        ],
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 迁移存储表
    |--------------------------------------------------------------------------
    */
    
    'migrations' => 'migrations',
    
    /*
    |--------------------------------------------------------------------------
    | 查询日志配置
    |--------------------------------------------------------------------------
    */
    
    'query_log' => [
        'enabled' => env('DB_QUERY_LOG', false),
        'slow_query_threshold' => env('DB_SLOW_QUERY_THRESHOLD', 1000), // milliseconds
        'max_log_entries' => env('DB_MAX_LOG_ENTRIES', 1000),
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 连接池配置
    |--------------------------------------------------------------------------
    */
    
    'pool' => [
        'enabled' => env('DB_POOL_ENABLED', false),
        'max_connections' => env('DB_POOL_MAX_CONNECTIONS', 10),
        'min_connections' => env('DB_POOL_MIN_CONNECTIONS', 1),
        'max_idle_time' => env('DB_POOL_MAX_IDLE_TIME', 60), // seconds
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 数据库事务配置
    |--------------------------------------------------------------------------
    */
    
    'transactions' => [
        'default_isolation_level' => 'READ_COMMITTED',
        'max_retry_attempts' => 3,
        'retry_delay' => 100, // milliseconds
    ],
];


