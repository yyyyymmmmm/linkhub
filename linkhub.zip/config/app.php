<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 应用配置
    |--------------------------------------------------------------------------
    */
    
    'name' => env('APP_NAME', 'LinkHub Professional'),
    
    'env' => env('APP_ENV', 'production'),
    
    'debug' => env('APP_DEBUG', false),
    
    'url' => env('APP_URL', 'http://localhost'),
    
    'asset_url' => env('ASSET_URL', null),
    
    'timezone' => env('APP_TIMEZONE', 'UTC'),
    
    'locale' => 'zh_CN',
    
    'fallback_locale' => 'en',
    
    'faker_locale' => 'zh_CN',
    
    'key' => env('APP_KEY'),
    
    'cipher' => 'AES-256-CBC',
    
    /*
    |--------------------------------------------------------------------------
    | 服务提供者
    |--------------------------------------------------------------------------
    */
    
    'providers' => [
        // 核心服务提供者
        OneNav\Providers\ConfigServiceProvider::class,
        OneNav\Providers\DatabaseServiceProvider::class,
        OneNav\Providers\CacheServiceProvider::class,
        OneNav\Providers\LoggingServiceProvider::class,
        OneNav\Providers\ViewServiceProvider::class,
        OneNav\Providers\AuthServiceProvider::class,
        OneNav\Providers\RouteServiceProvider::class,
        OneNav\Providers\ValidationServiceProvider::class,
        OneNav\Providers\FilesystemServiceProvider::class,
        
        // 应用服务提供者
        OneNav\Providers\AppServiceProvider::class,
        OneNav\Providers\EventServiceProvider::class,
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 中间件组
    |--------------------------------------------------------------------------
    */
    
    'middleware_groups' => [
        'web' => [
            OneNav\Http\Middleware\EncryptCookies::class,
            OneNav\Http\Middleware\StartSession::class,
            OneNav\Http\Middleware\VerifyCsrfToken::class,
            OneNav\Http\Middleware\SubstituteBindings::class,
        ],
        
        'api' => [
            OneNav\Http\Middleware\ThrottleRequests::class,
            OneNav\Http\Middleware\SubstituteBindings::class,
        ],
        
        'admin' => [
            OneNav\Http\Middleware\Authenticate::class,
            OneNav\Http\Middleware\CheckAdminRole::class,
        ],
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 路由中间件
    |--------------------------------------------------------------------------
    */
    
    'route_middleware' => [
        'auth' => OneNav\Http\Middleware\Authenticate::class,
        'auth.basic' => OneNav\Http\Middleware\AuthenticateWithBasicAuth::class,
        'guest' => OneNav\Http\Middleware\RedirectIfAuthenticated::class,
        'throttle' => OneNav\Http\Middleware\ThrottleRequests::class,
        'verified' => OneNav\Http\Middleware\EnsureEmailIsVerified::class,
        'admin' => OneNav\Http\Middleware\CheckAdminRole::class,
        'can' => OneNav\Http\Middleware\Authorize::class,
        'cors' => OneNav\Http\Middleware\HandleCors::class,
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 别名
    |--------------------------------------------------------------------------
    */
    
    'aliases' => [
        'App' => OneNav\Support\Facades\App::class,
        'Auth' => OneNav\Support\Facades\Auth::class,
        'Cache' => OneNav\Support\Facades\Cache::class,
        'Config' => OneNav\Support\Facades\Config::class,
        'DB' => OneNav\Support\Facades\DB::class,
        'Event' => OneNav\Support\Facades\Event::class,
        'File' => OneNav\Support\Facades\File::class,
        'Log' => OneNav\Support\Facades\Log::class,
        'Request' => OneNav\Support\Facades\Request::class,
        'Response' => OneNav\Support\Facades\Response::class,
        'Route' => OneNav\Support\Facades\Route::class,
        'Session' => OneNav\Support\Facades\Session::class,
        'Storage' => OneNav\Support\Facades\Storage::class,
        'URL' => OneNav\Support\Facades\URL::class,
        'Validator' => OneNav\Support\Facades\Validator::class,
        'View' => OneNav\Support\Facades\View::class,
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 性能优化配置
    |--------------------------------------------------------------------------
    */
    
    'performance' => [
        'enable_opcache' => env('ENABLE_OPCACHE', true),
        'enable_query_cache' => env('ENABLE_QUERY_CACHE', true),
        'enable_view_cache' => env('ENABLE_VIEW_CACHE', true),
        'enable_route_cache' => env('ENABLE_ROUTE_CACHE', false),
        'enable_config_cache' => env('ENABLE_CONFIG_CACHE', false),
    ],
    
    /*
    |--------------------------------------------------------------------------
    | 安全配置
    |--------------------------------------------------------------------------
    */
    
    'security' => [
        'password_hash_algo' => PASSWORD_ARGON2ID,
        'password_hash_options' => [
            'memory_cost' => 65536, // 64 MB
            'time_cost' => 4,       // 4 iterations
            'threads' => 3,         // 3 threads
        ],
        'session_lifetime' => env('SESSION_LIFETIME', 120),
        'csrf_protection' => true,
        'xss_protection' => true,
        'content_type_sniffing' => false,
        'frame_options' => 'DENY',
        'content_security_policy' => [
            'default-src' => "'self'",
            'script-src' => "'self' 'unsafe-inline' 'unsafe-eval'",
            'style-src' => "'self' 'unsafe-inline'",
            'img-src' => "'self' data: https:",
            'font-src' => "'self' data:",
        ],
    ],
];


