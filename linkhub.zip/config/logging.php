<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 日志配置
    |--------------------------------------------------------------------------
    */
    
    'default' => env('LOG_CHANNEL', 'daily'),
    
    'channels' => [
        'stack' => [
            'driver' => 'stack',
            'channels' => ['daily', 'slack'],
            'ignore_exceptions' => false,
        ],
        
        'single' => [
            'driver' => 'single',
            'path' => storage_path('logs/onenav.log'),
            'level' => env('LOG_LEVEL', 'debug'),
        ],
        
        'daily' => [
            'driver' => 'daily',
            'path' => storage_path('logs/onenav.log'),
            'level' => env('LOG_LEVEL', 'debug'),
            'days' => env('LOG_MAX_FILES', 7),
        ],
        
        'syslog' => [
            'driver' => 'syslog',
            'level' => env('LOG_LEVEL', 'debug'),
        ],
        
        'errorlog' => [
            'driver' => 'errorlog',
            'level' => env('LOG_LEVEL', 'debug'),
        ],
        
        'null' => [
            'driver' => 'null',
        ],
    ],
    
    'levels' => [
        'emergency' => 600,
        'alert'     => 550,
        'critical'  => 500,
        'error'     => 400,
        'warning'   => 300,
        'notice'    => 250,
        'info'      => 200,
        'debug'     => 100,
    ],
];


