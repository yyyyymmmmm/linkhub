<?php
/**
 * 简单的数据库连接配置
 * 用于过渡页等独立页面
 */

try {
    // 使用通用数据库连接
    require_once __DIR__ . '/database_connection.php';
    $pdo = getDatabaseConnection();
    $tablePrefix = getTablePrefix();
    
} catch (Exception $e) {
    // 如果连接失败，记录错误并使用默认值
    error_log("数据库连接失败: " . $e->getMessage());
    $pdo = null;
    $tablePrefix = 'on_';
}
?>
