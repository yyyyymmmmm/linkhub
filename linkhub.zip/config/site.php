<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 站点配置
    |--------------------------------------------------------------------------
    */
    
    'title' => env('SITE_TITLE', 'OneNav Professional'),
    
    'subtitle' => env('SITE_SUBTITLE', '专业级导航系统'),
    
    'description' => env('SITE_DESCRIPTION', '一款开源的专业级书签管理和导航系统'),
    
    'keywords' => env('SITE_KEYWORDS', 'OneNav,导航,书签管理,网址导航'),
    
    'logo' => env('SITE_LOGO', '/static/images/logo.png'),
    
    'favicon' => env('SITE_FAVICON', '/favicon.ico'),
    
    'beian' => env('SITE_BEIAN', ''),
    
    'custom_header' => env('SITE_CUSTOM_HEADER', ''),
    
    'custom_footer' => env('SITE_CUSTOM_FOOTER', ''),
    
    'link_model' => env('SITE_LINK_MODEL', 'direct'), // direct, transition, tracking
    
    'link_num' => env('SITE_LINK_NUM', 20),
    
    'new_window' => env('SITE_NEW_WINDOW', true),
    
    'sub_expand' => env('SITE_SUB_EXPAND', false),
    
    'admin' => [
        'sidebar_collapsed' => env('ADMIN_SIDEBAR_COLLAPSED', false),
        'pagination' => env('ADMIN_PAGINATION', 20),
    ],
    
    'analytics' => [
        'enabled' => env('ANALYTICS_ENABLED', false),
        'code' => env('ANALYTICS_CODE', ''),
    ],
    
    'theme' => [
        'default' => env('THEME_DEFAULT', 'default'),
        'admin' => env('THEME_ADMIN', 'admin'),
        'mobile' => env('THEME_MOBILE', 'default'),
    ],
    
    'api' => [
        'enable_url_exists_check' => env('API_URL_EXISTS_CHECK', true),
        'enable_custom_footer' => env('API_CUSTOM_FOOTER', true),
    ],
    
    'backup' => [
        'auto_backup' => env('BACKUP_AUTO', true),
        'backup_interval' => env('BACKUP_INTERVAL', 24), // hours
        'max_backups' => env('BACKUP_MAX', 30),
    ],
    
    'performance' => [
        'static_cache' => env('PERFORMANCE_STATIC_CACHE', true),
        'gzip_compression' => env('PERFORMANCE_GZIP', true),
        'lazy_loading' => env('PERFORMANCE_LAZY_LOADING', true),
    ],
];


