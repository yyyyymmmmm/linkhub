<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 视图配置
    |--------------------------------------------------------------------------
    */
    
    'paths' => [
        resource_path('views'),
    ],
    
    'compiled' => env('VIEW_COMPILED_PATH', storage_path('cache/views')),
    
    'engine' => 'twig',
    
    'engines' => [
        'twig' => [
            'extension' => 'twig',
            'debug' => env('APP_DEBUG', false),
            'cache' => env('VIEW_CACHE', true) ? storage_path('cache/views') : false,
            'auto_reload' => true,
            'strict_variables' => false,
            'autoescape' => 'html',
        ],
        
        'php' => [
            'extension' => 'php',
        ],
    ],
    
    'theme' => [
        'default' => env('THEME_DEFAULT', 'default'),
        'admin' => env('THEME_ADMIN', 'admin'),
        'mobile' => env('THEME_MOBILE', 'default'),
        'paths' => [
            base_path('templates'),
            base_path('data/templates'),
        ],
        'cache_enabled' => env('THEME_CACHE', true),
        'allowed_themes' => ['default', 'universal', 'sou', 'xinghe'],
    ],
];


