<?php

return [
    /*
    |--------------------------------------------------------------------------
    | 文件系统配置
    |--------------------------------------------------------------------------
    */
    
    'default' => env('FILESYSTEM_DRIVER', 'local'),
    
    'disks' => [
        'local' => [
            'driver' => 'local',
            'root' => storage_path('uploads'),
            'url' => env('APP_URL').'/uploads',
            'visibility' => 'public',
        ],
        
        'public' => [
            'driver' => 'local',
            'root' => public_path('uploads'),
            'url' => env('APP_URL').'/uploads',
            'visibility' => 'public',
        ],
        
        'backups' => [
            'driver' => 'local',
            'root' => storage_path('backups'),
        ],
        
        'icons' => [
            'driver' => 'local',
            'root' => storage_path('uploads/icons'),
            'url' => env('APP_URL').'/uploads/icons',
            'visibility' => 'public',
        ],
    ],
    
    'links' => [
        public_path('uploads') => storage_path('uploads'),
    ],
    
    'allowed_extensions' => env('ALLOWED_EXTENSIONS', 'jpg,jpeg,png,gif,svg,ico'),
    
    'max_file_size' => env('UPLOAD_MAX_SIZE', 10485760), // 10MB
    
    'image_optimization' => [
        'enabled' => env('IMAGE_OPTIMIZATION', true),
        'quality' => env('IMAGE_QUALITY', 80),
        'max_width' => env('IMAGE_MAX_WIDTH', 1920),
        'max_height' => env('IMAGE_MAX_HEIGHT', 1080),
    ],
];


