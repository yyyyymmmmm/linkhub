<?php
/**
 * 通用数据库连接配置
 * 支持MySQL和SQLite
 */

function getDatabaseConnection() {
    $basePath = dirname(__DIR__);
    $envFile = $basePath . '/.env';
    
    // 默认配置（SQLite）
    $dbConfig = [
        'type' => 'sqlite',
        'path' => $basePath . '/storage/database/database.sqlite'
    ];
    
    // 如果存在.env文件，读取配置
    if (file_exists($envFile)) {
        $envContent = file_get_contents($envFile);
        $envLines = explode("\n", $envContent);
        
        $config = [];
        foreach ($envLines as $line) {
            $line = trim($line);
            if (!empty($line) && strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $config[trim($key)] = trim($value);
            }
        }
        
        // 如果配置了MySQL
        if (isset($config['DB_CONNECTION']) && trim($config['DB_CONNECTION']) === 'mysql') {
            $dbConfig = [
                'type' => 'mysql',
                'host' => trim($config['DB_HOST'] ?? 'localhost'),
                'port' => trim($config['DB_PORT'] ?? '3306'),
                'dbname' => trim($config['DB_DATABASE'] ?? 'linkhub'),
                'username' => trim($config['DB_USERNAME'] ?? 'root'),
                'password' => trim($config['DB_PASSWORD'] ?? ''),
                'prefix' => trim($config['DB_PREFIX'] ?? 'on_')
            ];
        }
    }
    
    try {
        if ($dbConfig['type'] === 'mysql') {
            $dsn = "mysql:host={$dbConfig['host']};port={$dbConfig['port']};dbname={$dbConfig['dbname']};charset=utf8mb4";
            $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
        } else {
            // SQLite
            $pdo = new PDO("sqlite:{$dbConfig['path']}");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        }
        
        return $pdo;
    } catch (PDOException $e) {
        throw new Exception("数据库连接失败: " . $e->getMessage());
    }
}

// 获取表前缀
function getTablePrefix() {
    $basePath = dirname(__DIR__);
    $envFile = $basePath . '/.env';
    
    if (file_exists($envFile)) {
        $envContent = file_get_contents($envFile);
        if (preg_match('/DB_PREFIX=([^\n\r]+)/', $envContent, $matches)) {
            $prefix = trim($matches[1]);
            // 确保表前缀不为空且格式正确
            if (!empty($prefix)) {
                return $prefix;
            }
        }
    }
    
    return 'on_';
}
